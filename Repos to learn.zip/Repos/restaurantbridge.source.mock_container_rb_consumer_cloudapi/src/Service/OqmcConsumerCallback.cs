﻿using Avro.Generic;
<<<<<<< HEAD
using Common;
using McD.McFlow.Client.Library.Consumer.Models;
using NewRelic.Api.Agent;
using OQMCMenu.Processor.V1.Models;
using System.Text.Json;

namespace MockRBConsumer.CloudAPI
=======
using McD.McFlow.Client.Library.Consumer.Models;
using System.Text.Json;

namespace MockService.CloudAPI
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
{
    /// <summary>
    /// Consumer callback for kafka messages consumed
    /// </summary>
    public class OqmcConsumerCallback : IOqmcConsumerCallback
    {
<<<<<<< HEAD
        private readonly ILog Log;

        public List<OQMCOverrides> kafkaConsumerMessageList { get; set; }

        public OqmcConsumerCallback(ILog log)
        {
            Log = log;
            kafkaConsumerMessageList = new List<OQMCOverrides>();
=======
        protected readonly ILogger<IOqmcConsumerCallback> Logger;
        private readonly JsonSerializerOptions _jsonSerializerOptions;

        public OqmcConsumerCallback(ILogger<IOqmcConsumerCallback> logger)
        {
            Logger = logger ?? throw new ArgumentNullException(nameof(logger));
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
        }

        public virtual bool onCompletion(ConsumerMessage<string, object> consumerMessage)
        {
<<<<<<< HEAD
            throw new NotImplementedException();
        }

        public virtual bool onCompletion(ConsumerMessage<string, GenericRecord> consumerMessage)
        {
            throw new NotImplementedException();
        }

        [Transaction]
        public virtual async Task<bool> onCompletionAsync(ConsumerMessage<string, object> consumerMessage)
        {
            string raw_JSON = null;
            try
            {
                raw_JSON = consumerMessage?.Message.Value.ToString();
                Log.Info($"Message received from Kafka -  {raw_JSON}");
                var kafkaConsumerMessage = JsonSerializer.Deserialize<OQMCOverrides>(raw_JSON);
                Log.Info($"Message object deserialized -  {kafkaConsumerMessage.ToString()}");
                AddToKafkaConsumerMessageList(kafkaConsumerMessage);
                return true;
            }
            catch (JsonException jsonEx)
            {
                Log.Error("Unable to deserialize the received message. JSON: {" + raw_JSON + "}", jsonEx);
=======
            try
            {
                Logger.LogDebug($"Message received from Kafka -  {consumerMessage?.Message.Value}");
                return true;
            }
            catch (InvalidOperationException)
            {
                Logger.LogError($"{nameof(onCompletion)} - The message received has a value of null.");
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
                return true;
            }
            catch (Exception ex)
            {
<<<<<<< HEAD
                Log.Error("Unhandled exception happened when processing the message from kafka.", ex);
=======
                Logger.LogError($"{nameof(onCompletion)} - Unable to read a kafka message: {ex.Message}", ex);
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
                return false;
            }
        }

<<<<<<< HEAD
        public virtual Task<bool> onCompletionAsync(ConsumerMessage<string, GenericRecord> consumerMessage)
        {
            throw new NotImplementedException();
        }

        private void AddToKafkaConsumerMessageList(OQMCOverrides? kafkaMessage)
        {
            if (kafkaMessage == null)
                return;

            kafkaConsumerMessageList.Add(kafkaMessage);

            // If the collection exceeds the maximum limit, remove the oldest string
            if (kafkaConsumerMessageList.Count > 5)
                kafkaConsumerMessageList.RemoveAt(0);
=======

        public virtual bool onCompletion(ConsumerMessage<string, GenericRecord> consumerMessage)
        {
            return true;
        }

        public Task<bool> onCompletionAsync(ConsumerMessage<string, object> consumerMessage)
        {

            return Task.FromResult(onCompletion(consumerMessage));
        }
        public Task<bool> onCompletionAsync(ConsumerMessage<string, GenericRecord> consumerMessage)
        {
            // logic after consuming.
            return Task.FromResult(true);
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
        }
    }
}
