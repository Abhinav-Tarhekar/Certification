﻿namespace MockRBConsumer.CloudAPI
{
    /// <summary>
    /// Settings inside the app settings for connect with AWS app config 
    /// </summary>
    public class KafkaSettings : IKafkaSettings
    {
        /// <inheritdoc/>
        public int KafkaTopicWorkerCount { get; set; }
        /// <inheritdoc/>
        public bool PrintAllOutput { get; set; }
        /// <inheritdoc/>
        public string KafkaTopic { get; set; }
        /// <inheritdoc/>
        public string SerialNumber { get; set; }
        /// <inheritdoc/>
        public string TokenCode { get; set; }
        /// <inheritdoc/>
        public List<string> BootstrapServers { get; set; }
        /// <inheritdoc/>
        public string SchemaRegistryUrl { get; set; }
        /// <inheritdoc/>
        public string KafkaConsumerGroupID { get; set; }
        /// <inheritdoc/>
        public string KeySchemaType { get; set; }
        /// <inheritdoc/>
        public string ValueSchemaType { get; set; }
        /// <inheritdoc/>
        public string AutoOffsetReset { get; set; }
        /// <inheritdoc/>
        public bool EnableAutoCommit { get; set; }
        /// <inheritdoc/>
        public int RetryTotalAttempts { get; set; }
        /// <inheritdoc/>
        public int RetryBackoffPeriod { get; set; }
        /// <inheritdoc/>
        public string RetryBackoffTimeunit { get; set; }
        /// <inheritdoc/>
        public double RetryExponentialRate { get; set; }
        /// <inheritdoc/>
        public string IgnoreRetryTopicList { get; set; }
        /// <inheritdoc/>
        public int MessageCommitPeriod { get; set; }
        /// <inheritdoc/>
        public string RetryAppender { get; set; }
        /// <inheritdoc/>
        public string DLQAppender { get; set; }
        /// <inheritdoc/>
        public int MaxBatchSize { get; set; }
        /// <inheritdoc/>
        public int MaxPollIntervalMs { get; set; }

        public string SecurityProtocol { get; set; }
    }
}
