﻿using System;

namespace MockRBConsumer.CloudAPI
{
    public class RestaurantNotFoundException : Exception { public RestaurantNotFoundException(string message) : base(message) { }  }
    public class CircuitBreakerOpenException : Exception { public CircuitBreakerOpenException(string message) : base(message) { } }
    public class RequestTimeoutException : Exception { public RequestTimeoutException(string message) : base(message) { } }
}
