﻿using RestaurantBridge.Gateway.Cloud.API.Model;
using Common;

namespace MockRBConsumer.CloudAPI
{
    public class EventsManager
    {
        private readonly ILog Log;

        public EventsManager(ILog log, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced clientAdvancedV1, RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced clientAdvancedV2)
        {
            Log = log;

            // V1
            clientAdvancedV1.EventMonitor.onMenuCategoriesInvalidation += EventMonitor_onMenuCategoriesInvalidationV1;
            clientAdvancedV1.EventMonitor.onCacheReload += EventMonitor_onCacheReloadV1;
            clientAdvancedV1.EventMonitor.onConfigurationInvalidation += EventMonitor_onConfigurationInvalidationV1;
            clientAdvancedV1.EventMonitor.onProductsInvalidation += EventMonitor_onProductsInvalidationV1;
            clientAdvancedV1.EventMonitor.onProductsOutagesInvalidation += EventMonitor_onProductsOutagesInvalidationV1;
            clientAdvancedV1.EventMonitor.onCacheClear += EventMonitor_onCacheClearV1;
            clientAdvancedV1.EventMonitor.onPromotionsInvalidation += EventMonitor_onPromotionsInvalidationV1;
            clientAdvancedV1.EventMonitor.onSettingsInvalidation += EventMonitor_onSettingsInvalidationV1;
            clientAdvancedV1.EventMonitor.onStateInvalidation += EventMonitor_onStateInvalidationV1;
            clientAdvancedV1.EventMonitor.onDetailsInvalidation += EventMonitor_onDetailsInvalidationV1;

            // V2
            clientAdvancedV2.EventMonitor.onProductOutagesInvalidation += EventMonitor_onProductOutagesInvalidationV2;
            clientAdvancedV2.EventMonitor.onConfigurationInvalidation += EventMonitor_onConfigurationInvalidationV2;
            clientAdvancedV2.EventMonitor.onTaxParametersInvalidation += EventMonitor_onTaxParametersInvalidationV2;
            clientAdvancedV2.EventMonitor.onCoatesMenusInvalidation += EventMonitor_onCoatesMenusInvalidationV2;
            clientAdvancedV2.EventMonitor.onChannelMenusInvalidation += EventMonitor_onChannelMenusInvalidationV2;
            clientAdvancedV2.EventMonitor.onStateInvalidation += EventMonitor_onStateInvalidationV2;
            clientAdvancedV2.EventMonitor.onSettingsInvalidation += EventMonitor_onSettingsInvalidationV2;
            clientAdvancedV2.EventMonitor.onDetailsInvalidation += EventMonitor_onDetailsInvalidationV2;
            clientAdvancedV2.EventMonitor.onCacheClear += EventMonitor_onCacheClearV2;
            clientAdvancedV2.EventMonitor.onCacheReload += EventMonitor_onCacheReloadV2;
            //clientAdvancedV2.EventMonitor.onOqmc += EventMonitor_onOqmcV2;
        }

        #region v2
        private void EventMonitor_onOqmcV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.OQMCMenuProcessor is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onCacheClearV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.caches.clear.restaurant is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onCacheReloadV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.caches.reload.restaurant is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onDetailsInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.details is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onStateInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.state is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onSettingsInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.settings is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onChannelMenusInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.channelmenus is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onCoatesMenusInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.CoatesMenus is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onTaxParametersInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.taxparameters is received, restaurantId is: {e.restaurantID}");
        }
        private void EventMonitor_onProductOutagesInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.productoutages is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onConfigurationInvalidationV2(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v2.invalidate.restaurant.configuration is received, restaurantId is: {e.restaurantID}");
        }
        #endregion

        #region v1
        private void EventMonitor_onCacheClearV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.caches.clear.restaurant is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onCacheReloadV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.caches.reload.restaurant is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onDetailsInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.details is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onStateInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.state is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onSettingsInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.settings is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onPromotionsInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.promotions is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onProductsOutagesInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.products.outages is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onProductsInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.products is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onConfigurationInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.configuration is received, restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onProductOutagesInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.products.outages is received with restaurantId is: {e.restaurantID}");
        }

        private void EventMonitor_onMenuCategoriesInvalidationV1(object? sender, InvalidationEventArgs e)
        {
            Log.Info($"MockRBConsumer: v1.invalidate.restaurant.menucategories is received with restaurantId is: {e.restaurantID}");
        }
        #endregion
    }
}