﻿using Common;
using McD.McFlow.Client.Library.Consumer.Manager;

namespace MockRBConsumer.CloudAPI
{
    /// <summary>
    /// KafkaConsumerWorker class to start and stop the kafka workers
    /// </summary>
    public class KafkaConsumerWorker : BackgroundService
    {
        private readonly IKafkaConsumerBuilder _consumerBuilder;
        private readonly IOqmcConsumerCallback _oqmconsumerCallback;
        private readonly IConfiguration configuration;
        private readonly ILog Log;
        private readonly CancellationTokenSource _stopCancellationTokenSource;
        private Task _backgroundTask;
        private IMcFlowConsumer<string, object> _builder;

       
        public KafkaConsumerWorker(
            IKafkaConsumerBuilder consumerBuilder, 
            IOqmcConsumerCallback consumerCallback,
            IConfiguration configuration,
            ILog log)
        {
            _consumerBuilder = consumerBuilder ?? throw new ArgumentNullException(nameof(consumerBuilder));
            _oqmconsumerCallback = consumerCallback ?? throw new ArgumentNullException(nameof(consumerCallback));
            this.configuration = configuration;
            Log = log;
            _stopCancellationTokenSource = new CancellationTokenSource();
        }

        /// <summary>
        /// StartAsync the worker
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            Log.Info("KafkaConsumerWorker task started.");
            return base.StartAsync(cancellationToken);
        }

        /// <summary>
        /// StopAsync the worker
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            if (this._stopCancellationTokenSource.Token.CanBeCanceled)
            {
                this._stopCancellationTokenSource.Cancel();
            }

            if (_backgroundTask != null)
            {
                await _backgroundTask.ConfigureAwait(false);
                _backgroundTask.Dispose();
            }

            await base.StopAsync(cancellationToken);

            if (_builder != null)
            {
                _builder.Close();
            }

            Log.Info("KafkaConsumerWorker task stopped.");
        }

        /// <summary>
        /// ExecuterAsync the consumer of oqmcSubscriber inside the created workers
        /// </summary>
        /// <param name="stoppingToken"></param>
        /// <returns>If the task is completed</returns>
        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            _backgroundTask = Task.Run(async () =>
            {
                try
                {
                    BuilderDispose();

                    var kafka = new KafkaSettings()
                    {
                        KafkaTopicWorkerCount = KafkaConstants.WorkerCount,
                        KafkaTopic = configuration.topic,
                        KafkaConsumerGroupID = KafkaConstants.KafkaConsumerGroupID,
                        PrintAllOutput = KafkaConstants.PrintAllOutput,
                        MessageCommitPeriod = KafkaConstants.MessageCommitPeriod,
                        RetryAppender = KafkaConstants.RetryAppender,
                        DLQAppender = KafkaConstants.DLQAppender,
                        ValueSchemaType = KafkaConstants.ValueSchemaType,
                        SchemaRegistryUrl = configuration.schema_registry_url,
                        KeySchemaType = KafkaConstants.KeySchemaType,
                        AutoOffsetReset = KafkaConstants.AutoOffsetReset,
                        EnableAutoCommit = KafkaConstants.EnableAutoCommit,
                        RetryTotalAttempts = KafkaConstants.RetryTotalAttempts,
                        RetryBackoffPeriod = KafkaConstants.RetryBackoffPeriod,
                        RetryBackoffTimeunit = KafkaConstants.RetryBackoffTimeunit,
                        RetryExponentialRate = KafkaConstants.RetryExponentialRate,
                        IgnoreRetryTopicList = KafkaConstants.IgnoreRetryTopicList,
                        //SecurityProtocol = KafkaConstants.SecurityProtocol
                        BootstrapServers = new List<string>() { configuration.bootstrap_server }
                    };
                   
                    _builder = _consumerBuilder.Create(kafka, kafka.KafkaTopic, _oqmconsumerCallback); // using block

                    if (_builder != null)
                        await _builder.BeginConsumeAsync(this._stopCancellationTokenSource.Token);
                }
                catch (Exception ex)
                {
                    Log.Error("Unhandled exception happened.",ex);
                }
            }, stoppingToken);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed

            return Task.CompletedTask;
        }

        /// <summary>
        /// Release of unmanaged resources
        /// </summary>
        public override void Dispose()
        {
            BuilderDispose();

            base.Dispose();
            GC.SuppressFinalize(this);
        }

        private void BuilderDispose()
        {
            if (_builder != null)
            {
                _builder.Dispose();
                _builder = null;
            }
        }
    }
}
