﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Common;

using RestaurantBridge.Gateway.Cloud.V2.Models;

namespace MockRBConsumer.CloudAPI
{
    public class Service : IService
    {
        private readonly ILog Log;
        private readonly CustomRBClient _customRBClient;

        public Service(ILog logger, IConfiguration configuration, CustomRBClient customRBClient)
        {
            Log = logger;
            _customRBClient = customRBClient;
        }

        #region CACHE INVALIDATION HANDLING

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetRestaurantCatalogKeyFor(long restaurantID) => $"{restaurantID}";

        private volatile bool _canUseCache;
        private readonly SemaphoreSlim _canUseCacheStateLock = new SemaphoreSlim(1, 1);
        private readonly ConcurrentDictionary<long, (byte[], string)> _restaurantDetailsResponseCache = new ConcurrentDictionary<long, (byte[], string)>();
        private readonly ConcurrentDictionary<long, (byte[], string)> _restaurantStatusResponseCache = new ConcurrentDictionary<long, (byte[], string)>();
        private readonly ConcurrentDictionary<long, (byte[], string)> _restaurantMenusResponseCache = new ConcurrentDictionary<long, (byte[], string)>();

        private async Task DisableCacheAsync()
        {
            Log.Info($"{nameof(Service)}.{nameof(DisableCacheAsync)} : Disabling and clearing ENTIRE cache ..");
            await _canUseCacheStateLock.WaitAsync();
            try
            {
                _canUseCache = false;
                _restaurantDetailsResponseCache.Clear();
                _restaurantStatusResponseCache.Clear();
                _restaurantMenusResponseCache.Clear();
            }
            finally
            {
                _canUseCacheStateLock.Release();
            }
        }
        private async Task EnableCacheAsync()
        {
            Log.Info($"{nameof(Service)}.{nameof(EnableCacheAsync)} : Clearing ENTIRE cache and enabling ..");
            await _canUseCacheStateLock.WaitAsync();
            try
            {
                // cache should already have be clear .. but clear again just in case
                _restaurantDetailsResponseCache.Clear();
                _restaurantStatusResponseCache.Clear();
                _restaurantMenusResponseCache.Clear();
                _canUseCache = true;
            }
            finally
            {
                _canUseCacheStateLock.Release();
            }
        }
        private async Task ClearCacheAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(Service)}.{nameof(ClearCacheAsync)}({eventName},{restaurantID}) : Clearing cache entry ..");
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                _restaurantDetailsResponseCache.TryRemove(restaurantID, out _);
                _restaurantStatusResponseCache.TryRemove(restaurantID, out _);
                _restaurantMenusResponseCache.TryRemove(restaurantID, out _);
            }
        }
        private async Task ReloadCacheAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(Service)}.{nameof(ReloadCacheAsync)}({eventName},{restaurantID}) : Reloading cache entry ..");
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                try
                {
                    _restaurantDetailsResponseCache.TryRemove(restaurantID, out _);
                    _restaurantStatusResponseCache.TryRemove(restaurantID, out _);
                    _restaurantMenusResponseCache.TryRemove(restaurantID, out _);
                    var detailsTask = _customRBClient.GetDetailsGzippedAsync(restaurantID);
                    var statusTask = _customRBClient.GetStatusGzippedAsync(restaurantID);
                    var menusTask = _customRBClient.GetMenusGzippedAsync(restaurantID);
                    await Task.WhenAll(detailsTask, menusTask);
                    var details = await detailsTask;
                    var menus = await menusTask;
                    if (details.gzip != null) { _restaurantDetailsResponseCache.AddOrUpdate(restaurantID, details, (_, _) => details); }
                    if (menus.gzip != null) { _restaurantMenusResponseCache.AddOrUpdate(restaurantID, menus, (_, _) => menus); }
                }
                catch(Exception ex)
                {
                    Log.Warn($"{nameof(Service)}.{nameof(ReloadCacheAsync)}({eventName},{restaurantID}) : Failed to reload cache entry !!", ex);
                }
            }
        }
        private async Task ReloadDetailsCacheAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(Service)}.{nameof(ReloadDetailsCacheAsync)}({eventName},{restaurantID}) : Reloading cache entry ..");
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                try
                {
                    _restaurantDetailsResponseCache.TryRemove(restaurantID, out _);
                    var menus = await _customRBClient.GetDetailsGzippedAsync(restaurantID);
                    if (menus.gzip != null) { _restaurantDetailsResponseCache.AddOrUpdate(restaurantID, menus, (_, _) => menus); }
                }
                catch (Exception ex)
                {
                    Log.Warn($"{nameof(Service)}.{nameof(ReloadDetailsCacheAsync)}({eventName},{restaurantID}) : Failed to reload cache entry !!", ex);
                }
            }
        }
        private async Task ReloadMenusCacheAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(Service)}.{nameof(ReloadMenusCacheAsync)}({eventName},{restaurantID}) : Reloading cache entry ..");
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                try
                {
                    _restaurantMenusResponseCache.TryRemove(restaurantID, out _);
                    var menus = await _customRBClient.GetMenusGzippedAsync(restaurantID);
                    if (menus.gzip != null) { _restaurantMenusResponseCache.AddOrUpdate(restaurantID, menus, (_, _) => menus); }
                }
                catch (Exception ex)
                {
                    Log.Warn($"{nameof(Service)}.{nameof(ReloadMenusCacheAsync)}({eventName},{restaurantID}) : Failed to reload cache entry !!", ex);
                }
            }
        }
        private async Task ReloadStatusCacheAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(Service)}.{nameof(ReloadStatusCacheAsync)}({eventName},{restaurantID}) : Reloading cache entry ..");
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                try
                {
                    _restaurantStatusResponseCache.TryRemove(restaurantID, out _);
                    var status = await _customRBClient.GetStatusGzippedAsync(restaurantID);
                    if (status.gzip != null) { _restaurantStatusResponseCache.AddOrUpdate(restaurantID, status, (_, _) => status); }
                }
                catch (Exception ex)
                {
                    Log.Warn($"{nameof(Service)}.{nameof(ReloadStatusCacheAsync)}({eventName},{restaurantID}) : Failed to reload cache entry !!", ex);
                }
            } 
        }

        /* This help method is for unit testing purpose only */
        public async Task HelpTaskAsync(long restaurantID)
        {
            await DisableCacheAsync();
            await EnableCacheAsync();

            await ClearCacheAsync("onCacheClear", restaurantID);
            await ReloadCacheAsync("onCacheReload", restaurantID);

            await ReloadDetailsCacheAsync("onDetailsInvalidation", restaurantID);
            await ReloadMenusCacheAsync("onConfigurationInvalidation", restaurantID);
            await ReloadStatusCacheAsync("onStateInvalidation", restaurantID);

            await Task.CompletedTask;
        }

        public async Task InitializeAsync()
        {
            Log.Info($"{nameof(Service)}.{nameof(InitializeAsync)} ..");

            _customRBClient.EventMonitorV2.onDisconnect += async (_, e) => await DisableCacheAsync();
            _customRBClient.EventMonitorV2.onConnection += async (_, e) => await EnableCacheAsync();

            _customRBClient.EventMonitorV2.onCacheClear += async (_, e) => await ClearCacheAsync("onCacheClear", e.restaurantID);
            _customRBClient.EventMonitorV2.onCacheReload += async (_, e) => await ReloadCacheAsync("onCacheReload", e.restaurantID);

            _customRBClient.EventMonitorV2.onDetailsInvalidation += async (_, e) => await ReloadDetailsCacheAsync("onDetailsInvalidation", e.restaurantID);
            _customRBClient.EventMonitorV2.onConfigurationInvalidation += async (_, e) => await ReloadMenusCacheAsync("onConfigurationInvalidation", e.restaurantID);
            _customRBClient.EventMonitorV2.onStateInvalidation += async (_, e) => await ReloadStatusCacheAsync("onStateInvalidation", e.restaurantID);
            _customRBClient.EventMonitorV2.onProductOutagesInvalidation += async (_, e) => await ReloadStatusCacheAsync("onProductOutagesInvalidation", e.restaurantID);
            _customRBClient.EventMonitorV2.onSettingsInvalidation += async (_, e) => await ReloadMenusCacheAsync("onSettingsInvalidation", e.restaurantID);
            _customRBClient.EventMonitorV2.onChannelMenusInvalidation += async (_, e) => await ReloadMenusCacheAsync("onChannelMenusInvalidation", e.restaurantID);

            _canUseCacheStateLock.Wait();
            try
            {
                _canUseCache = _customRBClient.EventMonitorV2.isConnected;
            }
            finally
            {
                _canUseCacheStateLock.Release();
            }
            await Task.CompletedTask;
        }

        #endregion

        public Task<List<SearchedDetails>> SearchRestaurantsAsync(
                    HashSet<string> marketIDs = null,
                    HashSet<string> facilities = null,
                    double? latiude = null,
                    double? longitude = null,
                    double? maxDistanceInMeters = null,
                    uint? maxNumberOfRestaurantsToReturn = null, CancellationToken cancellationToken=default)
        {
            return _customRBClient.SearchRestaurantsAsync(marketIDs, facilities, latiude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn, cancellationToken);
        }

        public async Task<(byte[] gZippedRespponseContent, string eTag)> GetDetailsThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            if (!_canUseCache)
            {
                Log.Warn($"{nameof(GetDetailsThroughCacheAsync)}({restaurantID}) : CACHE DISABLED - running in fallback mode !!");
                return await _customRBClient.GetDetailsGzippedAsync(restaurantID, cancellationToken);
            }

            if (_restaurantDetailsResponseCache.TryGetValue(restaurantID, out var cachedDataOutOfLock))
            {
                return cachedDataOutOfLock;
            }
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                if (_restaurantDetailsResponseCache.TryGetValue(restaurantID, out var cachedDataInsideLock))
                {
                    return cachedDataInsideLock;
                }
                Log.Info($"{nameof(GetDetailsThroughCacheAsync)}({restaurantID}) : CACHE EMPTY - loading data from RB ..");
                var dataToCache = await _customRBClient.GetDetailsGzippedAsync(restaurantID, cancellationToken);
                if (dataToCache.gzip != null)
                {
                    _restaurantDetailsResponseCache.AddOrUpdate(restaurantID, dataToCache, (_, _) => dataToCache);
                }
                return dataToCache;
            }
        }
        public async Task<(byte[] gZippedRespponseContent, string eTag)> GetStatusThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            if (!_canUseCache)
            {
                Log.Warn($"{nameof(GetStatusThroughCacheAsync)}({restaurantID}) : CACHE DISABLED - running in fallback mode !!");
                return await _customRBClient.GetStatusGzippedAsync(restaurantID, cancellationToken);
            }

            if (_restaurantStatusResponseCache.TryGetValue(restaurantID, out var cachedDataOutOfLock))
            {
                return cachedDataOutOfLock;
            }
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                if (_restaurantStatusResponseCache.TryGetValue(restaurantID, out var cachedDataInsideLock))
                {
                    return cachedDataInsideLock;
                }
                Log.Info($"{nameof(GetStatusThroughCacheAsync)}({restaurantID}) : CACHE EMPTY - loading data from RB ..");
                var dataToCache = await _customRBClient.GetStatusGzippedAsync(restaurantID, cancellationToken);
                if (dataToCache.gzip != null)
                {
                    _restaurantStatusResponseCache.AddOrUpdate(restaurantID, dataToCache, (_, _) => dataToCache);
                }
                return dataToCache;
            }
        }
        public async Task<(byte[] gZippedRespponseContent, string eTag)> GetMenusThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            if (!_canUseCache)
            {
                Log.Warn($"{nameof(GetMenusThroughCacheAsync)}({restaurantID}) : CACHE DISABLED - running in fallback mode !!");
                return await _customRBClient.GetMenusGzippedAsync(restaurantID, cancellationToken);
            }

            if (_restaurantMenusResponseCache.TryGetValue(restaurantID, out var cachedDataOutOfLock))
            {
                return cachedDataOutOfLock;
            }
            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                if (_restaurantMenusResponseCache.TryGetValue(restaurantID, out var cachedDataInsideLock))
                {
                    return cachedDataInsideLock;
                }
                Log.Info($"{nameof(GetMenusThroughCacheAsync)}({restaurantID}) : CACHE EMPTY - loading data from RB ..");
                var dataToCache = await _customRBClient.GetMenusGzippedAsync(restaurantID, cancellationToken);
                if (dataToCache.gzip != null)
                {
                    _restaurantMenusResponseCache.AddOrUpdate(restaurantID, dataToCache, (_, _) => dataToCache);
                }
                return dataToCache;
            }
        }

        public async Task<string> Decompress(byte[] dataToDecompress, CancellationToken cancellationToken = default)
        {
            using (var compressedStream = new MemoryStream(dataToDecompress))
            using (var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
            using (var resultStream = new MemoryStream())
            {
                await zipStream.CopyToAsync(resultStream);
                return Encoding.UTF8.GetString(resultStream.ToArray());
            }
        }

    }
}