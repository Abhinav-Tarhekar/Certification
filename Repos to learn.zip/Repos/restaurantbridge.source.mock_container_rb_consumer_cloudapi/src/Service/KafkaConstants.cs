﻿namespace MockRBConsumer.CloudAPI
{
    public static class KafkaConstants
    {
        public const int WorkerCount = 1;
        public const string KafkaTopic = "oqmc_menu";
        public const int KafkaTimeToLiveInSeconds = 15;
        public const string KafkaDynamoTable = "Unified_Eventing_Retry";
        public const string CompressionType = "GZIP";
        public const string KeySchemaType = "STRING";
        public const string ValueSchemaType = "JSON";
        public const string SchemaRegistryUrl = "";
        public const string BootstrapServers = "b-1.digital-mcflow-dev1-t.2aucea.c18.kafka.us-east-1.amazonaws.com:9094,b-2.digital-mcflow-dev1-t.2aucea.c18.kafka.us-east-1.amazonaws.com:9094,b-3.digital-mcflow-dev1-t.2aucea.c18.kafka.us-east-1.amazonaws.com:9094";

        public const int DelayMS = 10;
        public const int Retries = 1;
        public const int RetryBackOffMS = 1000;
        public const int MessageCount = 5;
        public const bool EnableIdempotence = true;
        public const bool AutoRegisterSchemas = false;
        public const int MaxBlockMS = 5000;
        public const int LingerMS = 10;
        public const int BatchSize = 32768;
        public const int MaxInFlightRequests = 1;
        public const int MinReplicasInSync = 2;
        public const string Domain = "Menu";
        public const string Region = "US";
        public const string Market = "US";
        public const string ClusterName = "digital-mcflow-dev1-test-na-msk-us-east-1-f4ca";
        public const string Publisher = "DCS_1.2";
        public const string HeaderVersion = "1.0";
        public const string SecurityProtocol = "SSL";

        public const string AutoOffsetReset = "latest";
        public const bool EnableAutoCommit = false;
        public const string RetryBackoffTimeunit = "SECONDS";
        public const double RetryExponentialRate = 1;
        public const int MessageCommitPeriod = 100;
        public const int RetryBackoffPeriod = 5;
        public const int RetryTotalAttempts = 5;
        public const int MaxPollIntervalMs = 100;
        public const int MaxBatchSize = 200;
        public const int TimeoutMS = 10000;

        public const string KafkaConsumerGroupID = "-defaults.Kafka.KafkaConsumerGroupID-";
        public const bool PrintAllOutput = true;
        public const string message_commit_Period = "-defaults.Kafka.message_commit_Period-";
        public const string RetryAppender = "-defaults.Kafka.RetryAppender-";
        public const string DLQAppender = "-defaults.Kafka.DLQAppender-";
        public const string IgnoreRetryTopicList = "";
    }
}
