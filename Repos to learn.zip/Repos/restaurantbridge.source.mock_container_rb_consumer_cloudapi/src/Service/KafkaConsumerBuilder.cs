﻿using Common;
using McD.McFlow.Client.Consumer.Manager;
using McD.McFlow.Client.Library.Consumer.Manager;
using McD.McFlow.Client.Library.Consumer.Models;

namespace MockRBConsumer.CloudAPI
{
    /// <summary>
    /// ConsumerBuilder for Kafka consumer messages
    /// </summary>
    public class KafkaConsumerBuilder : IKafkaConsumerBuilder
    {
        private readonly ILog Log;
        //private readonly IKafkaLoggerProvider _loggerProvider;

        /// <summary>
        /// Initializes a new instance of <see cref="KafkaConsumerBuilder"/>
        /// </summary>
        /// <param name="loggerProvider"></param>
        /// <param name="logger"></param>
        /// <exception cref="System.ArgumentNullException"></exception>
        public KafkaConsumerBuilder(ILog log)
        {
            Log = log;
        }

        /// <inheritdoc/>
        public IMcFlowConsumer<string, object> Create(IKafkaSettings settings, string topicName, IConsumerCallback consumerCallback)
        {
            try
            {
                var configKey = new ConsumerConfig
                {
                    BootstrapServers = settings?.BootstrapServers != null ? String.Join(",", settings.BootstrapServers) : null,
                    SchemaRegistryUrl = settings?.SchemaRegistryUrl,
                    KeySchemaType = settings?.KeySchemaType ?? "STRING",
                    ValueSchemaType = settings?.ValueSchemaType ?? "JSON",
                    GroupId = settings?.KafkaConsumerGroupID,
                    AutoOffsetReset = settings?.AutoOffsetReset ?? "latest",
                    EnableAutoCommit = settings?.EnableAutoCommit != null ? settings.EnableAutoCommit.ToString().ToLower() : "false",
                    RetryTotalAttempts = settings?.RetryTotalAttempts ?? 5,
                    RetryBackoffPeriod = settings?.RetryBackoffPeriod ?? 5,
                    RetryBackoffTimeunit = settings?.RetryBackoffTimeunit ?? "SECONDS",
                    RetryExponentialRate = settings?.RetryExponentialRate ?? 1,
                    IgnoreRetryTopicList = settings?.IgnoreRetryTopicList,
                    MessageCommitPeriod = settings?.MessageCommitPeriod ?? 100,
                    RetryAppender = settings?.RetryAppender,
                    DLQAppender = settings?.DLQAppender,
                    //  MaxBatchSize = settings?.MaxBatchSize ?? 200,
                    MaxPollIntervalMs = settings?.MaxPollIntervalMs ?? 100,
                };

                return new ConsumerBuilder<string, object>().Build(configKey, new List<string> { topicName }, consumerCallback);
            }
            catch (Exception ex)
            {
                Log.Error("Unhandled exception happened during the Create method", ex);
            }

            return null;
        }

    }
}