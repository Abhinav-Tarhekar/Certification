﻿using McD.McFlow.Client.Consumer.Manager;
using McD.McFlow.Client.Library.Consumer.Manager;

namespace MockRBConsumer.CloudAPI
{
    /// <summary>
    /// Interface definition for KafkaConsumerBuilder
    /// </summary>
    public interface IKafkaConsumerBuilder
    {
        /// <summary>
        /// Create new <see cref="ConsumerBuilder{TKey, TValue}"/> instance
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="topicName"></param>
        /// <param name="consumerCallback"></param>
        /// <returns>A new consumerBuilder already builded</returns>
        IMcFlowConsumer<string, object> Create(IKafkaSettings settings, string topicName, IConsumerCallback consumerCallback);
    }
}

