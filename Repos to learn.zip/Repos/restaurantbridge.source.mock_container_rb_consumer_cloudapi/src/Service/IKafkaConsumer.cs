using System;
using System.Threading;
using System.Threading.Tasks;

namespace MockService.CloudAPI
{
    public interface IKafkaConsumer : IDisposable
    {
        Task BeginConsumeAsync(CancellationToken cancellationToken);
    }
}
