﻿using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

using Common;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System.Threading;

namespace MockRBConsumer.CloudAPI
{
    public class CustomRBClient
    {
        // This value is the same as defined in ChannelMenu
        public const long MENU_ID_OFFSET_CATEGORIES = 4200000000;
        private readonly ILog Log;
        private readonly RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced _clientV2;
        private readonly RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced _clientV1;

        private readonly HashSet<string> _channels;
        private readonly string[] _channelsArray;

        private readonly JsonSerializerSettings _jsonSerializationSettings;
        public CustomRBClient(ILog logger, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced clientV1, RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced clientV2, HashSet<string> channels)
        {
            Log = logger;
            _clientV1 = clientV1;
            _clientV2 = clientV2;
            _channels = channels;
            _channelsArray = channels.ToArray();

            _jsonSerializationSettings = new JsonSerializerSettings();
            _jsonSerializationSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter(null, true));
            _jsonSerializationSettings.ContractResolver = new DefaultContractResolver();
            _jsonSerializationSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;      // HERE WE WANT UTC .. all order timestamps are always UTC
            _jsonSerializationSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
            _jsonSerializationSettings.DateParseHandling = DateParseHandling.DateTime;
            _jsonSerializationSettings.NullValueHandling = NullValueHandling.Include;        // IF THE FRONT END CAN HANDLE IT THIS COULD BE OPTIMIZED TO "Ignore" 
            _jsonSerializationSettings.DefaultValueHandling = DefaultValueHandling.Include;  // IF THE FRONT END CAN HANDLE IT THIS COULD BE OPTIMIZED TO "Ignore"
        }

        public async Task<List<RestaurantBridge.Gateway.Cloud.V2.Models.SearchedDetails>> SearchRestaurantsAsync(
            HashSet<string> marketIDs = null,
            HashSet<string> facilities = null,
            double? latiude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null,
            CancellationToken cancellationToken = default)
        {
            var searchResults = await _clientV2.SearchRestaurantsAsync(marketIDs, _channels, facilities, latiude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn, cancellationToken);
            var channelsToTrim = new HashSet<string>();
            foreach (var details in searchResults)
            {
                var settings = await _clientV2.GetRestaurantSettingsAsync(details.restaurantID, cancellationToken);
                if (settings == null)
                {
                    Log.Warn($"{nameof(CustomRBClient)}.{nameof(SearchRestaurantsAsync)} : API Response for {details.restaurantID} : settings is null = {settings == null}");
                }
                channelsToTrim.Clear();
                foreach (var channel in details.channelHours)
                {
                    if (!_channels.Contains(channel.Key))
                    {
                        channelsToTrim.Add(channel.Key);
                    }
                }
                // Add Delivery Channels to trim if flex delivery is null
                if (settings.flexDelivery.deliveryFee == null)
                {
                    channelsToTrim.Add("GMAL_DELIVERY");
                    Log.Warn($"{nameof(CustomRBClient)}.{nameof(SearchRestaurantsAsync)}  : for {details.restaurantID} - Removed channelHours for GMAL_DELIVERY Since Delivery fees not found. Please verify RFM Configuration");
                }
                foreach (var channelToTrim in channelsToTrim)
                {
                    details.channelHours.Remove(channelToTrim);
                }
            }
            return searchResults;
        }   

        public async Task<(byte[] gzip, string eTag)> GetDetailsGzippedAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var settingsTask =  _clientV2.GetRestaurantSettingsAsync(restaurantID, cancellationToken);
            var detailsTask =  _clientV2.GetRestaurantDetailsAsync(restaurantID, cancellationToken);
            await Task.WhenAll(settingsTask, detailsTask);
            var settings = await settingsTask;
            var details = await detailsTask;
            if (settings == null || details == null)
            {
                Log.Warn($"{nameof(CustomRBClient)}.{nameof(GetDetailsGzippedAsync)} : Could not build cache for {restaurantID} : settings = {settings == null}, details = {details == null}");
                return (null, null);
            }
            var channelsToTrim = new HashSet<string>();
            foreach(var channel in details.channelHours)
            {
                if (!_channels.Contains(channel.Key))
                {
                    channelsToTrim.Add(channel.Key);
                }
            }
            // Add Delivery Channels to trim if flex delivery is null
            if (settings.flexDelivery.deliveryFee == null)
            {
                channelsToTrim.Add("GMAL_DELIVERY");
                Log.Warn($"{nameof(CustomRBClient)}.{nameof(GetDetailsGzippedAsync)} : for {restaurantID} - Removed channelHours for GMAL_DELIVERY Since Delivery fees not found. Please verify RFM Configuration");
            }           
            foreach (var channelToTrim in channelsToTrim)
            {
                details.channelHours.Remove(channelToTrim);
            }
            var responseJson = JsonConvert.SerializeObject(details, _jsonSerializationSettings);
            var gzippedResponse = await Compress(responseJson);
            string eTag = $"\"{CalculateHash(responseJson)}\"";
            return (gzippedResponse, eTag);
        }

        public class Status
        {
            /// <summary>
            /// AN ID for the restaurant. Use this ID for all RB interactions
            /// Source: restaurantID from configuration (consul)
            /// </summary>
            public long restaurantID { get; set; }
            public RestaurantBridge.Gateway.Cloud.V2.Models.State state { get; set; }
            public RestaurantBridge.Gateway.Cloud.V2.Models.ProductOutages productOutages { get; set; }
        }
        public async Task<(byte[] gzip, string eTag)> GetStatusGzippedAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var stateTask = _clientV2.GetRestaurantStateAsync(restaurantID, cancellationToken);
            var productOutagesTask = _clientV2.GetRestaurantProductOutagesAsync(restaurantID, cancellationToken);
            await Task.WhenAll(stateTask, productOutagesTask);
            var state = await stateTask;
            var productOutages= await productOutagesTask;
            if (productOutages == null || state == null)
            {
                Log.Warn($"{nameof(CustomRBClient)}.{nameof(GetStatusGzippedAsync)} : Could not build cache for {restaurantID} : outages = {productOutages == null}, state = {state == null}");
                return (null, null);
            }
            var response = new Status
            {
                restaurantID = restaurantID,
                state = state,
                productOutages = productOutages
            };
            var responseJson = JsonConvert.SerializeObject(response, _jsonSerializationSettings);
            var gzippedResponse = await Compress(responseJson);
            string eTag = $"\"{CalculateHash(responseJson)}\"";
            return (gzippedResponse, eTag);
        }

        public class Configuration
        {
            /// <summary>
            /// AN ID for the restaurant. Use this ID for all RB interactions
            /// Source: restaurantID from configuration (consul)
            /// </summary>
            public long restaurantID { get; set; }
            public RestaurantBridge.Gateway.Cloud.V2.Models.Configuration.TimeZone timeZone { get; set; }
        }
        public class Settings
        {
            public class TableService
            {
                /// <summary>
                /// Enum for OperatingMode
                /// Describes Methods of OperatingMode For The Store
                /// </summary>
                public enum OperatingMode
                {
                    NONE = 0,                 // None,
                    TABLE_NUMBER = 1,         // TableNumber,
                    LOCATOR_NUMBER = 2,       // Locator,
                    ZONED_TABLE_NUMBERS = 3   // Zone
                }
                /// <summary>
                /// TableNumber for the Store
                /// Values : Minimum Number Value/ Maximum Number Value
                /// </summary>
                public class TableNumber
                {
                    public int minimumNumberValue { get; set; }
                    public int maximumNumberValue { get; set; }
                }
                /// <summary>
                /// LocatorNumber for the Store
                /// Values : Minimum Number Value/ Maximum Number Value
                /// </summary>
                public class LocatorNumber
                {
                    public int minimumNumberValue { get; set; }
                    public int maximumNumberValue { get; set; }
                }
                public class Zone : Dictionary<int, ZoneDefinition> { }
                public class ZoneDefinition
                {
                    public bool available { get; set; }
                    public string definition { get; set; }
                    public string color { get; set; }
                    public ISet<int> tableNumbers { get; set; }
                }
                /// <summary>
                /// Enum for OperatingMode
                /// </summary>
                public OperatingMode operatingMode { get; set; }

                public decimal minimumPurchaseAmount { get; set; }

                public TableNumber tableNumber { get; set; }
                public LocatorNumber locatorNumber { get; set; }
                public Zone zone { get; set; }
            }

            public class OffersAndPromotions
            {
                public int? maximumNumberOfRegularOffersPerOrder { get; set; }
            }
            public class SettingsFlexDeliveryMinimumOrder
            {
                public long menuID { get; set; }
                public int amount { get; set; }
            }

            /// <summary>
            /// AN ID for the restaurant. Use this ID for all RB interactions
            /// Source: restaurantID from configuration (consul)
            /// </summary>
            public long restaurantID { get; set; }
            public TableService tableService { get; set; }
            public OffersAndPromotions offerAndPromotions { get; set; }
            public List<SettingsFlexDeliveryMinimumOrder> deliveryMinimumOrderAmount { get; set; }
            public int? menuTransitionAlertTimeInMinutes { get; set; }
        }
        public class Menus
        {
            /// <summary>
            /// AN ID for the restaurant. Use this ID for all RB interactions
            /// Source: restaurantID from configuration (consul)
            /// </summary>
            public long restaurantID { get; set; }
            public Configuration configuration { get; set; }
            public Settings settings { get; set; }
            public RestaurantBridge.Gateway.Cloud.V2.Models.ChannelMenus channelMenus { get; set; }
        }
        public async Task<(byte[] gzip, string eTag)> GetMenusGzippedAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var configurationTask = _clientV2.GetRestaurantConfiguration_DESERIALIZE_AS_Async<Configuration>(null, restaurantID, cancellationToken);
            var settingsTask = _clientV2.GetRestaurantSettingsAsync(restaurantID, cancellationToken);
            var channelMenusTask = _clientV2.GetRestaurantChannelMenusAsync(restaurantID, null, _channelsArray, cancellationToken);
            await Task.WhenAll(configurationTask, settingsTask, channelMenusTask);
            var configuration = await configurationTask;
            var settings = await settingsTask;
            var channelMenus = await channelMenusTask;
            if (configuration.configuration == null || settings == null || channelMenus == null)
            {
                Log.Warn($"{nameof(CustomRBClient)}.{nameof(GetMenusGzippedAsync)} : Could not build cache for {restaurantID} : configuration = {configuration.configuration == null}, settings = {settings == null}, channelMenus = {channelMenus == null}");
                return (null, null);
            }

            var convertedSettings = new Settings();
            convertedSettings.restaurantID = settings.restaurantID;
            // TODO: this should be necessary as RB should always return non null, but there is a test case somewhere that is causing this
            //       In V2 settings this should be guranteed
            convertedSettings.tableService = new Settings.TableService { operatingMode = Settings.TableService.OperatingMode.NONE, minimumPurchaseAmount = -1 };
            // TODO: remove this when GMAL is fixed to parse the table service correctly
            convertedSettings.tableService.tableNumber = new Settings.TableService.TableNumber();

            var amountMultiplier = Math.Pow(10, channelMenus.currency.decimalDigits);
            int amountConverter(decimal amount) => (int)(amount * (int)amountMultiplier);

           
            convertedSettings.offerAndPromotions = new Settings.OffersAndPromotions();
            convertedSettings.offerAndPromotions.maximumNumberOfRegularOffersPerOrder = settings.restaurantSpecificOverrides.offerAndPromotions.maximumNumberOfRegularOffersPerOrder;
            convertedSettings.menuTransitionAlertTimeInMinutes = settings.flexDelivery.menuTransitionAlertTimeInMinutes;
            convertedSettings.deliveryMinimumOrderAmount = new List<Settings.SettingsFlexDeliveryMinimumOrder>();

            //Update menu prices for products with fixed components
            foreach (var channel in channelMenus.channels)
            {
                var channelMenu = channel.Value;

                void _walkTree(ChannelMenus.ProductMenu.MenuGroup menuTree) 
                {
                    foreach (var menu in menuTree.groups)
                    {
                        _walkTree(menu);
                    }
                    foreach (var item in menuTree.items)
                    {
                        foreach (var option in item.options)
                        {
                            if (channelMenu.conditionalMenuModificationsLookup.ContainsKey(option.ID))
                            {
                                var fixedComponents = channelMenu.conditionalMenuModificationsLookup[option.ID]
                                    .Where(modification => modification.additionalData?.Keys.Contains("FIXED_COMPONENT") ?? false)
                                    .Select(modification => int.Parse(modification.additionalData["FIXED_COMPONENT"]["amount"]));
                                option.price += fixedComponents.Sum();
                            }
                        }
                    }
                }

                if (channelMenu.menus != null)
                {
                    foreach (var menu in channelMenu.menus)
                    {
                        _walkTree(menu);
                    }
                }
            }
            // First building up the list if there is any menuID under GMAL_DELIVERY, and defult the amount to 0
            if (channelMenus.channels.ContainsKey("GMAL_DELIVERY"))
            {
                foreach (KeyValuePair<string, ChannelMenus.ProductMenu> kvp in channelMenus.channels)
                {
                    if (kvp.Key == "GMAL_DELIVERY")
                    {
                        ChannelMenus.ProductMenu.Menu[] menuList = kvp.Value?.menus;
                        if (menuList != null)
                        {
                            foreach (var menu in menuList)
                            {
                                Settings.SettingsFlexDeliveryMinimumOrder minimumOrder = new Settings.SettingsFlexDeliveryMinimumOrder();
                                minimumOrder.menuID = menu.ID;
                                minimumOrder.amount = 0;
                                convertedSettings.deliveryMinimumOrderAmount.Add(minimumOrder);
                            }
                        }
                    }
                }
            }

            // update the amount if minimumOrderAmount is set in flexDelivery for that menuID
            List<RestaurantBridge.Gateway.Cloud.V2.Models.RestaurantSettingsFlexDeliveryMinimumOrder> flexDeliveryMinimumOrders = settings.flexDelivery.minimumOrderAmount;
            if (flexDeliveryMinimumOrders != null)
            {
                foreach (var order in flexDeliveryMinimumOrders)
                {
                    Settings.SettingsFlexDeliveryMinimumOrder minimumOrder = new Settings.SettingsFlexDeliveryMinimumOrder();
                    minimumOrder.menuID = MENU_ID_OFFSET_CATEGORIES + int.Parse(order.categoryID);
                    minimumOrder.amount = amountConverter((decimal)order.value);

                    var item = convertedSettings.deliveryMinimumOrderAmount.Where(x => x.menuID == minimumOrder.menuID).FirstOrDefault();
                    if (item != null)
                    {
                        item.amount = minimumOrder.amount;
                    } else
                    {
                        convertedSettings.deliveryMinimumOrderAmount.Add(minimumOrder);
                    }
                }
            }

            if (settings.tableService != null)
            { 
                convertedSettings.tableService.operatingMode = (Settings.TableService.OperatingMode)settings.tableService.operatingMode;
                convertedSettings.tableService.minimumPurchaseAmount = amountConverter(settings.tableService.minimumPurchaseAmount);

                if (settings.tableService.tableNumber != null)
                {
                    convertedSettings.tableService.tableNumber = new Settings.TableService.TableNumber();
                    convertedSettings.tableService.tableNumber.minimumNumberValue = settings.tableService.tableNumber.minimumNumberValue;
                    convertedSettings.tableService.tableNumber.maximumNumberValue = settings.tableService.tableNumber.maximumNumberValue;
                }

                if (settings.tableService.locatorNumber != null)
                {
                    convertedSettings.tableService.locatorNumber = new Settings.TableService.LocatorNumber();
                    convertedSettings.tableService.locatorNumber.minimumNumberValue = settings.tableService.locatorNumber.minimumNumberValue;
                    convertedSettings.tableService.locatorNumber.maximumNumberValue = settings.tableService.locatorNumber.maximumNumberValue;
                }
                if (settings.tableService.zone != null)
                {
                    convertedSettings.tableService.zone = new Settings.TableService.Zone();
                    foreach (var zone in settings.tableService.zone)
                    {
                        var convertedZoneDefinition = new Settings.TableService.ZoneDefinition();
                        convertedZoneDefinition.available = zone.Value.available;
                        convertedZoneDefinition.definition = zone.Value.definition;
                        convertedZoneDefinition.color = zone.Value.color;
                        convertedZoneDefinition.tableNumbers = zone.Value.tableNumbers;
                        convertedSettings.tableService.zone.Add(zone.Key, convertedZoneDefinition);
                    }
                }

            }
            
            

            // Add Delivery Channels to trim if flex delivery is null
            if (settings.flexDelivery.deliveryFee == null)
            {
                channelMenus.channels.Remove("GMAL_DELIVERY");
                Log.Warn($"{nameof(CustomRBClient)}.{nameof(GetMenusGzippedAsync)} : for {restaurantID} - Removed GMAL_DELIVERY from ChannelMenus Since Delivery fees not found. Please verify RFM Configuration");
            }

            var response = new Menus
            {
                restaurantID = restaurantID,
                configuration = configuration.configuration,
                settings = convertedSettings,
                channelMenus = channelMenus
            };
            var responseJson = JsonConvert.SerializeObject(response, _jsonSerializationSettings);
            var gzippedResponse = await Compress(responseJson);
            string eTag = $"\"{CalculateHash(responseJson)}\"";
            return (gzippedResponse, eTag);
        }


        public RestaurantBridge.Gateway.Cloud.V2.IEventMonitor EventMonitorV2 => (_clientV2 as RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced).EventMonitor;

        private async Task<byte[]> Compress(string stringToCompress)
        {
            byte[] dataToCompress = Encoding.UTF8.GetBytes(stringToCompress);
            using (MemoryStream memStream = new MemoryStream())
            {
                using (GZipStream zipStream = new GZipStream(memStream, CompressionMode.Compress))
                {
                    await zipStream.WriteAsync(dataToCompress, 0, dataToCompress.Length);
                    await zipStream.FlushAsync();
                }
                return memStream.ToArray();
            }
        }
        private string CalculateHash(string json)
        {
            StringBuilder builder = new StringBuilder();
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(json));
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
