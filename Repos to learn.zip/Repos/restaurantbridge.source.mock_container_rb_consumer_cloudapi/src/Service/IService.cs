﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using RestaurantBridge.Gateway.Cloud.V2.Models;

namespace MockRBConsumer.CloudAPI
{
    public interface IService
    {
        Task InitializeAsync();
        Task HelpTaskAsync(long restaurantID);

        Task<List<SearchedDetails>> SearchRestaurantsAsync(
            HashSet<string> marketIDs = null,
            HashSet<string> facilities = null,
            double? latiude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null,CancellationToken cancellationToken=default);

        Task<(byte[] gZippedRespponseContent, string eTag)> GetDetailsThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default);
        Task<(byte[] gZippedRespponseContent, string eTag)> GetStatusThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default);
        Task<(byte[] gZippedRespponseContent, string eTag)> GetMenusThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default);

        Task<string> Decompress(byte[] dataToDecompress, CancellationToken cancellationToken = default);
    }
}
