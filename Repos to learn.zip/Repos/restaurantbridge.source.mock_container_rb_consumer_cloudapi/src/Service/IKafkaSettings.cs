﻿namespace MockRBConsumer.CloudAPI
{
    public interface IKafkaSettings
    {
        /// <summary>
        /// Counter for worker to be created
        /// </summary>
        int KafkaTopicWorkerCount { get; }
        /// <summary>
        /// Boolean to choose print the outputs from the consumed messages
        /// </summary>
        bool PrintAllOutput { get; }
        /// <summary>
        /// Kafka topic name
        /// </summary>
        string KafkaTopic { get; }

        /// <summary>
        /// The e-mail from the user to access with the MFA code
        /// </summary>
        string SerialNumber { get; }
        /// <summary>
        /// The MFA code for access the AppConfig
        /// </summary>
        string TokenCode { get; }
        /// <summary>
        /// List of Bootstrap Servers
        /// </summary>
        List<string> BootstrapServers { get; }
        /// <summary>
        /// Schema- registru Url
        /// </summary>
        string SchemaRegistryUrl { get; }
        /// <summary>
        /// Kafka consumer group id
        /// </summary>
        string KafkaConsumerGroupID { get; }
        /// <summary>
        /// The schema type
        /// </summary>
        string KeySchemaType { get; }
        /// <summary>
        /// The value of schema type JSON or AVRO
        /// </summary>
        string ValueSchemaType { get; }
        /// <summary>
        /// Auto offset reset
        /// </summary>
        string AutoOffsetReset { get; }
        /// <summary>
        /// Enable disable automatic commit
        /// </summary>
        bool EnableAutoCommit { get; }
        /// <summary>
        /// Total retry attempts
        /// </summary>
        int RetryTotalAttempts { get; }
        /// <summary>
        /// Retry backoff period
        /// </summary>
        int RetryBackoffPeriod { get; }
        /// <summary>
        /// Retry backoff time unit
        /// </summary>
        string RetryBackoffTimeunit { get; }
        /// <summary>
        /// Retry exponential rate
        /// </summary>
        double RetryExponentialRate { get; }
        /// <summary>
        /// List of topics to ignore for retry
        /// </summary>
        string IgnoreRetryTopicList { get; }
        /// <summary>
        /// Message commit period
        /// </summary>
        int MessageCommitPeriod { get; }
        /// <summary>
        /// Retry appender
        /// </summary>
        string RetryAppender { get; }
        /// <summary>
        /// DLQ appender
        /// </summary>
        string DLQAppender { get; }
        /// <summary>
        /// Gets the maximum polling interval in milliseconds
        /// </summary>
        int MaxPollIntervalMs { get; }
        /// <summary>
        /// Gets max batch size
        /// </summary>
        int MaxBatchSize { get; }
        /// <summary>
        /// Security Protocol usually ssl
        /// </summary>
        string SecurityProtocol { get; }
    }
}
