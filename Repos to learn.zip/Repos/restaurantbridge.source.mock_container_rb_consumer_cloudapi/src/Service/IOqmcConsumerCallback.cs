﻿using McD.McFlow.Client.Consumer.Manager;
<<<<<<< HEAD
using OQMCMenu.Processor.V1.Models;

namespace MockRBConsumer.CloudAPI
=======

namespace MockService.CloudAPI
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
{
    /// <summary>
    /// Interface definition for OqmcConsumerCallback
    /// </summary>
<<<<<<< HEAD
    public interface IOqmcConsumerCallback : IConsumerCallback
    {
        List<OQMCOverrides> kafkaConsumerMessageList { get; }
    }
=======
    public interface IOqmcConsumerCallback : IConsumerCallback { }
>>>>>>> 7e8acb591c2a0a15995e7146567bd08448cb464b
}
