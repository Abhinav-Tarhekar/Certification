using McD.McFlow.Client.Common;
using McD.McFlow.Client.Library.Consumer.Manager;

namespace MockService.CloudAPI

{
    public sealed class KafkaConsumer : IKafkaConsumer
    {
        private IMcFlowConsumer<string, object> _builder;
        private readonly IKafkaConsumerBuilder _consumerBuilder;
        private readonly IOqmcConsumerCallback _oqmcConsumerCallback;
        private readonly ILogger<KafkaConsumer> _logger;
        private readonly IConfiguration Configuration;

        public KafkaConsumer(
             IKafkaConsumerBuilder consumerBuilder,
            IOqmcConsumerCallback consumerCallback,
            ILogger<KafkaConsumer> logger,
            IConfiguration configuration)
        {
            _consumerBuilder = consumerBuilder ?? throw new ArgumentNullException(nameof(consumerBuilder));
            _oqmcConsumerCallback = consumerCallback ?? throw new ArgumentNullException(nameof(consumerCallback));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            Configuration = configuration;
            IntializeConsumer();
        }

        public void IntializeConsumer()
        {
            try
            {
                BuilderDispose();

                var kafka = new KafkaSettings()
                {
                    KafkaTopicWorkerCount = 1,
                    KafkaTopic = Configuration.topic,
                    KafkaConsumerGroupID = KafkaConstants.KafkaConsumerGroupID,
                    PrintAllOutput = KafkaConstants.PrintAllOutput,
                    //message_commit_Period = KafkaConstants.message_commit_Period,
                    MessageCommitPeriod = KafkaConstants.MessageCommitPeriod,
                    RetryAppender = KafkaConstants.RetryAppender,
                    DLQAppender = KafkaConstants.DLQAppender,
                    //MaxBatchSize = KafkaConstants.MaxBatchSize,
                    //MaxPollIntervalMs = KafkaConstants.MaxPollIntervalMs,
                    ValueSchemaType = KafkaConstants.ValueSchemaType,
                    //SchemaRegistryUrl = "http://mcflow-schema-registry-core-us-int01.dev.us-east-1.dev.digitalecp.mcd.com",
                    SchemaRegistryUrl = Configuration.schema_registry_url,
                    KeySchemaType = KafkaConstants.KeySchemaType,
                    AutoOffsetReset = KafkaConstants.AutoOffsetReset,
                    EnableAutoCommit = KafkaConstants.EnableAutoCommit,
                    RetryTotalAttempts = KafkaConstants.RetryTotalAttempts,
                    RetryBackoffPeriod = KafkaConstants.RetryBackoffPeriod,
                    RetryBackoffTimeunit = KafkaConstants.RetryBackoffTimeunit,
                    RetryExponentialRate = KafkaConstants.RetryExponentialRate,
                    IgnoreRetryTopicList = KafkaConstants.IgnoreRetryTopicList,
                    //SecurityProtocol = KafkaConstants.SecurityProtocol
                    BootstrapServers = new List<string>() { Configuration.bootstrap_server }
                };
                _builder = _consumerBuilder.Create(kafka, kafka.KafkaTopic, _oqmcConsumerCallback); // using block

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception happened.");
            }
        }

        public async Task BeginConsumeAsync(CancellationToken cancellationToken)
        {

            try
            {
                await _builder.BeginConsumeAsync(cancellationToken);
                _logger.LogDebug($"{nameof(KafkaConsumer)} - started consumer at: {DateTime.UtcNow}");
            }
            catch (OperationCanceledException)
            {
                _logger.LogError($"{nameof(KafkaConsumer)} - Operation was cancelled.");
                BuilderDispose();
            }
        }

        private void BuilderDispose()
        {
            if (_builder != null)
            {
                _builder.Close();
                _builder.Dispose();
                _builder = null;
            }
        }

        public void Dispose()
        {
            BuilderDispose();
        }
    }
}
