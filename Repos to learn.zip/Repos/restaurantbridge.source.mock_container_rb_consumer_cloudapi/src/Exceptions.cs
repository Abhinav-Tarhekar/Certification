﻿using System;

namespace MockRBConsumer.Service.Exceptions
{
    public class CircuitBreakerOpenException : Exception { public CircuitBreakerOpenException(string message) : base(message) { } }
    public class RequestTimeoutException : Exception { public RequestTimeoutException(string message) : base(message) { } }
}
