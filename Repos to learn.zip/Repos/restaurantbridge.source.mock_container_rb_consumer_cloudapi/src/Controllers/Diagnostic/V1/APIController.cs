﻿using Microsoft.AspNetCore.Mvc;
using Common;
using RestaurantBridge.Gateway.Cloud.V1.Models;

namespace MockRBConsumer.CloudAPI.Diagnostic.V1
{
    [ApiController]
    [Route("diagnostic/api/v1/restaurants")]
    public class APIController : ControllerBase
    {
        private readonly ILog Log;
        private readonly IService _service;
        private readonly string _cache_control_headers;

        private ObjectResult LoggedFailureCode(int statusCode, Exception exception)
        {
            Log.Error($"Request Failed : {statusCode} : {exception.Message}", exception);
            return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}");
        }
        private readonly RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced _clientV1;

        public APIController(ILog log, IConfiguration configuration, IService service, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced clientV1)
        {
            Log = log;
            _service = service;
            _cache_control_headers = configuration.cache_control_headers;
            _clientV1 = clientV1;
        }

        [HttpGet()]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<List<long>>> SearchRestaurantsAsync()
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantIDsAsync();
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }
        [HttpGet("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantConfiguration>> GetRestaurantConfigurationAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantConfigurationAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantSettings>> GetRestaurantSettingsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantSettingsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        // GET api/v1/restaurants/{restaurantID}/status
        [HttpGet("{restaurantID}/state")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]

        public async Task<ActionResult<CustomRBClient.Status>> GetStatusAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (gZippedRespponseContent, eTag) = await _service.GetStatusThroughCacheAsync(restaurantID);
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag;
                    Response.Headers["Cache-Control"] = _cache_control_headers;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await _service.Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No details available for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/menus
        [HttpGet("{restaurantID}/menus")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Menus))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<CustomRBClient.Menus>> GetMenusAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (gZippedRespponseContent, eTag) = await _service.GetMenusThroughCacheAsync(restaurantID);
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag;
                    Response.Headers["Cache-Control"] = _cache_control_headers;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await _service.Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No menus available for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        [HttpGet("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantDetails>> GetRestaurantDetailsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantDetailsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/menus/categories")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<List<RestaurantMenuCategory>>> GetRestaurantMenusCategoriesAsync(long restaurantID, [FromQuery] int? menuID = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantMenusCategoriesAsync(restaurantID, menuID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/menus/{menuID}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantMenuTree>> GetRestaurantMenuAsync(long restaurantID, [FromQuery] int menuID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantMenuAsync(restaurantID, menuID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/products")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<List<int>>> GetRestaurantProductIDsAsync(long restaurantID, [FromQuery] int? categoryID, [FromQuery] bool? OUTAGE = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantProductIDsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/products/*")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<List<RestaurantProduct>>> GetRestaurantProductsAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantProductsAsync(restaurantID);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/products/{productID}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(RestaurantProduct))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<RestaurantProduct>> GetRestaurantProductAsync(long restaurantID, int productID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantProductAsync(restaurantID, productID);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/promotions")]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<List<int>>> GetRestaurantPromotionIDsAsync(long restaurantID, [FromQuery] bool? ADVERTISABLE = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantPromotionIDsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/promotions/*")]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<List<int>>> GetRestaurantPromotionsAsync(long restaurantID, [FromQuery] bool? ADVERTISABLE = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantPromotionIDsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/promotions/{promotionID}")]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<RestaurantPromotion>> GetRestaurantPromotionAsync(long restaurantID, int promotionID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantPromotionAsync(restaurantID, promotionID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/combined")]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<RestaurantCombined>> GetRestaurantCombinedAsync(long restaurantID, [FromQuery] HashSet<string> filterApis = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null)
        {
            try
            {
                var searchResults = await _clientV1.GetRestaurantCombinedAsync(restaurantID);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }
    }
}
