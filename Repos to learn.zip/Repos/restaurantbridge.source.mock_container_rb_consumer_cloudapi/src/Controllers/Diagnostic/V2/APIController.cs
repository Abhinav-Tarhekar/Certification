﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Common;
using System.Collections.Generic;
using Microsoft.Net.Http.Headers;
using System.Threading;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System.Threading.Channels;

namespace MockRBConsumer.CloudAPI.Diagnostic.V2
{
    [ApiController]
    [Route("diagnostic/api/v2/restaurants")]
    public class APIController : ControllerBase
    {
        private readonly ILog Log;
        private readonly IService _service;
        private readonly string _cache_control_headers;

        private ObjectResult LoggedFailureCode(int statusCode, Exception exception)
        {
            Log.Error($"Request Failed : {statusCode} : {exception.Message}", exception);
            return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}");
        }
        private readonly RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced _clientV2;

        public APIController(ILog log, IConfiguration configuration, IService service, RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced clientV2)
        {
            Log = log;
            _service = service;
            _cache_control_headers = configuration.cache_control_headers;
            _clientV2 = clientV2;
        }

        [HttpGet()]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<List<RestaurantBridge.Gateway.Cloud.V2.Models.SearchedDetails>>> SearchRestaurantsAsync()
        {
            try
            {
                var searchResults = await _clientV2.SearchRestaurantsAsync();
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }
        [HttpGet("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.Configuration>> GetRestaurantConfigurationAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantConfigurationAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.Settings>> GetRestaurantSettingsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantSettingsAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/channelmenus")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.ChannelMenus>> GetRestaurantChannelMenusAsync(long restaurantID, [FromQuery] string[] locales = null, [FromQuery] string[] channels = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantChannelMenusAsync(restaurantID, locales, channels, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/taxparameters")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.TaxParameters>> GetRestaurantTaxParametersAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantTaxParametersAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/productoutages")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.ProductOutages>> GetRestaurantOutagesAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantProductOutagesAsync(restaurantID, cancellationToken);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("oqmcmenu/{restaurantID}/overrides")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.OQMCOverrides>> GetOqmcOverridesAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null)
        {
            try
            {
                var searchResults = await _clientV2.GetOQMCOverridesAsync(restaurantID);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }

        [HttpGet("{restaurantID}/coatesmenus")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.RestaurantCoatesMenus>> GetRestaurantCoatesMenusAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null)
        {
            try
            {
                var searchResults = await _clientV2.GetRestaurantCoatesMenusAsync(restaurantID);
                return searchResults;
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }

        }


        // GET api/v2/restaurants/{restaurantID}/status
        [HttpGet("{restaurantID}/status")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Status))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]

        public async Task<ActionResult<CustomRBClient.Status>> GetStatusAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (gZippedRespponseContent, eTag) = await _service.GetStatusThroughCacheAsync(restaurantID);
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag;
                    Response.Headers["Cache-Control"] = _cache_control_headers;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await _service.Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No details available for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/menus
        [HttpGet("{restaurantID}/menus")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CustomRBClient.Menus))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<CustomRBClient.Menus>> GetMenusAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (gZippedRespponseContent, eTag) = await _service.GetMenusThroughCacheAsync(restaurantID);
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag;
                    Response.Headers["Cache-Control"] = _cache_control_headers;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await _service.Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No menus available for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        [HttpGet("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(RestaurantBridge.Gateway.Cloud.V2.Models.Details))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<RestaurantBridge.Gateway.Cloud.V2.Models.Details>> GetDetailsAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (gZippedRespponseContent, eTag) = await _service.GetDetailsThroughCacheAsync(restaurantID, cancellationToken);
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag;
                    Response.Headers["Cache-Control"] = _cache_control_headers;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await _service.Decompress(gZippedRespponseContent, cancellationToken);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No details available for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

    }
}
