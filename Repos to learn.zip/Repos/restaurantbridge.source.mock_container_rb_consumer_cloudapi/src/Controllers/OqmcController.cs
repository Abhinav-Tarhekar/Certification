﻿using Common;
using Microsoft.AspNetCore.Mvc;

namespace MockRBConsumer.CloudAPI.Oqmc
{
    [ApiController]
    [Route("api/oqmc")]
    public class OqmcController : ControllerBase
    {
        private readonly ILog Log;
        private readonly IOqmcConsumerCallback oqmcConsumerCallback;

        private ObjectResult LoggedFailureCode(int statusCode, Exception exception)
        {
            Log.Error($"Request Failed : {statusCode} : {exception.Message}", exception);
            return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}");
        }

        public OqmcController(ILog log, IOqmcConsumerCallback oqmcConsumerCallback)
        {
            Log = log;
            this.oqmcConsumerCallback = oqmcConsumerCallback;
        }

        [HttpGet("consume")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<CustomRBClient.Status>> ConsumeAsync()
        {
            try
            {
                if (oqmcConsumerCallback.kafkaConsumerMessageList.Count > 0)
                {
                    return StatusCode(StatusCodes.Status200OK, oqmcConsumerCallback.kafkaConsumerMessageList);
                }

                return StatusCode(StatusCodes.Status200OK);
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
    }
}
