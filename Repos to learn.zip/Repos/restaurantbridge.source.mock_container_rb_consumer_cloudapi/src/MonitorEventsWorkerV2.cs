﻿using Common;
using RestaurantBridge.Gateway.Cloud.API.Monitoring.V2;
using RestaurantBridge.Gateway.Cloud.V2;

namespace MockRBConsumer.CloudAPI
{
    public class MonitorEventsWorkerV2 : RestaurantMonitorEventsWorkerV2
    {
        public MonitorEventsWorkerV2(IClientAdvanced restaurantBridgeClient, ILog logger)
            : base(restaurantBridgeClient, logger)
        {
        }

        protected override string[] GetSubscribeList()
        {
            var eventsList = new string[]
           {
                Client.RestaurantEventMonitor.V2_CacheClear_Event,
                Client.RestaurantEventMonitor.V2_CacheReload_Event,
                Client.RestaurantEventMonitor.V2_Settings_Event,
                Client.RestaurantEventMonitor.V2_Configuration_Event,
                Client.RestaurantEventMonitor.V2_State_Event,
                Client.RestaurantEventMonitor.V2_Details_Event,
                Client.RestaurantEventMonitor.V2_ChannelMenu_Event,
                Client.RestaurantEventMonitor.V2_TaxParameters_Event,
                Client.RestaurantEventMonitor.V2_ProductOutages_Event,
                Client.RestaurantEventMonitor.V2_Oqmc_Event,
                Client.RestaurantEventMonitor.V2_CoatesMenu_Event
           };
            return eventsList;
        }
    }
}