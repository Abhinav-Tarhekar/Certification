﻿using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Common.Logger;

namespace MockRBConsumer.CloudAPI
{
    public interface IConfiguration
    {
        string http_prefix { get; }
        int http_client_timeout_ms { get; }
        string restaurant_bridge_api_url { get; }

        public string schema_registry_url { get; }
        public string bootstrap_server { get; }
        public string cluster_name { get; }
        public string topic { get; }
        string channel_filter { get; }
        string cache_control_headers { get; }

        int min_worker_threads { get; }
        int min_io_threads { get; }

        Logger.Level min_log_level { get; }
    }

    public class Configuration : IConfiguration
    {
        private const string HTTP_PREFIX = "http://*:7229";
        private const string HTTP_CLIENT_TIMEOUT_MS = "60000";
        private const string RESTAURANT_BRIDGE_API_URL = "http://localhost:8080/api";//"https://restaurantbridge-dev01-us.dev.us-east-1.dev.digitalecp.mcd.com/api";

        private const string SCHEMA_REGISTRY_URL = "";
        private const string BOOTSTRAP_SERVER = "";
        private const string CLUSTER_NAME = "mock";
        private const string TOPIC = "oqmc-menu-us";

        private const string CHANNEL_FILTER = "GMAL_EATIN,GMAL_PICKUP,GMAL_DELIVERY";
        private const string CACHE_CONTROL_HEADERS = "public, no-cache, must-revalidate, no-transform"; // NOTE: THIS IS A HACK BECAUSE WE NEED TO TUNE TO GMA IMPLEMENTATION .. THE "CORRECT" VALUES ARE THE DEFAULTS HERE

        private const string MIN_WORKER_THREADS = "100";
        private const string MIN_IO_THREADS = "100";

        private const string MIN_LOG_LEVEL = "DEBUG";

        public string http_prefix { get; private set; }
        public int http_client_timeout_ms { get; private set; }
        public string restaurant_bridge_api_url { get; private set; }
        public string channel_filter { get; private set; }
        public string cache_control_headers { get; private set; }
        public int min_worker_threads { get; private set; }
        public int min_io_threads { get; private set; }
        public string schema_registry_url { get; private set; }
        public string bootstrap_server { get; private set; }
        public string cluster_name { get; private set; }
        public string topic { get; private set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public Logger.Level min_log_level { get; private set; }

        public Configuration()
        {
            http_prefix = Environment.GetEnvironmentVariable("HTTP_PREFIX") ?? HTTP_PREFIX;
            http_client_timeout_ms = int.Parse(Environment.GetEnvironmentVariable("HTTP_CLIENT_TIMEOUT_MS") ?? HTTP_CLIENT_TIMEOUT_MS);
            restaurant_bridge_api_url = Environment.GetEnvironmentVariable("RESTAURANT_BRIDGE_API_URL") ?? RESTAURANT_BRIDGE_API_URL;

            schema_registry_url = Environment.GetEnvironmentVariable("SCHEMA_REGISTRY_URL") ?? SCHEMA_REGISTRY_URL;
            bootstrap_server = Environment.GetEnvironmentVariable("BOOTSTRAP_SERVER") ?? BOOTSTRAP_SERVER;
            cluster_name = Environment.GetEnvironmentVariable("CLUSTER_NAME") ?? CLUSTER_NAME;
            topic = Environment.GetEnvironmentVariable("TOPIC") ?? TOPIC;

            channel_filter = Environment.GetEnvironmentVariable("CHANNEL_FILTER") ?? CHANNEL_FILTER;
            cache_control_headers = Environment.GetEnvironmentVariable("CACHE_CONTROL_HEADERS") ?? CACHE_CONTROL_HEADERS;

            min_worker_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_WORKER_THREADS") ?? MIN_WORKER_THREADS);
            min_io_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_IO_THREADS") ?? MIN_IO_THREADS);

            min_log_level = (Logger.Level)Enum.Parse(typeof(Logger.Level), Environment.GetEnvironmentVariable("MIN_LOG_LEVEL") ?? MIN_LOG_LEVEL);
        }

        private string _configurationSummary;
        public override string ToString()
        {
            if (_configurationSummary == null)
            {
                StringBuilder configurationSummary = new StringBuilder();
                configurationSummary.AppendLine("CONFIGURATION :");
                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                configurationSummary.AppendLine($"http_prefix:               {http_prefix}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"http_client_timeout_ms:    {http_client_timeout_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"restaurant_bridge_api_url: {restaurant_bridge_api_url}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"channel_filter:            {channel_filter}");
                configurationSummary.AppendLine($"cache_control_headers:     {cache_control_headers}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_worker_threads:        {min_worker_threads}");
                configurationSummary.AppendLine($"min_io_threads:            {min_io_threads}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_log_level:             {min_log_level}");
                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                _configurationSummary = configurationSummary.ToString();
            }
            return _configurationSummary;
        }
    }
}
