﻿using Common;
using Common.RequestContext;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Mcd.Utilities.Extensions;

namespace MockRBConsumer.CloudAPI
{
    public class Startup
    {
        private readonly Regex typeCleanerRegex = new Regex(@"^(?:.*\.)?(.*)$", RegexOptions.Compiled);
        private static readonly string SERVICE_NAME = System.Reflection.Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace;

        private readonly ILog Log;
        private readonly IConfiguration Configuration;

        public Startup(ILog log, IConfiguration configuration)
        {
            Log = log;
            Configuration = configuration;
        }

        private class ApiExplorerGroupPerVersionConvention : IControllerModelConvention
        {
            public void Apply(ControllerModel controller)
            {
                var controllerNamespace = controller.ControllerType.Namespace;
                var apiVersion = controllerNamespace?.Split('.').Last().ToLower();
                controller.ApiExplorer.GroupName = apiVersion;
            }
        }
        private string SwaggerModelTypeCleaner(Type type)
        {
            var typeFullName = type.FullName;
            var swaggerTypeName = typeCleanerRegex.Replace(typeFullName, "$1").Replace("+", ".").Replace("CustomRBClient.", "");
            return swaggerTypeName;
        }


        public void ConfigureServices(IServiceCollection services)
        {
            services.TryAddSingleton<IOqmcConsumerCallback, OqmcConsumerCallback>();
            services.TryAddSingleton<IKafkaConsumerBuilder, KafkaConsumerBuilder>();
            services.AddHostedService<KafkaConsumerWorker>();

            services.RegisterPrefetchManager(prefetch =>
            {
                prefetch.Register<EventsManager>();
            });


            services.AddSingleton<IConfiguration>(this.Configuration);
            services.AddSingleton<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>((_) =>
            {
                var clientV1 = new RestaurantBridge.Gateway.Cloud.V1.Client(Log, Configuration.restaurant_bridge_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms);
                return clientV1;
            });
            services.AddSingleton<RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced>((_) =>
            {
                var client = new RestaurantBridge.Gateway.Cloud.V2.Client(Log, Configuration.restaurant_bridge_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms);
                return client;
            });
            services.AddSingleton<CustomRBClient>((ServiceProvider) =>
            {
                var channels = Configuration.channel_filter.Split(',', System.StringSplitOptions.RemoveEmptyEntries | System.StringSplitOptions.TrimEntries).ToHashSet();

                var client = new CustomRBClient(Log, ServiceProvider.GetService<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>(), ServiceProvider.GetService<RestaurantBridge.Gateway.Cloud.V2.IClientAdvanced>(), channels);
                return client;
            });

            services.AddSingleton<IService, Service>();
            services.AddSingleton<CloudAPI.EventsManager>();

            services.AddControllers();
            services.AddMvc(c => c.Conventions.Add(new ApiExplorerGroupPerVersionConvention())).AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter(null, true));
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
                options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
            });

            services.Configure<GzipCompressionProviderOptions>(options => options.Level = System.IO.Compression.CompressionLevel.Optimal);
            services.AddResponseCompression();

            services.AddSwaggerGen(c =>
            {
                c.EnableAnnotations();
                c.CustomSchemaIds((type) => SwaggerModelTypeCleaner(type));
                c.SwaggerDoc("v1", new OpenApiInfo { Title = $"{SERVICE_NAME} DIAGNOSTICS V1", Version = "diagnostic" });
                c.SwaggerDoc("v2", new OpenApiInfo { Title = $"{SERVICE_NAME} DIAGNOSTICS V2", Version = "diagnostic" });
                c.SwaggerDoc("oqmc", new OpenApiInfo { Title = $"{SERVICE_NAME}" });
            });
            services.AddSwaggerGenNewtonsoftSupport();

            services.AddHostedService<MonitorEventsWorkerV1>();
            services.AddHostedService<MonitorEventsWorkerV2>();

        }

        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            app.ApplicationServices.GetService<IService>().InitializeAsync().Wait();

            app.UsePrefetchAsync().Wait();

            app.UseResponseCompression();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swaggerDoc, httpRequest) =>
                {
                    if (httpRequest.Headers.ContainsKey("X-Forwarded-Path"))
                    {
                        var serverUrl = $"{httpRequest.Headers["X-Forwarded-Proto"]}://" +
                                        $"{httpRequest.Headers["X-Forwarded-Host"]}/" +
                                        $"{httpRequest.Headers["X-Forwarded-Path"]}";
                        swaggerDoc.Servers = new List<OpenApiServer>()
                        {
                            new OpenApiServer { Url = serverUrl }
                        };
                    }
                });
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{SERVICE_NAME} - Diagnostic/V1");
                c.SwaggerEndpoint("/swagger/v2/swagger.json", $"{SERVICE_NAME} - Diagnostic/V2");
                c.SwaggerEndpoint("/swagger/oqmc/swagger.json", $"{SERVICE_NAME} - OQMC");
            });
            app.Use((context, next) =>
            {
                if (context.Request.Headers.ContainsKey(RequestContext.HTTP_HEADER_KEY_CLIENT_NAME)) { RequestContext.ClientName.Init(context.Request.Headers[RequestContext.HTTP_HEADER_KEY_CLIENT_NAME]); }
                if (context.Request.Headers.ContainsKey(RequestContext.HTTP_HEADER_KEY_CORRELATION_ID)) { RequestContext.CorrelationID.Init(context.Request.Headers[RequestContext.HTTP_HEADER_KEY_CORRELATION_ID]); }
                return next.Invoke();
            });
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
