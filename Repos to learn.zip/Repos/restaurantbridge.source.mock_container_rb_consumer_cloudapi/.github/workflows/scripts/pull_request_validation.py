from github import Github
import github
import os
import re
import sys
import requests
import json

gh_token = os.environ['gh_token']
repo_name = os.environ['repo_name']
pr_number = int(os.environ['pr_number'])
branch_name = os.environ['branch_name']
jira_token = os.environ['jira_token']
print('pr #' + str(pr_number))
print('branch name: ' + branch_name)
print(repo_name)

g = Github(gh_token)


pattern = re.compile(".*\\b([a-zA-Z0-9]{2,6}-[0-9]{2,5})(\\b|_)")

repo = g.get_repo(repo_name)

pull_request = repo.get_pull(pr_number)

pr_commits = pull_request.get_commits()

JiraKey = ''

for commit in pr_commits:
    commit_in_focus = repo.get_commit(sha=str(commit.sha))
    commit_message = str(commit_in_focus.commit.message)
    regex_bool = bool(pattern.match(commit_message))
    if regex_bool:
        JiraKey = pattern.match(commit_message).group(1)

if pull_request.body is not None:
    regex_bool = bool(pattern.match(pull_request.body))
    if regex_bool:
        JiraKey = pattern.match(pull_request.body).group(1)

if pull_request.title is not None:
    regex_bool = bool(pattern.match(pull_request.title))
    if regex_bool:
        JiraKey = pattern.match(pull_request.title).group(1)

pr_comments = pull_request.get_issue_comments()

for comments in pr_comments:
    regex_bool = bool(pattern.match(comments.body))
    if regex_bool:
        JiraKey = pattern.match(comments.body).group(1)

if '/' in branch_name: 
    branch_name = branch_name.split('/')[1]
    
regex_bool = bool(pattern.match(branch_name))
if regex_bool:
    JiraKey = pattern.match(branch_name).group(1)
    
if JiraKey == '':
    print('Jira Key not found')
    sys.exit(1)


print('Found Jira Key:' + JiraKey)

url = 'https://us-jira.mcd.com/rest/api/2/issue/' + JiraKey.strip()

headers = {
  'Authorization': 'Bearer ' + jira_token,
  'Content-Type': 'application/json'
}

#response = requests.request("GET", url, headers=headers)

#resp = json.loads(response.text)
#need to remove status check for now
#print(resp['fields']['status']['name'])
#if (resp['fields']['status']['name']!='Done'):
#    print('Jira issue not done')
#    sys.exit(1)
