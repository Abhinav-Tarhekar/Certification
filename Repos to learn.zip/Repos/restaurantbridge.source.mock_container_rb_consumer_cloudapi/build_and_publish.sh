#!/bin/sh

CONTAINER_NAME="restaurant_bridge_mockrbconsumer_cloud_api"

# NOTE: !! VERSION LABELING !!
#
# The pre-release version prefix (PRERELEASE_PREFIX) 
# must be set as follows: 
# 
# * local/special builds should be "-alpha" (this is automatic if not set)
# * development branch should be "-beta"
# * candidate branch should be "-rc"
# * release branch should be ""

VERSION_SUFFIX=${VERSION_SUFFIX--alpha-g$(git rev-parse --short HEAD)}
NUGET_SOURCE_PUBLIC=${NUGET_SOURCE_PUBLIC}
NUGET_SOURCE_INTERNAL=${NUGET_SOURCE_INTERNAL}
NUGET_SOURCE_PRIVATE=${NUGET_SOURCE_PRIVATE}

#$REGISTRY_USERNAME // use environment variable value
#$REGISTRY_PASSWORD // use environment variable value
REGISTRY_HOST=${REGISTRY_HOST}

NUGET_PUBLISH_URL=${NUGET_PUBLISH_URL}
REGISTRY_USERNAME=${REGISTRY_USERNAME}
REGISTRY_PASSWORD=${REGISTRY_PASSWORD}
NUGET_SOURCE_MCFLOW=${NUGET_SOURCE_MCFLOW}
NUGET_SOURCE_MCFLOW_COMMONLIB=${NUGET_SOURCE_MCFLOW_COMMONLIB}

BUILD_DIR="."
DOCKERFILE="Dockerfile"

GIT_USER=${GITHUB_ACTOR}
GIT_COMMIT_HASH=$(git rev-parse HEAD)
GIT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
GIT_STATUS=$(git status --branch | sed  's/^/   /')
GIT_PORCELAIN=$(git status --porcelain | sed  's/^/   /')

VERSION_MAJOR=$(cat ./.version/MAJOR | tr -s -c [:digit:])
VERSION_MINOR=$(cat ./.version/MINOR | tr -s -c [:digit:])
VERSION_PATCH=$(cat ./.version/PATCH | tr -s -c [:digit:])
VERSION_BUILD=$(($(git tag -l v$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH* | sed -r -n "s/v$VERSION_MAJOR\.$VERSION_MINOR\.$VERSION_PATCH(\.|-[^.]+\.)([[:digit:]]+).*/\2/p" | sort -rn | head -n 1) + 1))

PRERELEASE_PREFIX=${PRERELEASE_PREFIX--alpha}
if [ "$PRERELEASE_PREFIX" = "-alpha" ]; then
  PRERELEASE_POSTFIX="-g$(git rev-parse --short HEAD)"
fi
if [ "$PRERELEASE_PREFIX" = "" ]; then
  VERSION_INFORMATIONAL="$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH"
else
  VERSION_INFORMATIONAL="$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH$PRERELEASE_PREFIX.$VERSION_BUILD$PRERELEASE_POSTFIX"
fi

VERSION_ASSEMBLY="$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH.$VERSION_BUILD"

GIT_BUILD_TAG="v$VERSION_INFORMATIONAL"
DATETIME_BUILD=$(date)

MESSAGE=$(echo -e "BUILD INFORMATION: =>\n\
-----------------------------------------------------------\n\
DATETIME_BUILD        : $DATETIME_BUILD\n\
-----------------------------------------------------------\n\
VERSION_INFORMATIONAL : $VERSION_INFORMATIONAL\n\
VERSION_ASSEMBLY      : $VERSION_ASSEMBLY\n\
-----------------------------------------------------------\n\
GIT_USER              : $GIT_USER\n\
GIT_COMMIT_HASH       : $GIT_COMMIT_HASH\n\
GIT_BUILD_TAG         : $GIT_BUILD_TAG\n\
-----------------------------------------------------------\n\
NUGET_SOURCE_PUBLIC   : $NUGET_SOURCE_PUBLIC\n\
NUGET_SOURCE_INTERNAL : $NUGET_SOURCE_INTERNAL\n\
NUGET_SOURCE_PRIVATE  : $NUGET_SOURCE_PRIVATE\n\
NUGET_SOURCE_USERNAME : **********************\n\
NUGET_SOURCE_PASSWORD : **********************\n\
-----------------------------------------------------------\n\
REGISTRY_HOST         : $REGISTRY_HOST\n\
REGISTRY_USERNAME     : **********************\n\
REGISTRY_PASSWORD     : **********************\n\
-----------------------------------------------------------\n\
GIT_STATUS            :\n$GIT_STATUS\n\
-----------------------------------------------------------\n\
GIT_PORCELAIN         :\n$GIT_PORCELAIN\n\
-----------------------------------------------------------\n")

echo "$MESSAGE"

BUILD_CONTAINER_NAME="container_build_g$GIT_COMMIT_HASH"

echo "BUILDING AND PUSHING: \"$GIT_BUILD_TAG\" in container \"$BUILD_CONTAINER_NAME\""

if [ -z "$PRERELEASE_PREFIX" ]
then
  #RELEASE
  docker build --network host -t "g$GIT_COMMIT_HASH" \
    -f "$DOCKERFILE" "$BUILD_DIR" \
    --build-arg NUGET_SOURCE_PUBLIC=$NUGET_SOURCE_PUBLIC \
    --build-arg NUGET_SOURCE_INTERNAL=$NUGET_SOURCE_INTERNAL \
    --build-arg NUGET_SOURCE_PRIVATE=$NUGET_SOURCE_PRIVATE \
    --build-arg VERSION_ASSEMBLY=$VERSION_ASSEMBLY \
    --build-arg NUGET_PUBLISH_URL=$NUGET_PUBLISH_URL \
    --build-arg NUGET_SOURCE_MCFLOW=$NUGET_SOURCE_MCFLOW \
    --build-arg NUGET_SOURCE_MCFLOW_COMMONLIB=$NUGET_SOURCE_MCFLOW_COMMONLIB \
    --build-arg NUGET_SOURCE_USERNAME=$NUGET_SOURCE_USERNAME \
    --build-arg NUGET_SOURCE_PASSWORD=$NUGET_SOURCE_PASSWORD \
    --build-arg VERSION_INFORMATIONAL=$VERSION_INFORMATIONAL \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:latest" \
    2>&1
else
  docker build --network host -t "g$GIT_COMMIT_HASH" \
    -f "$DOCKERFILE" "$BUILD_DIR" \
    --build-arg NUGET_SOURCE_PUBLIC=$NUGET_SOURCE_PUBLIC \
    --build-arg NUGET_SOURCE_INTERNAL=$NUGET_SOURCE_INTERNAL \
    --build-arg NUGET_SOURCE_PRIVATE=$NUGET_SOURCE_PRIVATE \
    --build-arg VERSION_ASSEMBLY=$VERSION_ASSEMBLY \
    --build-arg NUGET_PUBLISH_URL=$NUGET_PUBLISH_URL \
    --build-arg NUGET_SOURCE_MCFLOW=$NUGET_SOURCE_MCFLOW \
    --build-arg NUGET_SOURCE_MCFLOW_COMMONLIB=$NUGET_SOURCE_MCFLOW_COMMONLIB \
    --build-arg NUGET_SOURCE_USERNAME=$NUGET_SOURCE_USERNAME \
    --build-arg NUGET_SOURCE_PASSWORD=$NUGET_SOURCE_PASSWORD \
    --build-arg VERSION_INFORMATIONAL=$VERSION_INFORMATIONAL \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH$PRERELEASE_PREFIX" \
    -t "$REGISTRY_HOST/${CONTAINER_NAME}:${PRERELEASE_PREFIX#-}" \
    2>&1
fi

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo "BUILD FAILED !!"
    exit $EXIT_CODE
fi

clean_up() {
  EXIT_CODE=$1
  echo "REMOVING CONTAINER IMAGES: \"$BUILD_CONTAINER_NAME\""
  docker rmi --force $(docker images | grep g$GIT_COMMIT_HASH | head -n 1 | tr -s ' ' | cut -d ' ' -f 3)
  exit $EXIT_CODE
}

echo "LOGIN TO REGISTRY ..."
#JENKINS docker client is not happy about this 
#echo $REGISTRY_PASSWORD | docker login $REGISTRY_HOST --username $REGISTRY_USERNAME --password-stdin  
docker login $REGISTRY_HOST --username $REGISTRY_USERNAME --password $REGISTRY_PASSWORD  

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo "BUILD FAILED !!"
    clean_up $EXIT_CODE
fi

echo "TAGGING: \"$GIT_BUILD_TAG\""
echo "$MESSAGE"

git tag "$GIT_BUILD_TAG" -m "$MESSAGE"

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo "BUILD FAILED !!"
    clean_up $EXIT_CODE
fi

git push origin "$GIT_BUILD_TAG"

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo "BUILD FAILED !!"
    clean_up $EXIT_CODE
fi

if [ -z "$PRERELEASE_PREFIX" ]
then
  #RELEASE
    echo "PUSHING CONTAINER TO REGISTRY ..."
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY"
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH"
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR\""
    docker push $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR"
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:latest\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:latest"
else
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL"
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH$PRERELEASE_PREFIX\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_MAJOR.$VERSION_MINOR.$VERSION_PATCH$PRERELEASE_PREFIX"
    echo "docker push \"$REGISTRY_HOST/${CONTAINER_NAME}:${PRERELEASE_PREFIX#-}\""
    docker push "$REGISTRY_HOST/${CONTAINER_NAME}:${PRERELEASE_PREFIX#-}"
fi

EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
  if [ -z "$PRERELEASE_PREFIX" ]
  then
    #RELEASE
    echo "CONTAINER_DOCKER_IMAGE : $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY"
    echo "CONTAINER_MAIN_DLL     : $(docker inspect -f '{{index (.Config.Entrypoint) 1}}' $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY)"
    echo "::set-output name=CONTAINER_DOCKER_IMAGE::$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY"
    echo "::set-output name=CONTAINER_MAIN_DLL::$(docker inspect -f '{{index (.Config.Entrypoint) 1}}' $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_ASSEMBLY)"
  else
    echo "CONTAINER_DOCKER_IMAGE : $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL"
    echo "CONTAINER_MAIN_DLL     : $(docker inspect -f '{{index (.Config.Entrypoint) 1}}' $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL)"
    echo "::set-output name=CONTAINER_DOCKER_IMAGE::$REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL"
    echo "::set-output name=CONTAINER_MAIN_DLL::$(docker inspect -f '{{index (.Config.Entrypoint) 1}}' $REGISTRY_HOST/${CONTAINER_NAME}:$VERSION_INFORMATIONAL)"
  fi
fi

clean_up 0
