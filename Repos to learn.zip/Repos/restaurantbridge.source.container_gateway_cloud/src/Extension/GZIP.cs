﻿using System.IO.Compression;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantBridge.Gateway.Cloud.Extension
{
    public static class GZIP
    {
        [ExcludeFromCodeCoverage]
        public static async Task<byte[]> Compress(string stringToCompress)
        {
            byte[] dataToCompress = Encoding.UTF8.GetBytes(stringToCompress);
            using (MemoryStream memStream = new MemoryStream())
            {
                using (GZipStream zipStream = new GZipStream(memStream, CompressionMode.Compress))
                {
                    await zipStream.WriteAsync(dataToCompress, 0, dataToCompress.Length);
                    await zipStream.FlushAsync();
                }
                return memStream.ToArray();
            }
        }
        public static async Task<string> Decompress(byte[] dataToDecompress)
        {
            using (var compressedStream = new MemoryStream(dataToDecompress))
            using (var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
            using (var resultStream = new MemoryStream())
            {
                await zipStream.CopyToAsync(resultStream);
                return Encoding.UTF8.GetString(resultStream.ToArray());
            }
        }
    }
}
