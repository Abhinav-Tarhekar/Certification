﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;


using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

using Swashbuckle.AspNetCore.Annotations;

using Common;
using RestaurantBridge.Gateway.Cloud.API.Client;

namespace RestaurantBridge.Gateway.Cloud.NPOS61
{
    public static class HttpRequestExtensions
    {
        public static async Task<string> GetRawBodyStringAsync(this HttpRequest request, Encoding encoding = null)
        {
            if (encoding == null)
                encoding = Encoding.UTF8;

            using (StreamReader reader = new StreamReader(request.Body, encoding))
                return await reader.ReadToEndAsync();
        }
    }

    [ApiController]
    [Route("api/npos61")]
    public class APIController : ControllerBase
    {
        private readonly ILog Log;

        private readonly RestaurantMonitor.V1.IClient _restaurantMonitor;
        private readonly Cache.RFMXMLDatabases.V1.IClient _rfmxmlClientV1;
        private readonly Proxy.Premise.NPOS61.IClient _proxyPremiseNPOS61;

        public APIController(
            ILog logger,
            RestaurantMonitor.V1.IClientAdvanced restaurantMonitor,
            Cache.RFMXMLDatabases.V1.IClient rfmxmlClientV1,
            Proxy.Premise.NPOS61.IClient proxyPremiseNPOS61
        )
        {
            Log = logger;
            _restaurantMonitor = (RestaurantMonitor.V1.IClient)restaurantMonitor;
            _proxyPremiseNPOS61 = proxyPremiseNPOS61;
            _rfmxmlClientV1 = rfmxmlClientV1;
        }

        private StatusCodeResult LoggedResponseCode(int statusCode, string path)
        {
            Log.Warn($"RESPONSE : {statusCode} : {path}");
            return StatusCode(statusCode);
        }
        private ContentResult LoggedFailureCode(int statusCode, string path, Exception exception)
        {
            Log.Critical($"RESPONSE : {statusCode} : {path} : EXCEPTION : {exception.Message}", exception);
            var xDoc = new XDocument();
            xDoc.Add(new XElement("Error", new XElement("Message", exception.Message), new XElement("StackTrace", exception.StackTrace.ToString())));
            return new ContentResult { StatusCode = statusCode, Content = xDoc.ToString(), ContentType = "text/xml" };
        }

        private ContentResult RestaurantEndpointFaultExceptionResult(string path, Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
        {
            Log.Critical($"RESPONSE : 298 : {path} : EXCEPTION : {refex.Message}", refex);
            var xDoc = new XDocument();
            xDoc.Add(new XElement("RestaurantEndpointFault", new XElement("Message", refex.Message), new XElement("Code", refex.Code)));
            return new ContentResult { StatusCode = 298, Content = xDoc.ToString(), ContentType = "text/xml" };
        }

        // GET api/npos61/{restaurantID}/storeDB
        [HttpGet("{restaurantID}/storeDB")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = StoredbGetEndpoint.SUMMARY)]
        [SwaggerDescription(StoredbGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GET_storeDB(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantStateAsync(restaurantID);
                if (state != null)
                {
                    var eTag = $"\"{state.databaseVersions.store}\"";
                    if (eTag == IF_NONE_MATCH)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }

                    // do not allow state responses to be cached anywhere
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: eTag, isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    var resultXML = await _rfmxmlClientV1.GetFOEStoreDBxmlAsync(restaurantID);
                    if (resultXML != null)
                    {
                        return this.Content(resultXML, "text/xml");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/npos61/{restaurantID}/productDB
        [HttpGet("{restaurantID}/productDB")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductsdbGetEndpoint.SUMMARY)]
        [SwaggerDescription(ProductsdbGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GET_productsDB(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantStateAsync(restaurantID);
                if (state != null)
                {
                    var eTag = $"\"{state.databaseVersions.products}\"";
                    if (eTag == IF_NONE_MATCH)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }

                    // do not allow state responses to be cached anywhere
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: eTag, isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    var resultXML = await _rfmxmlClientV1.GetFOEProductsDBxmlAsync(restaurantID);
                    if (resultXML != null)
                    {
                        return this.Content(resultXML, "text/xml");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/npos61/{restaurantID}/namesDB
        [HttpGet("{restaurantID}/namesDB")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = NamesdbGetEndpoint.SUMMARY)]
        [SwaggerDescription(NamesdbGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GET_namesDB(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantStateAsync(restaurantID);
                if (state != null)
                {
                    var eTag = $"\"{state.databaseVersions.productNames}\"";
                    if (eTag == IF_NONE_MATCH)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }

                    // do not allow state responses to be cached anywhere
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: eTag, isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    var resultXML = await _rfmxmlClientV1.GetFOEProductNamesDBxmlAsync(restaurantID);
                    if (resultXML != null)
                    {
                        return this.Content(resultXML, "text/xml");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/npos61/{restaurantID}/promotionDB
        [HttpGet("{restaurantID}/promotionDB")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsdbGetEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsdbGetEndpoint.DESCRIPTION)]

        public async Task<ActionResult> GET_promotionDB(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantStateAsync(restaurantID);
                if (state != null)
                {
                    var eTag = $"\"{state.databaseVersions.promotions}\"";
                    if (eTag == IF_NONE_MATCH)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }

                    // do not allow state responses to be cached anywhere
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: eTag, isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    var resultXML = await _rfmxmlClientV1.GetFOEPromotionsDBxmlAsync(restaurantID);
                    if (resultXML != null)
                    {
                        return this.Content(resultXML, "text/xml");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/npos61/{restaurantID}/restaurantpromotionDB
        [HttpGet("{restaurantID}/restaurantpromotionDB")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = RestaurantPromotionsdbGetEndpoint.SUMMARY)]
        [SwaggerDescription(RestaurantPromotionsdbGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GET_restaurantpromotionDB(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantStateAsync(restaurantID);
                if (state != null)
                {
                    var eTag = $"\"{state.databaseVersions.restaurantPromotions}\"";
                    if (eTag == IF_NONE_MATCH)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }
                    // do not allow state responses to be cached anywhere
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    var resultXML = await _rfmxmlClientV1.GetFOERestaurantPromotionsDBxmlAsync(restaurantID);
                    if (resultXML != null)
                    {
                        return this.Content(resultXML, "text/xml");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        
        // PUT api/npos61/{restaurantID}/GetStoreStatus
        [HttpPut("{restaurantID}/GetStoreStatus")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoStoreStatusGetEndpoint.SUMMARY)]
        [SwaggerDescription(DoStoreStatusGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetStoreStatusAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetStoreStatusAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetStoredb
        [HttpPut("{restaurantID}/GetStoredb")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoStoreDbGetEndpoint.SUMMARY)]
        [SwaggerDescription(DoStoreDbGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetStoredbAync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetStoredbAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // PUT api/npos61/{restaurantID}/GetProduct
        [HttpPut("{restaurantID}/GetProduct")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoProductGetEndpoint.SUMMARY)]
        [SwaggerDescription(DoProductGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetProductAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetProductAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetNames
        [HttpPut("{restaurantID}/GetNames")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetNamesPutEndpoint.SUMMARY)]
        [SwaggerDescription(GetNamesPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetNamesAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetNamesAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetProdOutage
        [HttpPut("{restaurantID}/GetProdOutage")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetProdOutagePutEndpoint.SUMMARY)]
        [SwaggerDescription(GetProdOutagePutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetProdOutageAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetProdOutageAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetPromotiondb
        [HttpPut("{restaurantID}/GetPromotiondb")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetPromotiondbtPutEndpoint.SUMMARY)]
        [SwaggerDescription(GetPromotiondbtPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetPromotiondbAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetPromotiondbAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetRestaurantPromotiondb
        [HttpPut("{restaurantID}/GetRestaurantPromotiondb")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetRestaurantPromotiondbPutEndpoint.SUMMARY)]
        [SwaggerDescription(GetRestaurantPromotiondbPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetRestaurantPromotiondbAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var resultXML = await _proxyPremiseNPOS61.GetRestaurantPromotiondbAsync(restaurantID, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetFOERequestStatus
        [HttpPut("{restaurantID}/GetFOERequestStatus")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetFOERequestStatusPutEndpoint.SUMMARY)]
        [SwaggerDescription(GetFOERequestStatusPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetFOERequestStatusAsync(long restaurantID, [FromQuery] string replayPreventionTokenOverride = null, [FromQuery] uint? retriesOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var requestXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.GetFOERequestStatusAsync(restaurantID, requestXML, replayPreventionTokenOverride, retriesOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/DoFoeStore
        [HttpPut("{restaurantID}/DoFoeStore")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoFoeStorePutEndpoint.SUMMARY)]
        [SwaggerDescription(DoFoeStorePutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> DoFoeStoreAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.DoFoeStoreAsync(restaurantID, orderXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/DoFoeStoreDT
        [HttpPut("{restaurantID}/DoFoeStoreDT")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoFoeStoreDTPutEndpoint.SUMMARY)]
        [SwaggerDescription(DoFoeStoreDTPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> DoFoeStoreDTAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.DoFoeStoreDTAsync(restaurantID, orderXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/DoFoeStoreStaging
        [HttpPut("{restaurantID}/DoFoeStoreStaging")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DoFoeStoreStagingPutEndpoint.SUMMARY)]
        [SwaggerDescription(DoFoeStoreStagingPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> DoFoeStoreStagingAsync(long restaurantID, [FromQuery] string replayPreventionTokenOverride = null, [FromQuery] uint? retriesOverride = null, [FromQuery] bool? doPIIEncryption = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.DoFoeStoreStagingAsync(restaurantID, orderXML, replayPreventionTokenOverride, retriesOverride, doPIIEncryption);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/TransferFromStaging
        [HttpPut("{restaurantID}/TransferFromStaging")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = TransferFromStagingPutEndpoint.SUMMARY)]
        [SwaggerDescription(TransferFromStagingPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> TransferFromStagingAsync(long restaurantID, string replayPreventionTokenOverride = null, [FromQuery] uint? retriesOverride = null, [FromQuery] bool? doPIIEncryption = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.TransferFromStagingAsync(restaurantID, orderXML, replayPreventionTokenOverride, retriesOverride, doPIIEncryption);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // PUT api/npos61/{restaurantID}/GetOrderStatus
        [HttpPut("{restaurantID}/GetOrderStatus")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = GetOrderStatusPutEndpoint.SUMMARY)]
        [SwaggerDescription(GetOrderStatusPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetOrderStatusAsync(long restaurantID, string replayPreventionTokenOverride = null, [FromQuery] uint? retriesOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var requestXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.GetOrderStatusAsync(restaurantID, requestXML, replayPreventionTokenOverride, retriesOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        
        // PUT api/npos61/{restaurantID}/UpdateOrderStatus
        [HttpPut("{restaurantID}/UpdateOrderStatus")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = UpdateOrderStatusPutEndpoint.SUMMARY)]
        [SwaggerDescription(UpdateOrderStatusPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> UpdateOrderStatusAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.UpdateOrderStatusAsync(restaurantID, orderXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        
        // PUT api/npos61/{restaurantID}/SendOrderPaymentStatus
        [HttpPut("{restaurantID}/SendOrderPaymentStatus")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = SendOrderPaymentStatusPutEndpoint.SUMMARY)]
        [SwaggerDescription(SendOrderPaymentStatusPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> SendOrderPaymentStatusAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var orderXML = await Request.GetRawBodyStringAsync();
                await _proxyPremiseNPOS61.SendOrderPaymentStatusAsync(restaurantID, orderXML, replayPreventionTokenOverride);
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        
        // PUT api/npos61/{restaurantID}/UpdateFulfillmentMethod
        [HttpPut("{restaurantID}/UpdateFulfillmentMethod")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = UpdateFulfillmentMethodPutEndpoint.SUMMARY)]
        [SwaggerDescription(UpdateFulfillmentMethodPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> UpdateFulfillmentMethodAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var updateFulfillmentMethodXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.UpdateFulfillmentMethod(restaurantID, updateFulfillmentMethodXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        
        // PUT api/npos61/{restaurantID}/UpdateTableServiceNumber
        [HttpPut("{restaurantID}/UpdateTableServiceNumber")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = UpdateTableServiceNumberPutEndpoint.SUMMARY)]
        [SwaggerDescription(UpdateTableServiceNumberPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> UpdateTableServiceNumberAsync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var updateTableServiceNumberXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.UpdateTableServiceNumber(restaurantID, updateTableServiceNumberXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        
        // PUT api/npos61/{restaurantID}/UpdateCurbsideNumber
        [HttpPut("{restaurantID}/UpdateCurbsideNumber")]
        [RawXMLBody]
        [Consumes("text/xml")]
        [Produces("text/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(298)]
        [SwaggerResponse(298, "Restaurant Endpoint Fault")]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = UpdateCurbsideNumberPutEndpoint.SUMMARY)]
        [SwaggerDescription(UpdateCurbsideNumberPutEndpoint.DESCRIPTION)]
        public async Task<ActionResult> UpdateCurbsideNumberAync(long restaurantID, string replayPreventionTokenOverride = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var updateCurbsideNumberXML = await Request.GetRawBodyStringAsync();
                var resultXML = await _proxyPremiseNPOS61.UpdateCurbsideNumber(restaurantID, updateCurbsideNumberXML, replayPreventionTokenOverride);
                return this.Content(resultXML, "text/xml");
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantNotFoundException)
            {
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Proxy.Premise.NPOS61.Models.RestaurantEndpointFaultException refex)
            {
                return RestaurantEndpointFaultExceptionResult(Request.Path, refex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
    }
}
