﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.NPOS61
{

        // NOTE: DECRIPTION text ARE IN Github style MARKDOWN 
        //       blank line indicate paragraph
        //       doulbe space at end is a line break, 
        //       **BOLD**, 
        //       `CODE` 
        //       (4 space at begining also code),
        //       ```javascript\n...\n``` syntax highlighted 
        //       --- horizontal rule
    #region CommonEndPointInformation
        public static class CommonEndPointInformation
        {
            public const string STATUS_304_NOT_MODIFIED_RESPONSE = "A 304 status response without a body is returned when the 'If-None-Match Header' value matches the current eTag of the data.";
            public const string STATUS_200_SUCCESS = "A 200 status response with a body is returned when all mandatory fields are entered correctly";
            public const string STATUS_404_NOT_FOUND = "A 404 status response when the restaurantID is incorrect or not available";
        }
    #endregion

    #region storedb
    public static class StoredbGetEndpoint
    {
        public const string SUMMARY = " Gets the FOE StoreDb from NP6";
        public const string DESCRIPTION = @"
           Storedb maintains all the settings that are valid for 
           store  such as default values of all parameters associated to services  and adaptors                             
           tender,configuration,tax rates,etc";
    }
    #endregion

    #region namesdb
    public static class NamesdbGetEndpoint
    {
        public const string SUMMARY = "Gets the FOE NamesDb from NP6";
        public const string DESCRIPTION = @" 
            Namesdb holds the name of all 
            menu items including the description of base products, value meals,
            choices, etc. Also allows easy configuration of menu items with different
            languages within a single store.";
    }
    #endregion

    #region productsdb
    public static class ProductsdbGetEndpoint
    {
        public const string SUMMARY = "Gets the FOE ProductsDb from NP6";
        public const string DESCRIPTION = @" 
            Productdb is the file that contains 
            product items and their configuration settings.";
    }
    #endregion

    #region PromotionsDb
    public static class PromotionsdbGetEndpoint
    {
        public const string SUMMARY = "Gets the FOE Promotionsdb from NP6";
        public const string DESCRIPTION = @" 
           Promotionsdb contains the required configuration
           for the Promotions functionality";

    }
    #endregion 
    #region PromotionsDb
    public static class RestaurantPromotionsdbGetEndpoint
    {
        public const string SUMMARY = "Gets the FOE RestaurantPromotionsdb from NP6";
        public const string DESCRIPTION = @" 
           RestaurantPromotionsdb contains the required configuration
           for the RestaurantPromotions functionality";
    }
    #endregion 


    #region DoFoeStore
    public static class DoFoeStorePutEndpoint
    {
        public const string SUMMARY = "Send the FOE DoFoeStore to NP6";
        public const string DESCRIPTION = @"
        The DoFoeStore command stores a foreign order in the NP6 production “on-the-fly”. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion
    #region DoFoeStoreDT
    public static class DoFoeStoreDTPutEndpoint
    {
        public const string SUMMARY = "Send the FOE DoFoeStoreDT to NP6";
        public const string DESCRIPTION = @"
        The DoFoeStoreDT feature stores a foreign order in the restaurant DT Area. This message does contain the tender/cashless data and the NP stores the sale. The Payment data will be send to the NP through the ""sendOrderPaymentStatus"" command.
        ";
    }
    #endregion
    #region DoFoeStoreStaging
    public static class DoFoeStoreStagingPutEndpoint
    {
        public const string SUMMARY = "Send the FOE DoFoeStoreStaging to NP6";
        public const string DESCRIPTION = @"
        Microservices validate the order, apply the offer, initialise the payment process, and send the FOE DoFoeStoreStaging to NP6.
        ";
    }
    #endregion
    #region TransferFromStaging
    public static class TransferFromStagingPutEndpoint
    {
        public const string SUMMARY = "Send the FOE TransferFromStaging to NP6 with the tender information";
        public const string DESCRIPTION = @"
        Microservices authorise the payment and send the FOE TransferFromStaging to NP6 with the tender information.
        ";
    }
    #endregion
    #region GetOrderStatus
    public static class GetOrderStatusPutEndpoint
    {
        public const string SUMMARY = "Send the FOE GetOrderStatus to NP6";
        public const string DESCRIPTION = @"
        The GetOrderStatus command retrieves the real status of an order that has been previously queued in NP6 through FOE. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion
    #region UpdateOrderStatus
    public static class UpdateOrderStatusPutEndpoint
    {
        public const string SUMMARY = "Send the FOE UpdateOrderStatus to NP6";
        public const string DESCRIPTION = @"
        The UpdateOrderStatus command moves orders from the Order Staging area to the Production module. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion
    #region SendOrderPaymentStatus
    public static class SendOrderPaymentStatusPutEndpoint
    {
        public const string SUMMARY = "Send the FOE SendOrderPaymentStatus to NP6";
        public const string DESCRIPTION = @"
        The SendOrderPaymentStatus command sends a message providing the payment information about the order payment in eCP to the restaurant. The message will contain the order number, payment status and tender element if the payment was successful.
        This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion
    #region DoGetStoreStatus
    public static class DoStoreStatusGetEndpoint
    {
        public const string SUMMARY = "Send the FOE GetStoreStatus to NP6";
        public const string DESCRIPTION = @"
        This feature retrieves information about current FOE Interface version, current Store State and the version of NP6 Product Database, Names Database, Store Profile, Pos Profile and Products Outage.
        ";
    }
    #endregion
    #region DoGetStoreDb
    public static class DoStoreDbGetEndpoint
    {
        public const string SUMMARY = "Send the FOE GetStoreDb to NP6";
        public const string DESCRIPTION = @"
        The GetStoreDb command retrieves the NP6 Store Profile, STORE-DB.XML.
        ";
    }
    #endregion
    #region DoGetProduct
    public static class DoProductGetEndpoint
    {
        public const string SUMMARY = "Send the FOE GetProduct to NP6";
        public const string DESCRIPTION = @"
        The GetProduct command retrieves the NP6 Product Database, PRODUCT-DB.XML (defined by the <product>parameter of POS-DB.XML).
        ";
    }
    #endregion

    #region GetNames
    public static class GetNamesPutEndpoint
    {
        public const string SUMMARY = "Send the FOE GetNames to NP6";
        public const string DESCRIPTION = @"
        The GetNames command retrieves the NP6 Names Database, NAMES-DB.XML.
        ";
    }
    #endregion

    #region GetProdOutage
    public static class GetProdOutagePutEndpoint
    {
        public const string SUMMARY = "Send the FOE GetProdOutage to NP6";
        public const string DESCRIPTION = @"
        The GetProdOutage command retrieves the NP6 Product Outage Database, PRODOUTAGE.XML.
        ";
    }
    #endregion

    #region GetPromotiondb
    public static class GetPromotiondbtPutEndpoint
    {
        public const string SUMMARY = "Send the FOE GetPromotiondb to NP6";
        public const string DESCRIPTION = @"
        The GetPromotiondb command retrieves the NP6 Promotion Database, PROMOTION-DB.XML.
        ";
    }
    #endregion
    #region UpdateFulfillmentMethod
    public static class UpdateFulfillmentMethodPutEndpoint
    {
        public const string SUMMARY = "Send the FOE UpdateFulfillmentMethod to NP6";
        public const string DESCRIPTION = @"
        The UpdateFulfillmentMethod command sends a message providing the fulfillment information about the order in eCP to the restaurant. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion

    #region UpdateTableServiceNumber
    public static class UpdateTableServiceNumberPutEndpoint
    {
        public const string SUMMARY = "Send the FOE UpdateTableServiceNumber to NP6";
        public const string DESCRIPTION = @"
        The UpdateTableServiceNumber command sends a message providing the table service information about the order in eCP to the restaurant. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion

    #region UpdateCurbsideNumber
    public static class UpdateCurbsideNumberPutEndpoint
    {
        public const string SUMMARY = "Send the FOE UpdateCurbsideNumber to NP6";
        public const string DESCRIPTION = @"
        The UpdateCurbsideNumber command sends a message providing the curbside information about the order in eCP to the restaurant. This command has three parameters: Token, ID and Payload.
        ";
    }
    #endregion

    #region GetRestaurantPromotiondb
    public static class GetRestaurantPromotiondbPutEndpoint
    {
        public const string SUMMARY = "Send the FOE GetRestaurantPromotiondb to NP6";
        public const string DESCRIPTION = @"
        The GetRestaurantPromotiondb command retrieves the NP6 Restaurant Promotion Database, PROMOTION-DB.XML.
        ";
    }
    #endregion

    #region GetFOERequestStatus
    public static class GetFOERequestStatusPutEndpoint
    {
        public const string SUMMARY = "Send the FOE Request status to NP6";
        public const string DESCRIPTION = @"
        The GetFOERequestStatusAsync command retrieves the status of the restaurant that has been previously queued in NP6 through FOE.
        ";
    }
    #endregion

}
