﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Controllers.V2
{
    public static class APIErrorCodeList
    {
        public const string RESTAURANTS = "MENC1001";
        public const string CONFIGURATION = "MENC1002";
        public const string CONFIGURATIONHEAD = "MENC1003";
        public const string STATE = "MENC1004";
        public const string DETAILS = "MENC1005";
        public const string DETAILSHEAD = "MENC1006";
        public const string CHANNELMENUS = "MENC1007";
        public const string CHANNELMENUSHEAD = "MENC1008";
        public const string TAXPARAMETERS = "MENC1009";
        public const string TAXPARAMETERSHEAD = "MENC1010";
        public const string PRODUCTOUTAGES = "MENC1011";
        public const string OQMCMENU = "MENC1012";
        public const string COATESMENUS = "MENC1013";
        public const string COATESMENUSHEAD = "MENC1014";
        public const string SETTINGS = "MENC1015";
        public const string SETTINGSHEAD = "MENC1016";
        public const string RESTAURANTSCOMBINED = "MENC1017";
    }

    public class ErrorHandlingFunctions
    {
        public static string ReturnErrorType(int statusCode)
        {
            try {
                string retval = "TechnicalFault";
                var firstnum = statusCode.ToString().Substring(0, 1);
                switch (firstnum)
                {
                    case "5":
                        retval = "TechnicalFault";
                        break;
                    case "4":
                        retval = "ValidationFault";
                        break;
                    default:
                        retval = "TechnicalFault";
                        break;
                }          
                return retval;
            }
            catch(Exception e)
            {
                return "TechnicalFault";
            }
        }
    }

}





