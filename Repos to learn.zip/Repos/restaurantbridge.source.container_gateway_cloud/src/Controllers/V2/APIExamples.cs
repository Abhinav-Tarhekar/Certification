﻿using System.Collections.Generic;

using Swashbuckle.AspNetCore.Filters;

using Newtonsoft.Json;

namespace RestaurantBridge.Gateway.Cloud.V2
{
    public class APIExamples :
        IExamplesProvider<List<Models.Details>>,
        IExamplesProvider<Models.Configuration>,
        IExamplesProvider<Models.State>,
        IExamplesProvider<Models.Details>
    {
        private static readonly List<Models.Details> _restaurants = JsonConvert.DeserializeObject<List<Models.Details>>(@"
[
  {
    ""restaurantID"": 5869,
    ""marketID"": ""CA"",
    ""marketStoreID"": 5869,
    ""longitude"": -75.70197,
    ""latitude"": 45.36724,
    ""locales"": [
      ""en-CA"",
      ""fr-CA""
    ],
    ""channelHours"": {
      ""GMA_EATIN"": {
        ""SUNDAY"": {
          ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
        },
        ""MONDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
},
        ""TUESDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
},
        ""WEDNESDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
},
        ""THURSDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
},
        ""FRIDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
},
        ""SATURDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
        ""LOBBY"": [
              {
            ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
}
      },
      ""GMA_PICKUP"": {
    ""SUNDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""MONDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""TUESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""WEDNESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""THURSDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""FRIDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""SATURDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""19:59:59.9999999""
              }
            ],
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    }
},
      ""KIOSK"": {
    ""SUNDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""MONDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""TUESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""WEDNESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""THURSDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""FRIDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    },
        ""SATURDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
            ""to"": ""03:59:59.9999999""
          },
          ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
                ""to"": ""03:59:59.9999999""
              }
            ]
          }
    }
}
    },
    ""facilities"": [],
    ""name"": ""Hogsback"",
    ""phone"": ""6132262261"",
    ""address"": {
    ""address"": ""888 Medowlands Drive"",
      ""city"": ""Ottawa"",
      ""state"": ""ON"",
      ""country"": ""CA"",
      ""postCode"": ""K2C 3R2""
    },
    ""additionalInformation"": {
    ""CompanyName"": ""McDonalds""
    }
  },
  {
    ""restaurantID"": 39148,
    ""marketID"": ""US"",
    ""marketStoreID"": 39148,
    ""longitude"": -87.653335,
    ""latitude"": 41.884084,
    ""locales"": [
      ""en-US"",
      ""es-US""
    ],
    ""channelHours"": {
        ""GMA_DELIVERY"": {
            ""SUNDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""MONDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""TUESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""WEDNESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""THURSDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""FRIDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            },
        ""SATURDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""DELIVERY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
                      }
            ]
          }
            }
        },
      ""GMA_EATIN"": {
            ""SUNDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""TUESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""WEDNESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""THURSDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""FRIDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""SATURDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            }
        },
      ""GMA_PICKUP"": {
            ""SUNDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""MONDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""TUESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""WEDNESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""THURSDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""FRIDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            },
        ""SATURDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:59:59.9999999""
                },
          ""areaHours"": {
                    ""CURBSIDE"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:54:59.9999999""
                      }
            ],
            ""LOBBY"": [
              {
                        ""from"": ""08:00:00"",
                ""to"": ""16:59:59.9999999""
              }
            ]
          }
            }
        },
      ""KIOSK"": {
            ""SUNDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""TUESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""WEDNESDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""THURSDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""FRIDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            },
        ""SATURDAY"": {
                ""generalHours"": {
                    ""from"": ""08:00:00"",
            ""to"": ""16:29:59.9999999""
                },
          ""areaHours"": {
                    ""LOBBY"": [
                      {
                        ""from"": ""08:00:00"",
                ""to"": ""16:29:59.9999999""
                      }
            ],
            ""TABLESERVICE"": [
              {
                        ""from"": ""11:00:00"",
                ""to"": ""13:59:59.9999999""
              },
              {
                        ""from"": ""16:00:00"",
                ""to"": ""16:29:59.9999999""
              }
            ]
          }
            }
        }
    },
    ""facilities"": [
      ""Free WI-FI"",
      ""McCafe"",
      ""MOBILE ORDERING""
    ],
    ""name"": ""GLOBAL HEADQUARTERS RESTAURANT"",
    ""phone"": ""3122919224"",
    ""address"": {
        ""address"": ""WEST LOOP"",
      ""city"": ""CHICAGO"",
      ""state"": ""IL"",
      ""country"": ""US"",
      ""postCode"": ""60607""
    },
    ""additionalInformation"": {
        ""CompanyName"": ""McDonalds""
    }
}
]
");
        private static readonly Models.Configuration _configuration = JsonConvert.DeserializeObject<Models.Configuration>(@"
{
  ""restaurantID"": 39148,
  ""timeZone"": {
    ""standardTimeOffsetInMinutesFromUTC"": -300,
    ""daylightSavingTimeOffsetInMinutesFromUTC"": -240,
    ""daylightSavingTimeBegins"": ""2019-03-12T07:00:00Z"",
    ""daylightSavingTimeEnds"": ""2019-11-05T07:00:00Z""
  },
  ""activeChannels"": {
    ""GMA_DELIVERY"": {
      ""priceCode"": ""OTHER"",
      ""pointOfDistribution"": ""DELIVERY"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""DELIVERY"": ""DELIVERY""
      }
    },
    ""GMA_EATIN"": {
    ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP"",
        ""TABLESERVICE"": ""TABLESERVICE""
      }
},
    ""GMA_PICKUP"": {
    ""priceCode"": ""TAKEOUT"",
      ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP"",
        ""DRIVETHRU"": ""DRIVETHRU"",
        ""CURBSIDE"": ""CURBSIDE""
      }
},
    ""KIOSK"": {
    ""pointOfDistribution"": ""CSO"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP"",
        ""TABLESERVICE"": ""TABLESERVICE""
      }
}
  }
}
");
        private static readonly Models.State _state = JsonConvert.DeserializeObject<Models.State>(@"
{
  ""restaurantID"": 39148,
  ""connectivity"": ""ONLINE"",
  ""isOpen"": true,
  ""isHealthy"": true,
  ""currentTimezoneOffsetInMinutesFromUTC"": -300,
  ""businessDate"": ""2021-04-23"",
  ""businessDayOfWeek"": ""FRIDAY"",
  ""maxPossibleNPOS61ResponseTimesInMilliseconds"": {
    ""GetStoreStatus"": 120000,
    ""GetStoredb"": 120000,
    ""GetProduct"": 120000,
    ""GetNames"": 120000,
    ""GetProdOutage"": 120000,
    ""GetPromotiondb"": 120000,
    ""GetRestaurantPromotiondb"": 120000,
    ""DoFoeStore"": 120000,
    ""DoFoeStoreDT"": 120000,
    ""DoFoeStoreStaging"": 120000,
    ""TransferFromStaging"": 120000,
    ""GetOrderStatus"": 120000,
    ""UpdateOrderStatus"": 120000,
    ""SendOrderPaymentStatus"": 120000
  }
}
");
        private static readonly Models.Details _details = JsonConvert.DeserializeObject<Models.Details>(@"
{
  ""restaurantID"": 39148,
  ""marketID"": ""US"",
  ""marketStoreID"": 39148,
  ""longitude"": -87.653335,
  ""latitude"": 41.884084,
  ""locales"": [
    ""en-US"",
    ""es-US""
  ],
  ""channelHours"": {
    ""GMA_DELIVERY"": {
      ""SUNDAY"": {
        ""generalHours"": {
          ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
          ""DELIVERY"": [
            {
              ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
      },
      ""MONDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
},
      ""TUESDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
},
      ""WEDNESDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
},
      ""THURSDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
},
      ""FRIDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
},
      ""SATURDAY"": {
    ""generalHours"": {
        ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
        ""DELIVERY"": [
            {
            ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
}
    },
    ""GMA_EATIN"": {
    ""SUNDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""TUESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""WEDNESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""THURSDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""FRIDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""SATURDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    }
},
    ""GMA_PICKUP"": {
    ""SUNDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""MONDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""TUESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""WEDNESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""THURSDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""FRIDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    },
      ""SATURDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:59:59.9999999""
        },
        ""areaHours"": {
            ""CURBSIDE"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:54:59.9999999""
              }
          ],
          ""LOBBY"": [
            {
                ""from"": ""08:00:00"",
              ""to"": ""16:59:59.9999999""
            }
          ]
        }
    }
},
    ""KIOSK"": {
    ""SUNDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""TUESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""WEDNESDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""THURSDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""FRIDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    },
      ""SATURDAY"": {
        ""generalHours"": {
            ""from"": ""08:00:00"",
          ""to"": ""16:29:59.9999999""
        },
        ""areaHours"": {
            ""LOBBY"": [
              {
                ""from"": ""08:00:00"",
              ""to"": ""16:29:59.9999999""
              }
          ],
          ""TABLESERVICE"": [
            {
                ""from"": ""11:00:00"",
              ""to"": ""13:59:59.9999999""
            },
            {
                ""from"": ""16:00:00"",
              ""to"": ""16:29:59.9999999""
            }
          ]
        }
    }
}
  },
  ""facilities"": [
    ""Free WI-FI"",
    ""McCafe"",
    ""MOBILE ORDERING""
  ],
  ""name"": ""GLOBAL HEADQUARTERS RESTAURANT"",
  ""phone"": ""3122919224"",
  ""address"": {
    ""address"": ""WEST LOOP"",
    ""city"": ""CHICAGO"",
    ""state"": ""IL"",
    ""country"": ""US"",
    ""postCode"": ""60607""
  },
  ""additionalInformation"": {
    ""CompanyName"": ""McDonalds""
  }
}
");

        List<Models.Details> IExamplesProvider<List<Models.Details>>.GetExamples() { return _restaurants; }
        Models.Configuration IExamplesProvider<Models.Configuration>.GetExamples() { return _configuration; }
        Models.State IExamplesProvider<Models.State>.GetExamples() { return _state; }
        Models.Details IExamplesProvider<Models.Details>.GetExamples() { return _details; }
    }
}
