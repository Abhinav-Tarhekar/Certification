﻿namespace RestaurantBridge.Gateway.Cloud.V2
{
    // NOTE: DECRIPTION text ARE IN Github style MARKDOWN 
    //       blank line indicate paragraph
    //       doulbe space at end is a line break, 
    //       **BOLD**, 
    //       `CODE` 
    //       (4 space at begining also code),
    //       ```javascript\n...\n``` syntax highlighted 
    //       --- horizontal rule
    public static class CommonEndPointInformation
    {
        public const string STATUS_304_NOT_MODIFIED_RESPONSE = "A 304 status response without a body is returned when the 'If-None-Match Header' value matches the current eTag of the data.";
        public const string STATUS_200_SUCCESS = "A 200 status response with a body is returned when all mandatory fields are entered correctly";
        public const string STATUS_404_NOT_FOUND = "A 404 status response when the restaurantID is incorrect or not available";
    }
    #region SettingsEndpoint
    public static class SettingsGetEndpoint
    {
        public const string SUMMARY = "Returns the current settings of the selected restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant settings gathered 
from the currently active RFM package files 
and possibly augmented with data provided in the restaurant configurations maintained in consul.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class SettingsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Settings API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache 
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    #endregion

    public static class RestaurantsGetEndpoint
    {
        public const string SUMMARY = "Returns the restaurant details of all or a subset of restaurants based on the provided search parameters.";
        public const string DESCRIPTION = @"
Will return a list of restaurant details filtered to

* participate in the required channels (if provided)
* featuring the required facilities (if provided)
* within the specified distance of the geo coordinates (if provided)
* limited to the required distance (is provided)

and sorted by distance (if the search was location based).
";
    }
    public static class TaxParametersGetEndpoint
    {
        public const string SUMMARY = "Returns the taxparameters details for a given restaurant";
        public const string DESCRIPTION = @" 
This service provides the taxparameters details from RFM file store-db.xml and product-db.xml.

Contains tax information such as taxtable, taxtype taxcalculation method etc. 

";
    }

    public static class TaxParametersHeadEndpoint
    {
        public const string SUMMARY = "Returns the current TaxParameters API information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.

Cache Control Information

ETag

Expires

pragma

Example Response:

 cache-control: no-transformpublicmust-revalidateno-cache 

 connection: keep-alive 

 date: Mon07 Jun 2021 06:40:39 GMT 

 etag: 1a4fc55f17a9fbdad9b9f9d17835fb55dcb47d19908947c43cf16bedb2dc2ed3

 expires: 0 

 pragma: no-cache

 server: nginx/1.15.9 

 x-envoy-upstream-service-time: 31
";
    }
    public static class ChannelMenusGetEndpoint
    {
        public const string SUMMARY = "Returns the list of active menu for a given restaurant";
        public const string DESCRIPTION = @" 
This service provides the list of active menus.

It has the restaurant ID, the pricing, the currency, items available, customizations for items, and the schedule for different channels (which are basically different menus available to a user based on time and delivery/eat-in methods).

";
    }
    public static class ChannelMenusHeadEndpoint
    {
        public const string SUMMARY = "Returns the list of active menu for a given restaurant";
        public const string DESCRIPTION = @"This service provides the current API header information

 cache-control: publicno-cachemust-revalidateno-transform 

 connection: keep-alive 

 date: Wed23 Jun 2021 07:04:57 GMT 

 etag: 316d0992b160f11d9a73eba0d87fb868b019b4c103f8b7202c30e8d628dcb1f6 

 server: nginx/1.15.9
";
    }

    public static class CoatesMenusGetEndpoint
    {
        public const string SUMMARY = "Returns the list of active Coates menu for a given restaurant";
        public const string DESCRIPTION = @" 
This service provides the list of coates menus.

It has the restaurant ID, the address, the currency, list of products,daypart and the schedule for different channels (which are basically different menus available to a user based on time and delivery/eat-in methods).

";
    }
    public static class CoatesMenusHeadEndpoint
    {
        public const string SUMMARY = "Returns the list of active coates menu for a given restaurant";
        public const string DESCRIPTION = @"This service provides the current API header information

 cache-control: publicno-cachemust-revalidateno-transform 

 connection: keep-alive 

 date: Wed13 Dec 2023 07:04:57 GMT 

 etag: 316d0992b160f11d9a73eba0d87fb868b019b4c103f8b7202c30e8d628dcb1f6 

 server: nginx/1.15.9
";
    }
    public static class StateGetEndpoint
    {
        public const string SUMMARY = "Returns the current state of the identified restaurant.";
        public const string DESCRIPTION = @"
Returns information about the last polling result of the restaurant status.

The polling interval is defined at a market level. 

The websocket events will signal when a particular restaurant's state is changed.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }
    public static class DetailsGetEndpoint
    {
        public const string SUMMARY = "Returns the current details of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant details from RFM file store-db.xml.

Contains high level location and service abilities information for the current restaurant.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }
    public static class DetailsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Details API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache 
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    public static class ProductOutagesGetEndpoint
    {
        public const string SUMMARY = "Returns the current product outage of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant details from RFM file product-outages.xml.

Contains high level location and service abilities information for the current restaurant.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }
    public static class ConfigurationGetEndpoint
    {
        public const string SUMMARY = "Returns the current configuration of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant configuration as maintained in consul.

The websocket events will signal when a particular restaurant's configuration is changed.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class ConfigurationHeadEndpoint
    {
        public const string SUMMARY = "Returns the Configuration API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    public static class OverridesGetEndpoint
    {
        public const string SUMMARY = "Returns the current details of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant override details from DynamoDB database.";
    }

    public static class CombinedGetEndpointV2
    {
        public const string SUMMARY = "Returns all the current configurations of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the combined response of 4 different API for identifed restaurant.";

        public const string SETTINGS = "SETTINGS";
        public const string DETAILS = "DETAILS";
        public const string STATE = "STATE";
        public const string CONFIGURATION = "CONFIGURATION";
    }
}
