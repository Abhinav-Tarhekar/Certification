﻿using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using RestaurantBridge.Gateway.Cloud.Controllers.V2;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RestaurantBridge.Gateway.Cloud.API.Client;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1;
using Amazon.Runtime.Internal;
using Newtonsoft.Json;

namespace RestaurantBridge.Gateway.Cloud.V2
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/v2/restaurants")]
    public class APIController : ControllerBase
    {
        private readonly ILog Log;
        private readonly IService _service;

        private StatusCodeResult LoggedResponseCode(int statusCode, string path)
        {
            Log.Warn($"RESPONSE : {statusCode} : {path}");
            return StatusCode(statusCode);
        }
        private ObjectResult LoggedFailureCode(string errorCode, int statusCode, string path, Exception exception)
        {
            Log.Critical($"RESPONSE : {statusCode} : {path} : {errorCode} : EXCEPTION : {exception.Message}", exception);
            return StatusCode(statusCode, new API.V1.Models.ErrorDetail { code = errorCode, type = ErrorHandlingFunctions.ReturnErrorType(statusCode), title = exception.Message, detail = exception.StackTrace, service = System.Reflection.Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace });
        }

        private readonly IRestaurantSearchIndex _restaurantSearchIndex;
        private readonly RestaurantConfiguration.V1.IClientAdvanced _restaurantConfiguration;
        private readonly RestaurantMonitor.V1.IClientAdvanced _restaurantMonitor;
        private readonly Cache.ParsedDetails.V1.IClientAdvanced _cacheParsedDetails;
        private readonly Cache.ParsedChannelMenus.V1.IClientAdvanced _cacheParsedChannelMenus;
        private readonly Cache.ParsedTaxParameters.V1.IClientAdvanced _cacheParsedTaxParameters;
        private readonly Cache.ParsedProductOutages.V1.IClientAdvanced _cacheParsedProductOutages;
        private readonly OQMCMenu.Processor.V1.IClientAdvanced _oqmcOverrides;
        private readonly Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced _cacheParsedCoatesMenus;
        private readonly Cache.ParsedSettings.V1.IClientAdvanced _cacheParsedSettings;

        public APIController(
            ILog logger,
            IService service,
            IRestaurantSearchIndex restaurantSearchIndex,
            RestaurantConfiguration.V1.IClientAdvanced restaurantConfiguration,
            RestaurantMonitor.V1.IClientAdvanced restaurantMonitor,
            Cache.ParsedDetails.V1.IClientAdvanced cacheParsedDetails,
            Cache.ParsedChannelMenus.V1.IClientAdvanced cacheParsedChannelMenus,
            Cache.ParsedTaxParameters.V1.IClientAdvanced cacheParsedTaxParameters,
            Cache.ParsedProductOutages.V1.IClientAdvanced cacheParsedProductOutages,
            OQMCMenu.Processor.V1.IClientAdvanced oqmcOverrides,
            Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced cacheParsedCoatesMenus,
            Cache.ParsedSettings.V1.IClientAdvanced cacheParsedSettings

            )
        {
            Log = logger;
            _service = service;
            _restaurantSearchIndex = restaurantSearchIndex;
            _restaurantConfiguration = restaurantConfiguration;
            _restaurantMonitor = restaurantMonitor;
            _cacheParsedDetails = cacheParsedDetails;
            _cacheParsedChannelMenus = cacheParsedChannelMenus;
            _cacheParsedTaxParameters = cacheParsedTaxParameters;
            _cacheParsedProductOutages = cacheParsedProductOutages;
            _oqmcOverrides = oqmcOverrides;
            _cacheParsedCoatesMenus = cacheParsedCoatesMenus;
            _cacheParsedSettings = cacheParsedSettings;
        }

        // GET api/v2/restaurants
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = RestaurantsGetEndpoint.SUMMARY)]
        [SwaggerDescription(RestaurantsGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<List<Cloud.V2.Models.SearchedDetails>>> SearchRestaurantsAsync(
            /* Filters */
            [FromQuery] HashSet<long> restaurantIDs = null,
            [FromQuery] HashSet<string> marketIDs = null,
            [FromQuery] HashSet<string> channels = null,
            [FromQuery] HashSet<string> facilities = null,

            /* Position by restaurantID */
            [FromQuery] long? restaurantID = null,

            /* Position by marketID, marketStoreID */
            [FromQuery] string marketID = null,
            [FromQuery] long? marketStoreID = null,

            /* Position by GPS */
            [FromQuery] double? latitude = null,
            [FromQuery] double? longitude = null,

            /* limits */
            [FromQuery] double? maxDistanceInMeters = null,
            [FromQuery] uint? maxNumberOfRestaurantsToReturn = null)
        {
            try
            {
                var hasPositionSpecified_GPS = (latitude.HasValue || longitude.HasValue);
                if (hasPositionSpecified_GPS && (!(latitude.HasValue && longitude.HasValue)))
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Parameters 'latitude' and 'longitude' must be specified together or not at all");
                }

                var hasPositionSpecified_LegacyIDs = (!string.IsNullOrWhiteSpace(marketID) || marketStoreID.HasValue);
                if (hasPositionSpecified_LegacyIDs && (!(!string.IsNullOrWhiteSpace(marketID) && marketStoreID.HasValue)))
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Parameters 'marketID' and 'marketStoreID' must be specified together or not at all");
                }

                var hasPositionSpecified_ID = restaurantID.HasValue;

                var numberOfPositionsSpecified = ((hasPositionSpecified_GPS ? 1 : 0) + (hasPositionSpecified_LegacyIDs ? 1 : 0) + (hasPositionSpecified_ID ? 1 : 0));
                if (numberOfPositionsSpecified > 1)
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Only one set of positional parameters can be used at a time.");
                }

                if (maxDistanceInMeters.HasValue && numberOfPositionsSpecified == 0)
                {
                    return StatusCode(StatusCodes.Status400BadRequest, "Parameter 'maxDistanceInMeters' requires that a position is specified.");
                }

                if (hasPositionSpecified_GPS)
                {
                    if (latitude.Value < -90.0 || latitude.Value > 90.0)
                    {
                        return StatusCode(StatusCodes.Status400BadRequest, "Parameters out of range (-90.0 >= latitude =< 90.00)");
                    }
                    if (longitude.Value < -180.0 || longitude.Value > 180.0)
                    {
                        return StatusCode(StatusCodes.Status400BadRequest, "Parameters out of range (-180.0 >= longitude =< 180.00)");
                    }
                }

                var searchedDetails = await _restaurantSearchIndex.SearchRestaurantsAsync(
                    restaurantIDs,
                    marketIDs,
                    channels,
                    facilities,

                    restaurantID,

                    marketID,
                    marketStoreID,

                    latitude,
                    longitude,

                    maxDistanceInMeters,
                    maxNumberOfRestaurantsToReturn);

                var cacheControlHeaderValue = new CacheControlHeaderValue();
                cacheControlHeaderValue.Public = true;
                cacheControlHeaderValue.NoCache = true;
                cacheControlHeaderValue.MustRevalidate = true;
                cacheControlHeaderValue.NoTransform = true;

                Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                Response.Headers["Pragma"] = "no-cache";
                Response.Headers["Expires"] = "0";

                return StatusCode(StatusCodes.Status200OK, searchedDetails);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/configuration
        [HttpGet("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ConfigurationGetEndpoint.SUMMARY)]
        [SwaggerDescription(ConfigurationGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<Cloud.V2.Models.Configuration>> GetRestaurantConfigurationAsync(long restaurantID, string coatesStoreDetailsFilter = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (configuration, eTag) = await _restaurantConfiguration.GetRestaurantConfiguration_DESERIALIZE_AS_Async<Cloud.V2.Models.Configuration>(IF_NONE_MATCH, (long)restaurantID, coatesStoreDetailsFilter);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (configuration != null)
                {
                    configuration.activeChannels.ToList().ForEach(channel =>
                    {
                        var eligibleFulfillmentFlowMappingCnt = channel.Value.eligibleStoreAreasToRestaurantFulfillmentFlowMapping.Count();

                        //Podinfo
                        if (channel.Value.podInfo != null)
                        {
                            int podInfoCnt = 0;
                            channel.Value.podInfo.ToList().ForEach(fulfillment =>
                            {
                                if (fulfillment.Value == null)
                                {
                                    channel.Value.podInfo.Remove(fulfillment.Key);
                                    podInfoCnt++;
                                    if (eligibleFulfillmentFlowMappingCnt.Equals(podInfoCnt))
                                        channel.Value.podInfo = null;
                                }
                            });
                        }
                    });

                    configuration.marketConfigurationOverrides = JsonConvert.DeserializeObject<SortedDictionary<string, string>>(JsonConvert.SerializeObject(configuration.marketConfigurationOverrides.Where(item => !string.IsNullOrEmpty(item.Value)).ToDictionary()));

                    return StatusCode(StatusCodes.Status200OK, configuration);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v2/restaurants/{restaurantID}/configuration
        [HttpHead("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ConfigurationHeadEndpoint.SUMMARY)]
        [SwaggerDescription(ConfigurationHeadEndpoint.DESCRIPTION)]
        public async Task<ActionResult> GetRestaurantConfigurationHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _restaurantConfiguration.GetRestaurantConfigurationETagAsync((long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/state
        [HttpGet("{restaurantID}/state")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = StateGetEndpoint.SUMMARY)]
        [SwaggerDescription(StateGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<V2.Models.State>> GetRestaurantStateAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantState_DESERIALIZE_AS_Async<Cloud.V2.Models.State>((long)restaurantID, cancellationToken);
                if (state != null)
                {
                    // do not allow state responses to be cached anywhere

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    // convert business data to standard sortable format
                    state.businessDate = $"{state.businessDate.Substring(0, 4)}-{state.businessDate.Substring(4, 2)}-{state.businessDate.Substring(6, 2)}";
                    if (DateTime.TryParseExact(
                            state.businessDate,
                            "yyyy-MM-dd",
                            System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None,
                            out DateTime businessDate))
                    {
                        state.businessDayOfWeek = (Cloud.V2.Models.DayOfWeek)businessDate.DayOfWeek;
                    }

                    return StatusCode(StatusCodes.Status200OK, state);
                }
                else
                {
                    return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
                }
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/details
        [HttpGet("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DetailsGetEndpoint.SUMMARY)]
        [SwaggerDescription(DetailsGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<Cloud.V2.Models.Details>> GetRestaurantDetailsAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (details, eTag) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<Cloud.V2.Models.Details>(IF_NONE_MATCH, (long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (details != null)
                {
                    return StatusCode(StatusCodes.Status200OK, details);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v2/restaurants/{restaurantID}/details
        [HttpHead("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DetailsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(DetailsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult> GetRestaurantDetailsHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedDetails.GetRestaurantDetailsETagAsync((long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        #region Settings

        // GET api/v2/restaurants/{restaurantID}/settings
        [HttpGet("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = SettingsGetEndpoint.SUMMARY)]
        [SwaggerDescription(SettingsGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<V2.Models.Settings>> GetRestaurantSettingsAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (settings, eTag) = await _cacheParsedSettings.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(IF_NONE_MATCH, restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (settings != null)
                {
                    return StatusCode(StatusCodes.Status200OK, settings);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v2/restaurants/{restaurantID}/settings
        [HttpHead("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = SettingsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(SettingsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult> GetRestaurantSettingHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var eTag = await _cacheParsedSettings.GetRestaurantSettingsETagAsync(restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);
                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        #endregion
        // GET api/v2/restaurants/{restaurantID}/channelmenus
        [HttpGet("{restaurantID}/channelmenus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ChannelMenusGetEndpoint.SUMMARY)]
        [SwaggerDescription(ChannelMenusGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<V2.Models.ChannelMenus>> GetRestaurantChannelMenusAsync(long restaurantID, [FromQuery] string[] locales = null, [FromQuery] string[] channels = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (channelMenus, eTag) = await _cacheParsedChannelMenus.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<Cloud.V2.Models.ChannelMenus>(IF_NONE_MATCH, (long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (channelMenus != null)
                {
                    if (locales != null && locales.Length > 0)
                    {
                        var locales_to_remove = channelMenus.localizations.Keys.Except(locales).ToList();
                        foreach (var locale in locales_to_remove) { channelMenus.localizations.Remove(locale); }
                    }
                    if (channels != null && channels.Length > 0)
                    {
                        var channels_to_remove = channelMenus.channels.Keys.Except(channels).ToList();
                        foreach (var channel in channels_to_remove) { channelMenus.channels.Remove(channel); }
                    }
                    return StatusCode(StatusCodes.Status200OK, channelMenus);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/productlookup
        [HttpGet("{restaurantID}/productlookup")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ChannelMenusGetEndpoint.SUMMARY)]
        [SwaggerDescription(ChannelMenusGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<V2.Models.ProductLookup>> GetRestaurantProductLookupAsync(long restaurantID, [FromQuery] int[] productIDs , [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }

                // no support for eTag now
                var plu = await _service.GetRestaurantProductLookupV2Async(restaurantID, productIDs, cancellationToken);
                if (plu != null)
                {
                    return StatusCode(StatusCodes.Status200OK, plu);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v2/restaurants/{restaurantID}/channelmenus
        [HttpHead("{restaurantID}/channelmenus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ChannelMenusHeadEndpoint.SUMMARY)]
        [SwaggerDescription(ChannelMenusHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantChannelMenusHeadAsync(long restaurantID, [FromQuery] string[] locales = null, [FromQuery] string[] channels = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedChannelMenus.GetRestaurantChannelMenusETagAsync((long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CHANNELMENUSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }


        // GET api/v2/restaurants/{restaurantID}/taxparameters
        [HttpGet("{restaurantID}/taxparameters")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = TaxParametersGetEndpoint.SUMMARY)]
        [SwaggerDescription(TaxParametersGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]

        public async Task<ActionResult<V2.Models.TaxParameters>> GetRestaurantTaxParametersAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (taxParameters, eTag) = await _cacheParsedTaxParameters.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<Cloud.V2.Models.TaxParameters>(IF_NONE_MATCH, (long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (taxParameters != null)
                {
                    return StatusCode(StatusCodes.Status200OK, taxParameters);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v2/restaurants/{restaurantID}/taxparameters
        [HttpHead("{restaurantID}/taxparameters")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = TaxParametersHeadEndpoint.SUMMARY)]
        [SwaggerDescription(TaxParametersHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantTaxParametersHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedTaxParameters.GetRestaurantTaxParametersETagAsync((long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.TAXPARAMETERSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v2/restaurants/{restaurantID}/productoutages
        [HttpGet("{restaurantID}/productoutages")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductOutagesGetEndpoint.SUMMARY)]
        [SwaggerDescription(ProductOutagesGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<Cloud.V2.Models.ProductOutages>> GetRestaurantOutagesAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (products, eTag) = await _cacheParsedProductOutages.GetRestaurantProductOutagesAsync(IF_NONE_MATCH, (long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (products != null)
                {
                    var sortedProduct = new SortedSet<long>(products.Select(i => (long)i));
                    return StatusCode(StatusCodes.Status200OK, new Cloud.V2.Models.ProductOutages { restaurantID = restaurantID, productIDs = sortedProduct });
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTOUTAGES, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTOUTAGES, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTOUTAGES, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/v2/restaurants/oqmcmenu/{restaurantID}/overrides
        [HttpGet("oqmcmenu/{restaurantID}/overrides")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = OverridesGetEndpoint.SUMMARY)]
        [SwaggerDescription(OverridesGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<Cloud.V2.Models.OQMCOverrides>> GetOqmcOverridesAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var overrides = await _oqmcOverrides.GetOQMCOverrides_DESERIALIZE_AS_Async<Cloud.V2.Models.OQMCOverrides>(restaurantID);

                if (overrides != null)
                {
                    return StatusCode(StatusCodes.Status200OK, overrides);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.OQMCMENU, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.OQMCMENU, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.OQMCMENU, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }


        // GET api/v1/restaurants/{restaurantID}/coatesparser
        [HttpGet("{restaurantID}/coatesmenus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        [SwaggerOperation(Summary = CoatesMenusGetEndpoint.SUMMARY)]
        [SwaggerDescription(CoatesMenusGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]


        public async Task<ActionResult<RestaurantCoatesMenus>> GetRestaurantCoatesMenusAsync(long restaurantID, [FromQuery] HashSet<string> channels = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (coatesMenus, eTag) = await _cacheParsedCoatesMenus.GetRestaurantCoatesMenus_DESERIALIZE_AS_Async<Models.RestaurantCoatesMenus>(IF_NONE_MATCH, (long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (coatesMenus != null)
                {
                    if (channels != null && channels.Count > 0)
                    {
                        channels = new HashSet<string>(channels.Where(channel => !string.IsNullOrWhiteSpace(channel)).Select(channel => channel.ToUpperInvariant()));

                        foreach (var channel in coatesMenus.menus.Keys.Except(channels).ToList())
                        {
                            coatesMenus.menus.Remove(channel);
                        }
                    }

                    return StatusCode(StatusCodes.Status200OK, coatesMenus);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/coatesparser
        [HttpHead("{restaurantID}/coatesmenus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        [SwaggerOperation(Summary = CoatesMenusHeadEndpoint.SUMMARY)]
        [SwaggerDescription(CoatesMenusHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]

        public async Task<ActionResult> GetHeadCoatesMenusAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedCoatesMenus.GetRestaurantCoatesMenusETagAsync((long)restaurantID, cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.COATESMENUSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        [HttpGet("{restaurantID}/combined")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = CombinedGetEndpoint.SUMMARY)]
        [SwaggerDescription(CombinedGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<RestaurantCombinedV2>> GetRestaurantCombinedV2Async(
            long restaurantID,
            [FromQuery] HashSet<string> filterApis = null,
            [FromHeader(Name = RestaurantCombinedV2.ETag.IfNoneMatchSettings)] string IF_NONE_MATCH_SETTINGS = null,
            [FromHeader(Name = RestaurantCombinedV2.ETag.IfNoneMatchDetails)] string IF_NONE_MATCH_DETAILS = null,
            [FromHeader(Name = RestaurantCombinedV2.ETag.IfNoneMatchConfiguration)] string IF_NONE_MATCH_CONFIGURATION = null,
            [FromHeader(Name = RestaurantCombinedV2.ETag.IfNoneMatchState)] string IF_NONE_MATCH_STATE = null,
            CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = new RestaurantCombinedV2.ETag()
                {
                    Settings = IF_NONE_MATCH_SETTINGS,
                    Details = IF_NONE_MATCH_DETAILS,
                    Configuration = IF_NONE_MATCH_CONFIGURATION,
                    State = IF_NONE_MATCH_STATE
                };

                var combinedRestaurant = await _service.GetRestaurantCombinedV2Async(eTag, restaurantID, filterApis, cancellationToken);

                if (combinedRestaurant != null)
                    return new OkObjectResult(combinedRestaurant);

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

    }
}