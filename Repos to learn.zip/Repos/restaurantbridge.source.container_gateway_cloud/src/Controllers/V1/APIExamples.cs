﻿using System;
using System.Collections.Generic;

using Swashbuckle.AspNetCore.Filters;

using RestaurantBridge.Gateway.Cloud.V1.Models;

namespace RestaurantBridge.Gateway.Cloud.V1
{
    public class APIExamples :
        IExamplesProvider<Models.RestaurantConfigurationTimeZone>,
        IExamplesProvider<Models.RestaurantConfiguration>,
        IExamplesProvider<Models.RestaurantDetailsAddress>,
        IExamplesProvider<Models.RestaurantDetails>,
        IExamplesProvider<Models.RestaurantSettings>,
        IExamplesProvider<Models.RestaurantState>,
        IExamplesProvider<Models.Restaurant>,
        IExamplesProvider<Models.RestaurantCombined>
    {
        private const int standardTimeOffsetInMinutesFromUTC = -5 * 60;                // -5 hours for EST in Canada - for example
        private const int additionalDaylightSavingTimeOffsetInMinutes = 60;          // +1 hour
        private const int daylightTimeOffsetInMinutesFromUTC = standardTimeOffsetInMinutesFromUTC + additionalDaylightSavingTimeOffsetInMinutes;
        private static readonly RestaurantConfigurationTimeZone timeZone = new RestaurantConfigurationTimeZone
        {
            standardTimeOffsetInMinutesFromUTC = standardTimeOffsetInMinutesFromUTC,
            daylightSavingTimeOffsetInMinutesFromUTC = daylightTimeOffsetInMinutesFromUTC,
            // March 10, 2019 - 2:00 am EST time -> 3:00 am EDT
            daylightSavingTimeBegins = ((new DateTime(2019, 3, 10, 2, 0, 0, DateTimeKind.Utc).AddMinutes(-standardTimeOffsetInMinutesFromUTC))),
            // November 11, 2019 - 2:00 am EDT -> 1:00 am EST time
            daylightSavingTimeEnds = ((new DateTime(2019, 11, 3, 2, 0, 0, DateTimeKind.Utc).AddMinutes(-daylightTimeOffsetInMinutesFromUTC)))
        };
        private static readonly Models.RestaurantConfiguration configuration = new Models.RestaurantConfiguration
        {
            restaurantID = 2301,
            companyName = "McDonalds",
            isActiveForOrdering = true,
            timeZone = timeZone,
            encryption = new RestaurantConfigurationEncryption
            {
                activeKeyID = "6",
                keys = new Dictionary<string, string> { { "6", "*************************************" } }
            },
            totalizationMode = TotalizationMode.MARKET_DEFAULT
        };

        private static readonly RestaurantDetailsAddress address = new RestaurantDetailsAddress
        {
            address = "Address of Test Store 2301",
            city = "MUNCIE",
            state = "IN",
            country = "US",
            postCode = "2301"
        };
        private static readonly RestaurantDetails details = new RestaurantDetails
        {
            restaurantID = 2301,
            longitude = -44.708204,
            latitude = -22.6298,
            facilities = new HashSet<string> { "PLAYGROUND", "WI-FI", "DRIVE-THRU", "24HR", "MCCAFE", "MOBILE ORDERING" },
            name = "Common Test Store 2301 - BLTransition",
            phone = "1(555)444-3333",
            address = address
        };

        private static readonly RestaurantSettings settings = new RestaurantSettings
        {
            restaurantID = 2301,

        };

        private static readonly RestaurantState state = new RestaurantState
        {
            restaurantID = 2301,
            connectivity = Connectivity.ONLINE,
            isOpen = true,
            businessDate = "20190130",
            sequenceNumber = "18604873",
            maxPossibleNPOS61ResponseTimesInMilliseconds = new RestaurantStateMaxPossibleNPOS61ResponseTimesInMilliseconds {
                GetStoreStatus = 15000,
                GetStoredb = 90000,
                GetProduct = 90000,
                GetNames = 90000,
                GetProdOutage = 90000,
                GetPromotiondb = 90000,
                GetRestaurantPromotiondb = 90000,
                DoFoeStore = 15000,
                DoFoeStoreDT = 15000,
                DoFoeStoreStaging = 15000,
                TransferFromStaging = 15000,
                GetOrderStatus = 15000,
                UpdateOrderStatus = 15000,
                SendOrderPaymentStatus = 15000
            }
        };

        private static readonly Restaurant restaurant = new Restaurant
        {
            ID = 2301,
            configuration = configuration,
            details = details,
            settings = settings,
            state = state
        };
        public static readonly Models.RestaurantConfiguration config = new Models.RestaurantConfiguration
        {
            
            isActiveForOrdering = true,
            timeZone = configuration.timeZone,
            possiblePaymentProvidersAtPossibleFulfillmentFacilities = null

        };
        public static readonly RestaurantSettings Settings = new RestaurantSettings
        {

        };
        public static readonly RestaurantDetails Details = new RestaurantDetails
        {

        };
        private static readonly RestaurantCombined restaurantCombined = new RestaurantCombined
        {
            restaurantID = 2245,
            Configuration = config,
            Settings = Settings

        };
        

        Models.RestaurantConfigurationTimeZone IExamplesProvider<Models.RestaurantConfigurationTimeZone>.GetExamples() { return timeZone; }
        Models.RestaurantConfiguration IExamplesProvider<Models.RestaurantConfiguration>.GetExamples() { return configuration; }
        Models.RestaurantDetailsAddress IExamplesProvider<Models.RestaurantDetailsAddress>.GetExamples() { return address; }
        Models.RestaurantDetails IExamplesProvider<Models.RestaurantDetails>.GetExamples() { return details; }
        Models.RestaurantSettings IExamplesProvider<Models.RestaurantSettings>.GetExamples() { return settings; }
        Models.RestaurantState IExamplesProvider<Models.RestaurantState>.GetExamples() { return state; }
        Models.Restaurant IExamplesProvider<Models.Restaurant>.GetExamples() { return restaurant; }
        Models.RestaurantCombined IExamplesProvider<Models.RestaurantCombined>.GetExamples() { return restaurantCombined; }
    }
}
