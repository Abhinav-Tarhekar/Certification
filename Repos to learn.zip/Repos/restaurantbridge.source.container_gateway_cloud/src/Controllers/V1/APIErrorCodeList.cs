﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Controllers.V1
{
    public static class APIErrorCodeList
    {
        public const string RESTAURANTS = "MENC1001";
        public const string CONFIGURATION = "MENC1002";
        public const string CONFIGURATIONHEAD = "MENC1003";
        public const string STATE = "MENC1004";
        public const string DETAILS = "MENC1005";
        public const string DETAILSHEAD = "MENC1006";
        public const string PRODUCTOUTAGES = "MENC1011";
        public const string SETTINGS = "MENC1012";
        public const string SETTINGSHEAD = "MENC1013";
        public const string MENUS = "MENC1014";
        public const string MENUSCATEGORIES = "MENC1015";
        public const string MENUSCATEGORIESHEAD = "MENC1016";
        public const string MENUSWITHMENUID = "MENC1017";
        public const string PRODUCTSID = "MENC1018";
        public const string PRODUCTSHEAD = "MENC1019";
        public const string PRODUCTSALL = "MENC1020";
        public const string PRODUCTSALLPOST = "MENC1021";
        public const string PRODUCTSALLHEAD = "MENC1027";
        public const string PRODUCTSWITHID = "MENC1022";
        public const string PROMOTIONS = "MENC1023";
        public const string PROMOTIONSWITHID = "MENC1024";        
        public const string PROMOTIONSALLPOST = "MENC1025";
        public const string PROMOTIONSHEAD = "MENC1026";
        public const string RESTAURANTSCOMBINED = "MENC1028";

    }

    public class ErrorHandlingFunctions
    {
        public static string ReturnErrorType(int statusCode)
        {
            try {
                string retval = "TechnicalFault";
                var firstnum = statusCode.ToString().Substring(0, 1);
                switch (firstnum)
                {
                    case "5":
                        retval = "TechnicalFault";
                        break;
                    case "4":
                        retval = "ValidationFault";
                        break;
                    default:
                        retval = "TechnicalFault";
                        break;
                }          
                return retval;
            }
            catch(Exception e)
            {
                return "TechnicalFault";
            }
        }
    }

}





