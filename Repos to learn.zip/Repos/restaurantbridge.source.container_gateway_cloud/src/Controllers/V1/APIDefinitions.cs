﻿namespace RestaurantBridge.Gateway.Cloud.V1
{
    // NOTE: DECRIPTION text ARE IN Github style MARKDOWN 
    //       blank line indicate paragraph
    //       doulbe space at end is a line break, 
    //       **BOLD**, 
    //       `CODE` 
    //       (4 space at begining also code),
    //       ```javascript\n...\n``` syntax highlighted 
    //       --- horizontal rule
    #region CommonEndPointInformation
    public static class CommonEndPointInformation
    {
        public const string STATUS_304_NOT_MODIFIED_RESPONSE = "A 304 status response without a body is returned when the 'If-None-Match Header' value matches the current eTag of the data.";
        public const string STATUS_200_SUCCESS = "A 200 status response with a body is returned when all mandatory fields are entered correctly";
        public const string STATUS_404_NOT_FOUND = "A 404 status response when the restaurantID is incorrect or not available";
    }
    #endregion

    #region RestaurantsEndpoint
    public static class RestaurantsGetEndpoint
    {
        public const string SUMMARY = "Returns a list of Restaurant IDs";
        public const string DESCRIPTION = @"
Will return a list of restaurant IDs available and configured in consul  
for the market/markets covered by this instance of RB.
";
        public const string PARAM_ACTIVE_FOR_ORDERING = "Will filter returned restaurant IDs to only those active or inactive for digital ordering";
    }
    #endregion

    #region StateGetEndpoint
    public static class StateGetEndpoint
    {
        public const string SUMMARY = "Returns the current state of the identified restaurant.";
        public const string DESCRIPTION = @"
Returns information about the last polling result of the restaurant status.

The polling interval is defined at a market level. 

The websocket events will signal when a particular restaurant's state is changed.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }
    #endregion

    #region ConfigurationEndpoint
    public static class ConfigurationGetEndpoint
    {
        public const string SUMMARY = "Returns the current configuration of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant configuration as maintained in consul.

The websocket events will signal when a particular restaurant's configuration is changed.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class ConfigurationHeadEndpoint
    {
        public const string SUMMARY = "Returns the Configuration API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    #endregion

    #region DetailsEndpoint
    public static class DetailsGetEndpoint
    {
        public const string SUMMARY = "Returns the current details of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant details from RFM file store-db.xml.

Contains high level location and service abilities information for the current restaurant.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class DetailsGetAllEndpoint
    {
        public const string SUMMARY = "Returns the current details of all the restaurants in this market.";
        public const string DESCRIPTION = @"
This service provides the current restaurant details from RFM file store-db.xml.

Contains high level location and service abilities information for all the restaurants in this market.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class DetailsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Details API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache 
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    #endregion

    #region SettingsEndpoint
    public static class SettingsGetEndpoint
    {
        public const string SUMMARY = "Returns the current settings of the selected restaurant.";
        public const string DESCRIPTION = @"
This service provides the current restaurant settings gathered 
from the currently active RFM package files 
and possibly augmented with data provided in the restaurant configurations maintained in consul.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class SettingsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Settings API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.
Cache Control Information
ETag
Expires
pragma

Example Response:
 cache-control: no-transform, public, must-revalidate, no-cache 
 connection: keep-alive 
 date: Tue, 18 May 2022 21:21:39 GMT 
 etag: 848dbc80f3cde4da5eab2effc161d8c3d58bc6f439f27e39b96913c296c61af3 
 expires: 0 
 pragma: no-cache 
";
    }
    #endregion

    #region Product Endpoints
    public static class ProductGetEndpoint
    {
        public const string SUMMARY = "Returns a list of product IDs of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the list of product IDs available and defined in the product-db.xml.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class ProductHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Products API information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.

Cache Control Information

ETag

Expires

pragma

Example Response:
        cache-control: public, no-cache, must-revalidate, no-transform
        connection: keep-alive
        date: Fri, 06 Aug 2021 09:21:53 GMT
        etag: 49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb
        server: nginx/1.15.9
        x-envoy-upstream-service-time: 106 ";
    }

    public static class ProductsGetEndpoint
    {
        public const string SUMMARY = "Returns the all Product details of the identified restaurant.";
        public const string DESCRIPTION = @"
This operation will return the product details for all the products defined in the product-db.xml.

Utilizing the invalidation events allow a client to avoid polling  
and maintain a local cache of necessary data elements.
";
    }

    public static class ProductsPostEndpoint
    {
        public const string SUMMARY = "Returns the all Product details of the identified restaurant and product IDs.";
        public const string DESCRIPTION = @"
This operation will return the product details specified for the restaurant Id and product IDs for all the products defined in the product-db.xml.
";
    }

    public static class ProductsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Products API information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.

Cache Control Information

ETag

Expires

pragma

Example Response:
        cache-control: public, no-cache, must-revalidate, no-transform
        connection: keep-alive
        date: Fri, 06 Aug 2021 09:21:53 GMT
        etag: 49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb
        server: nginx/1.15.9
        x-envoy-upstream-service-time: 106 ";
    }
    public static class ProductByProductIDGetEndpoint
    {
        public const string SUMMARY = "Returns the Product details of the identified restaurant and product ID.";
        public const string DESCRIPTION = @"
This operation will return the product details specified for the restaurant Id and product ID for all the products defined in the product-db.xml.
";
    }
    #endregion

    #region MenusEndpoint
    public static class MenusGetEndpoint
    {
        public const string SUMMARY = "This operation will return the types of menus based on daypart for the restaurant specified in the request.";
        public const string DESCRIPTION = @"This operation will return the types of menus based on daypart. 
        The common dayparts defined are BREAKFAST, LUNCH and DINNER.
        The store-db.xml contains multiple categories defined under the <Categories> tag. 
        For this GET operation only the BREAKFAST, LUNCH, UNDEFINED categories are returned. 
        The UNDEFINED category is same as DINNER category.";
    }
    public static class MenuCategoriesGetEndpoint
    {
        public const string SUMMARY = "This operation will return all the menuid for the restaurant specified in the request. ";
        public const string DESCRIPTION = @"The sub-categories are returned in a hierarchical structure.
        Parent Category can be classified into Sub-Categories. 
        These sub-categories can be further broken down into sub-categories so on and so forth.";
    }
    public static class MenuIDGetEndpoint
    {
        public const string SUMMARY = "This operation will return all the sub-categories defined for the menu ID specified in the request.";
        public const string DESCRIPTION = @"Returns the subCategories of the restaurant according to the menuid.
		The sub-categories are returned in a hierarchical structure.
        Parent Category can be classified into Sub-Categories. 
        These sub-categories can be further broken down into sub-categories so on and so forth.";
    }
    public static class MenuCategoriesHeadEndpoint
    {
        public const string SUMMARY = "Returns the current MenuCategories API header information of the identified restaurant.";
        public const string DESCRIPTION = @"
        cache-control: public, no-cache, must-revalidate, no-transform 
        connection: keep-alive 
        date: Fri, 06 Aug 2021 09:21:53 GMT 
        etag: 49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb 
        server: nginx/1.15.9 
        x-envoy-upstream-service-time: 106 ";
    }

    #endregion

    #region PromotionsEndpoint
    public static class PromotionsIDByRestaurantIDGetEndpoint
    {
        public const string SUMMARY = "Returns the Promotions IDs of the identified restaurant.";
        public const string DESCRIPTION = @"
This operation will return the promotion IDs specified for the restaurant Id for all the products defined in the promotions-db.xml.
";
    }

    public static class PromotionsByRestaurantIDGetEndpoint
    {
        public const string SUMMARY = "Returns the Promotion details of the identified restaurant.";
        public const string DESCRIPTION = @"
This operation will return the promotion details specified for the restaurant Id for all the products defined in the promotions-db.xml.
";
    }

    public static class PromotionsPostByRestaurantIDPromotionIDGetEndpoint
    {
        public const string SUMMARY = "Returns the all Promotion details of the identified restaurant and promotion IDs.";
        public const string DESCRIPTION = @"
This operation will return the promotion details specified for the identified restaurant Id and promotion IDs for all the products defined in the product-db.xml.
";
    }

    public static class PromotionsHeadEndpoint
    {
        public const string SUMMARY = "Returns the current Promotions API information of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the current API header information.

Cache Control Information

ETag

Expires

pragma

Example Response:
        cache-control: public, no-cache, must-revalidate, no-transform
        connection: keep-alive
        date: Fri, 06 Aug 2021 09:21:53 GMT
        etag: 49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb
        server: nginx/1.15.9
        x-envoy-upstream-service-time: 106 ";
    }

    public static class PromotionsByRestaurantIDPromotionIDGetEndpoint
    {
        public const string SUMMARY = "Returns the Promotion details of the identified restaurant and promotion ID.";
        public const string DESCRIPTION = @"
This operation will return the promotion details specified for the restaurant Id and promotion ID for all the products defined in the promotions-db.xml.
";
    }
    #endregion
    public static class CombinedGetEndpoint
    {
        public const string SUMMARY = "Returns all the current configurations of the identified restaurant.";
        public const string DESCRIPTION = @"
This service provides the combined response of 5 different API for identifed restaurant.";

        public const string SETTINGS = "SETTINGS";
        public const string DETAILS = "DETAILS";
        public const string STATE = "STATE";
        public const string CONFIGURATION = "CONFIGURATION";
        public const string PROMOTIONS = "PROMOTIONS";
    }
}
