using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using RestaurantBridge.Gateway.Cloud.Controllers.V1;
using RestaurantBridge.Gateway.Cloud.Extension;
using RestaurantBridge.Gateway.Cloud.Services;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using RestaurantBridge.Gateway.Cloud.API.Client;

namespace RestaurantBridge.Gateway.Cloud.V1
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/v1/restaurants")]
    public class APIController : ControllerBase
    {
        private readonly ILog Log;
        private readonly IService _service;
        private StatusCodeResult LoggedResponseCode(int statusCode, string path)
        {
            Log.Warn($"RESPONSE : {statusCode} : {path}");
            return StatusCode(statusCode);
        }
        private ObjectResult LoggedFailureCode(string errorCode, int statusCode, string path, Exception exception)
        {
            Log.Critical($"RESPONSE : {statusCode} : {path} : {errorCode} : EXCEPTION : {exception.Message}", exception);
            return StatusCode(statusCode, new API.V1.Models.ErrorDetail { code = errorCode, type = ErrorHandlingFunctions.ReturnErrorType(statusCode), title = exception.Message, detail = exception.StackTrace, service = System.Reflection.Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace });
        }

        private readonly IProductsSpecifiedCache _productsSpecifiedCache;

        private readonly RestaurantConfiguration.V1.IClientAdvanced _restaurantConfiguration;
        private readonly RestaurantMonitor.V1.IClientAdvanced _restaurantMonitor;
        private readonly Cache.ParsedPromotions.V1.IClientAdvanced _cacheParsedPromotions;
        private readonly Cache.ParsedProductOutages.V1.IClientAdvanced _cacheParsedProductOutages;
        private readonly Cache.ParsedProducts.V1.IClientAdvanced _cacheParsedProducts;
        private readonly Cache.ParsedMenuCategories.V1.IClientAdvanced _cacheParsedMenuCategories;
        private readonly Cache.ParsedSettings.V1.IClientAdvanced _cacheParsedSettings;
        private readonly Cache.ParsedDetails.V1.IClientAdvanced _cacheParsedDetails;

        public APIController(
            ILog logger,            
            IService service,
            IProductsSpecifiedCache productsSpecifiedCache,
            RestaurantConfiguration.V1.IClientAdvanced restaurantConfiguration,
            RestaurantMonitor.V1.IClientAdvanced restaurantMonitor,
            Cache.ParsedPromotions.V1.IClientAdvanced cacheParsedPromotions,
            Cache.ParsedProductOutages.V1.IClientAdvanced cacheParsedProductOutages,
            Cache.ParsedProducts.V1.IClientAdvanced cacheParsedProducts,
            Cache.ParsedMenuCategories.V1.IClientAdvanced cacheParsedMenuCategories,
            Cache.ParsedSettings.V1.IClientAdvanced cacheParsedSettings,
            Cache.ParsedDetails.V1.IClientAdvanced cacheParsedDetails
            )
        {
            Log = logger;
            _service = service;
            _productsSpecifiedCache = productsSpecifiedCache;
            _restaurantConfiguration = restaurantConfiguration;
            _restaurantMonitor = restaurantMonitor;
            _cacheParsedPromotions = cacheParsedPromotions;
            _cacheParsedProductOutages = cacheParsedProductOutages;
            _cacheParsedProducts = cacheParsedProducts;
            _cacheParsedMenuCategories = cacheParsedMenuCategories;
            _cacheParsedSettings = cacheParsedSettings;
            _cacheParsedDetails = cacheParsedDetails;
        }


        // GET api/v1/restaurants
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = RestaurantsGetEndpoint.SUMMARY)]
        [SwaggerDescription(RestaurantsGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<ISet<long>>> GetRestaurantIDsAsync(
            [SwaggerParameter(RestaurantsGetEndpoint.PARAM_ACTIVE_FOR_ORDERING)] bool? isActiveForOrdering, 
            [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default
        )
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (restaurantIDs, eTag) = await _restaurantConfiguration.GetRestaurantIDsAsync(IF_NONE_MATCH, ((isActiveForOrdering ?? false) ? new HashSet<string> { "*" } : null),cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (restaurantIDs != null)
                {
                    return StatusCode(StatusCodes.Status200OK, restaurantIDs);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch(Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/state
        [HttpGet("{restaurantID}/state")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = StateGetEndpoint.SUMMARY)]
        [SwaggerDescription(StateGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<V1.Models.RestaurantState>> GetRestaurantStateAsync(long restaurantID,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var state = await _restaurantMonitor.GetRestaurantState_DESERIALIZE_AS_Async<Cloud.V1.Models.RestaurantState>(restaurantID,cancellationToken);
                if (state != null)
                {
                    // do not allow state responses to be cached anywhere

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    return StatusCode(StatusCodes.Status200OK, state);
                }
                else
                {
                    return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
                }
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.STATE, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        #region Configuration

        // GET api/v1/restaurants/{restaurantID}/configuration
        [HttpGet("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ConfigurationGetEndpoint.SUMMARY)]
        [SwaggerDescription(ConfigurationGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<Cloud.V1.Models.RestaurantConfiguration>> GetRestaurantConfigurationAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (internalConfiguration, eTag) = await _restaurantConfiguration.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(IF_NONE_MATCH, restaurantID);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;
                }

                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (internalConfiguration != null)
                {
                    var configuration = new Cloud.V1.Models.RestaurantConfiguration
                    {
                        restaurantID = internalConfiguration.restaurantID,
                        companyName = internalConfiguration.companyName,
                        isActiveForOrdering = internalConfiguration.isActiveForOrdering,
                        encryption = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationEncryption>(JsonConvert.SerializeObject(internalConfiguration.foe.crypto)),
                        timeZone = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationTimeZone>(JsonConvert.SerializeObject(internalConfiguration.timeZone)),
                        possiblePaymentProvidersAtPossibleFulfillmentFacilities = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationPaymentProviderFulfillmentFacilityMap>(JsonConvert.SerializeObject(internalConfiguration.possiblePaymentProvidersAtPossibleFulfillmentFacilities)),
                        totalizationMode = ((Cloud.V1.Models.TotalizationMode?)internalConfiguration.totalizationModeOverride) ?? Models.TotalizationMode.MARKET_DEFAULT,
                        foe = JsonConvert.DeserializeObject<RestaurantConfigurationFOE>(JsonConvert.SerializeObject(internalConfiguration.foe)),
                        marketConfigurationOverrides = JsonConvert.DeserializeObject<SortedDictionary<string, string>>(JsonConvert.SerializeObject(internalConfiguration.marketConfigurationOverrides.Where(item => !string.IsNullOrEmpty(item.Value)).ToDictionary()))
                    };
                    return StatusCode(StatusCodes.Status200OK, configuration);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATION, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/configuration
        [HttpHead("{restaurantID}/configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ConfigurationHeadEndpoint.SUMMARY)]
        [SwaggerDescription(ConfigurationHeadEndpoint.DESCRIPTION)]
  
        public async Task<ActionResult> GetRestaurantConfigurationHeadAsync(long restaurantID,CancellationToken cancellationToken= default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _restaurantConfiguration.GetRestaurantConfigurationETagAsync(restaurantID,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.CONFIGURATIONHEAD, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        #endregion

        #region Details

        // GET api/v1/restaurants/{restaurantID}/details
        [HttpGet("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DetailsGetEndpoint.SUMMARY)]
        [SwaggerDescription(DetailsGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]

        public async Task<ActionResult<V1.Models.RestaurantDetails>> GetRestaurantDetailsAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (details, eTag) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(IF_NONE_MATCH, restaurantID,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (details != null)
                {
                    return StatusCode(StatusCodes.Status200OK, details);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/details
        [HttpHead("{restaurantID}/details")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DetailsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(DetailsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]

        public async Task<ActionResult> GetRestaurantDetailsHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedDetails.GetRestaurantDetailsETagAsync(restaurantID,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;
                        ///ETag
                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        ///Cache Control
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;
                        ///No Cache
                        Response.Headers["Pragma"] = "no-cache";
                        ///Expires
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILSHEAD, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // GET api/v1/restaurants/*/details
        [HttpGet("*/details")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = DetailsGetAllEndpoint.SUMMARY)]
        [SwaggerDescription(DetailsGetAllEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<List<V1.Models.RestaurantDetails>>> GetRestaurantDetailsAll([FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var restaurantIDs = await _restaurantConfiguration.GetRestaurantIDsAsync();
                List<V1.Models.RestaurantDetails> restaurantDetails = new List<V1.Models.RestaurantDetails>();
                foreach (var restaurantID in restaurantIDs)
                {
                    restaurantDetails.Add((await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(null, restaurantID)).details);
                }
                using (var sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(restaurantDetails)));
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++) { builder.Append(bytes[i].ToString("x2")); }
                    var eTag = builder.ToString();

                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";

                    if (IF_NONE_MATCH == eTag)
                    {
                        return StatusCode(StatusCodes.Status304NotModified);
                    }
                    return StatusCode(StatusCodes.Status200OK, restaurantDetails);
                }
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.DETAILS, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }
        #endregion

        #region Settings

        // GET api/v1/restaurants/{restaurantID}/settings
        [HttpGet("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = SettingsGetEndpoint.SUMMARY)]
        [SwaggerDescription(SettingsGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult<V1.Models.RestaurantSettings>> GetRestaurantSettingsAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (settings, eTag) = await _cacheParsedSettings.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(IF_NONE_MATCH, restaurantID,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (settings != null)
                {
                    return StatusCode(StatusCodes.Status200OK, settings);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGS, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/settings
        [HttpHead("{restaurantID}/settings")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = SettingsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(SettingsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        public async Task<ActionResult> GetRestaurantSettingHeadAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedSettings.GetRestaurantSettingsETagAsync(restaurantID,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.SETTINGSHEAD, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        #endregion

        #region Menu

        // GET api/v1/restaurants/{restaurantID}/menus
        [HttpGet("{restaurantID}/menus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = MenusGetEndpoint.SUMMARY)]
        [SwaggerDescription(MenusGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<V1.Models.RestaurantMenu>>> GetRestaurantMenusAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (menuCategories, eTag) = await _cacheParsedMenuCategories.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(IF_NONE_MATCH, restaurantID, null,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (menuCategories != null)
                {
                    List<V1.Models.RestaurantMenu> restaurantMenues = new List<V1.Models.RestaurantMenu>();
                    foreach (var menuCategory in menuCategories)
                    {
                        if (menuCategory.display.parentID == -1)
                        {
                            restaurantMenues.Add(new V1.Models.RestaurantMenu
                            {
                                restaurantID = restaurantID,
                                ID = menuCategory.menuID,
                                dayPart = menuCategory.dayPart,
                                displayName = menuCategory.display.name
                            });
                        }
                    }
                    return StatusCode(StatusCodes.Status200OK, restaurantMenues);
                }
                else
                {
                    return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
                }
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUS, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/menus/categories
        [HttpGet("{restaurantID}/menus/categories")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = MenuCategoriesGetEndpoint.SUMMARY)]
        [SwaggerDescription(MenuCategoriesGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<V1.Models.RestaurantMenuCategory>>> GetRestaurantMenusCategoriesAsync(long restaurantID, [FromQuery] int? menuID = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (menuCategories, eTag) = await _cacheParsedMenuCategories.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(IF_NONE_MATCH, restaurantID, menuID,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (menuCategories != null)
                { 
                    return StatusCode(StatusCodes.Status200OK, menuCategories);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIES, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIES, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIES, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/menus/categories
        [HttpHead("{restaurantID}/menus/categories")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = MenuCategoriesHeadEndpoint.SUMMARY)]
        [SwaggerDescription(MenuCategoriesHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]

        public async Task<ActionResult> GetRestaurantMenusCategoriesHeadAsync(long restaurantID, [FromQuery] int? menuID = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedMenuCategories.GetRestaurantMenuCategoriesETagAsync(restaurantID, menuID,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIESHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIESHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSCATEGORIESHEAD, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/menus/{menuID}
        [HttpGet("{restaurantID}/menus/{menuID}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = MenuIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(MenuIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<V1.Models.RestaurantMenuTree>> GetRestaurantMenuAsync(long restaurantID, int menuID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (menuCategories, eTag) = await _cacheParsedMenuCategories.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(IF_NONE_MATCH, restaurantID, menuID,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }

                if ((menuCategories != null) && (menuCategories.Any()))
                {
                    var menuItems = menuCategories.Select(menuCatagory => new V1.Models.RestaurantMenuTree(menuCatagory)).ToDictionary(item => item.ID, item => item);
                    V1.Models.RestaurantMenuTree root = null;
                    foreach (var menuItem in menuItems)
                    {
                        if (menuItem.Value.display.parentID != -1)
                        {
                            menuItems[menuItem.Value.display.parentID].subCategories.Add(menuItem.Value);
                        }
                        else
                        {
                            root = menuItem.Value;
                        }
                    }
                    foreach (var menuItem in menuItems)
                    {
                        menuItem.Value.subCategories.Sort((a, b) => a.display.order.CompareTo(b.display.order));
                    }
                    return root;
                }
                else
                {
                    return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
                }
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSWITHMENUID, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSWITHMENUID, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.MENUSWITHMENUID, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        #endregion

        #region Products

        // GET api/v1/restaurants/{restaurantID}/products
        [HttpGet("{restaurantID}/products")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductGetEndpoint.SUMMARY)]
        [SwaggerDescription(ProductGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<int>>> GetRestaurantProductIDsAsync(long restaurantID, [FromQuery] int? categoryID, [FromQuery] bool? OUTAGE = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                bool byOutage = OUTAGE.HasValue;
                bool byCategory = categoryID.HasValue;

                bool badRequest = (byOutage && byCategory);

                if (badRequest)
                {
                    return StatusCode(StatusCodes.Status400BadRequest);
                }

                string resourceETag = null;
                ISet<int> products = null;
                if (byOutage)
                {
                    if (OUTAGE.Value)
                    {
                        (products, resourceETag) = await _cacheParsedProductOutages.GetRestaurantProductOutagesAsync(IF_NONE_MATCH, restaurantID,cancellationToken);
                    }
                    else
                    {
                        string [] eTags = new string[2] { null, null };
                        if (IF_NONE_MATCH != null && IF_NONE_MATCH.Contains('.'))
                        {
                            eTags = IF_NONE_MATCH.Split('.');
                        }
                        var (filteredProducts, productsETag) = await _cacheParsedProducts.GetRestaurantProductIDsAsync(eTags[0], restaurantID,cancellationToken);
                        var (productOutages, outagesETag) = await _cacheParsedProductOutages.GetRestaurantProductOutagesAsync(eTags[1], restaurantID,cancellationToken);
                        var comboETag = $"{productsETag}.{outagesETag}";
                        if (IF_NONE_MATCH != comboETag)
                        {
                            filteredProducts = filteredProducts ?? await _cacheParsedProducts.GetRestaurantProductIDsAsync(restaurantID,cancellationToken);
                            productOutages = productOutages ?? await _cacheParsedProductOutages.GetRestaurantProductOutagesAsync(restaurantID,cancellationToken);
                            if (filteredProducts != null && productOutages != null)
                            {
                                filteredProducts.ExceptWith(productOutages);
                                products = filteredProducts;
                                resourceETag = comboETag;
                            }
                        }
                        else
                        {
                            resourceETag = comboETag;  // combo not modified
                        }
                    }
                }
                else if (byCategory)
                {
                    // STEFAN - this should be optimized -- but no clients use it at the moment - would require and endpoint on the parsed cache
                    var (allProducts, eTag) = await _cacheParsedProducts.GetRestaurantProducts_DESERIALIZE_AS_Async<V1.Models.RestaurantProduct>(IF_NONE_MATCH, restaurantID,cancellationToken);
                    if (allProducts != null)
                    {
                        products = new HashSet<int>();
                        foreach (var product in allProducts)
                        {
                            if ((product.categories != null) && (product.categories.Any(c => c.ID == categoryID.Value)))
                            {
                                products.Add(product.ID);
                            }
                        }
                    }
                    resourceETag = eTag;
                }
                else
                {
                    (products,resourceETag) = await _cacheParsedProducts.GetRestaurantProductIDsAsync(IF_NONE_MATCH, restaurantID,cancellationToken);
                }

                if (resourceETag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (resourceETag.StartsWith("\"") ? resourceETag : $"\"{resourceETag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }

                if (resourceETag != null && IF_NONE_MATCH == resourceETag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }

                if (products != null)
                {
                    return StatusCode(StatusCodes.Status200OK, products);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSID, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSID, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSID, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // HEAD api/v1/restaurants/{restaurantID}/products
        [HttpHead("{restaurantID}/products")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductHeadEndpoint.SUMMARY)]
        [SwaggerDescription(ProductHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantProductOutageIDsHeadAsync(long restaurantID, [FromQuery] int? categoryID, [FromQuery] bool? OUTAGE = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                bool byOutage = OUTAGE.HasValue;
                bool byCategory = categoryID.HasValue;

                bool badRequest = (byOutage && byCategory);

                if (badRequest)
                {
                    return StatusCode(StatusCodes.Status400BadRequest);
                }

                string resourceETag = null;
                if (byOutage)
                {
                    if (OUTAGE.Value)
                    {
                        resourceETag = await _cacheParsedProductOutages.GetRestaurantProductOutagesETagAsync(restaurantID,cancellationToken);
                    }
                    else
                    {
                        var productsETag = await _cacheParsedProducts.GetRestaurantProductIDsETagAsync(restaurantID,cancellationToken);
                        var outagesETag = await _cacheParsedProductOutages.GetRestaurantProductOutagesETagAsync(restaurantID,cancellationToken);
                        if ((productsETag != null) && (outagesETag != null))
                        {
                            resourceETag = $"{productsETag}.{outagesETag}";
                        }
                    }
                }
                else if (byCategory)
                {
                    // STEFAN - this should be optimized -- but no clients use it at the moment - would require and endpoint on the parsed cache
                    // if the GET is changed we may also need to change the HEAD endpoint for this
                    resourceETag = await _cacheParsedProducts.GetRestaurantProductsETagAsync(restaurantID, cancellationToken);
                }
                else
                {
                    resourceETag = await _cacheParsedProducts.GetRestaurantProductIDsETagAsync(restaurantID, cancellationToken);
                }

                if (resourceETag != null)
                {
                    if (!string.IsNullOrWhiteSpace(resourceETag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (resourceETag.StartsWith("\"") ? resourceETag : $"\"{resourceETag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/products/*
        [HttpGet("{restaurantID}/products/*")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ISet<V1.Models.RestaurantProduct>))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductsGetEndpoint.SUMMARY)]
        [SwaggerDescription(ProductsGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantProductsAsync(long restaurantID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                byte[] dataGZIP;
                string eTag;

                (dataGZIP, eTag) = await _cacheParsedProducts.GetRestaurantProductsGZIPAsync(null, restaurantID);

                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }

                if (dataGZIP != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(dataGZIP, "application/json");
                    }
                    else
                    {
                        var dataJSON = await GZIP.Decompress(dataGZIP);
                        return Content(dataJSON, "application/json");
                    }
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALL, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALL, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALL, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // POST api/v1/restaurants/{restaurantID}/products/*
        [HttpPost("{restaurantID}/products/*")]
        [Consumes("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ISet<V1.Models.RestaurantProduct>))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductsPostEndpoint.SUMMARY)]
        [SwaggerDescription(ProductsPostEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantProductsSpecifiedAsync(long restaurantID, [FromBody] HashSet<int> productIDs)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var productsJSON = await _productsSpecifiedCache.GetMultipleAsync(restaurantID, productIDs);
                if (productsJSON != null)
                {
                    return this.Content(productsJSON, "application/json");
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLPOST, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLPOST, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLPOST, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // HEAD api/v1/restaurants/{restaurantID}/products/*
        [HttpHead("{restaurantID}/products/*")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(ProductsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantProductsHeadAsync(long restaurantID,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedProducts.GetRestaurantProductsETagAsync(restaurantID,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSALLHEAD, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        // GET api/v1/restaurants/{restaurantID}/products/{productID}
        [HttpGet("{restaurantID}/products/{productID}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(V1.Models.RestaurantProduct))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = ProductByProductIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(ProductByProductIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantProductAsync(long restaurantID, int productID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (productJSON, eTag) = await _productsSpecifiedCache.GetSingleAsync(restaurantID, productID);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (productJSON != null)
                {
                    return this.Content(productJSON, "application/json");
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSWITHID, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSWITHID, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PRODUCTSWITHID, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }

        #endregion

        #region Promotions

        // GET api/v1/restaurants/{restaurantID}/promotions
        [HttpGet("{restaurantID}/promotions")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsIDByRestaurantIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsIDByRestaurantIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<int>>> GetRestaurantPromotionIDsAsync(long restaurantID, [FromQuery] bool? ADVERTISABLE = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (promotionIDs, eTag) = await _cacheParsedPromotions.GetRestaurantPromotionIDsAsync(IF_NONE_MATCH, restaurantID, ADVERTISABLE,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (promotionIDs != null)
                {
                    return StatusCode(StatusCodes.Status200OK, promotionIDs);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // GET api/v1/restaurants/{restaurantID}/promotions/*
        [HttpGet("{restaurantID}/promotions/*")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsByRestaurantIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsByRestaurantIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<V1.Models.RestaurantPromotion>>> GetRestaurantPromotionsAsync(long restaurantID, [FromQuery] bool? ADVERTISABLE = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (promotions, eTag) = await _cacheParsedPromotions.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(IF_NONE_MATCH, restaurantID, ADVERTISABLE,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (promotions != null)
                {
                    return StatusCode(StatusCodes.Status200OK, promotions);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONS, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // POST api/v1/restaurants/{restaurantID}/promotions/*
        [HttpPost("{restaurantID}/promotions/*")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsPostByRestaurantIDPromotionIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsPostByRestaurantIDPromotionIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<ISet<V1.Models.RestaurantPromotion>>> GetRestaurantPromotionsSpecifiedAsync(long restaurantID, [FromBody] HashSet<int> promotionIDs, [FromQuery] bool? ADVERTISABLE = null, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (promotions, eTag) = await _cacheParsedPromotions.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(IF_NONE_MATCH, restaurantID, promotionIDs, ADVERTISABLE,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (promotions != null)
                {
                    return StatusCode(StatusCodes.Status200OK, promotions);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSALLPOST, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSALLPOST, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSALLPOST, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
        // HEAD api/v1/restaurants/{restaurantID}/promotions/*
        [HttpHead("{restaurantID}/promotions/*")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsHeadEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsHeadEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult> GetRestaurantPromotionsHeadAsync(long restaurantID, [FromQuery] bool? ADVERTISABLE = null, CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = await _cacheParsedPromotions.GetRestaurantPromotionsETagAsync(restaurantID, ADVERTISABLE,cancellationToken);
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                        var cacheControlHeaderValue = new CacheControlHeaderValue();
                        cacheControlHeaderValue.Public = true;
                        cacheControlHeaderValue.NoCache = true;
                        cacheControlHeaderValue.MustRevalidate = true;
                        cacheControlHeaderValue.NoTransform = true;

                        Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                        Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                        Response.Headers["Pragma"] = "no-cache";
                        Response.Headers["Expires"] = "0";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSHEAD, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSHEAD, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSHEAD, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }
        // GET api/v1/restaurants/{restaurantID}/promotions/{promotionID}
        [HttpGet("{restaurantID}/promotions/{promotionID}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = PromotionsByRestaurantIDPromotionIDGetEndpoint.SUMMARY)]
        [SwaggerDescription(PromotionsByRestaurantIDPromotionIDGetEndpoint.DESCRIPTION)]
        [SwaggerResponse(StatusCodes.Status304NotModified, CommonEndPointInformation.STATUS_304_NOT_MODIFIED_RESPONSE)]
        [SwaggerResponse(StatusCodes.Status200OK, CommonEndPointInformation.STATUS_200_SUCCESS)]
        [SwaggerResponse(StatusCodes.Status404NotFound, CommonEndPointInformation.STATUS_404_NOT_FOUND)]
        public async Task<ActionResult<V1.Models.RestaurantPromotion>> GetRestaurantPromotionAsync(long restaurantID, int promotionID, [FromHeader(Name = APIBase.IfNoneMatch)] string IF_NONE_MATCH = null,CancellationToken cancellationToken=default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (promotion, eTag) = await _cacheParsedPromotions.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(IF_NONE_MATCH, restaurantID, promotionID,cancellationToken);
                if (eTag != null)
                {
                    var entityTagHeaderValue = new EntityTagHeaderValue(tag: (eTag.StartsWith("\"") ? eTag : $"\"{eTag}\""), isWeak: false);

                    var cacheControlHeaderValue = new CacheControlHeaderValue();
                    cacheControlHeaderValue.Public = true;
                    cacheControlHeaderValue.NoCache = true;
                    cacheControlHeaderValue.MustRevalidate = true;
                    cacheControlHeaderValue.NoTransform = true;

                    Response.GetTypedHeaders().ETag = entityTagHeaderValue;
                    Response.GetTypedHeaders().CacheControl = cacheControlHeaderValue;

                    Response.Headers["Pragma"] = "no-cache";
                    Response.Headers["Expires"] = "0";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (promotion != null)
                {
                    return StatusCode(StatusCodes.Status200OK, promotion);
                }
                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSWITHID, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSWITHID, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.PROMOTIONSWITHID, StatusCodes.Status502BadGateway, Request.Path,  ex);
            }
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="restaurantID"></param>
        /// <param name="filterApis"></param>
        /// <param name="IF_NONE_MATCH"></param>
        [HttpGet("{restaurantID}/combined")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [SwaggerOperation(Summary = CombinedGetEndpoint.SUMMARY)]
        [SwaggerDescription(CombinedGetEndpoint.DESCRIPTION)]
        public async Task<ActionResult<RestaurantCombined>> GetRestaurantCombinedAsync(
            long restaurantID, 
            [FromQuery] HashSet<string> filterApis = null, 
            [FromHeader(Name = RestaurantCombined.ETag.IfNoneMatchSettings)] string IF_NONE_MATCH_SETTINGS = null,
            [FromHeader(Name = RestaurantCombined.ETag.IfNoneMatchDetails)] string IF_NONE_MATCH_DETAILS = null,
            [FromHeader(Name = RestaurantCombined.ETag.IfNoneMatchConfiguration)] string IF_NONE_MATCH_CONFIGURATION = null,
            [FromHeader(Name = RestaurantCombined.ETag.IfNoneMatchPromotions)] string IF_NONE_MATCH_PROMOTIONS = null,
            CancellationToken cancellationToken = default)
        {
            try
            {
                Metrics.SetRestaurantIdForTransaction(restaurantID);
                var eTag = new RestaurantCombined.ETag()
                {
                    Settings = IF_NONE_MATCH_SETTINGS,
                    Details = IF_NONE_MATCH_DETAILS,
                    Configuration = IF_NONE_MATCH_CONFIGURATION,
                    Promotions = IF_NONE_MATCH_PROMOTIONS
                };

                var combinedRestaurant = await _service.GetRestaurantCombinedAsync(eTag, restaurantID, filterApis, cancellationToken);

                if (combinedRestaurant != null)
                {
                    return new OkObjectResult(combinedRestaurant);
                }

                return LoggedResponseCode(StatusCodes.Status404NotFound, Request.Path);
            }
            catch (Services.Exceptions.RequestTimeoutException rtex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status504GatewayTimeout, Request.Path, rtex);
            }
            catch (Services.Exceptions.CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status503ServiceUnavailable, Request.Path, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(APIErrorCodeList.RESTAURANTSCOMBINED, StatusCodes.Status502BadGateway, Request.Path, ex);
            }
        }
    }
}
