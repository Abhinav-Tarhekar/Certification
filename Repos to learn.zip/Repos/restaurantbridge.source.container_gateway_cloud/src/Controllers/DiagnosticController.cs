﻿using System;
using System.Reflection;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Diagnostic
{
    [ApiController]
    [Produces("application/json")]
    [Route("diagnostic")]
    public class DiagnosticController : ControllerBase
    {
        private ILog Log;
        private readonly IConfiguration _configuration;
        private readonly Services.EventsManager _eventsManager;

        private ObjectResult LoggedFailureCode(int statusCode, Exception exception) { return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}"); }

        public DiagnosticController(ILog logger, IConfiguration configuration, Services.EventsManager eventsManager)
        {
            Log = logger;
            _configuration = configuration;
            _eventsManager = eventsManager;
        }

        // GET diagnostics/healthz
        [HttpGet("healthz")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public ActionResult GetHealth()
        {
            if (Program.CancellationTokenSource.IsCancellationRequested)
            {
                return StatusCode(StatusCodes.Status503ServiceUnavailable, "Instance shutting down ..");
            }

            return StatusCode(StatusCodes.Status200OK);
        }

        // GET diagnostics/version
        [HttpGet("version")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<string> GetVersions()
        {
            var version = $"{Assembly.GetEntryAssembly().GetName().Version} [{Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "UNKNOWN"}]";
            return StatusCode(StatusCodes.Status200OK, version);
        }

        // GET diagnostics/configuration
        [HttpGet("configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IConfiguration> GetConfiguration()
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _configuration);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        public class Insights
        {
            public string EnvironmentName { get; set; }
            public List<string> currentSubscribers { get; set; }
        }

        // GET diagnostics/insights
        [HttpGet("insights")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Insights))]
        public ActionResult<string> GetInsights()
        {
            return StatusCode(StatusCodes.Status200OK, new Insights 
            { 
                currentSubscribers = _eventsManager.CurrentSubscribers(),
                EnvironmentName = Environment.MachineName
            });
        }

        // GET diagnostics/stats
        [HttpGet("stats")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<string> GetStats()
        {
            return StatusCode(StatusCodes.Status200OK, "SOME DATA");
        }

        // GET diagnostics/dropsubscribers
        [HttpPut("dropsubscribers")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> DropSubscribersThatMatchPattern([FromQuery] string subscriberRegexPattern)
        {
            await _eventsManager.DropSubscribersThatMatchPatternAsync(subscriberRegexPattern);
            return StatusCode(StatusCodes.Status200OK);
        }

        // PUT diagnostics/eventinvalidation
        [HttpPut("eventinvalidation")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<string>> TriggerInvalidation(long restaurantID, string routingKey)
        {
            if (restaurantID <= 0)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            else
            {
                var result = await _eventsManager.TriggerInvalidation(restaurantID, routingKey);
                return StatusCode(result ? StatusCodes.Status200OK : StatusCodes.Status404NotFound);
            }
        }
    }
}