﻿using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;

namespace RestaurantBridge.Gateway.Cloud
{
    public static class Metrics
    {
        /// <summary>
        /// Add the <paramref name="restaurantID"/> value to Newrelic transaction as custom attribute <br/>
        /// Attribute name: <c>restaurantId</c>
        /// </summary>
        /// <param name="restaurantID"></param>
        public static void SetRestaurantIdForTransaction(long restaurantID)
        {
            var newrelicTransaction = NewRelic.Api.Agent.NewRelic.GetAgent().CurrentTransaction;
            if (newrelicTransaction != null)
                newrelicTransaction.AddCustomAttribute("restaurantId", restaurantID);
        }

        public static void SetTransaction(string category, RBEvent rbEvent)
        {
            NewRelic.Api.Agent.NewRelic.SetTransactionName(category, rbEvent.RoutingKey);
            var newrelicTransaction = NewRelic.Api.Agent.NewRelic.GetAgent().CurrentTransaction;
            if (newrelicTransaction != null)
            {
                newrelicTransaction.AddCustomAttribute("restaurantId", rbEvent.Data.RestaurantID);
                newrelicTransaction.AddCustomAttribute("correlationId", rbEvent.Data.EventID);
            }
        }
    }
}
