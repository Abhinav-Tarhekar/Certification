﻿using Common;
using Common.Logger;
using Common.RequestContext;
using Confluent.Kafka;
using McD.McFlow.Client.Library.Config;
using McD.McFlow.Client.Library.Config.Factory;
using McD.McFlow.Client.Library.Config.Producer;
using McD.McFlow.Client.Library.Producer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RestaurantBridge.Gateway.Cloud.Services;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;


namespace RestaurantBridge.Gateway.Cloud
{
    public class Startup
    {
        private static readonly string SERVICE_NAME = System.Reflection.Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace;

        private readonly ILog Log;
        private readonly IConfiguration Configuration;

        private int _number_of_active_requests;
    
        public Startup(ILog log, IConfiguration configuration)
        {
            Log = log;
            Configuration = configuration;
            _number_of_active_requests = 0;
        }

        private class ApiExplorerGroupPerVersionConvention : IControllerModelConvention
        {
            public void Apply(ControllerModel controller)
            {
                var controllerNamespace = controller.ControllerType.Namespace;
                var apiVersion = controllerNamespace?.Split('.').Last().ToLower();
                controller.ApiExplorer.GroupName = apiVersion;
            }
        }

        public void ConfigureServices(IServiceCollection services)
        {
            if (IsKafkaConfigurationPresent())
            {
                Log.Info("Calling  GetKafkaProducerConfig in IsKafkaConfigurationPresent method");
                services.AddSingleton(factory =>
                {
               

                var mcFlowProducerConfig = GetKafkaProducerConfig();
                    var configFactory = ConfigFactoryProvider.DefaultConfigFactory(mcFlowProducerConfig);
                    var producerBuilder = new McFlowProducerBuilder<string, string>(configFactory);
                    return producerBuilder.Build();               
                 });
            }

            services.AddSingleton<Common.IStringKeyValueStore>((_) =>
            {
                var instance = new Common.StringKeyValueStore.StringKeyValueStore_Redis(
                    Log,
                    Configuration.redis_connection_string,
                    Configuration.redis_database_number,
                    $"{Configuration.redis_key_prefix}:RestaurantBridge:CloudGateway:Subscribers");
                return instance;
            }); 
            services.AddSingleton<Common.IStringKeyHashStore>((_) =>
            {
                var storageType = Configuration.products_cache_specified_connection_string.Substring(0, Configuration.products_cache_specified_connection_string.IndexOf(':'));
                var details = Configuration.products_cache_specified_connection_string.Substring(storageType.Length + 1);
                switch (storageType)
                {
                    case "REDIS":
                        var parts = details.Split(',');
                        var dataBaseNumber = int.Parse(parts.First(s => s.StartsWith("dataBaseNumber=")).Substring("dataBaseNumber=".Length));
                        var keyPrefix = (parts.First(s => s.StartsWith("keyPrefix=")).Substring("keyPrefix=".Length));
                        var connectionString = string.Join(',', parts.Where(s => !(s.StartsWith("dataBaseNumber=") || s.StartsWith("keyPrefix="))));
                        var instance = new Common.StringKeyHashStore.StringKeyHashStore_Redis(
                            Log,
                            connectionString,
                            dataBaseNumber,
                            $"{keyPrefix}:RestaurantBridge:CloudGateway:ProductsSpecifiedCache");
                        return instance;
                    default:
                        throw new Exception($"storageType : {storageType} is not supported");
                }
            });
            services.AddSingleton<Common.IResourceLock>((_) =>
            {
                var instance = new Common.ResourceLock.ResourceLock_Redis(
                    Log,
                    Configuration.redis_connection_string,
                    Configuration.redis_database_number,
                    $"{Configuration.redis_key_prefix}:RestaurantBridge:CloudGateway:ProductsSpecifiedCache");
                return instance;
            });
            services.AddSingleton<Common.IEmpheralPubSub>((_) =>
            {
                var instance = new Common.EmpheralPubSub.EmpheralPubSub_Redis(
                    Log,
                    Configuration.redis_connection_string,
                    Configuration.redis_database_number,
                    $"{Configuration.redis_key_prefix}:RestaurantBridge",
                    () =>
                    {
                        Log.Critical("PUBSUB : REDIS DISCONNECT DETECTED : Could have lost messages. Consider 'kubectl rollout restart <deployment>' once connection/cluster issues are resolved !!");
                    },
                    () =>
                    {
                        Log.Critical("PUBSUB : REDIS RECONNECT DETECTED : Could have lost messages. Consider 'kubectl rollout restart <deployment>' once connection/cluster issues are resolved !!");
                    });
                return instance;
            });
            //services.AddSingleton<RestaurantBridge.Gateway.Cloud.AutomaticDecompressionHttpClient.IAutomaticDecompressionHttpClient>((_) =>
            //{
            //    var instance = new RestaurantBridge.Gateway.Cloud.AutomaticDecompressionHttpClient.AutomaticDecompressionHttpClient(this.Configuration.http_client_timeout_ms);
            //    return instance;
            //});
            services.AddSingleton<RestaurantConfiguration.V1.IClientAdvanced>((_) => new RestaurantConfiguration.V1.Client(Configuration.restaurant_configuration_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<RestaurantMonitor.V1.IClientAdvanced>((_) => new RestaurantMonitor.V1.Client(Configuration.restaurant_monitor_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedPromotions.V1.IClientAdvanced>((_) => new Cache.ParsedPromotions.V1.Client(Configuration.cache_parsed_promotions_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedProductOutages.V1.IClientAdvanced>((_) => new Cache.ParsedProductOutages.V1.Client(Configuration.cache_parsed_product_outages_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedProducts.V1.IClientAdvanced>((_) => new Cache.ParsedProducts.V1.Client(Configuration.cache_parsed_products_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedMenuCategories.V1.IClientAdvanced>((_) => new Cache.ParsedMenuCategories.V1.Client(Configuration.cache_parsed_menu_categories_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedChannelMenus.V1.IClientAdvanced>((_) => new Cache.ParsedChannelMenus.V1.Client(Configuration.cache_parsed_channel_menus_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedTaxParameters.V1.IClientAdvanced>((_) => new Cache.ParsedTaxParameters.V1.Client(Configuration.cache_parsed_tax_parameters_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedSettings.V1.IClientAdvanced>((_) => new Cache.ParsedSettings.V1.Client(Configuration.cache_parsed_settings_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.ParsedDetails.V1.IClientAdvanced>((_) => new Cache.ParsedDetails.V1.Client(Configuration.cache_parsed_details_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Cache.RFMXMLDatabases.V1.IClient>((_) => new Cache.RFMXMLDatabases.V1.Client(Configuration.cache_rfmxml_databases_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<Proxy.Premise.NPOS61.IClient>((_) => new Proxy.Premise.NPOS61.Client(Configuration.proxy_premise_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.proxy_premise_npos61_client_timeout_ms));
            services.AddSingleton<OQMCMenu.Processor.V1.IClientAdvanced>((_) => new OQMCMenu.Processor.V1.Client(Configuration.oqmcmenu_api_url,SERVICE_NAME,() =>RequestContext.CorrelationID.Value,Configuration.http_client_timeout_ms));
            services.AddSingleton<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>((_) => new Coates.Cache.ParsedRestaurantCoatesMenus.V1.Client(Configuration.cache_parsed_coates_menus_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms));
            services.AddSingleton<IService, Service>();           
            services.AddSingleton<EventsManager>((serviceProvider) =>
            {
                var eventsManager = new EventsManager(
                    serviceProvider.GetService<ILog>(), 
                    serviceProvider.GetService<Common.IEmpheralPubSub>(), Configuration,
                    serviceProvider.GetService<IMcFlowProducer<string, string>>(),
                    serviceProvider.GetService<Cache.ParsedDetails.V1.IClientAdvanced>(),
                    serviceProvider.GetService<RestaurantMonitor.V1.IClientAdvanced>(),
                    serviceProvider.GetService<RestaurantBridge.Common.IResourceLock>(),
                    Configuration.check_lock_auto_release_timeout_ms);
                return eventsManager;
            });
            services.AddSingleton<IConfiguration>(this.Configuration);
            services.AddSingleton<IProductsSpecifiedCache>((serviceProvider) =>
            {
                var products_cache_specified_ttl_ms = (Configuration.products_cache_specified_ttl_hours == -1) ? -1 : (Configuration.products_cache_specified_ttl_hours * 60 * 60 * 1000);
                var instance = new ProductsSpecifiedCache(
                    Log,
                    serviceProvider.GetService<EventsManager>(),
                    serviceProvider.GetService<Common.IStringKeyHashStore>(),
                    serviceProvider.GetService<Common.IResourceLock>(),
                    serviceProvider.GetService<Cache.ParsedProducts.V1.IClientAdvanced>(),
                    Configuration.products_cache_specified_build_auto_release_time_ms,
                    Configuration.products_cache_specified_build_take_retry_delay_ms,
                    products_cache_specified_ttl_ms);
                return instance;
            });

            if (Configuration.enableV2SearchRestaurantAPI)
            {
                services.AddSingleton<IRestaurantSearchIndex>((serviceProvider) =>
                {
                    var instance = new RestaurantSearchIndex(
                        Log,
                        serviceProvider.GetService<EventsManager>(),
                        serviceProvider.GetService<RestaurantConfiguration.V1.IClientAdvanced>(),
                        serviceProvider.GetService<Cache.ParsedDetails.V1.IClientAdvanced>());
                    return instance;
                });
            }
            else
                services.AddSingleton<IRestaurantSearchIndex, RestaurantSearchIndexBase>();

            services.AddControllers();
            services.AddMvc(options => {
                options.Conventions.Add(new ApiExplorerGroupPerVersionConvention());
                options.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
            }).AddNewtonsoftJson(options => {
                options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind; 
                options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
				options.SerializerSettings.DefaultValueHandling = DefaultValueHandling.Ignore; 
            });
            services.Configure<GzipCompressionProviderOptions>(options => options.Level = System.IO.Compression.CompressionLevel.Optimal);
            services.AddResponseCompression();

            services.AddSwaggerExamplesFromAssemblyOf<V1.APIExamples>();
            services.AddSwaggerGen(c =>
            {
                c.EnableAnnotations();
                c.CustomSchemaIds(x => x.FullName.Replace("+", "."));
                c.ExampleFilters();
                c.OperationFilter<RawXMLBodyFilter>();
                c.OperationFilter<SwaggerDescriptionOperationFilter>();
                var apiModelAnnotationsFile = Path.Combine(AppContext.BaseDirectory, "RestaurantBridge.Gateway.Cloud.API.xml");
                if (File.Exists(apiModelAnnotationsFile)) 
                { 
                    c.IncludeXmlComments(apiModelAnnotationsFile); 
                }
                else
                {
                    Log.Warn($"{apiModelAnnotationsFile} not found.");
                }
                c.OperationFilter<AddHeaderOperationFilter>(RequestContext.HTTP_HEADER_KEY_CLIENT_NAME, "The name of the service that is making the request", false);
                c.OperationFilter<AddHeaderOperationFilter>(RequestContext.HTTP_HEADER_KEY_CORRELATION_ID, "The correlation ID for this request.", false);
                c.SwaggerDoc("diagnostic", new OpenApiInfo { Title = $"{SERVICE_NAME} DIAGNOSTICS", Version = "diagnostic" });
                c.SwaggerDoc("npos61", new OpenApiInfo { Title = $"{SERVICE_NAME} API", Version = "npos61" });
                c.SwaggerDoc("v1", new OpenApiInfo { Title = $"{SERVICE_NAME} API", Version = "v1" });
                c.SwaggerDoc("v2", new OpenApiInfo { Title = $"{SERVICE_NAME} API", Version = "v2-preview" });
            });
            services.AddSwaggerGenNewtonsoftSupport();

            // Get the current settings.
            ThreadPool.GetMinThreads(out int minWorkerThreads, out int minIOCThreads);
            Log.Info($"Minimum thread was -> Workers={minWorkerThreads}, IOC={minIOCThreads}");
            ThreadPool.SetMinThreads(Configuration.min_worker_threads, Configuration.min_io_threads);
            Log.Info($"Minimum thread set to -> Workers={Configuration.min_worker_threads}, IOC={Configuration.min_io_threads}");

         services.AddHostedService(service => new BeaconBackgroundService(service.GetService<EventsManager>(), service.GetService<ILog>(), Configuration.beacon_interval_ms));
        }

        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            app.ApplicationServices.PrefetchDependencies(Program.CancellationTokenSource.Token).Wait();
         
            var webSocketOptions = new WebSocketOptions()
            {
                KeepAliveInterval = TimeSpan.FromSeconds(5),
            };
            app.UseWebSockets(webSocketOptions);

            app.UseResponseCompression();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swaggerDoc, httpRequest) =>
                {
                    if (httpRequest.Headers.ContainsKey("X-Forwarded-Path"))
                    {
                        var serverUrl = $"{httpRequest.Headers["X-Forwarded-Proto"]}://" +
                                        $"{httpRequest.Headers["X-Forwarded-Host"]}/" +
                                        $"{httpRequest.Headers["X-Forwarded-Path"]}";
                        swaggerDoc.Servers = new List<OpenApiServer>()
                        {
                            new OpenApiServer { Url = serverUrl }
                        };
                    }
                });
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/diagnostic/swagger.json", $"{SERVICE_NAME} DIAGNOSTIC");
                c.SwaggerEndpoint("/swagger/npos61/swagger.json", $"{SERVICE_NAME} API - NPOS61");
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{SERVICE_NAME} API - V1");
                c.SwaggerEndpoint("/swagger/v2/swagger.json", $"{SERVICE_NAME} API - V2");
            });
            app.Use((context, next) =>
            {
                var newrelicTransaction = NewRelic.Api.Agent.NewRelic.GetAgent().CurrentTransaction;

                string clientName = null;
                if (context.Request.Headers.TryGetValue(RequestContext.HTTP_HEADER_KEY_CLIENT_NAME, out StringValues svClientName))
                    clientName = svClientName.ToString();
                else
                    clientName = "unknown";

                RequestContext.ClientName.Init(clientName);

                string correlationId = null;
                if (context.Request.Headers.TryGetValue(RequestContext.HTTP_HEADER_KEY_CORRELATION_ID, out StringValues svCorrelationId))
                    correlationId = svCorrelationId.ToString();
                else
                    correlationId = "unknown";

                RequestContext.CorrelationID.Init(correlationId);

                if (newrelicTransaction != null)
                {
                    newrelicTransaction.AddCustomAttribute("client.name", clientName);
                    newrelicTransaction.AddCustomAttribute("correlationId", correlationId);
                }

                // NORMALLY WE SHOULD NOT DO THIS.
                // WE SHOULD NOT MAKE CODE PATH decisions BASED ON LOG LEVEL 
                // AS THIS CAN ALTER THE REALTIME BEHAVIOUR OF THE SERVICE 
                // BASED ON THE LOG LEVEL SELECTED
                // HOWEVER .. 
                // THE GW needs to be minimal overhead and creating this STRING on every request is significant overhead
                // BUT as we found out recently that we often have bad behaved actors in the stack (like LOYALTY MS) 
                // and we need a way of identifying such services
                // so we make an exception ... 
                // the GW should never run with debug in perf or prod unless investigating specific client issues.

                if (Configuration.min_log_level == Logger.Level.DEBUG)
                {
                    Log.Debug($"Request [{_number_of_active_requests}/{Configuration.http_max_concurrent_inbound_requests}] from 'mcd-client-name':'{RequestContext.ClientName.Value}' with 'mcd-correlation-id':'{RequestContext.CorrelationID.Value}' to '{context.Request.Method} :: {context.Request.Scheme}://{context.Request.Host}{context.Request.Path}{context.Request.QueryString}'");
                }

                return next.Invoke();
            });
            app.Use(async (context, next) =>
            {
                switch (context.Request.Path.Value?.ToLowerInvariant())
                {
                    case "/api/events":
                        if (context.WebSockets.IsWebSocketRequest)
                        {
                            var manager = context.RequestServices.GetService<EventsManager>().GlobalManager;
                            await HandleWebsocketAsync(manager, context);
                        }
                        else
                        {
                            context.Response.StatusCode = 400; // BadRequest
                        }
                        break;

                    case "/api/v1/events":
                        if (context.WebSockets.IsWebSocketRequest)
                        {
                            var manager = context.RequestServices.GetService<EventsManager>().V1Manager;
                            await HandleWebsocketAsync(manager, context);
                        }
                        else
                        {
                            context.Response.StatusCode = 400; // BadRequest
                        }
                        break;
                    case "/api/v2/events":
                        if (context.WebSockets.IsWebSocketRequest)
                        {
                            var manager = context.RequestServices.GetService<EventsManager>().V2Manager;
                            await HandleWebsocketAsync(manager, context);
                        }
                        else
                        {
                            context.Response.StatusCode = 400; // BadRequest
                        }
                        break;
                    default:
                        await next();
                        break;
                }
            });
            app.Use(async (context, next) =>
            {
                if (Configuration.http_max_concurrent_inbound_requests <= 0) 
                { 
                    await next.Invoke();
                }
                else
                { 
                    try
                    {
                        var currentNumberOfRequests = Interlocked.Increment(ref _number_of_active_requests);
                        if (currentNumberOfRequests > Configuration.http_max_concurrent_inbound_requests)
                        {
                            var message = $"Throtteling due to too many concurrent requests : There are {currentNumberOfRequests} active requests out of a possible {Configuration.http_max_concurrent_inbound_requests} !!";
                            Log.Error(message);
                            context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                            await context.Response.WriteAsync($"Error: 429 Too Many Requests\nHint: {message}");
                        }
                        else
                        {
                            await next.Invoke();
                        }
                    }
                    finally
                    {
                        var level = Interlocked.Decrement(ref _number_of_active_requests);
                    }
                }
            });

            
            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private async Task HandleWebsocketAsync(ISubscriberManager subscriberManager, HttpContext context)
        {
            Log.Info("Accepting Websocket request");
            using (WebSocket webSocket = await context.WebSockets.AcceptWebSocketAsync())
            {
                // as per new documentation from MS we are supposed to keep the pipeline running until we close the socket
                var socketFinishedTcs = new TaskCompletionSource<object>();
                await subscriberManager.WebsocketManager.HandleSubscribersAsync(context, webSocket, socketFinishedTcs, context.RequestAborted);
                await socketFinishedTcs.Task;
            }
        }

        private bool IsKafkaConfigurationPresent()
        {
            if (!string.IsNullOrEmpty(Configuration.schema_registry_url)
                && !string.IsNullOrEmpty(Configuration.bootstrap_server)
                && !string.IsNullOrEmpty(Configuration.event_topic_prefix)
                && !string.IsNullOrEmpty(Configuration.cluster_name)
                && Configuration.enable_rb_event_mcflow_publish)
            {
                Log.Info("Publishing message is enabled. Kakfa environment variables are configured.");
                return true;
            }
            else
                Log.Info("Publishing message is disabled. Check missing kafka environment variables.");
            return false;

        }
        private McFlowProducerConfig GetKafkaProducerConfig()
        {
            Log.Info("Creating ProducerConfig in GetKafkaProducerConfig method");            
            return new McFlowProducerConfig()
            {

                BootstrapServers = this.Configuration.bootstrap_server,
                SchemaRegistryConfig = new SchemaRegistryConfig
                {
                    SchemaRegistryUrl = this.Configuration.schema_registry_url
                },
                SecurityConfig = new SecurityConfig
                {
                    SecurityProtocol = SecurityProtocol.Ssl,
                    AwsStsRegion = Amazon.RegionEndpoint.GetBySystemName(this.Configuration.dynamodb_aws_region)
                },
                ProducerMessageConfig = new ProducerMessageConfig
                {
                    BatchSize = KafkaConstants.BatchSize,
                    BatchNumMessages = KafkaConstants.BatchNumMessages,
                    MessageMaxBytes = KafkaConstants.MessageMaxBytes,
                    CompressionType = CompressionType.Gzip
                },
                ProducerActionConfig = new ProducerActionConfig
                {
                    Acks = Acks.Leader,
                    DelayMs = KafkaConstants.DelayMS,
                    LingerMs = KafkaConstants.LingerMS,
                    MaxInFlightRequests = KafkaConstants.MaxInFlightRequests
                },
                ProducerMessageHeaders= new ProducerMessageHeaders()
                {
                    Domain=KafkaConstants.Domain,
                    Region=KafkaConstants.Region,
                    ClusterName=this.Configuration.cluster_name,
                    Publisher = KafkaConstants.Publisher,
                    HeaderVersion = KafkaConstants.HeaderVersion
                }
            };
        }
    }
}
