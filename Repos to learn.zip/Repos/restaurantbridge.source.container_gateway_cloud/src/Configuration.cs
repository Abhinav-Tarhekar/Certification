﻿using System;
using System.Text;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using Common.Logger;

namespace RestaurantBridge.Gateway.Cloud
{
    public interface IConfiguration
    {
        bool enableV2SearchRestaurantAPI { get; }
        string schema_registry_url { get; }
        string cluster_name { get; }
        string bootstrap_server { get; }
        string marketID { get; }
        string event_topic_prefix { get; }
        bool enable_rb_event_mcflow_publish { get; }
        bool publish_v1_events_mcflow { get; }
        bool publish_v2_events_mcflow { get; }
        bool enable_sub_event_mcflow_publish { get; }
        string dynamodb_aws_region { get; }
        string http_prefix { get; }
        int http_max_concurrent_inbound_requests { get; }
        int http_client_timeout_ms { get; }
        int proxy_premise_npos61_client_timeout_ms { get; }

        string restaurant_configuration_api_url { get; }
        string restaurant_monitor_api_url { get; }
        string cache_parsed_promotions_api_url { get; }
        string cache_parsed_product_outages_api_url { get; }
        string cache_parsed_products_api_url { get; }
        string cache_parsed_menu_categories_api_url { get; }
        string cache_parsed_channel_menus_api_url { get; }
        string cache_parsed_tax_parameters_api_url { get; }
        string cache_parsed_settings_api_url { get; }
        string cache_parsed_details_api_url { get; }
        string cache_rfmxml_databases_api_url { get; }
        string proxy_premise_api_url { get; }
        string oqmcmenu_api_url { get; }
        string cache_parsed_coates_menus_api_url { get; }
        string redis_connection_string { get; }
        int redis_database_number { get; }
        string redis_key_prefix { get; }
        string products_cache_specified_connection_string { get; }
        int products_cache_specified_ttl_hours { get; }
        int products_cache_specified_build_auto_release_time_ms { get; }
        int products_cache_specified_build_take_retry_delay_ms { get; }
        int beacon_interval_ms { get; }
        int min_worker_threads { get; }
        int min_io_threads { get; }
        Logger.Level min_log_level { get; }
        int check_lock_auto_release_timeout_ms { get; }
    }

    public class Configuration : IConfiguration
    {
        private const string ENABLE_V2_Search_RESTAURANT_API = "false"; //Default is false
        private const string HTTP_PREFIX = "http://*:8080";

        private const string MARKETID = "";
        private const string EVENT_TOPIC_PREFIX = "";

        private const string DYNAMODB_AWS_REGION = "us-east-1";
        private const string ENABLE_RB_EVENT_MCFLOW_PUBLISH = "true";
        private const string PUBLISH_V1_EVENTS_MCFLOW = "true";
        private const string PUBLISH_V2_EVENTS_MCFLOW = "true";
        private const string ENABLE_SUB_EVENT_MCFLOW_PUBLISH = "false";

        private const string SCHEMA_REGISTRY_URL = "";
        private const string BOOTSTRAP_SERVER = "";
        private const string CLUSTER_NAME = "";

        private const string HTTP_MAX_CONCURRENT_INBOUND_REQUESTS = "-1"; // NO RESTRICTION BY DEFAULT
        private const string HTTP_CLIENT_TIMEOUT_MS = "10000";
        private const string PROXY_PREMISE_NPOS61_CLIENT_TIMEOUT_MS = "120000"; // 2 min default, this should be the longest possible NPOS call timeout including retries

        private const string RESTAURANT_CONFIGURATION_API_URL = "http://localhost:8000/api";
        private const string RESTAURANT_MONITOR_API_URL = "http://localhost:8002/api";
        private const string CACHE_PARSED_PROMOTIONS_API_URL = "http://localhost:8004/api";
        private const string CACHE_PARSED_PRODUCT_OUTAGES_API_URL = "http://localhost:8005/api";
        private const string CACHE_PARSED_PRODUCTS_API_URL = "http://localhost:8006/api";
        private const string CACHE_PARSED_MENU_CATEGORIES_API_URL = "http://localhost:8007/api";
        private const string CACHE_PARSED_CHANNEL_MENUS_API_URL = "http://localhost:8011/api";
        private const string CACHE_PARSED_TAX_PARAMETERS_API_URL = "http://localhost:8012/api";
        private const string CACHE_PARSED_SETTINGS_API_URL = "http://localhost:8008/api";
        private const string CACHE_PARSED_DETAILS_API_URL = "http://localhost:8009/api";
        private const string CACHE_RFMXML_DATABASES_API_URL = "http://localhost:8003/api";
        private const string PROXY_PREMISE_API_URL = "http://localhost:8001/api";
        private const string OQMCMENU_API_URL = "https://localhost:9600/api";
        private const string CACHE_PARSED_COATES_MENUS_API_URL = "https://localhost:8019/api";



        private const string REDIS_CONNECTION_STRING = "localhost:6379";
        private const string REDIS_DATABASE_NUMBER = "1";
        private const string REDIS_KEY_PREFIX = "DEV";

        private const string PRODUCTS_CACHE_COMPLETE_RESPONSE_IN_MEMORY = "False";
        private const string PRODUCTS_CACHE_SPECIFIED_TTL_HOURS = "-1";
        private const string PRODUCTS_CACHE_SPECIFIED_BUILD_AUTO_RELEASE_TIME_MS = null;
        private const string PRODUCTS_CACHE_SPECIFIED_BUILD_TAKE_RETRY_DELAY_MS = "200";

        private const string BEACON_INTERVAL_MS = "10000";

        private const string MIN_WORKER_THREADS = "100";
        private const string MIN_IO_THREADS = "100";

        private const string MIN_LOG_LEVEL = "DEBUG";
        private const string CHECK_LOCK_AUTO_RELEASE_TIMEOUT_MS = "60000";

        public bool enableV2SearchRestaurantAPI { get; private set; }

        public bool enablefeatureflagMcFlow { get; private set; }
        public string schema_registry_url { get; private set; }
        public string bootstrap_server { get; private set; }
        public string cluster_name { get; private set; }
        public string marketID { get; private set; }
        public string event_topic_prefix { get; private set; }
        public bool enable_rb_event_mcflow_publish { get; private set; }
        public bool publish_v1_events_mcflow { get; private set; }
        public bool publish_v2_events_mcflow { get; private set; }
        public bool enable_sub_event_mcflow_publish { get; private set; }

        public string dynamodb_aws_region { get; private set; }
        public string http_prefix { get; private set; }
        public int http_max_concurrent_inbound_requests { get; private set; }
        public int http_client_timeout_ms { get; private set; }
        public int proxy_premise_npos61_client_timeout_ms { get; private set; }
        public string restaurant_configuration_api_url { get; private set; }
        public string restaurant_monitor_api_url { get; private set; }
        public string cache_parsed_promotions_api_url { get; private set; }
        public string cache_parsed_product_outages_api_url { get; private set; }
        public string cache_parsed_products_api_url { get; private set; }
        public string cache_parsed_menu_categories_api_url { get; private set; }
        public string cache_parsed_channel_menus_api_url { get; private set; }
        public string cache_parsed_coates_menus_api_url { get; private set; }
        public string cache_parsed_tax_parameters_api_url { get; private set; }
        public string cache_parsed_settings_api_url { get; private set; }
        public string cache_parsed_details_api_url { get; private set; }
        public string cache_rfmxml_databases_api_url { get; private set; }
        public string proxy_premise_api_url { get; private set; }
        public string oqmcmenu_api_url { get; private set; }
        public string redis_connection_string { get; private set; }
        public int redis_database_number { get; private set; }
        public string redis_key_prefix { get; private set; }
        public string products_cache_specified_connection_string { get; private set; }
        public int products_cache_specified_ttl_hours { get; private set; }
        public int products_cache_specified_build_auto_release_time_ms { get; private set; }
        public int products_cache_specified_build_take_retry_delay_ms { get; private set; }
        public int beacon_interval_ms { get; private set; }
        public int min_worker_threads { get; private set; }
        public int min_io_threads { get; private set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public Logger.Level min_log_level { get; private set; }
        public int check_lock_auto_release_timeout_ms { get; private set; }
        public Configuration()
        {
            enableV2SearchRestaurantAPI = bool.Parse(Environment.GetEnvironmentVariable("ENABLE_V2_Search_RESTAURANT_API") ?? ENABLE_V2_Search_RESTAURANT_API);
            http_prefix = Environment.GetEnvironmentVariable("HTTP_PREFIX") ?? HTTP_PREFIX;
            http_max_concurrent_inbound_requests = int.Parse(Environment.GetEnvironmentVariable("HTTP_MAX_CONCURRENT_INBOUND_REQUESTS") ?? HTTP_MAX_CONCURRENT_INBOUND_REQUESTS);
            http_client_timeout_ms = int.Parse(Environment.GetEnvironmentVariable("HTTP_CLIENT_TIMEOUT_MS") ?? HTTP_CLIENT_TIMEOUT_MS);
            proxy_premise_npos61_client_timeout_ms = int.Parse(Environment.GetEnvironmentVariable("PROXY_PREMISE_NPOS61_CLIENT_TIMEOUT_MS") ?? PROXY_PREMISE_NPOS61_CLIENT_TIMEOUT_MS);

            restaurant_configuration_api_url = Environment.GetEnvironmentVariable("RESTAURANT_CONFIGURATION_API_URL") ?? RESTAURANT_CONFIGURATION_API_URL;
            restaurant_monitor_api_url = Environment.GetEnvironmentVariable("RESTAURANT_MONITOR_API_URL") ?? RESTAURANT_MONITOR_API_URL;
            cache_parsed_promotions_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_PROMOTIONS_API_URL") ?? CACHE_PARSED_PROMOTIONS_API_URL;
            cache_parsed_product_outages_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_PRODUCT_OUTAGES_API_URL") ?? CACHE_PARSED_PRODUCT_OUTAGES_API_URL;
            cache_parsed_products_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_PRODUCTS_API_URL") ?? CACHE_PARSED_PRODUCTS_API_URL;
            cache_parsed_menu_categories_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_MENU_CATEGORIES_API_URL") ?? CACHE_PARSED_MENU_CATEGORIES_API_URL;
            cache_parsed_channel_menus_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_CHANNEL_MENUS_API_URL") ?? CACHE_PARSED_CHANNEL_MENUS_API_URL;
            cache_parsed_tax_parameters_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_TAX_PARAMETERS_API_URL") ?? CACHE_PARSED_TAX_PARAMETERS_API_URL;
            cache_parsed_settings_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_SETTINGS_API_URL") ?? CACHE_PARSED_SETTINGS_API_URL;
            cache_parsed_details_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_DETAILS_API_URL") ?? CACHE_PARSED_DETAILS_API_URL;
            cache_rfmxml_databases_api_url = Environment.GetEnvironmentVariable("CACHE_RFMXML_DATABASES_API_URL") ?? CACHE_RFMXML_DATABASES_API_URL;
            proxy_premise_api_url = Environment.GetEnvironmentVariable("PROXY_PREMISE_API_URL") ?? PROXY_PREMISE_API_URL;
            oqmcmenu_api_url = Environment.GetEnvironmentVariable("OQMCMENU_API_URL") ?? OQMCMENU_API_URL;
            cache_parsed_coates_menus_api_url = Environment.GetEnvironmentVariable("CACHE_PARSED_COATES_MENUS_API_URL") ?? CACHE_PARSED_COATES_MENUS_API_URL;

            redis_connection_string = Environment.GetEnvironmentVariable("REDIS_CONNECTION_STRING") ?? REDIS_CONNECTION_STRING;
            if (!redis_connection_string.Contains("connectTimeout")) { redis_connection_string += ",connectTimeout=30000"; }
            if (!redis_connection_string.Contains("syncTimeout")) { redis_connection_string += ",syncTimeout=15000"; }
            if (!redis_connection_string.Contains("keepAlive")) { redis_connection_string += ",keepAlive=10"; }

            redis_database_number = int.Parse(Environment.GetEnvironmentVariable("REDIS_DATABASE_NUMBER") ?? REDIS_DATABASE_NUMBER);
            redis_key_prefix = Environment.GetEnvironmentVariable("REDIS_KEY_PREFIX") ?? REDIS_KEY_PREFIX;

            products_cache_specified_connection_string = $"REDIS:dataBaseNumber={redis_database_number},keyPrefix={redis_key_prefix},{redis_connection_string}";
            products_cache_specified_connection_string = Environment.GetEnvironmentVariable("PRODUCTS_CACHE_SPECIFIED_CONNECTION_STRING") ?? products_cache_specified_connection_string;
            products_cache_specified_ttl_hours = int.Parse(Environment.GetEnvironmentVariable("PRODUCTS_CACHE_SPECIFIED_TTL_HOURS") ?? PRODUCTS_CACHE_SPECIFIED_TTL_HOURS);
            products_cache_specified_build_auto_release_time_ms = int.Parse(Environment.GetEnvironmentVariable("PRODUCTS_CACHE_SPECIFIED_BUILD_AUTO_RELEASE_TIME_MS") ?? PRODUCTS_CACHE_SPECIFIED_BUILD_AUTO_RELEASE_TIME_MS ?? http_client_timeout_ms.ToString());
            products_cache_specified_build_take_retry_delay_ms = int.Parse(Environment.GetEnvironmentVariable("PRODUCTS_CACHE_SPECIFIED_BUILD_TAKE_RETRY_DELAY_MS") ?? PRODUCTS_CACHE_SPECIFIED_BUILD_TAKE_RETRY_DELAY_MS);

            beacon_interval_ms = int.Parse(Environment.GetEnvironmentVariable("BEACON_INTERVAL_MS") ?? BEACON_INTERVAL_MS);
            if (beacon_interval_ms > 30000) { beacon_interval_ms = 30000; }

            min_worker_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_WORKER_THREADS") ?? MIN_WORKER_THREADS);
            min_io_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_IO_THREADS") ?? MIN_IO_THREADS);

            min_log_level = (Logger.Level)Enum.Parse(typeof(Logger.Level), Environment.GetEnvironmentVariable("MIN_LOG_LEVEL") ?? MIN_LOG_LEVEL);


            // Kafka Configuration
            schema_registry_url = Environment.GetEnvironmentVariable("SCHEMA_REGISTRY_URL") ?? SCHEMA_REGISTRY_URL;
            bootstrap_server = Environment.GetEnvironmentVariable("BOOTSTRAP_SERVER") ?? BOOTSTRAP_SERVER;
            cluster_name = Environment.GetEnvironmentVariable("CLUSTER_NAME") ?? CLUSTER_NAME;

            marketID = Environment.GetEnvironmentVariable("MARKETID") ?? MARKETID;
            event_topic_prefix = Environment.GetEnvironmentVariable("EVENT_TOPIC_PREFIX") ?? EVENT_TOPIC_PREFIX;
            enable_rb_event_mcflow_publish = "true".Equals(Environment.GetEnvironmentVariable(nameof(ENABLE_RB_EVENT_MCFLOW_PUBLISH)) ?? ENABLE_RB_EVENT_MCFLOW_PUBLISH, StringComparison.OrdinalIgnoreCase);
            publish_v1_events_mcflow = "true".Equals(Environment.GetEnvironmentVariable(nameof(PUBLISH_V1_EVENTS_MCFLOW)) ?? PUBLISH_V1_EVENTS_MCFLOW, StringComparison.OrdinalIgnoreCase);
            publish_v2_events_mcflow = "true".Equals(Environment.GetEnvironmentVariable(nameof(PUBLISH_V2_EVENTS_MCFLOW)) ?? PUBLISH_V2_EVENTS_MCFLOW, StringComparison.OrdinalIgnoreCase);
            enable_sub_event_mcflow_publish = "true".Equals(Environment.GetEnvironmentVariable(nameof(ENABLE_SUB_EVENT_MCFLOW_PUBLISH)) ?? ENABLE_SUB_EVENT_MCFLOW_PUBLISH, StringComparison.OrdinalIgnoreCase);
            dynamodb_aws_region = Environment.GetEnvironmentVariable("DYNAMODB_AWS_REGION") ?? DYNAMODB_AWS_REGION;
            check_lock_auto_release_timeout_ms = int.Parse(Environment.GetEnvironmentVariable("CHECK_LOCK_AUTO_RELEASE_TIMEOUT_MS") ?? CHECK_LOCK_AUTO_RELEASE_TIMEOUT_MS);
        }
        private string _configurationSummary;
        public override string ToString()
        {
            if (_configurationSummary == null)
            {
                StringBuilder configurationSummary = new StringBuilder();
                configurationSummary.AppendLine("CONFIGURATION :");
                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                configurationSummary.AppendLine($"http_prefix:                            {http_prefix}");
                configurationSummary.AppendLine($"http_max_concurrent_inbound_requests:   {http_max_concurrent_inbound_requests}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"http_client_timeout_ms:                 {http_client_timeout_ms}");
                configurationSummary.AppendLine($"proxy_premise_npos61_client_timeout_ms: {http_client_timeout_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"restaurant_configuration_api_url:     {restaurant_configuration_api_url}");
                configurationSummary.AppendLine($"restaurant_monitor_api_url:           {restaurant_monitor_api_url}");
                configurationSummary.AppendLine($"cache_parsed_promotions_api_url:      {cache_parsed_promotions_api_url}");
                configurationSummary.AppendLine($"cache_parsed_product_outages_api_url: {cache_parsed_product_outages_api_url}");
                configurationSummary.AppendLine($"cache_parsed_products_api_url:        {cache_parsed_products_api_url}");
                configurationSummary.AppendLine($"cache_parsed_menu_categories_api_url: {cache_parsed_menu_categories_api_url}");
                configurationSummary.AppendLine($"cache_parsed_channel_menus_api_url:   {cache_parsed_channel_menus_api_url}");
                configurationSummary.AppendLine($"cache_parsed_tax_parameters_api_url:  {cache_parsed_tax_parameters_api_url}");
                configurationSummary.AppendLine($"cache_parsed_settings_api_url:        {cache_parsed_settings_api_url}");
                configurationSummary.AppendLine($"cache_parsed_details_api_url:         {cache_parsed_details_api_url}");
                configurationSummary.AppendLine($"cache_rfmxml_databases_api_url:       {cache_rfmxml_databases_api_url}");
                configurationSummary.AppendLine($"proxy_premise_api_url:                {proxy_premise_api_url}");
                configurationSummary.AppendLine($"oqmcmenu_api_url:                     {oqmcmenu_api_url}");
                configurationSummary.AppendLine($"cache_parsed_coates_menus_api_url:   {cache_parsed_coates_menus_api_url}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"redis_connection_string:              {redis_connection_string}");
                configurationSummary.AppendLine($"redis_database_number:                {redis_database_number}");
                configurationSummary.AppendLine($"redis_key_prefix:                     {redis_key_prefix}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"products_cache_specified_connection_string:           {products_cache_specified_connection_string}");
                configurationSummary.AppendLine($"products_cache_specified_ttl_hours:                   {products_cache_specified_ttl_hours}");
                configurationSummary.AppendLine($"products_cache_specified_build_auto_release_time_ms:  {products_cache_specified_build_auto_release_time_ms}");
                configurationSummary.AppendLine($"products_cache_specified_build_take_retry_delay_ms:   {products_cache_specified_build_take_retry_delay_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"beacon_interval_ms:        {beacon_interval_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_worker_threads:        {min_worker_threads}");
                configurationSummary.AppendLine($"min_io_threads:            {min_io_threads}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_log_level:             {min_log_level}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"enableV2SearchRestaurantAPI:             {enableV2SearchRestaurantAPI}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"schema_registry_url:     {schema_registry_url}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"bootstrap_server:     {bootstrap_server}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"cluster_name:     {cluster_name}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"marketID: {MARKETID}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"dynamodb_aws_region: {dynamodb_aws_region}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"event_topic_prefix: {EVENT_TOPIC_PREFIX}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"enable_rb_event_mcflow_publish: {ENABLE_RB_EVENT_MCFLOW_PUBLISH}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"publish_v1_events_mcflow: {PUBLISH_V1_EVENTS_MCFLOW}");
                configurationSummary.AppendLine($"publish_v2_events_mcflow: {PUBLISH_V2_EVENTS_MCFLOW}");
                configurationSummary.AppendLine($"enable_sub_event_mcflow_publish: {ENABLE_SUB_EVENT_MCFLOW_PUBLISH}");

                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"check_lock_auto_release_timeout_ms: {CHECK_LOCK_AUTO_RELEASE_TIMEOUT_MS}");

                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                _configurationSummary = configurationSummary.ToString();
            }
            return _configurationSummary;
        }
    }
}