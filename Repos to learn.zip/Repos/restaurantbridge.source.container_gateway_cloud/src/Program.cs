﻿using System;
using System.Reflection;
using System.Threading;

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using Common;
using Common.Logger;
using Common.RequestContext;
using Common.Logger.NewRelic;
using RestaurantBridge.Gateway.Cloud.API.Logging;

namespace RestaurantBridge.Gateway.Cloud
{
    public class Program
    {
        public static CancellationTokenSource CancellationTokenSource = new CancellationTokenSource();
        public static void Shutdown(int? exitCode = null)
        {
            Environment.ExitCode = exitCode ?? 0;
            CancellationTokenSource.Cancel();
        }

        public static void Main()
        {
            var serviceName = Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace;
            var serviceVersion = $"{Assembly.GetEntryAssembly().GetName().Version} [{(Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "UNKNOWN")}]";

            using (Logger logger = new Logger_STDIO_JSON(serviceName, serviceVersion, () => RequestContext.ToImmutableContextDictionary()))
            {
                logger.Start();
                ILog Log = new InContextDecorator(logger);

                Log.Info($"Service: {serviceName}");
                Log.Info($"Version: {serviceVersion}");

                AppDomain.CurrentDomain.ProcessExit += (sender, eventArgs) => { Log.Info("ProcessExit event .. shutting down."); Shutdown(); };
                Console.CancelKeyPress += (sender, eventArgs) => { Log.Info("CancelKeyPress event .. shutting down."); eventArgs.Cancel = true; Shutdown(); };
                Thread.GetDomain().UnhandledException += (sender, eventArgs) => { Log.Fatal("UNHANDLED EXCEPTION .. shutting down :", eventArgs.ExceptionObject as Exception); Shutdown(-666); };
                
                IConfiguration configuration = new Configuration();
                Log.Info(configuration.ToString());

                logger.AdjustMinLogLevel(configuration.min_log_level);

                try
                {
                    WebHost.CreateDefaultBuilder()
                        .ConfigureAppConfiguration((_, config) => config.Sources.Clear())
                        .ConfigureLogging(config =>
                        { 
                            config.ClearProviders();
                            config.AddProvider(new CustomLoggingProvider(Log, Convert.ToInt32(configuration.min_log_level)));
                            config.SetMinimumLevel(CustomLogger.GetMinLevel(Convert.ToInt32(configuration.min_log_level)));
                            config.AddFilter("Microsoft",LogLevel.Warning);
                            config.AddFilter("System",LogLevel.Warning);
                        })
                        .SuppressStatusMessages(true)
                        .UseUrls(configuration.http_prefix)
                        .ConfigureServices(s => {
                            s.AddSingleton<ILog>(Log);
                            s.AddSingleton<IConfiguration>(configuration);
                        })
                        .UseStartup<Startup>()
                        .Build()
                        .RunAsync(CancellationTokenSource.Token)
                        .Wait();
                }
                catch(Exception ex)
                {
                    Log.Critical($"UNEXPECTED RUNTIME EXCEPTION : {ex.Message}", ex);
                }

                Log.Info($"Shutdown complete !!");
            }
        }
    }
}
