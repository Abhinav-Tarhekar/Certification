﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RestaurantBridge.Gateway.Cloud
{
    [AttributeUsage(AttributeTargets.Method)]
    public class RawXMLBodyAttribute : Attribute
    {
        public RawXMLBodyAttribute()
        {
            ParameterName = "body";
            Required = true;
            MediaType = "text/xml";
            Format = "text";
        }

        public string Format { get; set; }

        public string MediaType { get; set; }

        public bool Required { get; set; }

        public string ParameterName { get; set; }
    }
    public class RawXMLBodyFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var rawXMLBodyAttributes = context.ApiDescription.CustomAttributes().Where(x => x.GetType() == typeof(RawXMLBodyAttribute));

            if (rawXMLBodyAttributes.Any())
            {
                if (operation.RequestBody == null)
                {
                    operation.RequestBody = new OpenApiRequestBody();
                }
                if (operation.RequestBody.Content == null)
                {
                    operation.RequestBody.Content = new Dictionary<string, OpenApiMediaType>();
                }
                if (!operation.RequestBody.Content.ContainsKey("text/xml"))
                {
                    operation.RequestBody.Content.Add("text/xml", new OpenApiMediaType()
                    {
                        Schema = new OpenApiSchema()
                        {
                            Type = "object"
                        }
                    });
                }
            }
        }
    }

    [AttributeUsage(AttributeTargets.Method)]
    public class SwaggerDescriptionAttribute : Attribute
    {
        public string Description { get; private set; }

        public SwaggerDescriptionAttribute(string description)
        {
            this.Description = description;
        }
    }
    public class SwaggerDescriptionOperationFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var description = context.ApiDescription.CustomAttributes().Where(x => x.GetType() == typeof(SwaggerDescriptionAttribute)).Select(x => ((SwaggerDescriptionAttribute)x).Description).FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(description)) { operation.Description = description; }
        }
    }
}
