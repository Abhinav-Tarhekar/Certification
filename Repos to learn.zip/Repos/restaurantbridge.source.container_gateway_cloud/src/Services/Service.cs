﻿using Common;
using Newtonsoft.Json;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using RestaurantBridge.Gateway.Cloud.V2;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public partial class Service : IService
    {
        private readonly ILog Log;
        private readonly RestaurantConfiguration.V1.IClientAdvanced _restaurantConfiguration;
        private readonly Cache.ParsedPromotions.V1.IClientAdvanced _cacheParsedPromotions;
        private readonly Cache.ParsedSettings.V1.IClientAdvanced _cacheParsedSettings;
        private readonly Cache.ParsedDetails.V1.IClientAdvanced _cacheParsedDetails;
        private readonly RestaurantMonitor.V1.IClientAdvanced _restaurantMonitor;
        private readonly Cache.ParsedChannelMenus.V1.IClientAdvanced _cacheParsedChannelMenus;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="restaurantConfiguration"></param>
        /// <param name="cacheParsedPromotions"></param>
        /// <param name="cacheParsedSettings"></param>
        /// <param name="cacheParsedDetails"></param>
        /// <param name="empheralPubSub"></param>
        public Service(ILog logger, RestaurantConfiguration.V1.IClientAdvanced restaurantConfiguration, Cache.ParsedPromotions.V1.IClientAdvanced cacheParsedPromotions, Cache.ParsedSettings.V1.IClientAdvanced cacheParsedSettings, Cache.ParsedDetails.V1.IClientAdvanced cacheParsedDetails, RestaurantMonitor.V1.IClientAdvanced restaurantMonitor, Cache.ParsedChannelMenus.V1.IClientAdvanced cacheParsedChannelMenus)
        {
            Log = logger;
            _restaurantConfiguration = restaurantConfiguration;
            _cacheParsedPromotions = cacheParsedPromotions;
            _cacheParsedSettings = cacheParsedSettings;
            _cacheParsedDetails = cacheParsedDetails;
            _restaurantMonitor = restaurantMonitor;
            _cacheParsedChannelMenus = cacheParsedChannelMenus;
        }

        public async Task<RestaurantCombined> GetRestaurantCombinedAsync(RestaurantCombined.ETag eTag, long restaurantID, HashSet<string> filterApis = null, CancellationToken cancellationToken = default)
        {
            var restaurantCombined = new RestaurantCombined();
            restaurantCombined.ETags = new RestaurantCombined.ETag();

            restaurantCombined.restaurantID = restaurantID;

            string apiNames = null;

            HashSet<string> upperFilters = null;
            if (filterApis != null)
            {
                upperFilters = filterApis.Select(x => x.ToUpper()).ToHashSet();
                apiNames = string.Join(',', upperFilters);
            }
            else
                apiNames = "ALL";

            Log.Info($"{nameof(restaurantCombined)}:{nameof(GetRestaurantCombinedAsync)}: Filters applied are : {apiNames} for RestaurantID: {restaurantID}");

            List<Task<object>> tasks = new List<Task<object>>();

            var headers = eTag.GetKeys();

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpoint.SETTINGS))
                tasks.Add(SetRestaurantSettingAsync(headers, restaurantID, restaurantCombined, cancellationToken));

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpoint.DETAILS))
                tasks.Add(SetRestaurantDetailsAsync(headers, restaurantID, restaurantCombined, cancellationToken));
            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpoint.STATE))
                tasks.Add(SetRestaurantStateAsync(restaurantID, restaurantCombined, cancellationToken));

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpoint.CONFIGURATION))
                tasks.Add(SetRestaurantConfigurationAsync(headers, restaurantID, restaurantCombined, cancellationToken));

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpoint.PROMOTIONS))
                tasks.Add(SetRestaurantPromotionAsync(headers, restaurantID, restaurantCombined, cancellationToken));

            if (tasks.Count == 0)
            {
                Log.Warn("Invalid filter parameters");
                return null;
            }

            await Task.WhenAll(tasks).ConfigureAwait(false);

            if (tasks.All(task => task.Result == null))
                return null; // if the restaurant does not exist, we return NULL (404)

            var failedTask = tasks.FirstOrDefault(x => x.Exception is not null);
            if (failedTask != null)
                throw failedTask.Exception;

            return restaurantCombined;
        }

        async Task<object> SetRestaurantSettingAsync(Dictionary<string, string> headers, long restaurantID, RestaurantCombined restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombined.ETag.IfNoneMatchSettings, out string if_none_match);
            var (settings, eTag) = await _cacheParsedSettings.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantSettings>(if_none_match, restaurantID, cancellationToken);
            if (settings == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Settings = eTag;
                    return eTag;
                }

                Log.Warn("Missing setting object for " + restaurantID);
                return null;
            }
            restaurantCombined.ETags.Settings = eTag;
            restaurantCombined.Settings = settings;
            return settings;
        }

        async Task<object> SetRestaurantDetailsAsync(Dictionary<string, string> headers, long restaurantID, RestaurantCombined restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombined.ETag.IfNoneMatchDetails, out string if_none_match);
            var (details, eTag) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<RestaurantDetails>(if_none_match, restaurantID, cancellationToken);
            if (details == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Details = eTag;
                    return eTag;
                }

                Log.Warn("Missing details object for " + restaurantID);
                return null;
            }

            restaurantCombined.ETags.Details = eTag;
            restaurantCombined.Details = details;
            return details;
        }

        async Task<object> SetRestaurantStateAsync(long restaurantID, RestaurantCombined restaurantCombined, CancellationToken cancellationToken)
        {
            var state = await _restaurantMonitor.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantState>(restaurantID, cancellationToken);
            if (state == null)
            {
                Log.Warn("Missing state object for " + restaurantID);
                return null;
            }

            restaurantCombined.State = state;
            return state;
        }

        async Task<object> SetRestaurantConfigurationAsync(Dictionary<string, string> headers, long restaurantID, RestaurantCombined restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombined.ETag.IfNoneMatchConfiguration, out string if_none_match);
            var (internalConfiguration, eTag) = await _restaurantConfiguration.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(if_none_match, restaurantID, cancellationToken: cancellationToken);
            if (internalConfiguration == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Configuration = eTag;
                    return eTag;
                }

                Log.Warn("Missing configuration object for " + restaurantID);
                return null;
            }

            var configuration = new Cloud.V1.Models.RestaurantConfiguration
            {
                restaurantID = internalConfiguration.restaurantID,
                companyName = internalConfiguration.companyName,
                isActiveForOrdering = internalConfiguration.isActiveForOrdering,
                encryption = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationEncryption>(JsonConvert.SerializeObject(internalConfiguration.foe.crypto)),
                timeZone = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationTimeZone>(JsonConvert.SerializeObject(internalConfiguration.timeZone)),
                possiblePaymentProvidersAtPossibleFulfillmentFacilities = JsonConvert.DeserializeObject<Cloud.V1.Models.RestaurantConfigurationPaymentProviderFulfillmentFacilityMap>(JsonConvert.SerializeObject(internalConfiguration.possiblePaymentProvidersAtPossibleFulfillmentFacilities)),
                totalizationMode = ((Cloud.V1.Models.TotalizationMode?)internalConfiguration.totalizationModeOverride) ?? TotalizationMode.MARKET_DEFAULT,
                foe = JsonConvert.DeserializeObject<RestaurantConfigurationFOE>(JsonConvert.SerializeObject(internalConfiguration.foe)),
                marketConfigurationOverrides = JsonConvert.DeserializeObject<SortedDictionary<string, string>>(JsonConvert.SerializeObject(internalConfiguration.marketConfigurationOverrides.Where(item => !string.IsNullOrEmpty(item.Value)).ToDictionary()))
            };

            restaurantCombined.Configuration = configuration;
            restaurantCombined.ETags.Configuration = eTag;

            return configuration;
        }

        async Task<object> SetRestaurantPromotionAsync(Dictionary<string, string> headers, long restaurantID, RestaurantCombined restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombined.ETag.IfNoneMatchPromotions, out string if_none_match);
            var (promotions, eTag) = await _cacheParsedPromotions.GetRestaurantPromotions_DESERIALIZE_AS_Async<RestaurantPromotion>(if_none_match, restaurantID, cancellationToken: cancellationToken);
            if (promotions == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Promotions = eTag;
                    return eTag;
                }

                Log.Warn("Missing promotion object for " + restaurantID);
                return null;
            }

            var promotionArray = promotions.ToArray();
            restaurantCombined.Promotions = promotionArray;
            restaurantCombined.ETags.Promotions = eTag;
            return promotionArray;
        }

        //----------------------------------------------------------------------Filter for V2-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public async Task<RestaurantCombinedV2> GetRestaurantCombinedV2Async(RestaurantCombinedV2.ETag eTag, long restaurantID, HashSet<string> filterApis = null, CancellationToken cancellationToken = default)
        {
            var restaurantCombined = new RestaurantCombinedV2();
            restaurantCombined.ETags = new RestaurantCombinedV2.ETag();

            restaurantCombined.restaurantID = restaurantID;

            string apiNames = null;

            HashSet<string> upperFilters = null;
            if (filterApis != null)
            {
                upperFilters = filterApis.Select(x => x.ToUpper()).ToHashSet();
                apiNames = string.Join(',', upperFilters);
            }
            else
                apiNames = "ALL";

            Log.Info($"{nameof(restaurantCombined)}:{nameof(GetRestaurantCombinedV2Async)}: Filters applied are : {apiNames} for RestaurantID: {restaurantID}");

            List<Task<object>> tasks = new List<Task<object>>();

            var headers = eTag.GetKeys();

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpointV2.SETTINGS))
                tasks.Add(SetRestaurantSettingV2Async(headers, restaurantID, restaurantCombined, cancellationToken));

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpointV2.DETAILS))
                tasks.Add(SetRestaurantDetailsV2Async(headers, restaurantID, restaurantCombined, cancellationToken));
            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpointV2.STATE))
                tasks.Add(SetRestaurantStateV2Async(restaurantID, restaurantCombined, cancellationToken));

            if (upperFilters == null || upperFilters.Contains(CombinedGetEndpointV2.CONFIGURATION))
                tasks.Add(SetRestaurantConfigurationV2Async(headers, restaurantID, restaurantCombined, cancellationToken));

            if (tasks.Count == 0)
            {
                Log.Warn("Invalid filter parameters");
                return null;
            }

            await Task.WhenAll(tasks).ConfigureAwait(false);

            if (tasks.All(task => task.Result == null))
            {
                return null; // if the restaurant does not exist, we return NULL (404)
            }


            var failedTask = tasks.FirstOrDefault(x => x.Exception is not null);
            if (failedTask != null)
                throw failedTask.Exception;


            return restaurantCombined;
        }

        async Task<object> SetRestaurantSettingV2Async(Dictionary<string, string> headers, long restaurantID, RestaurantCombinedV2 restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombinedV2.ETag.IfNoneMatchSettings, out string if_none_match);
            var (settings, eTag) = await _cacheParsedSettings.GetRestaurantSettings_DESERIALIZE_AS_Async<Settings>(if_none_match, restaurantID, cancellationToken);
            if (settings == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Settings = eTag;
                    return eTag;
                }
                Log.Warn("Missing setting object for " + restaurantID);
                return null;
            }
            restaurantCombined.ETags.Settings = eTag;
            restaurantCombined.Settings = settings;
            return settings;
        }

        async Task<object> SetRestaurantDetailsV2Async(Dictionary<string, string> headers, long restaurantID, RestaurantCombinedV2 restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombinedV2.ETag.IfNoneMatchDetails, out string if_none_match);
            var (details, eTag) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<Details>(if_none_match, restaurantID, cancellationToken);
            if (details == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Details = eTag;
                    return eTag;
                }
                Log.Warn("Missing details object for " + restaurantID);
                return null;
            }
            restaurantCombined.ETags.Details = eTag;
            restaurantCombined.Details = details;
            return details;
        }

        async Task<object> SetRestaurantStateV2Async(long restaurantID, RestaurantCombinedV2 restaurantCombined, CancellationToken cancellationToken)
        {
            var state = await _restaurantMonitor.GetRestaurantState_DESERIALIZE_AS_Async<State>(restaurantID, cancellationToken);
            if (state == null)
            {
                Log.Warn("Missing state object for " + restaurantID);
                return null;
            }
            restaurantCombined.State = state;
            return state;
        }

        async Task<object> SetRestaurantConfigurationV2Async(Dictionary<string, string> headers, long restaurantID, RestaurantCombinedV2 restaurantCombined, CancellationToken cancellationToken)
        {
            headers.TryGetValue(RestaurantCombinedV2.ETag.IfNoneMatchConfiguration, out string if_none_match);
            var (internalConfiguration, eTag) = await _restaurantConfiguration.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(if_none_match, restaurantID, cancellationToken: cancellationToken);
            if (internalConfiguration == null)
            {
                if (eTag == if_none_match)
                {
                    restaurantCombined.ETags.Configuration = eTag;
                    return eTag;
                }
                Log.Warn("Missing configuration object for " + restaurantID);
                return null;
            }

            var configuration = new Cloud.V2.Models.Configuration
            {
                restaurantID = internalConfiguration.restaurantID,
                timeZone = JsonConvert.DeserializeObject<Cloud.V2.Models.Configuration.TimeZone>(JsonConvert.SerializeObject(internalConfiguration.timeZone)),
                activeChannels = JsonConvert.DeserializeObject<System.Collections.Generic.SortedDictionary<string, Cloud.V2.Models.Configuration.ChannelConfiguration>>(JsonConvert.SerializeObject(internalConfiguration.activeChannels)),
                foe = JsonConvert.DeserializeObject<V2.Models.Configuration.RestaurantConfigurationFOE>(JsonConvert.SerializeObject(internalConfiguration.foe)),
                marketConfigurationOverrides = JsonConvert.DeserializeObject<SortedDictionary<string, string>>(JsonConvert.SerializeObject(internalConfiguration.marketConfigurationOverrides.Where(item => !string.IsNullOrEmpty(item.Value)).ToDictionary()))
            };

            restaurantCombined.Configuration = configuration;
            restaurantCombined.ETags.Configuration = eTag;

            return configuration;
        }

        public async Task<ProductLookup> GetRestaurantProductLookupV2Async(long restaurantID, int[] productIDs, CancellationToken cancellationToken = default)
        {
            var (channelMenus, _) = await _cacheParsedChannelMenus.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<Cloud.V2.Models.ChannelMenus>(null, restaurantID, cancellationToken);
            ProductLookup plu = ConvertToProductLookUp(channelMenus, productIDs);
            return plu;
        }
        private ProductLookup ConvertToProductLookUp(Cloud.V2.Models.ChannelMenus cm, int[] productIDs)
        {
            if (cm == null || productIDs.Length == 0) return null;
            Log.Verbose($"{nameof(ConvertToProductLookUp)} : Converting ChannelMenu to ProductLookup for store {cm.restaurantID} ... ");
            var startTime = DateTime.Now;

            var plu = new ProductLookup();
            plu.restaurantID = cm.restaurantID;
            plu.channels = new SortedDictionary<string, ProductLookup.Product>();

            try
            {
                foreach (var channel in cm.channels)
                {
                    var cmProductList = channel.Value.productLookup;
                    SortedDictionary<long, ProductLookup.ProductDetails> products = new SortedDictionary<long, ProductLookup.ProductDetails>();
                    ProductLookup.Product product = new ProductLookup.Product();

                    foreach (int productCode in productIDs.Distinct())
                    {
                        if (cmProductList.ContainsKey(productCode))
                        {
                            var details = new ProductLookup.ProductDetails();
                            details.ID = cmProductList[productCode].ID;
                            ProductLookup.ProductDetails.Customizations[] customizations = null;
                            if (cmProductList[productCode].customizations != null)
                            {
                                customizations = new ProductLookup.ProductDetails.Customizations[cmProductList[productCode].customizations.Length];

                                for (int i = 0; i < cmProductList[productCode].customizations.Length; i++)
                                {
                                    ProductLookup.ProductDetails.Customizations.ProductOption[] option = null;
                                    if (cmProductList[productCode].customizations[i].options != null)
                                    {
                                        option = new ProductLookup.ProductDetails.Customizations.ProductOption[cmProductList[productCode].customizations[i].options.Length];
                                        for (int j = 0; j < cmProductList[productCode].customizations[i].options.Length; j++)
                                        {
                                            option[j] = new ProductLookup.ProductDetails.Customizations.ProductOption();
                                            option[j].cost = cmProductList[productCode].customizations[i].options[j].cost;
                                            option[j].energy = cmProductList[productCode].customizations[i].options[j].energy;
                                        }
                                    }

                                    details.customizations = customizations;

                                    details.customizations[i] = new ProductLookup.ProductDetails.Customizations();
                                    details.customizations[i].ID = cmProductList[productCode].customizations[i].ID;
                                    details.customizations[i].type = (ProductLookup.ProductDetails.Customizations.OptionType)cmProductList[productCode].customizations[i]?.type;
                                    details.customizations[i].Default = cmProductList[productCode].customizations[i].Default;
                                    details.customizations[i].options = option;
                                }
                            }

                            ProductLookup.ProductDetails.Choice[] choice = null;
                            if (cmProductList[productCode].choices != null)    // product 107 contains 2 choices, product 61 contains 1 choices
                            {
                                choice = new ProductLookup.ProductDetails.Choice[cmProductList[productCode].choices.Length];
                                for (int i = 0; i < cmProductList[productCode].choices.Length; i++)
                                {
                                    choice[i] = new ProductLookup.ProductDetails.Choice();
                                    choice[i].ID = cmProductList[productCode].choices[i]?.ID;
                                    choice[i].Defaults = cmProductList[productCode].choices[i]?.Defaults;
                                }
                                details.choices = choice;
                            }

                            var localizationsDict = new SortedDictionary<string, ProductLookup.ProductDetails.ChannelLocalization>();
                            foreach (var loc in cm.localizations)
                            {
                                var nameInfo = loc.Value.lookup.Where(x => x.Key.Equals(productCode)).Select(x => x.Value).FirstOrDefault();
                                var channelLocalization = new ProductLookup.ProductDetails.ChannelLocalization();
                                channelLocalization.name = loc.Value.strings[(long)nameInfo[0]]?.ToString();                            
                                localizationsDict.Add(loc.Key, channelLocalization);
                            }

                            details.localizations = localizationsDict;
                            products.Add(productCode, details);
                            product.products = products;
                        } 
                        else
                        {
                            Log.Warn($"{nameof(ConvertToProductLookUp)} : This productId {productCode} does not exist in {channel.Key}.");
                        }

                    }
                    plu.channels.Add(channel.Key, product);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"{nameof(ConvertToProductLookUp)} : Failed to process productlookup due to an expception. {ex.Message}");
            }

            var stopTime = DateTime.Now;
            Log.Verbose($"{nameof(ConvertToProductLookUp)} :  Converting a Product Lookup. Done. Total Time {Convert.ToInt32(stopTime.Subtract(startTime).TotalMilliseconds)}ms.");

            return plu;
        }
    }
}