﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Common;

using RestaurantBridge.Common.GeoLocationIndex;
using RestaurantBridge.Gateway.Cloud.V2.Models;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public interface IRestaurantSearchIndex
    {
        Task InitializeAsync();

        Task<List<Cloud.V2.Models.SearchedDetails>> SearchRestaurantsAsync(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,

            long? restaurantID = null,

            string marketID = null,
            long? marketStoreID = null,
            
            double? latitude = null,
            double? longitude = null,
            
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null);
    }

    public class RestaurantSearchIndexBase : IRestaurantSearchIndex
    {
        public virtual Task InitializeAsync()
        {
            return Task.CompletedTask;
        }

        public virtual Task<List<SearchedDetails>> SearchRestaurantsAsync(HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null, HashSet<string> channels = null, HashSet<string> facilities = null, long? restaurantID = null, string marketID = null, long? marketStoreID = null, double? latitude = null, double? longitude = null, double? maxDistanceInMeters = null, uint? maxNumberOfRestaurantsToReturn = null)
        {
            return Task.FromResult<List<SearchedDetails>>(null);
        }
    }

    public class RestaurantSearchIndex: RestaurantSearchIndexBase
    {
        private readonly ILog Log;
        private readonly EventsManager _eventsManager;

        private readonly RestaurantConfiguration.V1.IClientAdvanced _restaurantConfiguration;
        private readonly Cache.ParsedDetails.V1.IClientAdvanced _cacheParsedDetails;

        private readonly SemaphoreSlim _restaurantDetailsUpdateLock = new SemaphoreSlim(1,1);

        private readonly AsyncReadWriteLock _restaurantDetailsAsyncReadWriteLock = new AsyncReadWriteLock();
        
        private Dictionary<long, Cloud.V2.Models.Details> _details;
        private GeoLocationIndex<Cloud.V2.Models.Details> _geoLocationIndex;
        private string _eTag;

        public RestaurantSearchIndex (
            ILog logger,
            EventsManager eventsManager,
            RestaurantConfiguration.V1.IClientAdvanced restaurantConfiguration,
            Cache.ParsedDetails.V1.IClientAdvanced cacheParsedDetails
        )
        {
            Log = logger;
            _eventsManager = eventsManager;

            _restaurantConfiguration = restaurantConfiguration;
            _cacheParsedDetails = cacheParsedDetails;

            _eventsManager.onCachesClear += (_, e) => ClearAsync(e.RestaurantID);
            _eventsManager.onCachesReload += (_, e) => ReloadAsync("onCachesReload", e.RestaurantID);
            _eventsManager.onConfigurationInvalidation += (_, e) => ReloadAsync("onConfigurationInvalidation", e.RestaurantID);
            _eventsManager.onStateInvalidation += (_, e) => ReloadAsync("onStateInvalidation", e.RestaurantID, onlyIfNotIndexedYet: true); 
            _eventsManager.onDetailsInvalidation += (_, e) => ReloadAsync("onDetailsInvalidation", e.RestaurantID);
        }

        public override async Task InitializeAsync()
        {
            Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(InitializeAsync)}: INITIALIZING SEARCH INDEX ..");
            // start empty and then ReInitialize to better handle any issues at startup
            await _restaurantDetailsUpdateLock.WaitAsync();
            try
            {
                var detailsLookup = new Dictionary<long, Cloud.V2.Models.Details>();
                var geoLocationIndex = new GeoLocationIndex<Cloud.V2.Models.Details>();
                geoLocationIndex.BuildIndex();
                await _UpdateCacheAndIndexDataAsync(detailsLookup, geoLocationIndex);
            }
            finally
            {
                _restaurantDetailsUpdateLock.Release();
            }
            var fireAndForget = ReInitializeAsync();
        }

        public async Task ReInitializeAsync() 
        {
            Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ReInitializeAsync)}: REINITIALIZING SEARCH INDEX ..");

            await _restaurantDetailsUpdateLock.WaitAsync();
            try
            {
                var restaurantIDs = await _restaurantConfiguration.GetRestaurantIDsAsync();
                var detailsLookup = new Dictionary<long, Cloud.V2.Models.Details>();
                foreach (var restaurantID in restaurantIDs)
                {
                    try
                    {
                        var (details, _) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<Cloud.V2.Models.Details>(null, restaurantID);
                        if (details != null)
                        {
                            detailsLookup.Add(details.restaurantID, details);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Critical($"{nameof(RestaurantSearchIndex)}:{nameof(ReInitializeAsync)}: {restaurantID} : FAILED TO GET DETAILS. Excluding {restaurantID} from index.", ex);
                    }
                }
                var geoLocationIndex = new GeoLocationIndex<Cloud.V2.Models.Details>();
                foreach (var kv in detailsLookup)
                {
                    geoLocationIndex.Add(kv.Value.latitude, kv.Value.longitude, kv.Value);
                }
                geoLocationIndex.BuildIndex();

                await _UpdateCacheAndIndexDataAsync(detailsLookup, geoLocationIndex);
            }
            catch (Exception ex)
            {
                Log.Critical($"{nameof(RestaurantSearchIndex)}:{nameof(ReInitializeAsync)}: Failed to reinitialize geo location index !!", ex);
            }
            finally
            {
                _restaurantDetailsUpdateLock.Release();
            }
        }

        private async Task _UpdateCacheAndIndexDataAsync(Dictionary<long, Cloud.V2.Models.Details> detailsLookup, GeoLocationIndex<Cloud.V2.Models.Details> geoLocationIndex)
        {
            await _restaurantDetailsAsyncReadWriteLock.EnterWriteLockAsync();
                _details = detailsLookup;
                _geoLocationIndex = geoLocationIndex;
            await _restaurantDetailsAsyncReadWriteLock.ExitWriteLockAsync();
        }

        [ExcludeFromCodeCoverage]
        private async Task ClearAsync(long restaurantID)
        {
            Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ClearAsync)}({restaurantID}) ...");
            Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ClearAsync)}({restaurantID}) : REBUILDING ENTIRE SEARCH INDEX ..");
            await ReInitializeAsync();
        }

        [ExcludeFromCodeCoverage]
        private async Task ReloadAsync(string eventName, long restaurantID, bool onlyIfNotIndexedYet=false) 
        {
            Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ReloadAsync)}({eventName}, {restaurantID}) ...");
            await _restaurantDetailsUpdateLock.WaitAsync();
            try
            {
                if (_details.ContainsKey(restaurantID)) {
                    if (onlyIfNotIndexedYet)  
                    { 
                        return; 
                    }
                }
                else
                {
                    Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ReloadAsync)}({eventName}, {restaurantID}) : ADDING new restaurant.");
                }

                var geoLocationIndex = _geoLocationIndex;
                var detailsLookup = new Dictionary<long, Cloud.V2.Models.Details>(_details); // clone 

                Cloud.V2.Models.Details details = null;
                try
                {
                    (details, _) = await _cacheParsedDetails.GetRestaurantDetails_DESERIALIZE_AS_Async<Cloud.V2.Models.Details>(null, restaurantID);
                }
                catch(Exception ex)
                {
                    Log.Warn($"{nameof(RestaurantSearchIndex)}:{nameof(ReloadAsync)}({eventName}, {restaurantID}) : FAILED TO GET DETAILS. Removing {restaurantID} from index", ex);
                }

                if (details == null)
                {
                    if (detailsLookup.ContainsKey(restaurantID))
                    {
                        // removal requires reindex
                        detailsLookup.Remove(restaurantID);
                        geoLocationIndex = null;
                    }
                }
                else
                {
                    if (!detailsLookup.ContainsKey(restaurantID))
                    {
                        // addition requires reindex
                        detailsLookup.Add(restaurantID, details);
                        geoLocationIndex = null; 
                    }
                    else
                    {
                        var previousDetails = detailsLookup[restaurantID];
                        if ( ! (previousDetails.latitude == details.latitude && previousDetails.longitude == details.longitude))
                        {
                            // location change requires reindex
                            detailsLookup[restaurantID] = details;
                            geoLocationIndex = null; 
                        }
                        else
                        {
                            // just update the data at the existing reference
                            previousDetails.restaurantID = details.restaurantID;
                            previousDetails.marketID = details.marketID;
                            previousDetails.marketStoreID = details.marketStoreID;
                            previousDetails.longitude = details.longitude;
                            previousDetails.latitude = details.latitude;
                            previousDetails.locales = details.locales;
                            previousDetails.channelHours = details.channelHours;
                            previousDetails.facilities = details.facilities;
                            previousDetails.name = details.name;
                            previousDetails.phone = details.phone;
                            previousDetails.email = details.email;
                            previousDetails.address = details.address;
                            previousDetails.defaultLocale = details.defaultLocale;
                            previousDetails.additionalInformation = details.additionalInformation;
                        }
                    }
                }

                if (geoLocationIndex == null)
                {
                    Log.Info($"{nameof(RestaurantSearchIndex)}:{nameof(ReloadAsync)}({eventName}, {restaurantID}) : requires indexing ..");
                    geoLocationIndex = new GeoLocationIndex<Cloud.V2.Models.Details>();
                    foreach (var kv in detailsLookup)
                    {
                        geoLocationIndex.Add(kv.Value.latitude, kv.Value.longitude, kv.Value);
                    }
                    geoLocationIndex.BuildIndex();
                }

                await _UpdateCacheAndIndexDataAsync(detailsLookup, geoLocationIndex);
            }
            catch (Exception ex)
            {
                Log.Critical($"{nameof(RestaurantSearchIndex)}:{nameof(ReloadAsync)}({eventName}, {restaurantID}) : Failed to update geo location index !!.", ex);
            }
            finally
            {
                _restaurantDetailsUpdateLock.Release();
            }
        }

        public override async Task<List<Cloud.V2.Models.SearchedDetails>> SearchRestaurantsAsync(
            /* Filters */
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            /* Position */
            long? restaurantID = null,
            /* Position */
            string marketID = null,
            long? marketStoreID = null,
            /* Position */
            double? latitude = null,
            double? longitude = null,
            /* Limits */
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            // TODO: implement
            // if this is a request without any filter, so the request is for all data
            //    this is a request that is common for tooling purposes
            //    in this case we can return the pre cached full data reply
            //if(no parameters are set) return canned response of all  


            // Cleanup inputs

            if (marketIDs != null) { marketIDs = new HashSet<string>(marketIDs.Where(marketID => !string.IsNullOrWhiteSpace(marketID)).Select(marketID => marketID.ToUpperInvariant())); }
            if (channels != null) { channels = new HashSet<string>(channels.Where(channel => !string.IsNullOrWhiteSpace(channel)).Select(channel => channel.ToUpperInvariant())); }
            if (facilities != null) { facilities = new HashSet<string>(facilities.Where(facility => !string.IsNullOrWhiteSpace(facility)).Select(facility => facility.ToUpperInvariant())); }
            marketID = marketID?.ToUpperInvariant();
            maxDistanceInMeters = maxDistanceInMeters ?? Double.PositiveInfinity;
            maxNumberOfRestaurantsToReturn = maxNumberOfRestaurantsToReturn ?? 0;

            // Setup filters

            bool _filter(Cloud.V2.Models.Details details)
            {
                if (restaurantIDs != null && restaurantIDs.Count > 0)
                {
                    if (!restaurantIDs.Contains(details.restaurantID)) { return false; }
                }
                if (marketIDs != null && marketIDs.Count > 0)
                {
                    if (!marketIDs.Contains(details.marketID)) { return false; }
                }
                if (channels != null && channels.Count > 0)
                {
                    var restaurantChannels = new HashSet<string>(details.channelHours.Keys);
                    restaurantChannels.IntersectWith(channels);
                    if (restaurantChannels.Count == 0) { return false; }
                }
                if (facilities != null && facilities.Count > 0)
                {
                    var restaurantFacilities = new HashSet<string>(details.facilities.Select(facility => facility.ToUpperInvariant()));
                    if (!restaurantFacilities.IsSupersetOf(facilities)) { return false; }
                }
                return true;
            }

            // GET A SET OF IMMUTABLE DATA TO PERFORM THE SEARCH ON

            await _restaurantDetailsAsyncReadWriteLock.EnterReadLockAsync();
                Dictionary<long, Cloud.V2.Models.Details> detailsLookup = _details;
                GeoLocationIndex<Cloud.V2.Models.Details> geoLocationIndex = _geoLocationIndex;
            await _restaurantDetailsAsyncReadWriteLock.ExitReadLockAsync();

            // on "stores" nearby "store" search get geoLocation from existing
            // store or return an empty response

            if (restaurantID != null)
            {
                V2.Models.Details foundStoreForGeoLocation = null;
                foundStoreForGeoLocation = detailsLookup.Values
                    .Where(details => details.restaurantID == restaurantID)
                    .FirstOrDefault();
                if (foundStoreForGeoLocation == null)
                {
                    return new List<V2.Models.SearchedDetails>();
                }
                latitude = foundStoreForGeoLocation.latitude;
                longitude = foundStoreForGeoLocation.longitude;
            }
            else if (marketID != null)
            {
                V2.Models.Details foundStoreForGeoLocation = null;
                if (marketStoreID.HasValue)
                {
                    foundStoreForGeoLocation = detailsLookup.Values
                        .Where(details => (details.marketID == marketID) && (details.marketStoreID == marketStoreID))
                        .FirstOrDefault();
                }
                if (foundStoreForGeoLocation == null)
                {
                    return new List<V2.Models.SearchedDetails>();
                }
                latitude = foundStoreForGeoLocation.latitude;
                longitude = foundStoreForGeoLocation.longitude;
            }

            Cloud.V2.Models.SearchedDetails _upgradeToSearchDetails(double? distanceInMeters, Cloud.V2.Models.Details details)
            {
                return new V2.Models.SearchedDetails
                {
                    distanceInMeters = distanceInMeters,
                    restaurantID = details.restaurantID,
                    marketID = details.marketID,
                    marketStoreID = details.marketStoreID,
                    longitude = details.longitude,
                    latitude = details.latitude,
                    locales = details.locales,
                    channelHours = details.channelHours,
                    facilities = details.facilities,
                    name = details.name,
                    phone = details.phone,
                    email = details.email,
                    address = details.address,
                    defaultLocale = details.defaultLocale,
                    additionalInformation = details.additionalInformation
                    
                };
            }

            List<Cloud.V2.Models.SearchedDetails> searchResults = null;
            if (latitude.HasValue && longitude.HasValue)
            {
                var geoSearchResults = geoLocationIndex.Get(latitude.Value, longitude.Value, (int)(maxNumberOfRestaurantsToReturn.Value), maxDistanceInMeters.Value, _filter);
                searchResults = geoSearchResults.Select(pair => _upgradeToSearchDetails(pair.distance, pair.value)).ToList();
            }
            else
            {
                if (maxNumberOfRestaurantsToReturn.Value > 0)
                {
                    searchResults = detailsLookup.Values.Where(_filter).Take((int)maxNumberOfRestaurantsToReturn.Value).Select(details => _upgradeToSearchDetails(null, details)).ToList();
                }
                else
                {
                    searchResults = detailsLookup.Values.Where(_filter).Select(details => _upgradeToSearchDetails(null, details)).ToList();
                }
            }

            return searchResults; 
        }
    }
}
