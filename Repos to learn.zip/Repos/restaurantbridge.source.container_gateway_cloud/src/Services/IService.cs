﻿using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public interface IService
    {
        Task<RestaurantCombined> GetRestaurantCombinedAsync(RestaurantCombined.ETag eTag, long restaurantID, HashSet<string> filterApis = null, CancellationToken cancellationToken = default);
        Task<RestaurantCombinedV2> GetRestaurantCombinedV2Async(RestaurantCombinedV2.ETag eTag, long restaurantID, HashSet<string> filterApis = null, CancellationToken cancellationToken = default);
        Task<ProductLookup> GetRestaurantProductLookupV2Async(long restaurantID, int[] productIDs, CancellationToken cancellationToken = default);
    }
}
