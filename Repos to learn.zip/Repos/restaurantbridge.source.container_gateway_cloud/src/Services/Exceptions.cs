﻿using System;

namespace RestaurantBridge.Gateway.Cloud.Services.Exceptions
{
    public class CircuitBreakerOpenException : Exception { public CircuitBreakerOpenException(string message) : base(message) { } }
    public class RequestTimeoutException : Exception { public RequestTimeoutException(string message) : base(message) { } }
}
