﻿using System.Diagnostics.CodeAnalysis;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    [ExcludeFromCodeCoverage]
    public static class KafkaConstants
    {
        public const string KafkaTopic = "na_us_dev_product_outage_invalidation";
        public const int KafkaTimeToLiveInSeconds = 15;
        public const string KafkaDynamoTable = "Unified_Eventing_Retry";
        public const string CompressionType = "GZIP";
        public const string KeySchemaType = "STRING";
        public const string ValueSchemaType = "JSON";
        public const string SchemaRegistryUrl = "localhost:8085";
        public const string BootstrapServers = "localhost:29092";

        public const int DelayMS = 10;
        public const int Retries = 1;
        public const int RetryBackOffMS = 1000;
        public const int MessageCount = 5;
        public const bool EnableIdempotence = true;
        public const bool AutoRegisterSchemas = false;
        public const int MaxBlockMS = 5000;
        public const int LingerMS = 10;
        public const int BatchSize = 32768;
        public const int BatchNumMessages = 40;
        public const int MessageMaxBytes = 1048576;   // 1M Bytes
        public const int MaxInFlightRequests = 1;
        public const int MinReplicasInSync = 2;
        public const string Domain = "Menu";
        public const string Region = "US";
        public const string Market = "US";
        public const string ClusterName = "mock";
        public const string Publisher = "DCS_1.2";
        public const string HeaderVersion = "1.0";
        public const string SecurityProtocol = "SSL";

        public const string AutoOffsetReset = "latest";
        public const string EnableAutoCommit = "false";
        public const string RetryBackoffTimeunit = "SECONDS";
        public const double RetryExponentialRate = 1;
        public const int MessageCommitPeriod = 100;
        public const int RetryBackoffPeriod = 5;
        public const int RetryTotalAttempts = 5;
        public const int MaxPollIntervalMs = 100;
        public const int MaxBatchSize = 200;
        public const int TimeoutMS = 30000;
        public const string dynamodb_aws_region = "us-west-2";
    }
}