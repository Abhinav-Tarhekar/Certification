﻿using Coates.Cache.ParsedRestaurantCoatesMenus.V1.Models;
using Common;
using McD.McFlow.Client.Library.Producer;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using OQMCMenu.Processor.V1.Models;
using RestaurantBridge.Cache.ParsedChannelMenus.V1.Models;
using RestaurantBridge.Cache.ParsedDetails.V1.Models;
using RestaurantBridge.Cache.ParsedMenuCategories.V1.Models;
using RestaurantBridge.Cache.ParsedProductOutages.V1.Models;
using RestaurantBridge.Cache.ParsedProducts.V1.Models;
using RestaurantBridge.Cache.ParsedPromotions.V1.Models;
using RestaurantBridge.Cache.ParsedSettings.V1.Models;
using RestaurantBridge.Cache.ParsedTaxParameters.V1.Models;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using RestaurantBridge.Gateway.Cloud.API.Model;
using RestaurantBridge.Gateway.Cloud.Services.SubscriberManagers;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using RestaurantBridge.RestaurantConfiguration.V1.Models;
using RestaurantBridge.RestaurantMonitor.V1.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using GlobalMonitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Global.RestaurantEventMonitor;
using V1Monitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.V1.RestaurantEventMonitor;
using V2Monitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.V2.RestaurantEventMonitor;


namespace RestaurantBridge.Gateway.Cloud.Services
{
    public class EventsManager : IDisposable
    {
        public delegate Task RestaurantMonitorEventHandler(object sender, InvalidationEventArgs args);

        private readonly ILog Log;
        private readonly IEmpheralPubSub _empheralPubSub;
        private readonly IConfiguration _configuration;
        private readonly RestaurantMonitor.V1.IClientAdvanced _restaurantMonitorClient;
        
        public readonly ISubscriberManager GlobalManager;
        public readonly ISubscriberManager V1Manager;
        public readonly ISubscriberManager V2Manager;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="empheralPubSub"></param>
        /// <param name="configuration"></param>
        /// <param name="mcFlowProducer"></param>
        /// <param name="rbClientAdvanced"></param>
        /// <param name="restaurantMonitorClient"></param>
        /// <param name="resourceLock"></param>
        /// <param name="cacheWriteLockAutoReleaseTimeInMs"></param>
        public EventsManager(
            ILog logger, 
            IEmpheralPubSub empheralPubSub, 
            IConfiguration configuration, 
            IMcFlowProducer<string, string> mcFlowProducer, 
            Cache.ParsedDetails.V1.IClientAdvanced rbClientAdvanced, 
            RestaurantMonitor.V1.IClientAdvanced restaurantMonitorClient,
            IResourceLock resourceLock, 
            int cacheWriteLockAutoReleaseTimeInMs)
        {
            Log = logger;
            _empheralPubSub = empheralPubSub;
            _configuration = configuration;
            _restaurantMonitorClient = restaurantMonitorClient;
            var mcFlowManager = CreateMcFlowChannel(configuration, mcFlowProducer, rbClientAdvanced, resourceLock, cacheWriteLockAutoReleaseTimeInMs);
            
            GlobalManager = new SubscriberManager(CreateWebsocketChannel(true), null);
            V1Manager = new SubscriberManager(CreateWebsocketChannel(), mcFlowManager);
            V2Manager = new SubscriberManager(CreateWebsocketChannel(), mcFlowManager);
        }

        private IWebsocketManager CreateWebsocketChannel(bool blockEmptySubscribers = false)
        {
            return new WebsocketManager(Log, blockEmptySubscribers);
        }

        private IMcFlowManager CreateMcFlowChannel(IConfiguration configuration, IMcFlowProducer<string, string> mcFlowProducer, Cache.ParsedDetails.V1.IClientAdvanced rbClientAdvanced, IResourceLock resourceLock, int cacheWriteLockAutoReleaseTimeInMs)
        {
            if (configuration == null)
                return null;

            if (configuration.enable_rb_event_mcflow_publish)
                return new McFlowManager(Log, configuration, mcFlowProducer, rbClientAdvanced, resourceLock, cacheWriteLockAutoReleaseTimeInMs);

            return null;
        }
        public List<string> CurrentSubscribers()
        {
            var result = new List<string>();

            result.AddRange(GlobalManager.GetSubscribers());
            result.AddRange(V1Manager.GetSubscribers());
            result.AddRange(V2Manager.GetSubscribers());

            return result;
        }
        public Task DropSubscribersThatMatchPatternAsync(string subscriberRegexPattern)
        {
            Log.Info($"{nameof(EventsManager)}.{nameof(DropSubscribersThatMatchPatternAsync)} : PUBLISHING : V1:GatewayDropSubscribersEvent : {subscriberRegexPattern}");
            return _empheralPubSub.Publish("V1:GatewayDropSubscribersEvent", subscriberRegexPattern);
        }
        private async Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken)
        {
            await V1Manager.DropSubscribersAsync(regexPattern, cancellationToken);
            await V2Manager.DropSubscribersAsync(regexPattern, cancellationToken);

            await GlobalManager.DropSubscribersAsync(regexPattern, cancellationToken);
        }

        public event RestaurantMonitorEventHandler onConfigurationInvalidation;
        public event RestaurantMonitorEventHandler onStateInvalidation;
        public event RestaurantMonitorEventHandler onDetailsInvalidation;
        public event RestaurantMonitorEventHandler onSettingsInvalidation;
        public event RestaurantMonitorEventHandler onMenuCategoriesInvalidation;
        public event RestaurantMonitorEventHandler onProductsInvalidation;
        public event RestaurantMonitorEventHandler onChannelMenusInvalidation;
        public event RestaurantMonitorEventHandler onTaxParametersInvalidation;
        public event RestaurantMonitorEventHandler onProductsOutagesInvalidation;
        public event RestaurantMonitorEventHandler onPromotionsInvalidation;
        public event RestaurantMonitorEventHandler onOqmcInvalidation;
        public event RestaurantMonitorEventHandler onCoatesMenusInvalidation;


        public event RestaurantMonitorEventHandler onCachesClear;
        public event RestaurantMonitorEventHandler onCachesReload;

        private Task ConfigurationInvalidationHandler(InvalidationEventArgs e) => onConfigurationInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task StateInvalidationHandler(InvalidationEventArgs e) => onStateInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task DetailsInvalidationHandler(InvalidationEventArgs e) => onDetailsInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task SettingsInvalidationHandler(InvalidationEventArgs e) => onSettingsInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task MenuCategoriesInvalidationHandler(InvalidationEventArgs e) => onMenuCategoriesInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task ProductsInvalidationHandler(InvalidationEventArgs e) => onProductsInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task ChannelMenusInvalidationHandler(InvalidationEventArgs e) => onChannelMenusInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task TaxParametersInvalidationHandler(InvalidationEventArgs e) => onTaxParametersInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task ProductsOutagesInvalidationHandler(InvalidationEventArgs e) => onProductsOutagesInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task PromotionsInvalidationHandler(InvalidationEventArgs e) => onPromotionsInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task OqmcInvalidationHandler(InvalidationEventArgs e) => onOqmcInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task CoatesMenusInvalidationHandler(InvalidationEventArgs e) => onCoatesMenusInvalidation?.Invoke(this, e) ?? Task.CompletedTask;
        private Task RestaurantCachesClearHandler(InvalidationEventArgs e) => onCachesClear?.Invoke(this, e) ?? Task.CompletedTask;
        private Task RestaurantCachesReloadHandler(InvalidationEventArgs e) => onCachesReload?.Invoke(this, e) ?? Task.CompletedTask;
        public async Task<bool> TriggerInvalidation(long restaurantID, string routingKey)
        {
            try
            {
                var state = await _restaurantMonitorClient.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantState>(restaurantID);
                if (state is not null)
                {
                    var myData = new { eventID = Guid.NewGuid(), restaurantID = restaurantID };
                    var message = JsonConvert.SerializeObject(myData);
                    await _empheralPubSub.Publish(routingKey, message);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.Debug($"RestaurantID: {restaurantID} data not present in the cache. {ex.Message}", ex);
                return false;
            }
        }
        
        public async Task InitializeAsync(CancellationToken cancellationToken)
        {
            Log.Info($"{nameof(EventsManager)}.InitalizeAsync : Subscribing to internal restaurant bridge events ..");

            var eventRoutingKeyFilterPattern = $"V1:*";
            await _empheralPubSub.Subscribe(eventRoutingKeyFilterPattern, async (routingKey, message) =>
            {
                try
                {
                    RBEvent V1_externalEvent = null;
                    RBEvent V2_externalEvent = null;
                    RBEvent externalEvent = null;
                    string subEvent = null;
                    string subEventV1 = null;
                    string subEventV2 = null;

                    var subEventFeatureFlag = _configuration.enable_sub_event_mcflow_publish;

                    switch (routingKey)
                    {
                        case "V1:GatewayDropSubscribersEvent":
                            {
                                await DropSubscribersAsync(message, cancellationToken);
                            }
                            break;
                        case "V1:RestaurantConfigurationInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantConfigurationInvalidationEvent>(message);
                                // internalEvent.SubEvent

                                string configSubEvent = null;
                                string configSubEvent1 = null;
                                string configSubEvent2 = null;
                                if (subEventFeatureFlag)
                                {
                                    configSubEvent = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                    configSubEvent1 = ProcessConfigV1SubEvent(configSubEvent, jsonSerializerSettings);
                                    configSubEvent2 = ProcessConfigV2SubEvent(configSubEvent, jsonSerializerSettings);
                                }

                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = configSubEvent1 } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = configSubEvent2 } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = configSubEvent2 } };


                                //V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                //V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                //externalEvent = new RBEvent { RoutingKey = GlobalMonitor.ConfigurationEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                await ConfigurationInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;

                        case "V1:RestaurantStateInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantStateInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEventV1 = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                    subEventV2 = ProcessSubEvent(subEventV1, jsonSerializerSettings);
                                }

                                V1_externalEvent = CreateRBEvent(V1Monitor.StateEvent, internalEvent.eventID, internalEvent.restaurantID, subEventV1);
                                V2_externalEvent = CreateRBEvent(V2Monitor.StateEvent, internalEvent.eventID, internalEvent.restaurantID, subEventV2);
                                externalEvent = CreateRBEvent(GlobalMonitor.StateEvent, internalEvent.eventID, internalEvent.restaurantID, subEventV2);

                                await StateInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;

                        case "V1:RestaurantDetailsInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantDetailsInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEventV2 = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                    subEventV1 = ProcessDetailsSubEvent(subEventV2, jsonSerializerSettings);
                                }
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.DetailsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEventV1 } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.DetailsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEventV2 } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.DetailsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEventV2 } };

                                await DetailsInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantSettingsInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantSettingsInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEvent = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                }
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.SettingsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.SettingsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.SettingsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                await SettingsInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantMenuCategoriesInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantMenuCategoriesInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEvent = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                }
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.MenuCategoriesEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.MenuCategoriesEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                await MenuCategoriesInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantProductsInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantProductsInvalidationEvent>(message);
                                if (subEventFeatureFlag)
                                {
                                    var sortedProduct = new SortedSet<long>(internalEvent.subEvent.Select(i => (long)i));
                                    subEvent = JsonConvert.SerializeObject(sortedProduct);
                                }

                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.ProductsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.ProductsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                await ProductsInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantChannelMenusInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantChannelMenusInvalidationEvent>(message);
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.ChannelMenuEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.ChannelMenuEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                await ChannelMenusInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantTaxParametersInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantTaxParametersInvalidationEvent>(message);
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.TaxParametersEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.TaxParametersEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                await TaxParametersInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantProductOutagesInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantProductOutagesInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEvent = JsonConvert.SerializeObject(new ProductOutages { restaurantID = internalEvent.restaurantID, productIDs = internalEvent.subEvent });
                                }
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.OutagesEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.ProductOutagesEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.OutagesEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                await ProductsOutagesInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantPromotionInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantPromotionInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEvent = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                }

                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.PromotionsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.PromotionsEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent } };
                                await PromotionsInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantCachesClearEvent":
                            {
                                var eventId = Guid.NewGuid().ToString();
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantCachesClearEvent>(message);
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.CacheClearEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID, EventID = eventId } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.CacheClearEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID, EventID = eventId } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.CacheClearEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID } };
                                await RestaurantCachesClearHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantCachesReloadEvent":
                            {
                                var eventId = Guid.NewGuid().ToString();
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantCachesReloadEvent>(message);
                                V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.CacheReloadEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID, EventID = eventId } };
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.CacheReloadEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID, EventID = eventId } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.CacheReloadEvent, Data = new RBEventData { RestaurantID = internalEvent.restaurantID } };
                                await RestaurantCachesReloadHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:OqmcInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<OqmcInvalidationEvent>(message);

                                if (subEventFeatureFlag)
                                {
                                    subEvent = SerializeSubEvent(internalEvent.subEvent, jsonSerializerSettings);
                                }
                                
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.OqmcEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent  } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.OqmcEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID, ETag = internalEvent.eTag, SubEvent = subEvent  } };
                                await OqmcInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                        case "V1:RestaurantCoatesMenusInvalidationEvent":
                            {
                                var internalEvent = JsonConvert.DeserializeObject<RestaurantCoatesMenusInvalidationEvent>(message);
                                V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.CoatesMenuEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                externalEvent = new RBEvent { RoutingKey = GlobalMonitor.CoatesMenuEvent, Data = new RBEventData { EventID = internalEvent.eventID.ToString(), RestaurantID = internalEvent.restaurantID } };
                                await CoatesMenusInvalidationHandler(new InvalidationEventArgs(internalEvent.restaurantID, cancellationToken));
                            }
                            break;
                    }

                    Task global_publishing_task = (externalEvent != null) ? GlobalManager.PublishEventAsync(externalEvent, Program.CancellationTokenSource.Token) : Task.CompletedTask;
                    Task V1_publishing_task = (V1_externalEvent != null) ? V1Manager.PublishEventAsync(V1_externalEvent, Program.CancellationTokenSource.Token) : Task.CompletedTask;
                    Task V2_publishing_task = (V2_externalEvent != null) ? V2Manager.PublishEventAsync(V2_externalEvent, Program.CancellationTokenSource.Token) : Task.CompletedTask;

                    await Task.WhenAll(global_publishing_task, V1_publishing_task, V2_publishing_task).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Log.Critical($"Failed to handle {routingKey}:{message} !!", ex);
                }
            });
        }

        static readonly JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            Converters = new List<JsonConverter> { new StringEnumConverter() }
        };

        private string SerializeSubEvent(object subEvent, JsonSerializerSettings jsonSerializerSettings)
        {
            return JsonConvert.SerializeObject(subEvent, jsonSerializerSettings);
        }

        // Method to process and format the sub-event
        private string ProcessSubEvent(string subEventV1, JsonSerializerSettings jsonSerializerSettings)
        {
            var subEventManupulation = JsonConvert.DeserializeObject<State>(subEventV1);
            subEventManupulation.businessDate = FormatBusinessDate(subEventManupulation.businessDate);
            var businessDate = DateTime.ParseExact(subEventManupulation.businessDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            subEventManupulation.businessDayOfWeek = ConvertToCustomDayOfWeek(businessDate.DayOfWeek);
            return JsonConvert.SerializeObject(subEventManupulation, jsonSerializerSettings);
        }

        private string ProcessDetailsSubEvent(string subEvent, JsonSerializerSettings jsonSerializerSettings)
        {
            var subEventManipulation = JsonConvert.DeserializeObject<V1.Models.RestaurantDetails>(subEvent);
            return JsonConvert.SerializeObject(subEventManipulation, jsonSerializerSettings);
        }

        private string ProcessConfigV1SubEvent(string subEvent, JsonSerializerSettings jsonSerializerSettings)
        {
            var subEventManipulation = JsonConvert.DeserializeObject<V1.Models.RestaurantConfiguration>(subEvent);
            return JsonConvert.SerializeObject(subEventManipulation, jsonSerializerSettings);
        }

        private string ProcessConfigV2SubEvent(string subEvent, JsonSerializerSettings jsonSerializerSettings)
        {
            var subEventManipulation = JsonConvert.DeserializeObject<V2.Models.Configuration>(subEvent);
            return JsonConvert.SerializeObject(subEventManipulation, jsonSerializerSettings);
        }

        // Method to format the business date
        private string FormatBusinessDate(string date)
        {
            return $"{date.Substring(0, 4)}-{date.Substring(4, 2)}-{date.Substring(6, 2)}";
        }

        // Method to create an RBEvent
        private RBEvent CreateRBEvent(string routingKey, Guid eventID, long restaurantID, string subEvent = null)
        {
            return new RBEvent
            {
                RoutingKey = routingKey,
                Data = new RBEventData
                {
                    EventID = eventID.ToString(),
                    RestaurantID = restaurantID,
                    SubEvent = subEvent
                }
            };
        }
        [ExcludeFromCodeCoverage]
        private Cloud.V2.Models.DayOfWeek ConvertToCustomDayOfWeek(System.DayOfWeek systemDayOfWeek)
        {
            return systemDayOfWeek switch
            {
                System.DayOfWeek.Sunday => Cloud.V2.Models.DayOfWeek.SUNDAY,
                System.DayOfWeek.Monday => Cloud.V2.Models.DayOfWeek.MONDAY,
                System.DayOfWeek.Tuesday => Cloud.V2.Models.DayOfWeek.TUESDAY,
                System.DayOfWeek.Wednesday => Cloud.V2.Models.DayOfWeek.WEDNESDAY,
                System.DayOfWeek.Thursday => Cloud.V2.Models.DayOfWeek.THURSDAY,
                System.DayOfWeek.Friday => Cloud.V2.Models.DayOfWeek.FRIDAY,
                System.DayOfWeek.Saturday => Cloud.V2.Models.DayOfWeek.SATURDAY,
                _ => throw new ArgumentOutOfRangeException(nameof(systemDayOfWeek), systemDayOfWeek, null)
            };
        }

        [ExcludeFromCodeCoverage]
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                GlobalManager.Dispose();
                V1Manager.Dispose();
                V2Manager.Dispose();
            }
        }
    }
}
