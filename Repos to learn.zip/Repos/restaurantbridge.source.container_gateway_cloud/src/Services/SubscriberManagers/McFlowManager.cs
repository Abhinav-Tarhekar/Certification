﻿using Common;
using Common.RequestContext;
using Confluent.Kafka;
using McD.McFlow.Client.Library.Common;
using McD.McFlow.Client.Library.Producer;
using NewRelic.Api.Agent;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using System;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.IO.Hashing;
using Newtonsoft.Json;

namespace RestaurantBridge.Gateway.Cloud.Services.SubscriberManagers
{
    public interface IMcFlowManager : IBaseManager { }

    public class McFlowManager : BaseManager, IMcFlowManager
    {
        private readonly ILog Log;

        private readonly IConfiguration _configuration;
        private readonly IMcFlowProducer<string, string> _mcFlowProducer;

        private readonly Cache.ParsedDetails.V1.IClientAdvanced _rbClientAdvanced;
        private readonly IResourceLock _resourceLock;
        private readonly int _cacheWriteLockAutoReleaseTimeInMs;
        private string lockID;
        private static string GetLockIDFor(long restaurantID) => $"{restaurantID}_LOCK";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="stringKeyValueStore"></param>
        /// <param name="beaconIntervalInMilliseconds"></param>
        /// <param name="blockEmptySubscribeList"></param>
        /// <exception cref="ArgumentNullException"></exception>

        public McFlowManager(ILog logger, IConfiguration configuration, IMcFlowProducer<string, string> mcFlowProducer, Cache.ParsedDetails.V1.IClientAdvanced rbClientAdvanced, IResourceLock resourceLock, int cacheWriteLockAutoReleaseTimeInMs, bool blockEmptySubscribeList = false)
        {
            Log = logger;

            _configuration = configuration;
            _mcFlowProducer = mcFlowProducer;
            _rbClientAdvanced = rbClientAdvanced;
            _resourceLock = resourceLock;
            _cacheWriteLockAutoReleaseTimeInMs = cacheWriteLockAutoReleaseTimeInMs;
        }

        [ExcludeFromCodeCoverage]// Need to write UT, excluded due to McFlow.
        [Transaction]
        public override async Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken)
        {
            Metrics.SetTransaction("Kafka", rbEvent);

            RequestContext.CorrelationID.Init(rbEvent.Data.EventID);
           
            Guid lockToken = Guid.Empty;
            try
            {
                var routingKey = rbEvent.RoutingKey;

                if ((_configuration.publish_v1_events_mcflow && routingKey.Contains("v1") && !routingKey.Equals("v1.connection.beacon"))

                || (_configuration.publish_v2_events_mcflow && routingKey.Contains("v2") && !routingKey.Equals("v2.connection.beacon")))
                {
                    lockID = GetLockIDFor(rbEvent.Data.RestaurantID) + "_" + routingKey;
                    lockToken = await _resourceLock.TakeAsync(lockID, _cacheWriteLockAutoReleaseTimeInMs);

                    if (lockToken == Guid.Empty)
                    {
                        Log.Debug($"{nameof(EventsManager)} : Lock is already taken for {lockID}");
                        return;
                    }

                    await PublishMessage_ToMcFlowAsync(rbEvent);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"{nameof(EventsManager)}.{nameof(PublishEventAsync)} : Failed to publish kafka message to McFlow : {ex.Message}", ex);
            }
        }

        static readonly HashSet<string> ignoredEvents = new HashSet<string>
        {
            "v1.caches.clear.restaurant",
            "v2.caches.clear.restaurant",
            "v1.caches.reload.restaurant",
            "v2.caches.reload.restaurant"
        };

        public bool IsRBEventInvalid(RBEvent rbEvent)
        {
            if (ignoredEvents.Contains(rbEvent.RoutingKey))
            {
                if (rbEvent.Data.RestaurantID == 0)
                    return true;
            }
            else if (string.IsNullOrEmpty(rbEvent.Data.EventID) || rbEvent.Data.RestaurantID == 0)
            {
                return true;
            }

            return false;
        }
        /// <summary>
        /// PublishMessage_ToMcFlowAsync this method is used to publush message using McFlow kafka
        /// </summary>
        /// <param name="rbEvent"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        private async Task PublishMessage_ToMcFlowAsync(RBEvent rbEvent)
        {
            try
            {
                if (IsRBEventInvalid(rbEvent))
                {
                    Log.Error($"{nameof(PublishMessage_ToMcFlowAsync)} : Failed to publish kafka message to McFlow as EventID or RestaurantID is null or empty.");
                    return;
                }

                using (var cancellationTokenSource = new CancellationTokenSource(KafkaConstants.TimeoutMS))
                {
                    var headers = new Headers();
                    var (details, eTag) = await _rbClientAdvanced.GetRestaurantDetails_DESERIALIZE_AS_Async<Cloud.V2.Models.Details>(null, rbEvent.Data.RestaurantID, cancellationTokenSource.Token);

                    if (details == null)
                    {
                        Log.Error($"{nameof(PublishMessage_ToMcFlowAsync)}: Details Api failed, marketID cannot be added");
                        return;
                    }
                    else
                        headers.AddHeaderIfNotPresent(HeaderConstants.HEADERS_MARKET, details.marketID);

                    //var msgData = base.GetJsonSerializedEvent(rbEvent);
                    var msgData = JsonConvert.SerializeObject(rbEvent);

                    var topicName = GetTopicName(rbEvent.RoutingKey);
                   
                    byte[] data= System.Text.Encoding.UTF8.GetBytes(rbEvent.Data.RestaurantID.ToString());
                    var xxHash32 = new XxHash32();
                    xxHash32.Append(data);                    
                    var partitionkey = xxHash32.GetCurrentHash();
                    if (!string.IsNullOrEmpty(msgData) && !string.IsNullOrEmpty(topicName))
                    {
                        var message = new ProducerMessage<string, string>( Convert.ToBase64String(partitionkey), msgData, headers, new Timestamp(DateTime.Now));
                        

                        var result = await _mcFlowProducer.SendAsync(message, topicName, cancellationTokenSource.Token);

                        if (result != null)
                        {
                            Log.Info($"{nameof(PublishMessage_ToMcFlowAsync)}:Message published successfully on topic:{topicName}, " +
                                $", Message: {msgData}" +
                                $", Market: {details.marketID}" + $", PartitionKey: {Convert.ToBase64String(partitionkey)}");
                        }
                        else
                            Log.Info($"{nameof(PublishMessage_ToMcFlowAsync)}: Failed to publish kafka message." +
                                $"TopicName: {topicName}");
                    }
                    else
                    {
                        Log.Info($"{nameof(PublishMessage_ToMcFlowAsync)}: Failed to publish kafka message as message" +
                                $"Message: {msgData}" + "is null or empty.");
                    }
                }  
            }

            catch (Exception ex)
            {
                Log.Error($"{nameof(PublishMessage_ToMcFlowAsync)} : Failed to publish kafka message to McFlow : {ex.Message}", ex);
            }
        }

        /// <summary>
        /// getTopicName takes routing key as input parameter and return topic name.
        /// </summary>
        /// <param name="routingKey"></param>
        /// <returns>topicName</returns>
        private string GetTopicName(string routingKey)
        {
            return _configuration.event_topic_prefix + routingKey.Replace('.', '-').ToString();
        }

        public override IEnumerable<string> GetSubscribers()
        {
            return Enumerable.Empty<string>();
        }

        public override Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
