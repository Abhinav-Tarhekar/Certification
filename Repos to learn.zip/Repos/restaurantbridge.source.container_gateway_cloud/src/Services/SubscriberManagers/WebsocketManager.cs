﻿using Common;
using Common.RequestContext;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using NewRelic.Api.Agent;
using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using RestaurantBridge.Gateway.Cloud.Services.Model;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Services.SubscriberManagers
{
    public interface IWebsocketManager : IBaseManager
    {
        Task HandleSubscribersAsync(HttpContext context, WebSocket webSocket, TaskCompletionSource<object> socketFinishedTcs, CancellationToken cancellationToken);
    }

    public class WebsocketManager : BaseManager, IWebsocketManager
    {
        private readonly ILog Log;

        private readonly SemaphoreSlim _subscriberQueuesLookupLock;
        private readonly ConcurrentDictionary<Guid, Model.Subscriber> _subscriberQueuesLookup;
        private readonly SemaphoreSlim _publishLock;

        private readonly bool _blockEmptySubscribeList;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="stringKeyValueStore"></param>
        /// <param name="beaconIntervalInMilliseconds"></param>
        /// <param name="blockEmptySubscribeList"></param>
        /// <exception cref="ArgumentNullException"></exception>

        public WebsocketManager(ILog logger, bool blockEmptySubscribeList = false)
        {
            Log = logger;

            _subscriberQueuesLookupLock = new SemaphoreSlim(1, 1);
            _subscriberQueuesLookup = new ConcurrentDictionary<Guid, Model.Subscriber>();
            _publishLock = new SemaphoreSlim(1, 1);
            _blockEmptySubscribeList = blockEmptySubscribeList;
        }

        public override IEnumerable<string> GetSubscribers()
        {
            return _subscriberQueuesLookup.Select(x => x.Value.ClientName);
        }

        private static List<string> GetSubscriptionList(HttpContext context)
        {
            if (context.Request?.Headers?.TryGetValue("subscribe", out StringValues stringValue) ?? false && stringValue.Count > 0)
                return stringValue[0].Split('|').ToList();

            return new List<string>();
        }
        [ExcludeFromCodeCoverage]// Need to write UT, excluded due to McFlow.
        [Transaction]
        public override Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken)
        {
            Metrics.SetTransaction("Websocket", rbEvent);

            RequestContext.CorrelationID.Init(rbEvent.Data.EventID);
         
            if (_subscriberQueuesLookup.IsEmpty)
            {
                Log.Info($"{nameof(EventsManager)}.{nameof(PublishEventAsync)} : Empty subscriber list");
                return Task.CompletedTask;
            }

            return DoPublishEventAsync(rbEvent, cancellationToken);
        }

        [ExcludeFromCodeCoverage]//We need to write UT for this.
        private async Task DoPublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken)
        {
            await _publishLock.WaitAsync(cancellationToken).ConfigureAwait(false);
            try
            {
                List<Guid> failedSubscriberIDs = new List<Guid>();

                var webSocketsSubscribers = _subscriberQueuesLookup.Where(x => rbEvent.RoutingKey.Contains("connection.beacon") ||
                                                                            x.Value.EventSubscribed.Count == 0 ||
                                                                            x.Value.EventSubscribed.Contains(rbEvent.RoutingKey)).ToList();

                if (rbEvent.RoutingKey.Contains("beacon"))                                                                                                     // 3/10
                    Log.Info($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : Publishing Event : <{rbEvent.RoutingKey}> to {webSocketsSubscribers.Count}/{_subscriberQueuesLookup.Count} subscribers");
                else
                    Log.Info($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : Publishing Event : <{rbEvent.RoutingKey}> to {webSocketsSubscribers.Count}/{_subscriberQueuesLookup.Count} subscribers for Store : <{rbEvent.Data.RestaurantID}>");

                if (webSocketsSubscribers.Count > 0)
                {
                    var bytes = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(rbEvent, RBEventContext.Default.RBEvent);

                    var arraySegment = new ArraySegment<byte>(bytes);

                    foreach (var webSocketSubscriber in webSocketsSubscribers)
                    {
                        try
                        {
                            await webSocketSubscriber.Value.Connection.SendAsync(arraySegment, WebSocketMessageType.Text, true, cancellationToken).ConfigureAwait(false);
                            Log.Info(rbEvent.RoutingKey + " received by " + webSocketSubscriber.Value.ClientName);
                        }
                        catch (Exception ex)
                        {
                            Log.Error($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : Failed to send event to Subscriber {webSocketSubscriber.Value.ClientName}:{webSocketSubscriber.Key}. This subscriber will be removed : {ex.Message}", ex);
                            failedSubscriberIDs.Add(webSocketSubscriber.Key);
                        }
                    }
                }

                if (failedSubscriberIDs.Count > 0)
                {
                    List<(Guid subscriberID, Subscriber)> should_close = new List<(Guid, Subscriber)>();
                    await _subscriberQueuesLookupLock.WaitAsync(cancellationToken).ConfigureAwait(false);
                    try
                    {
                        foreach (var failedSubscriberID in failedSubscriberIDs)
                        {
                            Log.Warn($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : Removing FAILED Subscriber : {failedSubscriberID} ..");
                            if (_subscriberQueuesLookup.TryRemove(failedSubscriberID, out Model.Subscriber subscriber))
                            {
                                Log.Warn($"{nameof(Services.SubscriberManager)}.{nameof(PublishEventAsync)} : Subscriber : {subscriber.ClientName}:{failedSubscriberID} : NOW REMOVED !!");
                                if (subscriber.Connection != null)
                                {
                                    should_close.Add(((Guid subscriberID, Model.Subscriber))(failedSubscriberID, subscriber));
                                }
                            }
                            else
                                Log.Warn($"{nameof(Services.SubscriberManager)}.{nameof(PublishEventAsync)} : Subscriber : {subscriber.ClientName}:{failedSubscriberID} : ALREADY REMOVED !!");
                        }
                    }
                    finally { _subscriberQueuesLookupLock.Release(); }

                    foreach (var (subscriberID, subscriber) in should_close)
                    {
                        try
                        {
                            switch (subscriber.Connection.State)
                            {
                                case WebSocketState.Open:
                                case WebSocketState.CloseReceived:
                                case WebSocketState.CloseSent:
                                    Log.Info($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : {subscriber.ClientName}:{subscriberID}:{subscriber.Connection.State} : CLOSING webSocket ..");
                                    await subscriber.Connection.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed by the Server", cancellationToken).ConfigureAwait(false);

                                    break;
                                default:
                                    Log.Info($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : {subscriber.ClientName}:{subscriberID}:{subscriber.Connection.State} : No need to close webSocket as it is already terminated ..");
                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Critical($"{nameof(SubscriberManager)}.{nameof(PublishEventAsync)} : FAILED TO CLOSE FAILED SUBSCRIBER : {subscriber.ClientName}:{subscriberID} : EXCEPTION : {ex.Message}", ex);
                        }
                    }
                }
            }
            finally
            {
                _publishLock.Release();
            }
        }

        public async Task HandleSubscribersAsync(HttpContext context, WebSocket webSocket, TaskCompletionSource<object> socketFinishedTcs, CancellationToken cancellationToken)
        {
            string clientName = RequestContext.ClientName.Value;
            Guid subscriberID = Guid.NewGuid();

            try
            {
                Log.Info($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : ADDING subscriber ..");

                var subscriber = new Model.Subscriber()
                {
                    ClientName = clientName,
                    Connection = webSocket,
                    EventSubscribed = GetSubscriptionList(context)
                };

                if (_blockEmptySubscribeList && subscriber.EventSubscribed.Count == 0)
                {
                    Log.Error("Please fill the 'subscribe' array with relevant event names!");
                    throw new InvalidOperationException("Please fill the 'subscribe' array with relevant event names!");
                }

                _subscriberQueuesLookup.TryAdd(subscriberID, subscriber);

                Log.Info("Client " + subscriber.ClientName + " subscribed for " + (subscriber.EventSubscribed.Count > 0 ? string.Join(',', subscriber.EventSubscribed) : " all event"));

                try
                {
                    while (webSocket.State == WebSocketState.Open)
                    {
                        var buffer = new byte[4096];
                        var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), cancellationToken).ConfigureAwait(false);
                        if (result != null)
                        {
                            if (result.MessageType == WebSocketMessageType.Close)
                            {
                                Log.Warn($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : Received CLOSE message ..");
                            }
                        }
                        else
                        {
                            throw new Exception("Received a null WebSocketReceiveResult");
                        }
                    }
                }
                catch (OperationCanceledException ex)
                {
                    Log.Debug($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : ReceiveAsync : Operation Canceled", ex);
                }
                catch (Exception ex)
                {
                    Log.Error($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : EXCEPTION : {ex.Message}", ex);
                }
                Log.Info($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : REMOVING subscriber ..");

                if (_subscriberQueuesLookup.TryRemove(subscriberID, out Model.Subscriber _))
                {
                    Log.Warn($"{nameof(Services.SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : SUBSCRIBER ALREADY REMOVED !!");
                }

                try
                {
                    switch (webSocket.State)
                    {
                        case WebSocketState.Open:
                        case WebSocketState.CloseReceived:
                        case WebSocketState.CloseSent:
                            Log.Info($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : CLOSING webSocket ..");
                            await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed by the Server", cancellationToken).ConfigureAwait(false);
                            break;
                        default:
                            Log.Info($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : No need to close webSocket as it is already terminated ..");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : EXCEPTION : {ex.Message}", ex);
                }
            }
            finally
            {
                Log.Info($"{nameof(SubscriberManager)}.{nameof(HandleSubscribersAsync)} : {clientName}:{subscriberID}:{webSocket.State} : DISPOSING webSocket ..");
                socketFinishedTcs.SetResult("Socket closed and disposed");
            }
        }

        public override async Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken)
        {
            try
            {
                if (_subscriberQueuesLookup.Count == 0)
                    return;

                System.Text.RegularExpressions.Regex matcher = null;

                // validate that this is a good regex pattern before publishing it as a event
                if (string.IsNullOrWhiteSpace(regexPattern))
                    throw new ArgumentException($"The subscriberRegexPattern must be a valid regex");

                try
                {
                    matcher = new System.Text.RegularExpressions.Regex(regexPattern);
                }
                catch (Exception ex)
                {
                    throw new ArgumentException($"The subscriberRegexPattern must be a valid regex", ex);
                }

                var subscribersToDrop = _subscriberQueuesLookup.Where(item => matcher.IsMatch(item.Value.ClientName)).Select(x => x.Key).ToList();
                Log.Info($"{nameof(EventsManager)}.{nameof(DropSubscribersAsync)} : {regexPattern} matched {subscribersToDrop.Count} subscribers.");


                foreach (var item in subscribersToDrop)
                {
                    try
                    {
                        if (_subscriberQueuesLookup.TryGetValue(item, out Model.Subscriber subscriberData) && subscriberData.Connection != null)
                        {
                            Log.Info($"{nameof(Services.EventsManager)}.{nameof(DropSubscribersAsync)} : Dropping subscriber : {item} : {subscriberData.ClientName}");
                            await subscriberData.Connection.CloseAsync(WebSocketCloseStatus.EndpointUnavailable, "DROPPED BY SERVER", cancellationToken).ConfigureAwait(false);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error($"{nameof(EventsManager)}.{nameof(DropSubscribersAsync)} : EXCEPTION : {ex.Message}", ex);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error($"{nameof(EventsManager)}.{nameof(DropSubscribersAsync)} : EXCEPTION : {ex.Message}", ex);
            }
        }

        [ExcludeFromCodeCoverage]
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                foreach(var item in _subscriberQueuesLookup)
                {
                    item.Value.Connection.Dispose();
                }

                _subscriberQueuesLookup.Clear();

                _subscriberQueuesLookupLock.Dispose();
                _publishLock.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}
