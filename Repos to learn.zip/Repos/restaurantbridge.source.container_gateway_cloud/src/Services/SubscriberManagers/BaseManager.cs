﻿using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Threading;
using System;
using System.Collections.Generic;

namespace RestaurantBridge.Gateway.Cloud.Services.SubscriberManagers
{
    [JsonSerializable(typeof(RBEvent))]
    partial class RBEventContext : JsonSerializerContext { }

    public abstract class BaseManager : IBaseManager
    {
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing) { }

        public string GetJsonSerializedEvent(RBEvent rbEvent)
        {
            return System.Text.Json.JsonSerializer.Serialize(rbEvent, RBEventContext.Default.RBEvent);
        }

        public abstract Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken);

        public byte[] SerializeToUtf8Bytes(RBEvent rbEvent)
        {
            return System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(rbEvent, RBEventContext.Default.RBEvent);
        }

        public abstract IEnumerable<string> GetSubscribers();

        public abstract Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken);
    }

    public interface IBaseManager : IDisposable
    {
        Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken);
        IEnumerable<string> GetSubscribers();
        Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken);
    }
}
