using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using RestaurantBridge.Gateway.Cloud.Services.SubscriberManagers;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public interface ISubscriberManager : IDisposable
    {
        IWebsocketManager WebsocketManager { get; }
        IMcFlowManager McFlowManager { get; }
        Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken);
        IEnumerable<string> GetSubscribers();
        Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken);
    }

    public class SubscriberManager : ISubscriberManager
    {
        public IWebsocketManager WebsocketManager { get; private set; }
        public IMcFlowManager McFlowManager { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="websocketManager"></param>
        /// <param name="mcFlowManager"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public SubscriberManager(IWebsocketManager websocketManager, IMcFlowManager mcFlowManager)
        {
            WebsocketManager = websocketManager;
            McFlowManager = mcFlowManager;
        }

        public Task PublishEventAsync(RBEvent rbEvent, CancellationToken cancellationToken)
        {
            var tasks = new List<Task>();

            if (WebsocketManager != null)
                tasks.Add(WebsocketManager.PublishEventAsync(CloneWithoutPayload(rbEvent), cancellationToken));

            if (McFlowManager != null)
                tasks.Add(McFlowManager.PublishEventAsync(rbEvent, cancellationToken));

            return Task.WhenAll(tasks);
        }

        public IEnumerable<string> GetSubscribers()
        {
            var list = new List<string>();
            
            if (WebsocketManager != null)
                list.AddRange(WebsocketManager.GetSubscribers());
            
            if (McFlowManager != null)
                list.AddRange(McFlowManager.GetSubscribers());
            
            return list;
        }

        public Task DropSubscribersAsync(string regexPattern, CancellationToken cancellationToken)
        {
            var tasks = new List<Task>();

            if (WebsocketManager != null)
                tasks.Add(WebsocketManager.DropSubscribersAsync(regexPattern, cancellationToken));

            if (McFlowManager != null)
                tasks.Add(McFlowManager.DropSubscribersAsync(regexPattern, cancellationToken));

            return Task.WhenAll(tasks);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                WebsocketManager?.Dispose();
                McFlowManager?.Dispose();
            }
        }

        static RBEvent CloneWithoutPayload(RBEvent rbEvent)
        {
            if (rbEvent.Data.SubEvent == null)
                return rbEvent;

            var clone = new RBEvent()
            {
                RoutingKey = rbEvent.RoutingKey,
                Data = new RBEventData()
                {
                    ETag = rbEvent.Data.ETag,
                    EventID = rbEvent.Data.EventID,
                    Interval_MS = rbEvent.Data.Interval_MS,
                    Nounce = rbEvent.Data.Nounce,
                    RestaurantID = rbEvent.Data.RestaurantID,
                    ServerID = rbEvent.Data.ServerID,
                    SubEvent = null // intentional
                }
            };

            return clone;
        }
    }
}
