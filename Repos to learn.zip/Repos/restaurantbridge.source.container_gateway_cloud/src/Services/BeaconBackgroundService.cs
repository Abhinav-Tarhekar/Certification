﻿using Common;
using Microsoft.Extensions.Hosting;
using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using GlobalMonitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Global.RestaurantEventMonitor;
using V1Monitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.V1.RestaurantEventMonitor;
using V2Monitor = RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.V2.RestaurantEventMonitor;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public class BeaconBackgroundService : BackgroundService
    {
        private readonly ILog _log;
        private readonly EventsManager _eventsManager;
        private readonly int _timeBetweenBeaconsInMilliseconds;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventsManager"></param>
        /// <param name="log"></param>
        /// <param name="timeBetweenBeaconsInMilliseconds"></param>
        /// <exception cref="ArgumentNullException"></exception>
        [ExcludeFromCodeCoverage]
        public BeaconBackgroundService(EventsManager eventsManager, ILog log, int timeBetweenBeaconsInMilliseconds)
        {
            _eventsManager = eventsManager ?? throw new ArgumentNullException(nameof(eventsManager));
            _log = log ?? throw new ArgumentNullException(nameof(log));
            _timeBetweenBeaconsInMilliseconds = timeBetweenBeaconsInMilliseconds;
        }

        /// <summary>
        /// Triggered when the applicatin host is ready to start the service
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _log.Info("Beacon service was started");
            return base.StartAsync(cancellationToken);
        }

        /// <summary>
        /// Triggered when the application host is performing a graceful shutdown
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _log.Info("Beacon service was stopped");
            return base.StopAsync(cancellationToken);
        }

        [ExcludeFromCodeCoverage]
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    _log.Debug($"{nameof(BeaconBackgroundService)} : Sending BEACON ..");

                    var eventId = Guid.NewGuid().ToString();

                    RBEvent V1_externalEvent = new RBEvent { RoutingKey = V1Monitor.BeaconEvent, Data = new RBEventData { RestaurantID = -1, ServerID = Environment.MachineName, Nounce = Guid.NewGuid().ToString(), Interval_MS = _timeBetweenBeaconsInMilliseconds, EventID = eventId } };
                    Task V1_publishing_task = _eventsManager.V1Manager.WebsocketManager.PublishEventAsync(V1_externalEvent, stoppingToken);

                    RBEvent V2_externalEvent = new RBEvent { RoutingKey = V2Monitor.BeaconEvent, Data = new RBEventData { RestaurantID = -1, ServerID = Environment.MachineName, Nounce = Guid.NewGuid().ToString(), Interval_MS = _timeBetweenBeaconsInMilliseconds, EventID = eventId } };
                    Task V2_publishing_task = _eventsManager.V2Manager.WebsocketManager.PublishEventAsync(V2_externalEvent, stoppingToken);
                    
                    RBEvent globalEvent = new RBEvent { RoutingKey = GlobalMonitor.BeaconEvent, Data = new RBEventData { RestaurantID = -1, ServerID = Environment.MachineName, Nounce = Guid.NewGuid().ToString(), Interval_MS = _timeBetweenBeaconsInMilliseconds, EventID = eventId } };
                    Task global_publishing_task = _eventsManager.GlobalManager.WebsocketManager.PublishEventAsync(globalEvent, stoppingToken);

                    await Task.WhenAll(V1_publishing_task, V2_publishing_task, global_publishing_task).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _log.Error($"{nameof(BeaconBackgroundService)} : EXCEPTION : Failed to send BEACON : {ex.Message}", ex);
                }
                await Task.Delay(_timeBetweenBeaconsInMilliseconds, stoppingToken).ConfigureAwait(false);
            }
        }
    }
}
