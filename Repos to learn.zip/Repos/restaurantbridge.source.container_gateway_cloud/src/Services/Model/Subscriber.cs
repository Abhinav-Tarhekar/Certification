﻿using RestaurantBridge.Gateway.Cloud.API.Client.Monitoring.Models;
using System.Collections.Generic;
using System.Net.WebSockets;

namespace RestaurantBridge.Gateway.Cloud.Services.Model
{
    public class Subscriber
    {
        public string ClientName { get; set; }
        public WebSocket Connection { get; set; }
        public List<string> EventSubscribed { get; set; }
    }
}
