﻿using Common;
using Newtonsoft.Json;
using RestaurantBridge.Common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.Services
{
    public interface IProductsSpecifiedCache
    {
        Task<(string productJson, string eTag)> GetSingleAsync(long restaurantID, int productID);
        Task<string> GetMultipleAsync(long restaurantID, HashSet<int> productIDs);
        Task HelpAsync(string eventName, long restaurantID);
    }

    public class ProductsSpecifiedCache : IProductsSpecifiedCache
    {
        private const string _ETAG_KEY_ = "_ETAG_";

        private readonly ILog Log;
        private readonly EventsManager _eventsManager;
        private readonly IStringKeyHashStore _stringKeyHashStore;
        private readonly IResourceLock _resourceLock;
        private readonly Cache.ParsedProducts.V1.IClientAdvanced _cacheParsedProducts;

        private readonly int _cacheWriteLockAutoReleaseTimeInMs;
        private readonly int _cacheWriteLockAquisitionTimeoutInMs;
        private readonly int _cacheWriteLockTakeRetryDelayInMs;
        private readonly int _cacheTimeToLiveInMs;

        private readonly ConcurrentDictionary<long, Task<string>> _eTagCache;

        public ProductsSpecifiedCache(
            ILog logger, 
            EventsManager eventsManager, 
            IStringKeyHashStore stringKeyHashStore, 
            IResourceLock resourceLock, 
            Cache.ParsedProducts.V1.IClientAdvanced cacheParsedProducts,
            int cacheWriteLockAutoReleaseTimeInMs,
            int cacheWriteLockTakeRetryDelayInMs,
            int cacheTimeToLiveInMs)
        {
            Log = logger;
            _eventsManager = eventsManager;
            _stringKeyHashStore = stringKeyHashStore;
            _resourceLock = resourceLock;
            _cacheParsedProducts = cacheParsedProducts;

            _cacheWriteLockAutoReleaseTimeInMs = cacheWriteLockAutoReleaseTimeInMs;
            _cacheWriteLockAquisitionTimeoutInMs = _cacheWriteLockAutoReleaseTimeInMs + cacheWriteLockTakeRetryDelayInMs;
            _cacheWriteLockTakeRetryDelayInMs = cacheWriteLockTakeRetryDelayInMs;
            _cacheTimeToLiveInMs = cacheTimeToLiveInMs;
            _eTagCache = new ConcurrentDictionary<long, Task<string>>();

            _eventsManager.onCachesClear += (_, e) => ClearAsync("onCachesClear", e.RestaurantID);
            _eventsManager.onCachesReload += (_, e) => ReloadAsync("onCachesReload", e.RestaurantID);
            _eventsManager.onProductsInvalidation += (_, e) => ReloadAsync("onProductsInvalidation", e.RestaurantID);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetKeyIDFor(long restaurantID) => $"{restaurantID}";
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetLockIDFor(long restaurantID) => $"{restaurantID}_LOCK";


        private static readonly JsonSerializerSettings _serializerSettings = new JsonSerializerSettings()
        {
            DefaultValueHandling = DefaultValueHandling.Ignore,
            NullValueHandling = NullValueHandling.Ignore,
            Converters = { new Newtonsoft.Json.Converters.StringEnumConverter() }
        };

        private async Task ClearAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(ClearAsync)} : {eventName} : Waiting for global resource lock for {restaurantID} ..");
            var lockID = GetLockIDFor(restaurantID);
            var lockTocken = await _resourceLock.TryTakeAsync(lockID, _cacheWriteLockAutoReleaseTimeInMs, _cacheWriteLockAquisitionTimeoutInMs, _cacheWriteLockTakeRetryDelayInMs);
            if (lockTocken != Guid.Empty)
            {
                try
                {
                    Log.Info($"{nameof(ClearAsync)} : Clearing products specified data for {restaurantID} ..");
                    _eTagCache.TryRemove(restaurantID, out _);
                    var key = GetKeyIDFor(restaurantID);
                    await _stringKeyHashStore.ClearAsync(key);
                }
                finally
                {
                    Log.Info($"{nameof(ClearAsync)} : Releasing global resource lock for {restaurantID} ..");
                    await _resourceLock.ReleaseAsync(lockID, lockTocken);
                }
            }
            else
            {
                Log.Critical($"{nameof(ClearAsync)} : Failed to get global resource lock for {restaurantID}. Clearing cache without lock ..");
                _eTagCache.TryRemove(restaurantID, out _);
                var key = GetKeyIDFor(restaurantID);
                await _stringKeyHashStore.ClearAsync(key);
            }
        }

        private async Task ReloadAsync(string eventName, long restaurantID)
        {
            Log.Info($"{nameof(ReloadAsync)} : {eventName} : Received warmup request for products specified data cache for {restaurantID}.");
            _eTagCache.TryRemove(restaurantID, out _); // clear in mem eTag
            await Task.Run(async () =>
            {
                try
                {
                    Log.Info($"{nameof(ReloadAsync)} : Updating products specified data cache for {restaurantID} ..");
                    await UpdateAsync(restaurantID, new HashSet<string>(0), false);
                }
                catch (Exception ex)
                {
                    Log.Warn($"{nameof(ReloadAsync)} : Could not warm up products specified data cache for {restaurantID} because of exception : {ex.Message}", ex);
                }
           });
        }

        private async Task<Dictionary<string,string>> UpdateAsync(long restaurantID, HashSet<string> itemsKeyToReturnValuesFor, bool force)
        {
            Log.Info($"{nameof(UpdateAsync)} : Updating products specified data for {restaurantID} {(force ? "FORCED ":"")}..");
            var key = GetKeyIDFor(restaurantID);

            Log.Info($"{nameof(UpdateAsync)} : Waiting for global resource lock for {restaurantID} ..");
            var lockID = GetLockIDFor(restaurantID);
            var lockTocken = await _resourceLock.TryTakeAsync(lockID, _cacheWriteLockAutoReleaseTimeInMs, _cacheWriteLockAquisitionTimeoutInMs, _cacheWriteLockTakeRetryDelayInMs);
            if (lockTocken != Guid.Empty)
            {
                try
                {
                    Log.Info($"{nameof(UpdateAsync)} : Got global resource lock for {restaurantID} .. ");

                    if (force)
                    {
                        Log.Info($"{nameof(UpdateAsync)} : Forced updated for {restaurantID} clearing cache .. ");
                        _eTagCache.TryRemove(restaurantID, out _);
                        await _stringKeyHashStore.ClearAsync(key);
                    }

                    var currentItems = await _stringKeyHashStore.GetAsync(key, new HashSet<string>(1) { _ETAG_KEY_ });
                    var currentETag = (currentItems == null) ? null : (currentItems.ContainsKey(_ETAG_KEY_) ? currentItems[_ETAG_KEY_] : null);

                    string eTag = null;
                    List<V1.Models.RestaurantProduct> products = null;

                    eTag = await _cacheParsedProducts.GetRestaurantProductsETagAsync(restaurantID);

                    if ((currentETag != null) && (currentETag == eTag))
                    {
                        Log.Info($"{nameof(UpdateAsync)} : No change for' products specified data' for {restaurantID} ..");
                        return await _stringKeyHashStore.GetAsync(key, itemsKeyToReturnValuesFor);
                    }

                    (products, eTag) = await _cacheParsedProducts.GetRestaurantProducts_DESERIALIZE_AS_Async<V1.Models.RestaurantProduct>(currentETag, restaurantID);

                    if (products == null)
                    {
                        _eTagCache.TryRemove(restaurantID, out _);
                        await _stringKeyHashStore.ClearAsync(key);
                        return await _stringKeyHashStore.GetAsync(key, itemsKeyToReturnValuesFor);
                    }
                    else
                    {
                        Log.Info($"{nameof(UpdateAsync)} : Writing 'products specified data' for {restaurantID} ..");
                        var items = new Dictionary<string, string>();
                        items.Add(_ETAG_KEY_, eTag);
                        foreach(var product in products)
                        {
                            var productJson = JsonConvert.SerializeObject(product, _serializerSettings);
                            items.Add(product.ID.ToString(), productJson);
                        }
                        await _stringKeyHashStore.SetAsync(key, items, _cacheTimeToLiveInMs);
                        var completedTask = _eTagCache.AddOrUpdate(restaurantID, Task.FromResult(eTag), (_, __) => Task.FromResult(eTag));
                        return await _stringKeyHashStore.GetAsync(key, itemsKeyToReturnValuesFor);
                    }
                }
                finally
                {
                    Log.Info($"{nameof(UpdateAsync)} : Releasing global resource lock for {restaurantID} ..");
                    await _resourceLock.ReleaseAsync(lockID, lockTocken);
                }
            }
            else
            {
                Log.Critical($"{nameof(UpdateAsync)} : Failed to get global resource lock for {restaurantID}.");
            }

            throw new Exception($"{nameof(UpdateAsync)} : Could not update/verify cache data for {restaurantID}");
        }

        public async Task<(string productJson, string eTag)> GetSingleAsync(long restaurantID, int productID)
        {
            Log.Debug($"{nameof(GetSingleAsync)} : Get 'products specified data' for {restaurantID}:{productID} ..");
            var key = GetKeyIDFor(restaurantID);
            try
            {
                string expectedETag = null;
                try
                {
                    // get etag for complete product data
                    expectedETag = await _eTagCache.GetOrAdd(restaurantID, (_) => _cacheParsedProducts.GetRestaurantProductsETagAsync(restaurantID));
                    if (expectedETag != null && string.IsNullOrWhiteSpace(expectedETag))
                    {
                        throw new Exception($"eTag received was empty or whitespace");
                    }
                    if (expectedETag == null)
                    {
                        // restaurant product data not found 

                        // clear to not store this so we retry next time
                        _eTagCache.TryRemove(restaurantID, out _);

                        return (null, null);
                    }
                }
                catch(Exception ex)
                {
                    // if something when wrong clear the eTag cache - we don't want to store and exception in the dictionary
                    // treat as not found
                    Log.Error($"{nameof(GetSingleAsync)} : Could not get eTag of products for {restaurantID} : EXECPTION : {ex.Message}", ex);
                    _eTagCache.TryRemove(restaurantID, out _);
                    return (null, null);
                }
               
                // ok so now there is an eTag - let's try to read data from the redis cache

                var productKey = productID.ToString();

                var itemKeys = new HashSet<string>();
                itemKeys.Add(productKey);
                itemKeys.Add(_ETAG_KEY_);

                Dictionary<string,string> itemValues = await _stringKeyHashStore.GetAsync(key, itemKeys);

                if (   itemValues == null                                                                         // This should not happen .. so something is wrong and we need to try to update
                    || !itemValues.ContainsKey(_ETAG_KEY_)                                                        // This should not happen .. so something is wrong and we need to try to update
                    || ((itemValues[_ETAG_KEY_] != null) && string.IsNullOrWhiteSpace(itemValues[_ETAG_KEY_]))    // This should not happen .. so something is wrong and we need to try to update
                   )
                {
                    Log.Error($"{nameof(GetSingleAsync)} : Missing, Corrupted eTag information for 'products specified data' for {restaurantID}:{productID} .. updating ..");
                    itemValues = await UpdateAsync(restaurantID, itemKeys, true);
                }
                else
                {
                    if (itemValues[_ETAG_KEY_] != expectedETag)
                    {
                        // This means the data is not in the cache or the cached data is out of date / stale
                        itemValues = await UpdateAsync(restaurantID, itemKeys, false);
                    }
                }

                // if the product has a value and that value is not a null -- then the product was found , but if it is null or whitespace then the redis data is corrupted
                if (itemValues.ContainsKey(productKey) && itemValues[productKey] != null && string.IsNullOrWhiteSpace(itemValues[productKey]))
                {
                    Log.Error($"{nameof(GetSingleAsync)} : Missing, Corrupted content information for 'products specified data' for {restaurantID}:{productID} .. updating ..");
                    itemValues = await UpdateAsync(restaurantID, itemKeys, true);
                }

                return (itemValues[productKey], itemValues[productKey] == null ? null : itemValues[_ETAG_KEY_]);
            }
            catch(Exception ex)
            {
                // SOMETHING WHEN SUPER WRONG and we will clear the cache for good measure
                Log.Warn($"{nameof(GetSingleAsync)} : Could not get 'products specified data' for {restaurantID}:{productID} .. clearing cache .. : EXCEPTION : {ex.Message}", ex);
                await ClearAsync(nameof(GetSingleAsync), restaurantID);
            }
            return (null, null);
        }

        public async Task<string> GetMultipleAsync(long restaurantID, HashSet<int> productIDs)
        {
            Log.Debug($"{nameof(GetMultipleAsync)} : Get 'products specified data' for {restaurantID} and {productIDs.Count} products ..");
            var key = GetKeyIDFor(restaurantID);
            try
            {
                string expectedETag = null;
                try
                {
                    // get etag for complete product data
                    expectedETag = await _eTagCache.GetOrAdd(restaurantID, (_) => _cacheParsedProducts.GetRestaurantProductsETagAsync(restaurantID));
                    if (expectedETag != null && string.IsNullOrWhiteSpace(expectedETag))
                    {
                        throw new Exception($"eTag received was empty or whitespace");
                    }
                    if (expectedETag == null)
                    {
                        // restaurant product data not found 

                        // clear to not store this so we retry next time
                        _eTagCache.TryRemove(restaurantID, out _);

                        return null;
                    }
                }
                catch (Exception ex)
                {
                    // if something when wrong clear the eTag cache - we don't want to store and exception in the dictionary
                    // treat as not found
                    Log.Error($"{nameof(GetMultipleAsync)} : Could not get eTag of products for {restaurantID} : EXECPTION : {ex.Message}", ex);
                    _eTagCache.TryRemove(restaurantID, out _);
                    return null;
                }

                // ok so now there is an eTag - let's try to read data from the redis cache

                var productKeys = productIDs.Select(id => id.ToString()).ToList();

                var itemKeys = new HashSet<string>(productKeys);
                itemKeys.Add(_ETAG_KEY_);

                Dictionary<string, string> itemValues = await _stringKeyHashStore.GetAsync(key, itemKeys);

                if (itemValues == null                                                                            // This should not happen .. so something is wrong and we need to try to update
                    || !itemValues.ContainsKey(_ETAG_KEY_)                                                        // This should not happen .. so something is wrong and we need to try to update
                    || ((itemValues[_ETAG_KEY_] != null) && string.IsNullOrWhiteSpace(itemValues[_ETAG_KEY_]))    // This should not happen .. so something is wrong and we need to try to update
                   )
                {
                    Log.Error($"{nameof(GetMultipleAsync)} : Missing, Corrupted eTag information for 'products specified data' for {restaurantID} and {productIDs.Count} products .. updating ..");
                    itemValues = await UpdateAsync(restaurantID, itemKeys, true);
                }
                else
                {
                    if (itemValues[_ETAG_KEY_] != expectedETag)
                    {
                        // This means the data is not in the cache or the cached data is out of data / stale
                        itemValues = await UpdateAsync(restaurantID, itemKeys, false);
                    }
                }

                // if any product has a value and that value is not a null -- then the product was found , but if it is null or whitespace then the redis data is corrupted
                var corruptedProductsDetected = false;
                foreach (var productKey in productKeys)
                {
                    if (itemValues.ContainsKey(productKey) && itemValues[productKey] != null && string.IsNullOrWhiteSpace(itemValues[productKey]))
                    {
                        Log.Error($"{nameof(GetMultipleAsync)} : Missing, Corrupted content information for 'products specified data' for {restaurantID}:{productKey} ..");
                        corruptedProductsDetected = true;
                    }
                }
                if (corruptedProductsDetected)
                {
                    Log.Error($"{nameof(GetMultipleAsync)} : Corrupted content information for 'products specified data' for {restaurantID} .. updating ..");
                    itemValues = await UpdateAsync(restaurantID, itemKeys, true);
                }

                itemValues.Remove(_ETAG_KEY_);
                StringBuilder productListBuilder = new StringBuilder();

                var separator = "";
                productListBuilder.Append('[');
                foreach (var itemValue in itemValues.Values)
                {
                    if (!string.IsNullOrWhiteSpace(itemValue))
                    {
                        productListBuilder.Append(separator);
                        productListBuilder.Append(itemValue);
                        separator = ",";
                    }
                }
                productListBuilder.Append(']');

                return (productListBuilder.ToString());
            }
            catch (Exception ex)
            {
                // SOMETHING WHEN SUPER WRONG and we will clear the cache for good measure
                Log.Warn($"{nameof(GetMultipleAsync)} : Could not get 'products specified data' for {restaurantID} .. clearing cache .. : EXCEPTION : {ex.Message}", ex);
                await ClearAsync(nameof(GetMultipleAsync), restaurantID);
            }
            return null;
        }

        public async Task HelpAsync(string eventName, long restaurantID)
        {
            ClearAsync(eventName, restaurantID);
            ReloadAsync(eventName, restaurantID);
        }
    }
}
