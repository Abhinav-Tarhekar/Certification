﻿using Mcd.Utilities.Abstraction.Extensions;
using RestaurantBridge.Common.EmpheralPubSub;
using RestaurantBridge.Common.ResourceLock;
using RestaurantBridge.Common.StringKeyHashStore;
using RestaurantBridge.Common.StringKeyValueStore;
using RestaurantBridge.Gateway.Cloud.Services;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud
{
    public static class StartupExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task PrefetchDependencies(this IServiceProvider serviceProvider, CancellationToken cancellationToken)
        {
            await serviceProvider.UsePrefetchAsync<Common.IStringKeyValueStore>(item =>
            {
                item
                .WithInfiniteReply()
                .WithReplyDelay(TimeSpan.FromSeconds(1))
                .WithInitialization(async init =>
                {
                    var stringKeyValueStore = init.Value as StringKeyValueStore_Redis;
                    if (stringKeyValueStore != null)
                        await stringKeyValueStore.StartAsync(init.CancellationToken);
                });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<Common.IStringKeyHashStore>(item =>
            {
                item
                    .WithInfiniteReply()
                    .WithReplyDelay(TimeSpan.FromSeconds(1))
                    .WithInitialization(async init =>
                    {
                        var stringKeyHashStore = init.Value as StringKeyHashStore_Redis;
                        if (stringKeyHashStore != null)
                            await stringKeyHashStore.StartAsync(init.CancellationToken);
                    });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<Common.IResourceLock>(item =>
            {
                item
                    .WithInfiniteReply()
                    .WithReplyDelay(TimeSpan.FromSeconds(1))
                    .WithInitialization(async init =>
                    {
                        var resourceLock = init.Value as ResourceLock_Redis;
                        if (resourceLock != null)
                            await resourceLock.StartAsync();
                    });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<Common.IEmpheralPubSub>(item =>
            {
                item
                    .WithInfiniteReply()
                    .WithReplyDelay(TimeSpan.FromSeconds(1))
                    .WithInitialization(async init =>
                    {
                        var empheralPubSub = init.Value as EmpheralPubSub_Redis;
                        if (empheralPubSub != null)
                            await empheralPubSub.StartAsync(init.CancellationToken);
                    });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<EventsManager>(item =>
            {
                item
                    .WithInfiniteReply()
                    .WithReplyDelay(TimeSpan.FromSeconds(1))
                    .WithInitialization(async init =>
                    {
                        var eventsManager = init.Value;
                        if (eventsManager != null)
                            await eventsManager.InitializeAsync(init.CancellationToken);
                    });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<IRestaurantSearchIndex>(item =>
            {
                item
                    .WithInfiniteReply()
                    .WithReplyDelay(TimeSpan.FromSeconds(1))
                    .WithInitialization(async init =>
                    {
                        var restaurantSearchIndex = init.Value;
                        if (restaurantSearchIndex != null)
                            await restaurantSearchIndex.InitializeAsync();
                    });
            }, cancellationToken);

            await serviceProvider.UsePrefetchAsync<IProductsSpecifiedCache>(cancellationToken);
        }
    }
}
