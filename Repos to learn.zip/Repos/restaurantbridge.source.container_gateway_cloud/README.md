# RestaurantBridge.Gateway.Cloud

This is a gateway service that implements the external faceing and public API for cloud components to use. 

It is for the most part a pass through to the internal APIs.
It is independent to provide a single unified endpoint for bridge clients.
It serves as an abstraction on the bridge internal implementation to enable the bridge capability to refactor as needed without inpacting clients.
It filters some of the information from the internal APIs (like foe configuration etc.) that should not be exposed to outside parties.

It deals with agregating the internal bridge events and exposing the external events on the websocket to signal changes in data which clients need to update their in memory cached data without polling the bridge.

You can visit "http://URL/swagger" to explore or exercise the API.

The bridge team exposes a public C#/.NET implementation of the bridge client from repo "public_library_nuget_api_gateway_cloud"


.NET clients are encouraged to use this library to access the API.
The implementation maps the websockets to event simplifying use.

#This is a Dummy Commit.
#Latest NewRelic Instrument Tag is V2
Dummy comit
