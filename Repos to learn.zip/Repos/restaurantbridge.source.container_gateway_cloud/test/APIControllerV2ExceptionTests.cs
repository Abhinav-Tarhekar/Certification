﻿using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.Services.Exceptions;
using RestaurantBridge.Gateway.Cloud.V2;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1.Models;


namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    public class APIControllerV2ExceptionTests
    {
        APIController apiController;

        #region"Initialization Not Found Exception"
        public async Task InitializeNotFoundException()
        {
            var eTag = (string)null;
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrides = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

            apiController = new V2.APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrides.Object,
                 _cacheParsedCoatesMenus.Object,
                  _cacheParsedSettings.Object
                 
                 );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            #region Search Restaurant
            _restaurantSearchIndex.Setup(x => x.SearchRestaurantsAsync(null, null, null, null, null, null, null, null, null, null, null));
            #endregion

            #region Restaurant Details           

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(),new CancellationToken { }));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Restaurant State
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), It.IsAny<bool>(), new CancellationToken { }));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Channel Menus
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenusETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Tax Parameters
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<V2.Models.TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Product Outages

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region OQMC Overrides
            _oqmcOverrides.Setup(x => x.GetOQMCOverridesAsync(It.IsAny<long>()));
            #endregion
            #region Restaurant Settings

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion
            #region Combined Restaurant
            _service.Setup(s => s.GetRestaurantCombinedV2Async(It.IsAny<RestaurantCombinedV2.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { }));
            #endregion
        }
        #endregion

        #region"Initialization Bad Gateway Exception"
        public async Task InitializeBadGatewayException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrride = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

            apiController = new V2.APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrride.Object,
                 _cacheParsedCoatesMenus.Object,
                 _cacheParsedSettings.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            #region Search Restaurant
            _restaurantSearchIndex.Setup(x => x.SearchRestaurantsAsync(null, null, null, null, null, null, null, null, null, null, null)).Throws(new Exception("Error"));
            #endregion    
            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new Exception("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            #endregion

            #region Restaurant State
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Restaurant Configuration
            //_restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationAsync(It.IsAny<long>(), It.IsAny<bool>())).Throws(new Exception("Error"));
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { })).Throws(new Exception("Error"));
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Channel Menus
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Tax Parameters
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<V2.Models.TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Product Outages mocking
            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region OQMC Overrides
            _oqmcOverrride.Setup(x => x.GetOQMCOverrides_DESERIALIZE_AS_Async<V2.Models.OQMCOverrides>(It.IsAny<long>())).Throws(new Exception("Error"));
            #endregion

            #region coates
            _cacheParsedCoatesMenus.Setup(x=>x.GetRestaurantCoatesMenus_DESERIALIZE_AS_Async<RestaurantCoatesMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            _cacheParsedCoatesMenus.Setup(x=>x.GetRestaurantCoatesMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion
            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion
            #region Combined Restaurant
            _service.Setup(s => s.GetRestaurantCombinedV2Async(It.IsAny<RestaurantCombinedV2.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

        }
        #endregion

        #region"Initialization Request Timeout Exception"
        public async Task InitializeRequestTimeoutException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrides = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

            apiController = new V2.APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrides.Object,
                 _cacheParsedCoatesMenus.Object,
                 _cacheParsedSettings.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            #region Search Restaurant
            _restaurantSearchIndex.Setup(x => x.SearchRestaurantsAsync(null, null, null, null, null, null, null, null, null, null, null)).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new RequestTimeoutException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            #endregion,

            #region Restaurant state
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(),null, null, new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Channel Menus
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(),It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Tax Parameters
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<V2.Models.TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Product Outages

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region OQMC Overrides
            _oqmcOverrides.Setup(x => x.GetOQMCOverrides_DESERIALIZE_AS_Async<V2.Models.OQMCOverrides>(It.IsAny<long>())).Throws(new RequestTimeoutException("Error"));
            #endregion
            #region coates
            _cacheParsedCoatesMenus.Setup(x => x.GetRestaurantCoatesMenus_DESERIALIZE_AS_Async<RestaurantCoatesMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _cacheParsedCoatesMenus.Setup(x => x.GetRestaurantCoatesMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion
            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion
            #region Combined Restaurant
                _service.Setup(s => s.GetRestaurantCombinedV2Async(It.IsAny<RestaurantCombinedV2.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion
        }
        #endregion

        #region"Initialization Circuit Breaker Open Exception"
        public async Task InitializeCircuitBreakerOpenException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrides = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

            apiController = new V2.APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrides.Object,
                 _cacheParsedCoatesMenus.Object,
                 _cacheParsedSettings.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            #region Search Restaurant            
            _restaurantSearchIndex.Setup(x => x.SearchRestaurantsAsync(null, null, null, null, null, null, null, null, null, null, null)).Throws(new CircuitBreakerOpenException("Error"));

            #endregion

            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            #endregion

            #region Restaurant State           
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Channel Menus
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Tax Parameters
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<V2.Models.TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Product Outages

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region OQMC Overrides
            _oqmcOverrides.Setup(x => x.GetOQMCOverrides_DESERIALIZE_AS_Async<V2.Models.OQMCOverrides>(It.IsAny<long>())).Throws(new CircuitBreakerOpenException("Error"));
            #endregion
            #region coates
            _cacheParsedCoatesMenus.Setup(x => x.GetRestaurantCoatesMenus_DESERIALIZE_AS_Async<RestaurantCoatesMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            _cacheParsedCoatesMenus.Setup(x => x.GetRestaurantCoatesMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion
            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion
            #region Combined Restaurant
            _service.Setup(s => s.GetRestaurantCombinedV2Async(It.IsAny<RestaurantCombinedV2.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion
        }
        #endregion

        #region Unit Tests

        #region  Search Restaurants
        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, null)]
        public async Task SearchRestaurantsObjecCircuitBreakerOpenAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, null)]
        public async Task SearchRestaurantsRequestTimeoutExceptionAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, null)]
        public async Task SearchRestaurantsBadGatewayAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeBadGatewayException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(502, statusCode.StatusCode);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 32.482322, null, null, null)]
        public async Task SearchRestaurantslongitudeHasNoValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, -84.941197, null, null)]
        public async Task SearchRestaurantslatitudeHasNoValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 91, -84.941197, null, null)]
        public async Task SearchRestaurantslatitudeOutOfRangeValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, -91, -84.941197, null, null)]
        public async Task SearchRestaurantslatitudeOutOfRangeValueNegativeAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 32.482322, 181, null, null)]
        public async Task SearchRestaurantslongitudeOutOfRangeValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 32.482322, -181, null, null)]
        public async Task SearchRestaurantslongitudeOutOfRangeNegativeValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, 1000, null)]
        public async Task SearchRestaurantsmaxDistanceInMetersHasValueAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await InitializeNotFoundException();
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 400);
        }
        #endregion

        #region  Restaurants Details 
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        #endregion

        #region Restaurant State

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }
        #endregion

        #region Restaurant Configuration

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationNotFoundAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion

        #region Channel Menus

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjectNotFoundAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode1 = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode1);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjectBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjectRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjecCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion

        #region ChannelMenus Head
        [Test]
        [TestCase(1188765)]
        public async Task RestaurantChannelMenusHeadNotFoundAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            var statusCode = result as StatusCodeResult;
            Assert.AreEqual(statusCode.StatusCode, 404);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusHeadBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusHeadObjectRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusHeadObjecCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion

        #region Tax Parameters

        [Test]
        [TestCase(4567)]
        public async Task WhenInvalidStoreIdIsProvided(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var objResult = result.Result as StatusCodeResult;
            objResult.StatusCode.Equals(404);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParametersObjectBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParametersObjectObjectRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParametersObjecCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParameterHeadNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantTaxParametersHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParameteHeadBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantTaxParametersHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParameteHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantTaxParametersHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task TaxParameteHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantTaxParametersHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion

        #region  Product Outages

        [Test]
        [TestCase(2455)]
        public async Task ProductOutagesNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task ProductOutagesBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task ProductOutagesRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task ProductOutagesCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        #endregion

        #region OQMC Overrides
        [Test]
        [TestCase(2455)]
        public async Task OqmcOverridesNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetOqmcOverridesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task OqmcOverridesBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetOqmcOverridesAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455)]
        public async Task OqmcOverridesRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetOqmcOverridesAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }
        [Test]
        [TestCase(2455)]
        public async Task OqmcOverridesCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetOqmcOverridesAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
       
        #region Coates 
        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusHeadNotFoudnAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetHeadCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusHeadBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetHeadCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetHeadCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CoatesMenusHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetHeadCoatesMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        #endregion
        #region "Restaurant Setings"


        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantSettingsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion
        #region Combined Restaurant 
        #region V2
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantCombinedV2Async(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(504, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantCruitBreakAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantCombinedV2Async(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(503, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantCombinedV2Async(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(502, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantNotFoundAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantCombinedV2Async(restaurantID);
            var statusCode1 = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode1);
        }
        #endregion
        #endregion
        #endregion
    }
}
