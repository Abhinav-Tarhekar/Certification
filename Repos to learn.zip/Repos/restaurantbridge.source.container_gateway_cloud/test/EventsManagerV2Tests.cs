﻿using Common;
using McD.McFlow.Client.Library.Producer;
using Microsoft.AspNetCore.Http;
using Moq;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.Services;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    [TestFixture]
    public class EventsManagerV2Tests
    {
        private EventsManager _eventsManager;
        private TestingEmpheralPubSub empheralPubSub;
        private HttpContext _httpContext;

        Mock<WebSocket> _webSocket = new Mock<WebSocket>();
        Mock<ILog> logger = new Mock<ILog>();
        Mock<IStringKeyValueStore> stringKeyHashStore = new Mock<IStringKeyValueStore>();
        private Mock<RestaurantMonitor.V1.IClientAdvanced> _restaurantMonitorClient;
        
        [SetUp]
        public async Task TestInitialize()
        {
            empheralPubSub = new TestingEmpheralPubSub();
            int beaconIntervalInMilliseconds = 30;

            _httpContext = Mock.Of<HttpContext>();
            CancellationToken cancellationToken = new CancellationToken();
            TaskCompletionSource<object> socketFinishedTcs = Mock.Of<TaskCompletionSource<object>>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            stringKeyHashStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Throws(new Exception());
            List<string> stringvaluestore = new List<string> { "11223344-5566-7788-99AA-BBCCDDEEFF000", "11223344-5566-7788-99AA-BBCCDDEEFF01" };
            stringKeyHashStore.Setup(x => x.GetAllKeys()).Returns(stringvaluestore);
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _restaurantMonitorClient = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _resourceLock = new Mock<IResourceLock>().Object;
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            _eventsManager = new EventsManager(
                logger.Object,
                empheralPubSub,
                configuration, 
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitorClient.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            await _eventsManager.InitializeAsync(cancellationToken);
            await _eventsManager.V2Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs, cancellationToken);
        }

        #region subscriberRegexPatternTests
        [Test]
        [TestCase("11223344-5566-7788-99AA-BBCCDDEEFF000")]
        public async Task subscriberRegexPatternTests(string subscriberRegexPattern)
        {
            await _eventsManager.DropSubscribersThatMatchPatternAsync(subscriberRegexPattern);
            Assert.IsTrue(true);
        }
        #endregion
    }
        
}

