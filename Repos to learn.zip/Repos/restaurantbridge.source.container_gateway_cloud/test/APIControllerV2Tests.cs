﻿
using Common;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Namotion.Reflection;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.Services.Exceptions;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using RestaurantBridge.Gateway.Cloud.V2;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    [TestFixture]
    public class APIControllerV2Tests
    {
        APIController apiController;

        #region Test Data
        //For Search Restaurants API
        public async Task<List<SearchedDetails>> SearchRestaurantsTestDataAsync()
        {
            var searchedDetailsJson = JsonConvert.DeserializeObject<List<SearchedDetails>>(await File.ReadAllTextAsync($"data/default/SearchRestaurants.json"));
            return searchedDetailsJson;
        }
        //Restaurant Configuration API
        public async Task<V2.Models.Configuration> RestaurantConfigurationTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<V2.Models.Configuration>(await File.ReadAllTextAsync($"data/default/RestaurantConfiguration.json"));
            return restaurantDetailsJson;
        }
        //Channel Menus API
        public async Task<ChannelMenus> ChannelMenusTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<ChannelMenus>(await File.ReadAllTextAsync($"data/default/RestaurantChannelMenus.json"));
            return restaurantDetailsJson;
        }
        //For Restaurant State
        public async Task<V2.Models.State> GetRestaurantStateTestDataAsync()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<V2.Models.State>(await File.ReadAllTextAsync($"data/default/State.json"));
            return restaurantStateJson;
        }
        //Restaurant Details
        public async Task<IEnumerable<long>> RestIDsTestDataAsync()
        {
            var restaurantIDsJson = JsonConvert.DeserializeObject<IEnumerable<long>>(await File.ReadAllTextAsync($"data/default/RestaurantIDs.json"));
            return restaurantIDsJson;
        }
        public async Task<Details> RestaurantDetailsTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<Cloud.V2.Models.Details>(await File.ReadAllTextAsync($"data/default/Details.json"));
            return restaurantDetailsJson;
        }
        // Tax Parameters
        public async Task<TaxParameters> TaxParametersTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<TaxParameters>(await File.ReadAllTextAsync($"data/default/TaxParameters.json"));
            return restaurantDetailsJson;
        }

        //Product Outages       
        public async Task<ISet<int>> ProductOutagesTestDataAsync()
        {
            var productOutagesIDsJson = JsonConvert.DeserializeObject<ISet<int>>(await File.ReadAllTextAsync($"data/default/ProductOutages.json"));
            return productOutagesIDsJson;
        }
        //Oqmc Overrides
        public async Task<OQMCMenu.Processor.V1.Models.OQMCOverrides> OqmcOverridesTestDataAsync()
        {
            var oqmcOverridesJson = JsonConvert.DeserializeObject<OQMCMenu.Processor.V1.Models.OQMCOverrides>(await File.ReadAllTextAsync($"data/default/OqmcOverrides.json"));
            return oqmcOverridesJson;
        }
        //CoatesMenus
        public async Task<RestaurantCoatesMenus> RestaurantCoatesMenusTestDataAsync()
        {
            var coatesJson = JsonConvert.DeserializeObject<RestaurantCoatesMenus> (await File.ReadAllTextAsync($"data/default/RestaurantCoatesMenus.json"));
            return coatesJson;
        }
        //RestaurantSetting
        public async Task<V2.Models.Settings> RestaurantSettingsTestDataAsync()
        {
            var restaurantSettingsJson = JsonConvert.DeserializeObject<V2.Models.Settings>(await File.ReadAllTextAsync($"data/default/RestaurantSettings.json"));
            return restaurantSettingsJson;
        }
        //CombinedAPI
        public async Task<API.V2.Models.RestaurantCombinedV2> RestaurantCombinedV2TestDataAsync()
        {
            var restaurantCombinedJson = JsonConvert.DeserializeObject<API.V2.Models.RestaurantCombinedV2>(await File.ReadAllTextAsync($"data/default/RestaurantCombinedV2.json"));
            return restaurantCombinedJson;
        }
        #endregion

        #region"Initialization"
        [SetUp]
        public async Task Initialize()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrides = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

          
            apiController = new APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrides.Object,
                 _cacheParsedCoatesMenus.Object,
                 _cacheParsedSettings.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;
           

            #region Search Restaurant

            var searchRestaurants = await SearchRestaurantsTestDataAsync();
            _restaurantSearchIndex.Setup(x => x.SearchRestaurantsAsync(null, null, null, null, null, null, null, null, null, null, null)).ReturnsAsync(searchRestaurants);
            #endregion

            #region Restaurant Configuration

            var restaurantConfiguration = await RestaurantConfigurationTestDataAsync();
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), null, new CancellationToken { })).ReturnsAsync((restaurantConfiguration, eTag));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(),new CancellationToken { })).ReturnsAsync(eTag);
            #endregion

            #region Channel Menus
            var channelMenus = await ChannelMenusTestDataAsync();
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((channelMenus, eTag));
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);
            #endregion

            #region Restaurant State
            var restaurantState = await GetRestaurantStateTestDataAsync();

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantState));
            #endregion

            #region Restaurant Details

            var restIDs = await RestIDsTestDataAsync();

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(),new CancellationToken { })).ReturnsAsync((restIDs));

            var restaurantDetails = await RestaurantDetailsTestDataAsync();

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<Cloud.V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .ReturnsAsync((restaurantDetails, eTag));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            #endregion

            #region Tax Parameters

            var taxParameters = await TaxParametersTestDataAsync();
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((taxParameters, eTag));
            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);
            #endregion

            #region Product Outages

            var productOutages = await ProductOutagesTestDataAsync();
            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(),new CancellationToken { })).ReturnsAsync((productOutages,eTag));

            #endregion
            #region Oqmc Overrides
            var oqmcOverrides = await OqmcOverridesTestDataAsync();
            _oqmcOverrides.Setup(x => x.GetOQMCOverrides_DESERIALIZE_AS_Async<V2.Models.OQMCOverrides>(It.IsAny<long>())).ReturnsAsync(oqmcOverrides);

            #endregion
            #region Coates
            var coatesMenus = await RestaurantCoatesMenusTestDataAsync();
            _cacheParsedCoatesMenus.Setup(x=>x.GetRestaurantCoatesMenus_DESERIALIZE_AS_Async<V2.Models.RestaurantCoatesMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((coatesMenus, eTag));
            _cacheParsedCoatesMenus.Setup(x => x.GetRestaurantCoatesMenusETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);
            #endregion
            #region Restaurant Settings

            var restaurantSettings = await RestaurantSettingsTestDataAsync();

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantSettings, eTag));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);


            #endregion

            #region Combined Api

            var combinedapiResult = await RestaurantCombinedV2TestDataAsync();

            _service.Setup(x => x.GetRestaurantCombinedV2Async(It.IsAny<RestaurantCombinedV2.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { }))
            .ReturnsAsync(combinedapiResult);

            #endregion

        }
        #endregion
        #region Restaurant Combined V2
        [Test]
        [TestCase]
        public async Task GetRestaurantCombinedV2AsyncValidInput()
        {
            var restaurantId = 2455;
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "STATE" };
            var result = await apiController.GetRestaurantCombinedV2Async(restaurantId, new HashSet<string>(), null, null, null, null, new CancellationToken());
            Assert.IsNotNull(result.Result);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.API.V2.Models.RestaurantCombinedV2)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Configuration);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.API.V2.Models.RestaurantCombinedV2)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Details);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.API.V2.Models.RestaurantCombinedV2)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Settings);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.API.V2.Models.RestaurantCombinedV2)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).State);

        }
        #endregion
        #region Test Cases
        #region Restaurants API
        [Test]
        [TestCase]
        public async Task SearchedDetailsObjectNotNullAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 32.482322, -84.941197, null, null)]
        public async Task SearchedRestaurantsWithLongitudeandLatitudeObjectNotNullAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, 32.482322, null, null, null)]
        public async Task SearchedRestaurantsOnlyLongitudeObjectNotFoundAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(400, statusCode.StatusCode);
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, 1, null)]
        public async Task SearchedRestaurantsWithoutLongitudeLatitudeObjectNotFoundAsyncTest(
            HashSet<long> restaurantIDs = null,
            HashSet<string> marketIDs = null,
            HashSet<string> channels = null,
            HashSet<string> facilities = null,
            long? restaurantID = null,
            string marketID = null,
            long? marketStoreID = null,
            double? latitude = null,
            double? longitude = null,
            double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(400, statusCode.StatusCode);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByMarketIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID = "US", marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(400, statusCode.StatusCode);
            Assert.AreEqual("Parameters 'marketID' and 'marketStoreID' must be specified together or not at all", statusCode.Value);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByMarketStoreIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID, marketStoreID = 2455, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(400, statusCode.StatusCode);
            Assert.AreEqual("Parameters 'marketID' and 'marketStoreID' must be specified together or not at all", statusCode.Value);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByMarketIDandMarketStoreIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID, marketID = "US", marketStoreID = 2455, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(200, statusCode.StatusCode);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantIDandMarketIDandMarketStoreIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await apiController.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities, restaurantID = 2455, marketID = "US", marketStoreID = 2455, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(400, statusCode.StatusCode);
            Assert.AreEqual("Only one set of positional parameters can be used at a time.", statusCode.Value);
        }

        #endregion

        #region "Restaurants Configuration"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455,"", "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantsConfigurationNoChangeObjectAsyncTest(long restaurantID, string coatesStoreDetailsFilter, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID, coatesStoreDetailsFilter, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantsConfigurationHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        //[Test]
        //[TestCase(2455)]
        //public async Task RestaurantConfigurationActiveChannelNotNull(long restaurantID)
        //{
        //    var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
        //    Assert.IsNotNull(result, "result is null");
        //    Console.WriteLine(JsonConvert.SerializeObject(result, Formatting.Indented));
        //    result.Value.activeChannels.ToList().ForEach(channel =>
        //    {
        //        Assert.IsNotNull(channel.Value.podInfo, "PodInfo is null");
        //        channel.Value.podInfo.ToList().ForEach(fulfillment =>
        //        {
        //            Assert.IsNull(fulfillment.Value, "Fulfillment value not null");
        //        });
        //    });
        //}
        #endregion

        #region ChannelMenus

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjectSuccessAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            var objectResult = result.Result as ObjectResult;
            if (objectResult != null)
            {
                var responseObject = objectResult.Value as RestaurantBridge.Gateway.Cloud.V2.Models.ChannelMenus;
                if (responseObject != null)
                {
                    var marketId = responseObject.marketID;
                    Assert.AreEqual("US", marketId);
                    
                }
            }
            
            Assert.AreEqual(statusCode.StatusCode, 200);
        }

        [Test]
        [TestCase(2455)]
        public async Task ChannelMenusTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }
        [Test]
        [TestCase(2455, null, null)]
        public async Task RestaurantChannelMenusObjectLocalesNotNullAsyncTest(long restaurantID, string[] locales, string[] channels = null)
        {
            locales = new string[] { "en-US" };
            channels = new string[] { "GMA_DELIVERY" };
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID, locales, channels);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantChannelMenusNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID, null, null, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusObjectRestaurantIDAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantChannelMenusAsync(restaurantID);
            var objResult = result.Result as ObjectResult;
            var restDetails = objResult.Value as ChannelMenus;
            Assert.AreEqual(restDetails.restaurantID, 2455);
        }
        #endregion

        #region Channel Menus Head

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusHeadNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantChannelMenusHeadSuccessAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantChannelMenusHeadAsync(restaurantID);
            var statusCode = result as StatusCodeResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }

        #endregion

        #region "For State API"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        #endregion

        #region Details
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectNotNullAsyncTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            Assert.IsNotNull(restaurantDetails.Result);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectNotNullValidationConfigurationAsyncTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            Assert.IsNotNull(restaurantDetails.Result);
            var result = restaurantDetails.Result as ObjectResult;
            var validationConfig  = ((Cloud.V2.Models.Details)result.Value).ValidationConfiguration;

            Assert.IsNotNull(validationConfig);
            Assert.AreEqual(validationConfig["GMA_DELIVERY"].outageValidation, false);
            Assert.AreEqual(validationConfig["GMA_DELIVERY"].timeOfTheDayValidation, true);
            Assert.AreEqual(validationConfig["GMA_DELIVERY"].orderValueLimit, 15000);
            Assert.AreEqual(validationConfig["GMA_DELIVERY"].orderItemLimit, 15);

            Assert.AreEqual(validationConfig["GMA_PICKUP"].outageValidation, true);
            Assert.AreEqual(validationConfig["GMA_PICKUP"].timeOfTheDayValidation, false);
            Assert.AreEqual(validationConfig["GMA_PICKUP"].orderValueLimit, 10000);
            Assert.AreEqual(validationConfig["GMA_PICKUP"].orderItemLimit, 10);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectNotNullChannelConfigurationAsyncTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            Assert.IsNotNull(restaurantDetails.Result);
            var result = restaurantDetails.Result as ObjectResult;

            var channelConfig = ((Cloud.V2.Models.Details)result.Value).ChannelConfiguration;
            Assert.IsNotNull(channelConfig);
            Assert.AreEqual(channelConfig["GMA_DELIVERY"]["DELIVERY"].podInfo.podName, "FOE9901");
            Assert.AreEqual(channelConfig["GMA_DELIVERY"]["DELIVERY"].podInfo.pod, 3);
            Assert.AreEqual(channelConfig["GMA_DELIVERY"]["DELIVERY"].podInfo.remPod, 3);
            Assert.AreEqual(channelConfig["GMA_DELIVERY"]["DELIVERY"].podInfo.type, 2);

            Assert.AreEqual(channelConfig["GMA_PICKUP"]["CURBSIDE"].podInfo.podName, "FOE0002");
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["CURBSIDE"].podInfo.pod, 2);
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["CURBSIDE"].podInfo.remPod, 2);
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["CURBSIDE"].podInfo.type, 1);

            Assert.AreEqual(channelConfig["GMA_PICKUP"]["DRIVETHRU"].podInfo.podName, "FOE0003");
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["DRIVETHRU"].podInfo.pod, 1);
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["DRIVETHRU"].podInfo.remPod, 1);
            Assert.AreEqual(channelConfig["GMA_PICKUP"]["DRIVETHRU"].podInfo.type, 1);

            Assert.AreEqual(channelConfig["GMAL_PICKUP"]["PICKUP"].podInfo.podName, "FOE9904");
            Assert.AreEqual(channelConfig["GMAL_PICKUP"]["PICKUP"].podInfo.pod, 3);
            Assert.AreEqual(channelConfig["GMAL_PICKUP"]["PICKUP"].podInfo.remPod, 3);
            Assert.AreEqual(channelConfig["GMAL_PICKUP"]["PICKUP"].podInfo.type, 2);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectStatusNotModifiedAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantDetailsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var result = restaurantDetails.Result as ObjectResult;
            long restID = ((Cloud.V2.Models.Details)result.Value).restaurantID;
            Assert.NotNull(restID, "2455");
        }

        [Test]
        [TestCase(2455)]
        public async Task DetailsEmailIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var result = restaurantDetails.Result as ObjectResult;
            var email = ((Cloud.V2.Models.Details)result.Value).email;
            Assert.NotNull(email, "example@mail.com");
        }

        [Test]
        [TestCase(2455)]
        public async Task MarketIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var marketID = ((Cloud.V2.Models.Details)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).marketID;
            Assert.NotNull(marketID);
        }

        [Test]
        [TestCase(2455)]
        public async Task MarketIDAreEqualTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var marketID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Details)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).marketID;
            Assert.AreEqual(marketID, "US");
        }

        [Test]
        [TestCase(2455)]
        public async Task FacilitiesCountTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var facilities = ((Cloud.V2.Models.Details)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).facilities;
            Assert.NotZero(facilities.Count);
        }
        #endregion

        #region Tax Parameters
        [Test]
        [TestCase(2455)]
        public async Task TaxParametersObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }
        [Test]
        [TestCase(1111, null)]
        public async Task TaxParametersNotFoundObjectNotNullAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {

            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID, IF_NONE_MATCH);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455)]
        public async Task WhenValidStoreIDETagIsProvided(long restaurantID)
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID, eTag);
            var objResult = result.Result as StatusCodeResult;
            objResult.StatusCode.Equals(304);
        }
        [Test]
        [TestCase(2455)]
        public async Task TaxParameterHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task offerTypesExcludedFromProportionalPriceAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var offerTypesExcludedFromProportionalPrice = ((V2.Models.TaxParameters)((ObjectResult)result.Result).Value).operationModeConfiguration.offerTypesExcludedFromProportionalPrice;
            Assert.AreEqual(3, offerTypesExcludedFromProportionalPrice.Count);
            Assert.AreEqual("REWARD", offerTypesExcludedFromProportionalPrice[0]);
            Assert.AreEqual("SINGLEVOUCHER", offerTypesExcludedFromProportionalPrice[1]);
            Assert.AreEqual("MULTIPLEVOUCHER", offerTypesExcludedFromProportionalPrice[2]);
        }
        #endregion

        #region Product Outages 
        [Test]
        [TestCase(2455)]
        public async Task ProductOutagesObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task ProductOutagesNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantOutagesAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }
        #endregion

        #region Oqmc Overrides
        [Test]
        [TestCase(2455)]
        public async Task OqmcOverridesObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetOqmcOverridesAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.IsNotNull(result.Result);
            Assert.AreEqual(statusCode.StatusCode, 200);
        }
        #endregion

        #region Coates
        [Test]
        [TestCase(2455)]
        public async Task RestaurantCoatesObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID);
            Assert.IsNotNull(result.Result);

        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantCoatesHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetHeadCoatesMenusAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantCoatesEtag(long restaurantID)
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID,null, eTag);
            var objResult = result.Result as StatusCodeResult;
            objResult.StatusCode.Equals(304);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantCoatesNotNullAsyncTest(long restaurantID)
        {
            var channels = new HashSet<string>() { "GMA_EATIN", "GMAL_PICKUP" };
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID, channels);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantCoatesNullAsyncTest(long restaurantID)
        {
            var channels = new HashSet<string>();
            channels = null;
            var result = await apiController.GetRestaurantCoatesMenusAsync(restaurantID, channels);
            Assert.IsNotNull(result.Result);
        }

        #endregion
        #region Restaurant Settings
        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantSettingsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsIDNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            long restID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).restaurantID;
            Assert.IsNotNull(restID);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsIDAreEqualAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            long restID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).restaurantID;
            Assert.AreEqual(2455, restID);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsMenuScheduleAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var menuSchedule = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).menuSchedule;
            Assert.NotNull(menuSchedule);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsMenuScheduleCountAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var menuSchedule = ((V2.Models.Settings)((ObjectResult)result.Result).Value).menuSchedule;
            Assert.IsNotNull(menuSchedule.Count);
        }

        [Test]
        [TestCase(2455)]
        public async Task FulfillmentFacilityScheduleNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var fulfillmentFacilitySchedule = ((V2.Models.Settings)((ObjectResult)result.Result).Value).fulfillmentFacilitySchedule;
            Assert.IsNotNull(fulfillmentFacilitySchedule);
        }

        [Test]
        [TestCase(2455)]
        public async Task FulfillmentFacilityScheduleCountNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var fulfillmentFacilitySchedule = ((V2.Models.Settings)((ObjectResult)result.Result).Value).fulfillmentFacilitySchedule;
            Assert.IsNotNull(fulfillmentFacilitySchedule.Count);
        }

        [Test]
        [TestCase(2455)]
        public async Task TableServiceNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var tableService = ((V2.Models.Settings)((ObjectResult)result.Result).Value).tableService;
            Assert.IsNotNull(tableService);
        }

        [Test]
        [TestCase(2455)]
        public async Task TableServicelocatorNumberNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var tableService = ((V2.Models.Settings)((ObjectResult)result.Result).Value).tableService;
            Assert.IsNotNull(tableService.locatorNumber);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsProprtionalVATTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V2.Models.Settings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsTrue(taxDefinitions.isProportionalVAT);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsOfferTypesExcludedFromProprtionalPriceAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V2.Models.Settings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.AreEqual(3, taxDefinitions.offerTypesExcludedFromProportionalPrice.Count);
            Assert.AreEqual("REWARD", taxDefinitions.offerTypesExcludedFromProportionalPrice[0]);
            Assert.AreEqual("SINGLEVOUCHER", taxDefinitions.offerTypesExcludedFromProportionalPrice[1]);
            Assert.AreEqual("MULTIPLEVOUCHER", taxDefinitions.offerTypesExcludedFromProportionalPrice[2]);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsEnableDeliveryTaxIdTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V2.Models.Settings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsNull(taxDefinitions.proportionalDeliveryChargeTaxId);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsEnableDeliveryTaxTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V2.Models.Settings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsFalse(taxDefinitions.enableProportionalDeliveryChargeTax);
        }

        [Test]
        [TestCase(2455)]
        public async Task RetailDeliveryFeeNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.retailDeliveryFee);
        }

        [Test]
        [TestCase(2455)]
        public async Task TakeAwayFeeNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.takeAwayFee);
        }

        [Test]
        [TestCase(2455)]
        public async Task IsMcDOwnedPricingEnabledTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V2.Models.Settings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsFalse(restID.isMcDOwnedPricingEnabled);
        }

        [Test]
        [TestCase(2455)]
        public async Task MinimumOrderValueNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V2.Models.Settings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.minimumOrderAmount);
            Assert.AreEqual(restID.minimumOrderAmount.Count, 3);
            Assert.AreEqual(restID.minimumOrderAmount[0].categoryID, "1");
            Assert.AreEqual(restID.minimumOrderAmount[0].value, Convert.ToDecimal(10.15));
            Assert.AreEqual(restID.minimumOrderAmount[1].categoryID, "2");
            Assert.AreEqual(restID.minimumOrderAmount[1].value, Convert.ToDecimal(20.25));
            Assert.AreEqual(restID.minimumOrderAmount[2].categoryID, "13");
            Assert.AreEqual(restID.minimumOrderAmount[2].value, Convert.ToDecimal(30.35));
        }
        [Test]
        [TestCase(2455)]
        public async Task MenuTransitionAlertTimeInMinutesNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V2.Models.Settings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.menuTransitionAlertTimeInMinutes);
        }
        [Test]
        [TestCase("default", 2455)]
        public async Task MenuTransitionAlertTimeInMinutesAreEqual(string testDataSet, long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V2.Models.Settings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.AreEqual(restID.menuTransitionAlertTimeInMinutes.Value, 10);
        }
        [Test]
        [TestCase(2455)]
        public async Task StagingBlockTimePastBusinessDateInMinutes(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V2.Models.Settings)((ObjectResult)result.Result).Value).restaurantSpecificOverrides.orderFlow;
            Assert.IsNotNull(restID.stagingBlockTimePastBusinessDateInMinutes);
            Assert.AreEqual(restID.stagingBlockTimePastBusinessDateInMinutes, 30240);
        }
        #endregion
        #endregion
    }

}
