using Common;
using McD.McFlow.Client.Library.Producer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.Services.Exceptions;
using RestaurantBridge.Gateway.Cloud.V1;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest.APIControllerTests
{
    [TestFixture]
    public class APIControllerTests
    {
        APIController apiController;
        ProductsSpecifiedCache productsSpecifiedCache;
        EventsManager _eventsManager;
        private readonly IService _service;

        #region "Test Data"

        public async Task<ISet<long>> RestaurantIDsTestDataAsync()
        {
            var restaurantIDsJson = JsonConvert.DeserializeObject<ISet<long>>(await File.ReadAllTextAsync($"data/default/RestaurantIDs.json"));
            return restaurantIDsJson;
        }

        public async Task<V1.Models.RestaurantState> GetRestaurantStateTestDataAsync()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<V1.Models.RestaurantState>(await File.ReadAllTextAsync($"data/default/RestaurantState.json"));
            return restaurantStateJson;
        }

        public async Task<V1.Models.RestaurantDetails> RestaurantDetailsTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<V1.Models.RestaurantDetails>(await File.ReadAllTextAsync($"data/default/RestaurantDetails.json"));
            return restaurantDetailsJson;
        }

        public async Task<V1.Models.RestaurantDetails> RestaurantDetailsMarketIDTestDataAsync()
        {
            var restaurantDetailsMarketIdJson = JsonConvert.DeserializeObject<V1.Models.RestaurantDetails>(await File.ReadAllTextAsync($"data/default/RestaurantDetailsmarketID.json"));
            return restaurantDetailsMarketIdJson;
        }

        public async Task<IEnumerable<long>> RestIDsTestDataAsync()
        {
            var restaurantIDsJson = JsonConvert.DeserializeObject<IEnumerable<long>>(await File.ReadAllTextAsync($"data/default/RestaurantIDs.json"));
            return restaurantIDsJson;
        }

        public async Task<V1.Models.RestaurantSettings> RestaurantSettingsTestDataAsync()
        {
            var restaurantSettingsJson = JsonConvert.DeserializeObject<V1.Models.RestaurantSettings>(await File.ReadAllTextAsync($"data/default/RestaurantSettings.json"));
            return restaurantSettingsJson;
        }

        public async Task<RestaurantConfiguration.V1.Models.RestaurantConfiguration> RestaurantConfigurationTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(await File.ReadAllTextAsync($"data/default/RestaurantConfiguration.json"));
            return restaurantDetailsJson;
        }

        public async Task<List<V1.Models.RestaurantMenuCategory>> RestaurantMenusTestDataAsync()
        {
            var restaurantMenusJson = JsonConvert.DeserializeObject<List<V1.Models.RestaurantMenuCategory>>(await File.ReadAllTextAsync($"data/default/RestaurantMenus.json"));
            return restaurantMenusJson;
        }

        public async Task<List<V1.Models.RestaurantMenuCategory>> RestaurantMenusCategoriesTestDataAsync()
        {
            var restaurantMenusCategoriesJson = JsonConvert.DeserializeObject<List<V1.Models.RestaurantMenuCategory>>(await File.ReadAllTextAsync($"data/default/RestaurantMenusCategories.json"));
            return restaurantMenusCategoriesJson;
        }

        public async Task<ISet<int>> RestaurantProductIDsOutageTestDataAsync()
        {
            var restaurantProductIDsJson = JsonConvert.DeserializeObject<ISet<int>>(await File.ReadAllTextAsync($"data/default/RestaurantProductIDs.json"));
            return restaurantProductIDsJson;
        }

        public async Task<(List<V1.Models.RestaurantProduct>, string)> RestaurantProductIDsTestDataAsync()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var restaurantProductIDsJson = JsonConvert.DeserializeObject<List<V1.Models.RestaurantProduct>>(await File.ReadAllTextAsync($"data/default/RestaurantProducts.json"));
            return (restaurantProductIDsJson, eTag);
        }

        public async Task<byte[]> RestaurantProductsTestDataAsync()
        {
            var restaurantProductsJson = JsonConvert.DeserializeObject<byte[]>(await File.ReadAllTextAsync($"data/default/RestaurantProducts.json"));
            return restaurantProductsJson;
        }

        public async Task<string> RestaurantProductsSpecifiedTestDataAsync()
        {
            string restaurantProductsSpecifiedJson = await File.ReadAllTextAsync($"data/default/RestaurantProductsSpecified.json");
            return restaurantProductsSpecifiedJson;
        }

        public async Task<(string, string)> GetRestaurantProductIDsAsync()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var products = await File.ReadAllTextAsync($"data/default/RestProductID.json");
            return (products.ToString(), eTag);
        }

        public (byte[], string) GetRestaurantProductsGZIPAsync()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            byte[] productsGZIPAsync = new byte[] { 1, 2, 3, 4 };
            return (productsGZIPAsync, eTag);
        }
        public async Task<List<int>> RestaurantPromotionIDsTestDataAsync()
        {
            var restaurantPromotionIDsJson = JsonConvert.DeserializeObject<List<int>>(await File.ReadAllTextAsync($"data/default/RestaurantPromotionIDs.json"));
            return restaurantPromotionIDsJson;
        }

        public async Task<List<V1.Models.RestaurantPromotion>> RestaurantPromotionsTestDataAsync()
        {
            var restaurantPromotionsJson = JsonConvert.DeserializeObject<List<V1.Models.RestaurantPromotion>>(await File.ReadAllTextAsync($"data/default/RestaurantPromotions.json"));
            return restaurantPromotionsJson;
        }

        public async Task<List<V1.Models.RestaurantPromotion>> RestaurantPromotionsSpecifiedTestDataAsync()
        {
            var restaurantPromotionsSpecifiedJson = JsonConvert.DeserializeObject<List<V1.Models.RestaurantPromotion>>(await File.ReadAllTextAsync($"data/default/RestaurantPromotionsSpecified.json"));
            return restaurantPromotionsSpecifiedJson;
        }

        public async Task<V1.Models.RestaurantPromotion> RestaurantPromotionTestDataAsync()
        {
            var restaurantPromotionJson = JsonConvert.DeserializeObject<V1.Models.RestaurantPromotion>(await File.ReadAllTextAsync($"data/default/RestaurantPromotion.json"));
            return restaurantPromotionJson;
        }
        public async Task<V1.Models.RestaurantCombined> RestaurantCombinedTestDataAsync()
        {
            var restaurantCombinedJson = JsonConvert.DeserializeObject<V1.Models.RestaurantCombined>(await File.ReadAllTextAsync($"data/default/RestaurantCombined.json"));
            return restaurantCombinedJson;
        }

        #endregion

        #region"Initialization"

        [SetUp]
        #region setup
        public async Task Initialize()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantcombination = new Mock<IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _proxyPremiseNPOS61 = new Mock<Proxy.Premise.NPOS61.IClient>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            int cacheWriteLockTakeRetryDelayInMs = 10;
            int cacheTimeToLiveInMs = 10;
            var empheralPubSub = new Mock<IEmpheralPubSub>();
            var cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClient>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            var _resourceLock = new Mock<IResourceLock>().Object;

            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid());

            _eventsManager = new EventsManager
               (
                _logger.Object,
                empheralPubSub.Object,
                configuration, 
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitor.Object, 
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs
           );
            productsSpecifiedCache = new ProductsSpecifiedCache
            (
             _logger.Object,
             _eventsManager,
             _iStringKeyHashStore.Object,
             _iResourceLock.Object,
             _cacheParsedProducts.Object,
             cacheWriteLockAutoReleaseTimeInMs,
             cacheWriteLockTakeRetryDelayInMs,
             cacheTimeToLiveInMs
             );

            apiController = new APIController
               (
                _logger.Object,
                _service.Object,
                productsSpecifiedCache,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            var keys = new Dictionary<string, string>()
            { { "1","93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"}};
            _iStringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ReturnsAsync(keys);
            apiController.ControllerContext = context;

            var restaurantIDs = await RestaurantIDsTestDataAsync();

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<string>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).ReturnsAsync((restaurantIDs, eTag));

            var restaurantState = await GetRestaurantStateTestDataAsync();

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantState));

            #endregion

            #region Restaurant Details

            var restIDs = await RestIDsTestDataAsync();

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).ReturnsAsync((restIDs));

            var restaurantDetails = await RestaurantDetailsTestDataAsync();

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .ReturnsAsync((restaurantDetails, eTag));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            #endregion

            #region Restaurant Settings

            var restaurantSettings = await RestaurantSettingsTestDataAsync();

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantSettings, eTag));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);


            #endregion

            #region Restaurant Configuration

            var restaurantConfiguration = await RestaurantConfigurationTestDataAsync();

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(),null, null, new CancellationToken { })).ReturnsAsync((restaurantConfiguration, eTag));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);
            #endregion


            #region Combined Api

            var combinedapiResult = await RestaurantCombinedTestDataAsync();

            _service.Setup(x => x.GetRestaurantCombinedAsync(It.IsAny<RestaurantCombined.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { }))
            .ReturnsAsync(combinedapiResult);

            #endregion


            #region Restaurant Menus

            var restaurantMenus = await RestaurantMenusTestDataAsync();

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).ReturnsAsync((restaurantMenus, eTag));

            //_cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>())).ReturnsAsync(eTag);
            #endregion

            #region Restaurant Menus Categories

            var restaurantMenusCategories = await RestaurantMenusCategoriesTestDataAsync();

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { })).ReturnsAsync((restaurantMenusCategories, eTag));

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).ReturnsAsync(eTag);
            #endregion

            #region Restaurant Products

            var restaurantProductOutageIDs = await RestaurantProductIDsOutageTestDataAsync();

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantProductOutageIDs, eTag));

            cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(restaurantProductOutageIDs);

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantProductOutageIDs, eTag));

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            var products = await RestaurantProductIDsTestDataAsync();

            _cacheParsedProducts.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<V1.Models.RestaurantProduct>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(products);

            var gzip = GetRestaurantProductsGZIPAsync();
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsGZIPAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(gzip);

            var restaurantProductsSpecified = await RestaurantProductsSpecifiedTestDataAsync();
            _productsSpecifiedCache.Setup(x => x.GetMultipleAsync(It.IsAny<long>(), It.IsAny<HashSet<int>>())).ReturnsAsync(restaurantProductsSpecified);

            var restaurantProduct = await GetRestaurantProductIDsAsync();
            _productsSpecifiedCache.Setup(x => x.GetSingleAsync(It.IsAny<long>(), It.IsAny<int>())).ReturnsAsync(restaurantProduct);

            #endregion

            #region Restaurant Promotion

            var restaurantPromotionIDs = await RestaurantPromotionIDsTestDataAsync();

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionIDsAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).ReturnsAsync((restaurantPromotionIDs, eTag));

            var restaurantPromotions = await RestaurantPromotionsTestDataAsync();

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).ReturnsAsync((restaurantPromotions, eTag));

            var restaurantPromotionsSpecified = await RestaurantPromotionsSpecifiedTestDataAsync();

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<HashSet<int>>(), It.IsAny<bool?>(), new CancellationToken { })).ReturnsAsync((restaurantPromotions, eTag));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsETagAsync(It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).ReturnsAsync(eTag);

            var restaurantPromotion = await RestaurantPromotionTestDataAsync();

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { })).ReturnsAsync((restaurantPromotion, eTag));


            #endregion

        }

        public async Task InitializeETag()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _proxyPremiseNPOS61 = new Mock<Proxy.Premise.NPOS61.IClient>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            int cacheWriteLockTakeRetryDelayInMs = 10;
            int cacheTimeToLiveInMs = 10;
            var empheralPubSub = new Mock<IEmpheralPubSub>();
            var _stringKeyValueStore = new Mock<IStringKeyValueStore>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid());
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            var _resourceLock = new Mock<IResourceLock>().Object;
            _eventsManager = new EventsManager
               (
                _logger.Object,
                empheralPubSub.Object,
                configuration,
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitor.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);
            productsSpecifiedCache = new ProductsSpecifiedCache
            (
             _logger.Object,
             _eventsManager,
             _iStringKeyHashStore.Object,
             _iResourceLock.Object,
             _cacheParsedProducts.Object,
             cacheWriteLockAutoReleaseTimeInMs,
             cacheWriteLockTakeRetryDelayInMs,
             cacheTimeToLiveInMs
             );

            apiController = new APIController
               (
                _logger.Object,
                _service.Object,
                productsSpecifiedCache,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            var keys = new Dictionary<string, string>()
            { { "1","93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"},
            { "_ETAG_","93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"}};
            _iStringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ReturnsAsync(keys);
            apiController.ControllerContext = context;

            #region Restaurant Products

            var restaurantProductOutageIDs = await RestaurantProductIDsOutageTestDataAsync();

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);


            #endregion


        }


        #endregion

        #region "Test Cases"
        [Test]
        [TestCase(true, "ABC")]
        public async Task RestaurantIDsObjectNotNullAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(true, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantIDsNoChangeObjectAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(true)]
        public async Task RestaurantIDsObjectNotNullAsyncTest(bool? isActiveForOrdering)
        {
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        #endregion

        #region Restaurant Combined Test

        [Test]
        [TestCase]
        public async Task GetRestaurantCombinedV1Test()
        {
            var restaurantId = 2455;
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "PROMOTIONS" };
            var result = await apiController.GetRestaurantCombinedAsync(restaurantId, filterApis, null, null, null, null, new CancellationToken());
            Assert.IsNotNull(result);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Configuration);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Details);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Promotions);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Settings);
            Assert.IsNotNull(((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).State);
        }



        #endregion

        #region "Restaurant Details"

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsObjectStatusNotModifiedAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantDetailsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase("4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945")]
        public async Task RestaurantDetailsAllObjectNotNullAsyncTest(string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantDetailsAll();
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase("0482f63522034110ead8bbc2dd0a97325471387450cf8347d9e01b54011e09ed")]
        public async Task RestaurantDetailsAllNoChangeObjectAsyncTest(string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantDetailsAll(IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var result = restaurantDetails.Result as ObjectResult;
            long restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)result.Value).restaurantID;
            Assert.NotNull(restID, "2455");
        }

        [Test]
        [TestCase(2455)]
        public async Task DetailsEmailIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var result = restaurantDetails.Result as ObjectResult;
            var email = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)result.Value).email;
            Assert.NotNull(email, "example@mail.com");
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsIDAreEqualTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var result = restaurantDetails.Result as ObjectResult;
            long restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)result.Value).restaurantID;
            Assert.AreEqual(restID, 2455);
        }

        [Test]
        [TestCase(2455)]
        public async Task PosIDAreEqualTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var posID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).posID;
            Assert.AreEqual(posID, 2455);
        }

        [Test]
        [TestCase(2455)]
        public async Task MarketIDNotNullTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var marketID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).marketID;
            Assert.NotNull(marketID);
        }

        [Test]
        [TestCase(2455)]
        public async Task MarketIDAreEqualTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var marketID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).marketID;
            Assert.AreEqual(marketID, "US");
        }
        //MENC-14412 Parsing Three Letter marketID
        [Test]
        [TestCase(1830002)]
        public async Task ThreeLetterMarketId(long restaurantID)
        {
            var restaurantDetails = await RestaurantDetailsMarketIDTestDataAsync();
            var marketID = restaurantDetails.marketID;
            Assert.AreEqual(marketID, "SAR");
            Assert.IsTrue(marketID.Length >= 3, marketID);
        }

        [Test]
        [TestCase(2455)]
        public async Task TwoLetterMarketId(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var marketID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).marketID;
            Assert.AreEqual(marketID, "US");
            Assert.IsTrue(marketID.Length < 3, marketID);
        }

        [Test]
        [TestCase(2455)]
        public async Task FacilitiesCountTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var facilities = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).facilities;
            Assert.NotZero(facilities.Count);
        }

        [Test]
        [TestCase(2455)]
        public async Task OperationModeTest(long restaurantID)
        {
            var restaurantDetails = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var operationMode = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails)((Microsoft.AspNetCore.Mvc.ObjectResult)restaurantDetails.Result).Value).operationMode;
            Assert.IsNotNull(operationMode);
        }
        #endregion

        #region "Restaurant Settings"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantSettingsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsIDNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            long restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).restaurantID;
            Assert.IsNotNull(restID);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsIDAreEqualAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            long restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).restaurantID;
            Assert.AreEqual(2455, restID);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsMenuScheduleAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var menuSchedule = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).menuSchedule;
            Assert.NotNull(menuSchedule);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsMenuScheduleCountAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var menuSchedule = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).menuSchedule;
            Assert.IsNotNull(menuSchedule.Count);
        }

        [Test]
        [TestCase(2455)]
        public async Task FulfillmentFacilityScheduleNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var fulfillmentFacilitySchedule = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).fulfillmentFacilitySchedule;
            Assert.IsNotNull(fulfillmentFacilitySchedule);
        }

        [Test]
        [TestCase(2455)]
        public async Task FulfillmentFacilityScheduleCountNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var fulfillmentFacilitySchedule = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).fulfillmentFacilitySchedule;
            Assert.IsNotNull(fulfillmentFacilitySchedule.Count);
        }

        [Test]
        [TestCase(2455)]
        public async Task TableServiceNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var tableService = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).tableService;
            Assert.IsNotNull(tableService);
        }

        [Test]
        [TestCase(2455)]
        public async Task TableServicelocatorNumberNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var tableService = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).tableService;
            Assert.IsNotNull(tableService.locatorNumber);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsProprtionalVATTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsTrue(taxDefinitions.isProportionalVAT);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsOfferTypesExcludedFromProprtionalPriceAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.AreEqual(3, taxDefinitions.offerTypesExcludedFromProportionalPrice.Count);
            Assert.AreEqual("REWARD", taxDefinitions.offerTypesExcludedFromProportionalPrice[0]);
            Assert.AreEqual("SINGLEVOUCHER", taxDefinitions.offerTypesExcludedFromProportionalPrice[1]);
            Assert.AreEqual("MULTIPLEVOUCHER", taxDefinitions.offerTypesExcludedFromProportionalPrice[2]);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsEnableDeliveryTaxIdTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsNull(taxDefinitions.proportionalDeliveryChargeTaxId);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsEnableDeliveryTaxTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var taxDefinitions = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).taxDefinitions.order;
            Assert.IsFalse(taxDefinitions.enableProportionalDeliveryChargeTax);
        }

        [Test]
        [TestCase(2455)]
        public async Task RetailDeliveryFeeNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.retailDeliveryFee);
        }

        [Test]
        [TestCase(2455)]
        public async Task TakeAwayFeeNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.takeAwayFee);
        }

        [Test]
        [TestCase(2455)]
        public async Task IsMcDOwnedPricingEnabledTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsFalse(restID.isMcDOwnedPricingEnabled);
        }

        [Test]
        [TestCase(2455)]
        public async Task MinimumOrderValueNotNullTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.minimumOrderAmount);
            Assert.AreEqual(restID.minimumOrderAmount.Count, 3);
            Assert.AreEqual(restID.minimumOrderAmount[0].categoryID, "1");
            Assert.AreEqual(restID.minimumOrderAmount[0].value, Convert.ToDecimal(10.15));
            Assert.AreEqual(restID.minimumOrderAmount[1].categoryID, "2");
            Assert.AreEqual(restID.minimumOrderAmount[1].value, Convert.ToDecimal(20.25));
            Assert.AreEqual(restID.minimumOrderAmount[2].categoryID, "13");
            Assert.AreEqual(restID.minimumOrderAmount[2].value, Convert.ToDecimal(30.35));
        }
        [Test]
        [TestCase(2455)]
        public async Task MenuTransitionAlertTimeInMinutesNotNull(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.IsNotNull(restID.menuTransitionAlertTimeInMinutes);
        }
        [Test]
        [TestCase("default", 2455)]
        public async Task MenuTransitionAlertTimeInMinutesAreEqual(string testDataSet, long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).flexDelivery;
            Assert.AreEqual(restID.menuTransitionAlertTimeInMinutes.Value, 10);
        }

        [Test]
        [TestCase("default", 2455)]
        public async Task ROADaypartTransitionTimeInMinutesNotNull(string testDataSet, long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).restaurantSpecificOverrides.readyOnArrival;
            Assert.IsNotNull(restID.roaDaypartTransitionTimeInMinutes);
            Assert.AreEqual(restID.roaDaypartTransitionTimeInMinutes.Value, 10);
        }

        [Test]
        [TestCase(2455)]
        public async Task StagingBlockTimePastBusinessDateInMinutes(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).restaurantSpecificOverrides.orderFlow;
            Assert.IsNotNull(restID.stagingBlockTimePastBusinessDateInMinutes);
            Assert.AreEqual(restID.stagingBlockTimePastBusinessDateInMinutes, 30240);
        }

        [Test]
        [TestCase(2455)]
        public async Task TPOFeesNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var restID = ((V1.Models.RestaurantSettings)((ObjectResult)result.Result).Value).tpoFees;
            Assert.IsNotNull(result);
            Assert.IsNotNull(restID.deliveryFee);
            Assert.IsNotNull(restID.distanceFee);
            Assert.IsTrue(restID.deliveryFee.productCode.Equals(333));
            Assert.IsTrue(restID.distanceFee.productCode.Equals(444));
        }

        #endregion        

        #region "Restaurant Configuration"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantConfigurationNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        #endregion

        #region "Restaurant Menus"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantMenusAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantMenusNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantMenusAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantMenuObjectNotNullAsyncTest(long restaurantID, int menuID)
        {
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, 1, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantMenuNoChangeObjectAsyncTest(long restaurantID, int menuID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        #endregion

        #region "Restaurant Menus Categories"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64", 1)]
        public async Task RestaurantMenusCategoriesNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH, int? menuID = null)
        {
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID, menuID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantMenusCategoriesHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        #endregion

        #region "Restaurant Products"
        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantProductIDsObjectNotNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            Assert.IsNotNull(result.Result);
        }
        [Test]
        [TestCase(2455, null, true, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantProductIDsObjectNotNullEtagAsyncTest(long restaurantID, int? categoryID, bool OUTAGE, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE, IF_NONE_MATCH);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, null, null)]
        public async Task RestaurantProductIDsOutageNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            Assert.IsNotNull(result.Result);
        }
        [Test]
        [TestCase(2455, null, null, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64.93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantProductIDsOutageExceptionNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE, string IF_NON_MATCH)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE, IF_NON_MATCH);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, null, null, "93cb5341aed10a59b71c66330b570de47a.5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantProductIDsOutageNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE, IF_NONE_MATCH);
            Assert.IsNotNull(result.Result);
        }


        [Test]
        [TestCase(2455, 0, true)]
        public async Task RestaurantProductIDsObject400AsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            int statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(statusCode, 400);
        }

        [Test]
        [TestCase(2455, 40)]
        public async Task RestaurantProductIDsWithCategoryIdAsyncTest(long restaurantID, int? categoryID)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID);
            Assert.NotNull(result);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductIDsObjectNotNullAsyncTest(long restaurantID, int? categoryID)
        {
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID);
            Assert.NotNull(result.Result);
        }

        [Test]
        [TestCase(2455, 0)]
        public async Task RestaurantProductOutageIDsHeadObjectNotNullAsyncTest(long restaurantID, int? categoryID)
        {
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, 0, true)]
        public async Task RestaurantProductOutageIDsHeadObjectNotNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID, OUTAGE);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, null, false)]
        public async Task RestaurantProductOutageIDsFalseHeadObjectNotNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID, OUTAGE);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantProductOutageIDsTrueHeadObjectNotNullAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID, OUTAGE);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductOutageIDsCategoryFalseHeadObjectNotNullAsyncTest(long restaurantID, int? categoryID)
        {
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantProductsHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantProductsNoChangeAsyncTest(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantProductsAsync(restaurantID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            Assert.NotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsHeaderAsyncTest(long restaurantID)
        {
            apiController.ControllerContext.HttpContext.Request.Headers["Accept-Encoding"] = "gzip";
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            Assert.NotNull(result);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductsSpecifiedNotNullAsyncTest(long restaurantID, HashSet<int> productIDs)
        {
            productIDs = new HashSet<int>() { 1, 2 };
            var result = await apiController.GetRestaurantProductsSpecifiedAsync(restaurantID, productIDs);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductNotNullAsyncTest(long restaurantID, int productID)
        {
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productID);
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase(2455, 1, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantProductsEtagAsyncTest(long restaurantID, int productid, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productid, IF_NONE_MATCH);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductObjectNotNullAsyncTest(long restaurantID, int productID)
        {
            await InitializeETag();

            var result = await apiController.GetRestaurantProductAsync(restaurantID, productID);
            Assert.IsNotNull(result);
        }
        #endregion      

        #region "Restaurant Promotions"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionIDsObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantPromotionIDsAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64", true)]
        public async Task RestaurantPromotionIDsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH, bool? ADVERTISABLE = null)
        {
            var result = await apiController.GetRestaurantPromotionIDsAsync(restaurantID, ADVERTISABLE, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionsObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantPromotionsAsync(restaurantID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64", true)]
        public async Task RestaurantPromotionsNoChangeObjectAsyncTest(long restaurantID, string IF_NONE_MATCH, bool? ADVERTISABLE = null)
        {
            var result = await apiController.GetRestaurantPromotionsAsync(restaurantID, ADVERTISABLE, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionsSpecifiedObjectNotNullAsyncTest(long restaurantID, HashSet<int> promotionIDs)
        {
            var result = await apiController.GetRestaurantPromotionsSpecifiedAsync(restaurantID, promotionIDs);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, null, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64", true)]
        public async Task RestaurantPromotionsSpecifiedNoChangeObjectAsyncTest(long restaurantID, HashSet<int> promotionIDs, string IF_NONE_MATCH, bool? ADVERTISABLE = null)
        {
            var result = await apiController.GetRestaurantPromotionsSpecifiedAsync(restaurantID, promotionIDs, ADVERTISABLE, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionsHeadObjectNotNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantPromotionsHeadAsync(restaurantID);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, 548)]
        public async Task RestaurantPromotionObjectNotNullAsyncTest(long restaurantID, int promotionID)
        {
            var result = await apiController.GetRestaurantPromotionAsync(restaurantID, promotionID);
            Assert.IsNotNull(result.Result);
        }

        [Test]
        [TestCase(2455, 548, "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64")]
        public async Task RestaurantPromotionNoChangeObjectAsyncTest(long restaurantID, int promotionID, string IF_NONE_MATCH)
        {
            var result = await apiController.GetRestaurantPromotionAsync(restaurantID, promotionID, IF_NONE_MATCH);
            var statusCode = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(304, statusCode);
        }

        #endregion

    }
}