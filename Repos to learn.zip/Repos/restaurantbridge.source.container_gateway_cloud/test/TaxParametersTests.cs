﻿using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.V2;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    [TestFixture]
    public class TaxParametersTests
    {
        APIController apiController;
        #region "Test Data"
        public async Task<TaxParameters> TaxParametersTestDataAsync()
        {
            var taxParametersJson = JsonConvert.DeserializeObject<TaxParameters>(await File.ReadAllTextAsync($"data/default/TaxParameters.json"));
            return taxParametersJson;
        }
        #endregion

        #region"Initialization"
        [SetUp]
        public async Task Initialize()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();
         
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _service = new Mock<IService>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _cacheParsedTaxParameters = new Mock<Cache.ParsedTaxParameters.V1.IClientAdvanced>();
            var _restaurantSearchIndex = new Mock<IRestaurantSearchIndex>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _oqmcOverrides = new Mock<OQMCMenu.Processor.V1.IClientAdvanced>();
            var _cacheParsedCoatesMenus = new Mock<Coates.Cache.ParsedRestaurantCoatesMenus.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();

            apiController = new APIController
               (
                _logger.Object,
                _service.Object,
                _restaurantSearchIndex.Object,
                _restaurantConfiguration.Object,
                 _restaurantMonitor.Object,
                 _cacheParsedDetails.Object,
                 _cacheParsedChannelMenus.Object,
                 _cacheParsedTaxParameters.Object,
                 _cacheParsedProductOutages.Object,
                 _oqmcOverrides.Object,
                 _cacheParsedCoatesMenus.Object,
                 _cacheParsedSettings.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            #region TaxParameters

            var restaurantSettings = await TaxParametersTestDataAsync();

            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParameters_DESERIALIZE_AS_Async<V2.Models.TaxParameters>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((restaurantSettings, eTag));

            _cacheParsedTaxParameters.Setup(x => x.GetRestaurantTaxParametersETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);

            #endregion
        }
        #endregion


        #region OperationModeConfiguration
        [Test]
        [TestCase(2455)]
        public async Task enableProportionalDeliveryChargeTaxNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var taxDefinitions = ((V2.Models.TaxParameters)((ObjectResult)result.Result).Value).operationModeConfiguration.enableProportionalDeliveryChargeTax;
            Assert.IsFalse(taxDefinitions);
        }
        [Test]
        [TestCase(2455)]
        public async Task proportionalDeliveryChargeTaxIdNullAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var taxDefinitions = ((V2.Models.TaxParameters)((ObjectResult)result.Result).Value).operationModeConfiguration.proportionalDeliveryChargeTaxId;
            Assert.IsNull(taxDefinitions);
        }

        [Test]
        [TestCase(2455)]
        public async Task enableTaxBreakDownUpchargeTrueAsyncTest(long restaurantID)
        {
            var result = await apiController.GetRestaurantTaxParametersAsync(restaurantID);
            var taxDefinitions = ((V2.Models.TaxParameters)((ObjectResult)result.Result).Value).operationModeConfiguration.enableTaxBreakDownUpcharge;
            Assert.IsTrue(taxDefinitions);
        }

        #endregion

    }

}


