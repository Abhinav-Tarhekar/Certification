﻿using Common;
using Common.Logger;
using McD.McFlow.Client.Library.Producer;

using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.Services;
using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using RestaurantBridge.RestaurantMonitor.V1.Models;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    #region EmpheralPubSubSetUp
    public class TestingEmpheralPubSub : IEmpheralPubSub
    {
        public class GlobMatch
        {
            Regex mRegex;
            public GlobMatch(string wildcard)
            {
                string pattern = string.Format("^{0}$", Regex.Escape(wildcard)
                    .Replace(@"\*", ".*").Replace(@"\?", "."));
                mRegex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
            }
            public bool IsMatch(string filenameToCompare)
            {
                return mRegex.IsMatch(filenameToCompare);
            }
        }
        Dictionary<string, Func<string, string, Task>> messageHandlers = new Dictionary<string, Func<string, string, Task>>();
        public async Task Publish(string routingKey, string message)
        {
            foreach (var routingKeyGlobFilter in messageHandlers.Keys)
            {
                if (new GlobMatch(routingKeyGlobFilter).IsMatch(routingKey)) { await messageHandlers[routingKeyGlobFilter].Invoke(routingKey, message); }
            }
        }
        public Task<Guid> Subscribe(string routingKeyGlobFilter, Func<string, string, Task> messageHandler)
        {
            messageHandlers.Add(routingKeyGlobFilter, messageHandler);
            return Task.FromResult(Guid.NewGuid());
        }
        public Task Unsubscribe(Guid subscriptionToken)
        {
            return Task.CompletedTask;
        }
    }
    #endregion

    #region TestingConfiguration
    public class TestingConfiguration : IConfiguration
    {
        public bool enableV2SearchRestaurantAPI { get; private set; }
        public bool enablefeatureflagMcFlow { get; private set; }
        public string schema_registry_url { get; private set; }
        public string bootstrap_server { get; private set; }
        public string cluster_name { get; private set; }
        public string marketID { get; private set; }
        public string event_topic_prefix { get; private set; }
        public bool enable_rb_event_mcflow_publish { get; private set; }
        public bool publish_v1_events_mcflow { get; private set; }
        public bool publish_v2_events_mcflow { get; private set; }
        public bool enable_sub_event_mcflow_publish { get; private set; }
        public string dynamodb_aws_region { get; private set; }
        public string http_prefix { get; private set; }
        public int http_max_concurrent_inbound_requests { get; private set; }
        public int http_client_timeout_ms { get; private set; }
        public int proxy_premise_npos61_client_timeout_ms { get; private set; }
        public string restaurant_configuration_api_url { get; private set; }
        public string restaurant_monitor_api_url { get; private set; }
        public string cache_parsed_promotions_api_url { get; private set; }
        public string cache_parsed_product_outages_api_url { get; private set; }
        public string cache_parsed_products_api_url { get; private set; }
        public string cache_parsed_menu_categories_api_url { get; private set; }
        public string cache_parsed_channel_menus_api_url { get; private set; }
        public string cache_parsed_coates_menus_api_url { get; private set; }
        public string cache_parsed_tax_parameters_api_url { get; private set; }
        public string cache_parsed_settings_api_url { get; private set; }
        public string cache_parsed_details_api_url { get; private set; }
        public string cache_rfmxml_databases_api_url { get; private set; }
        public string proxy_premise_api_url { get; private set; }
        public string oqmcmenu_api_url { get; private set; }
        public string redis_connection_string { get; private set; }
        public int redis_database_number { get; private set; }
        public string redis_key_prefix { get; private set; }
        public string products_cache_specified_connection_string { get; private set; }
        public int products_cache_specified_ttl_hours { get; private set; }
        public int products_cache_specified_build_auto_release_time_ms { get; private set; }
        public int products_cache_specified_build_take_retry_delay_ms { get; private set; }
        public int beacon_interval_ms { get; private set; }
        public int min_worker_threads { get; private set; }
        public int min_io_threads { get; private set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public Logger.Level min_log_level { get; private set; }
        public int check_lock_auto_release_timeout_ms { get; private set; }
        public TestingConfiguration()
        {
            products_cache_specified_connection_string = "";
            enableV2SearchRestaurantAPI = false;
            http_prefix = "http://*:8080";
            marketID = "";
            event_topic_prefix = "na-us-dev01-menu-";
            dynamodb_aws_region = "us-east-1";
            enable_rb_event_mcflow_publish = true;
            publish_v1_events_mcflow = true;
            publish_v2_events_mcflow = true;
            enable_sub_event_mcflow_publish = true;
            enablefeatureflagMcFlow = true;
            schema_registry_url = "localhost:8085/";
            bootstrap_server = "localhost:29092/";
            cluster_name = "mock";
            http_max_concurrent_inbound_requests = -1;
            http_client_timeout_ms = 10000;
            proxy_premise_npos61_client_timeout_ms = 120000;
            restaurant_configuration_api_url = "";
            restaurant_monitor_api_url = "";
            cache_parsed_promotions_api_url = "";
            cache_parsed_product_outages_api_url = "";
            cache_parsed_products_api_url = "";
            cache_parsed_menu_categories_api_url = "";
            cache_parsed_channel_menus_api_url = "";
            cache_parsed_tax_parameters_api_url = "";
            cache_parsed_settings_api_url = "";
            cache_parsed_details_api_url = "";
            cache_rfmxml_databases_api_url = "";
            proxy_premise_api_url = "";
            oqmcmenu_api_url = "";
            cache_parsed_coates_menus_api_url = "";
            redis_connection_string = "localhost:6379";
            redis_database_number = 1;
            redis_key_prefix = "DEV";
            products_cache_specified_ttl_hours = -1;
            products_cache_specified_build_auto_release_time_ms = 0;
            products_cache_specified_build_take_retry_delay_ms = 200;
            beacon_interval_ms = 10000;
            min_worker_threads = 100;
            min_io_threads = 100;
            min_log_level = Logger.Level.DEBUG;
            check_lock_auto_release_timeout_ms = 60000;
        }
    }
    #endregion

    [TestFixture]
    public class EventsManagerV1Tests
    {
        private EventsManager _eventsManager;
        private TestingEmpheralPubSub empheralPubSub;
        private HttpContext _httpContext;
        private Configuration configuration = new Mock<Configuration>().Object;
        private IMcFlowProducer<string, string> _mcFlowProducer;
        Mock<WebSocket> _webSocket = new Mock<WebSocket>();
        Mock<ILog> logger = new Mock<ILog>();
        Mock<IStringKeyValueStore> stringKeyHashStore = new Mock<IStringKeyValueStore>();
        private TestingConfiguration configuration2 = new Mock<TestingConfiguration>().Object;
        private Mock<IConfiguration> configuration3 = new Mock<IConfiguration>();
        private Mock<RestaurantMonitor.V1.IClientAdvanced> _restaurantMonitorClient;

        [SetUp]
        public async Task TestInitialize()
        {
            empheralPubSub = new TestingEmpheralPubSub();
            _httpContext = Mock.Of<HttpContext>();
            CancellationToken cancellationToken = new CancellationToken();
            TaskCompletionSource<object> socketFinishedTcs = Mock.Of<TaskCompletionSource<object>>();
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            stringKeyHashStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Throws(new Exception());
            List<string> stringvaluestore = new List<string> { "11223344-5566-7788-99AA-BBCCDDEEFF000", "11223344-5566-7788-99AA-BBCCDDEEFF01" };
            stringKeyHashStore.Setup(x => x.GetAllKeys()).Returns(stringvaluestore);
            var _resourceLock = new Mock<IResourceLock>().Object;
            _restaurantMonitorClient = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            _eventsManager = new EventsManager(
                logger.Object,
                empheralPubSub,
                configuration,
                _mcFlowProducer, 
                _rbClientAdvanced,
                _restaurantMonitorClient.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            await _eventsManager.InitializeAsync(Program.CancellationTokenSource.Token);
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs, cancellationToken);
        }

        public async Task TestDataInitialize()
        {
            empheralPubSub = new TestingEmpheralPubSub();
            _httpContext = Mock.Of<HttpContext>();
            CancellationToken cancellationToken = new CancellationToken();
            TaskCompletionSource<object> socketFinishedTcs = Mock.Of<TaskCompletionSource<object>>();
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            stringKeyHashStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Throws(new Exception());
            List<string> stringvaluestore = new List<string> { "11223344-5566-7788-99AA-BBCCDDEEFF000", "11223344-5566-7788-99AA-BBCCDDEEFF01" };
            stringKeyHashStore.Setup(x => x.GetAllKeys()).Returns(stringvaluestore);
            var _resourceLock = new Mock<IResourceLock>().Object;
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            _eventsManager = new EventsManager(
                logger.Object,
                empheralPubSub,
                configuration2,
                _mcFlowProducer, 
                _rbClientAdvanced,
                _restaurantMonitorClient.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            await _eventsManager.InitializeAsync(Program.CancellationTokenSource.Token);
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs, cancellationToken);
        }

        public async Task TestSubEventInitialize()
        {
            empheralPubSub = new TestingEmpheralPubSub();
            _httpContext = Mock.Of<HttpContext>();
            CancellationToken cancellationToken = new CancellationToken();
            TaskCompletionSource<object> socketFinishedTcs = Mock.Of<TaskCompletionSource<object>>();
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            stringKeyHashStore.Setup(x => x.SetAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Throws(new Exception());
            List<string> stringvaluestore = new List<string> { "11223344-5566-7788-99AA-BBCCDDEEFF000", "11223344-5566-7788-99AA-BBCCDDEEFF01" };
            stringKeyHashStore.Setup(x => x.GetAllKeys()).Returns(stringvaluestore);
            var _resourceLock = new Mock<IResourceLock>().Object;
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            configuration3.Setup(x => x.enable_sub_event_mcflow_publish).Returns(false);
            _eventsManager = new EventsManager(
                logger.Object,
                empheralPubSub,
                configuration3.Object,
                _mcFlowProducer, 
                _rbClientAdvanced,
                _restaurantMonitorClient.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            await _eventsManager.InitializeAsync(Program.CancellationTokenSource.Token);
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs, cancellationToken);
        }
        #region Test Lambda Scenarios

        [Test]
        [TestCase(2455)]
        public async Task GatewayDropSubscribersEventTest(long restaurantID)
        {
            var guid = Guid.NewGuid();
            await empheralPubSub.Publish("V1:GatewayDropSubscribersEvent", guid.ToString());
        }

        [TestCase(2455)]
        public async Task RestaurantConfigurationInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantConfigurationInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantStateInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantStateInvalidationEvent", message);
        }


        [TestCase(2455)]
        public async Task RestaurantDetailsInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantDetailsInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantSettingsInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantSettingsInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantMenuCategoriesInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantMenuCategoriesInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantProductsInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantProductsInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantChannelMenusInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantChannelMenusInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantTaxParametersInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantTaxParametersInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantProductOutagesInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantProductOutagesInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantPromotionInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantPromotionInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantCachesClearEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantCachesClearEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantCachesReloadEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantCachesReloadEvent", message);
        }

        [TestCase(2455)]
        public async Task OQMCInvalidationEventTest(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:OqmcInvalidationEvent", message);
        }

        [TestCase(2455)]
        public async Task RestaurantCoatesMenusInvalidationEvent(long restaurantID)
        {
            string message = @"{""restaurantID"": ""2455"", ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c""}";
            await empheralPubSub.Publish("V1:RestaurantCoatesMenusInvalidationEvent", message);
        }

        [Test]
        public async Task UnsubscribeTest()
        {
            await empheralPubSub.Unsubscribe(new Guid());
        }
        #endregion

        #region subscriberRegexPatternTests
        [Test]
        [TestCase("11223344-5566-7788-99AA-BBCCDDEEFF000")]
        public async Task subscriberRegexPatternTests(string subscriberRegexPattern)
        {
            await _eventsManager.DropSubscribersThatMatchPatternAsync(subscriberRegexPattern);
            Assert.IsTrue(true);
        }
        #endregion

        #region InvalidationTests
        [TestCase(2455, "V1:RestaurantTaxParametersInvalidationEvent")]
        public async Task TriggerInvalidationTest_TriggeredSuccessfully(long restaurantID, string routingKey)
        {
          _restaurantMonitorClient
            .Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantState>(restaurantID,
              It.IsAny<CancellationToken>()))
            .ReturnsAsync(new RestaurantState());
          
          var result = await _eventsManager.TriggerInvalidation(restaurantID, routingKey);
          
          Assert.IsTrue(result);
        }
        
        [TestCase(2455, "V1:RestaurantTaxParametersInvalidationEvent")]
        public async Task TriggerInvalidationTest_RestaurantNotFound(long restaurantID, string routingKey)
        {
          _restaurantMonitorClient
            .Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantState>(restaurantID,
              It.IsAny<CancellationToken>()))
            .ReturnsAsync((RestaurantState)null);
          
          var result = await _eventsManager.TriggerInvalidation(restaurantID, routingKey);

          Assert.IsFalse(result);
        }
        
        [TestCase(2455, "V1:RestaurantTaxParametersInvalidationEvent")]
        public async Task TriggerInvalidationTest_ExceptionThrown(long restaurantID, string routingKey)
        {
          _restaurantMonitorClient
            .Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantState>(restaurantID,
              It.IsAny<CancellationToken>()))
            .ThrowsAsync(new Exception());
          
          var result = await _eventsManager.TriggerInvalidation(restaurantID, routingKey);
          
          Assert.IsFalse(result);
        }
        #endregion
        
        #region Sub-Event UT for V1 and V2
        [TestCase]
        public async Task RestaurantStateInvalidationSubEventTest()
        {
            await TestInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                               ""eTag"": null,
                              ""subEvent"": {
                                          ""restaurantID"": 2455,
                                          ""lastUpdateTime"": ""2024-07-26T10:08:54.3186957+05:30"",
                                          ""sequenceNumberActivationTime"": ""2024-07-18T15:16:24.4186955+05:30"",
                                          ""sequenceNumber"": ""05192034"",
                                           ""connectivity"": 2,
                                           ""isOpen"": true,
                                           ""isHealthy"": true,
                                           ""currentTimezoneOffsetInMinutesFromUTC"": -360,
                                           ""businessDate"": ""20240726"",
                                           ""databaseVersions"": {
                                               ""store"": ""20240613:141437000"",
                                               ""products"": ""20240725:085241000"",
                                               ""productNames"": ""20240613:141447000"",
                                               ""productOutages"": ""20240613:141424000"",
                                               ""promotions"": ""20240613:141438000"",
                                               ""restaurantPromotions"": ""20240613:141429000""
                                            },
                    ""maxPossibleNPOS61ResponseTimesInMilliseconds"": {
                        ""GetStoreStatus"": 120000,
                        ""GetStoredb"": 120000,
                        ""GetProduct"": 120000,
                        ""GetNames"": 120000,
                        ""GetProdOutage"": 120000,
                        ""GetPromotiondb"": 120000,
                        ""GetRestaurantPromotiondb"": 120000,
                        ""DoFoeStore"": 120000,
                        ""DoFoeStoreDT"": 120000,
                        ""DoFoeStoreStaging"": 120000,
                        ""TransferFromStaging"": 120000,
                        ""GetOrderStatus"": 120000,
                        ""UpdateOrderStatus"": 120000,
                        ""SendOrderPaymentStatus"": 120000
                    }
                }
            }";
            await empheralPubSub.Publish("V1:RestaurantStateInvalidationEvent", message);
        }

        [TestCase]
        public async Task RestaurantDetailsInvalidationSubEventTest()
        {
            await TestInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                               ""eTag"": null,
                              ""subEvent"": {
""restaurantID"": 2455,
  ""marketID"": ""US"",
  ""posID"": 2455,
  ""longitude"": -84.941197,
  ""latitude"": 32.482322,
  ""operationMode"": ""PICKUP_ONLY"",
  ""facilities"": [
    ""24HR"",
    ""DRIVE-THRU"",
    ""MCCAFE"",
    ""MOBILE ORDERING"",
    ""WI-FI""
  ],
  ""name"": ""STORE 2455 eCP 3.0"",
  ""phone"": ""7065618375"",
  ""address"": {
    ""address"": ""3315 MACON ROAD Test"",
    ""city"": ""COLUMBUS"",
    ""state"": ""GA"",
    ""country"": ""US"",
    ""postCode"": ""31906-2304""
  },
  ""defaultLocale"": ""en-US""
}
            }";
            await empheralPubSub.Publish("V1:RestaurantDetailsInvalidationEvent", message);
        }

        [TestCase]
        public async Task RestaurantDetailsV2InvalidationSubEventTest()
        {
            await TestInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": ""83cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"",
                              ""subEvent"": {
  ""restaurantID"": 2455,
  ""marketID"": ""US"",
  ""marketStoreID"": 2455,
  ""latitude"": 32.482322,
  ""longitude"": -84.941197,
  ""locales"": [
    ""en-US""
  ],
  ""channelHours"": {
    ""COATES_IDMB"": {
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    },
    ""COATES_ODMB"": {
      ""SUNDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    },
    ""GMA_EATIN"": {
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    },
    ""GMA_PICKUP"": {
      ""SUNDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    },
    ""GMAL_EATIN"": {
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    },
    ""GMAL_PICKUP"": {
      ""SUNDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""MONDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""TUESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""WEDNESDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""THURSDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""FRIDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      },
      ""SATURDAY"": {
        ""generalHours"": {
          ""from"": ""04:00:00"",
          ""to"": ""03:59:59.9999999"",
          ""nextDay"": true
        },
        ""areaHours"": {
          ""DRIVETHRU"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""LOBBY"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ],
          ""ORDERAHEADLANE"": [
            {
              ""from"": ""04:00:00"",
              ""to"": ""03:59:59.9999999"",
              ""nextDay"": true
            }
          ]
        }
      }
    }
  },
  ""facilities"": [
    ""24HR"",
    ""DRIVE-THRU"",
    ""MCCAFE"",
    ""MOBILE ORDERING"",
    ""WI-FI""
  ],
  ""name"": ""STORE 455 eCP 3.0"",
  ""phone"": ""7065618375"",
  ""address"": {
    ""address"": ""3315 MACON ROAD Test"",
    ""city"": ""COLUMBUS"",
    ""state"": ""GA"",
    ""country"": ""US"",
    ""postCode"": ""31906-2304""
  },
  ""additionalInformation"": {
    ""CompanyName"": ""FOEEMULATOR""
  },
  ""defaultLocale"": ""en-US"",
  ""ChannelConfiguration"": {
    ""GMA_DELIVERY"": {
      ""DELIVERY"": {
        ""podInfo"": {
          ""podName"": ""FOE9901"",
          ""pod"": 3,
          ""remPod"": 3,
          ""type"": 2
        }
      }
    },
    ""GMA_EATIN"": {
      ""PICKUP"": {
        ""podInfo"": {
          ""podName"": ""FOE0018"",
          ""pod"": 0,
          ""remPod"": 0,
          ""type"": 0
        }
      }
    },
    ""GMA_PICKUP"": {
      ""CURBSIDE"": {
        ""podInfo"": {
          ""podName"": ""FOE0018"",
          ""pod"": 2,
          ""remPod"": 2,
          ""type"": 1
        }
      },
      ""DRIVETHRU"": {
        ""podInfo"": {
          ""podName"": ""FOE0019"",
          ""pod"": 1,
          ""remPod"": 1,
          ""type"": 1
        }
      }
    },
    ""GMAL_DELIVERY"": {
      ""DELIVERY"": {
        ""podInfo"": {
          ""podName"": ""FOE9901"",
          ""pod"": 3,
          ""remPod"": 3,
          ""type"": 2
        }
      }
    },
    ""GMAL_EATIN"": {
      ""PICKUP"": {
        ""podInfo"": {
          ""podName"": ""FOE0018"",
          ""pod"": 0,
          ""remPod"": 0,
          ""type"": 0
        }
      }
    },
    ""GMAL_PICKUP"": {
      ""CURBSIDE"": {
        ""podInfo"": {
          ""podName"": ""FOE0018"",
          ""pod"": 2,
          ""remPod"": 2,
          ""type"": 1
        }
      },
      ""DRIVETHRU"": {
        ""podInfo"": {
          ""podName"": ""FOE0019"",
          ""pod"": 1,
          ""remPod"": 1,
          ""type"": 1
        }
      }
    }
  },
  ""ValidationConfiguration"": {
    ""COATES_IDMB"": {},
    ""COATES_ODMB"": {},
    ""GMA_DELIVERY"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true,
      ""orderValueLimit"": 15000,
      ""orderItemLimit"": 15
    },
    ""GMA_EATIN"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true,
      ""orderValueLimit"": 10000,
      ""orderItemLimit"": 10
    },
    ""GMA_PICKUP"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true,
      ""orderValueLimit"": 10000,
      ""orderItemLimit"": 10
    },
    ""GMAL_DELIVERY"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true,
      ""orderValueLimit"": 14000,
      ""orderItemLimit"": 14
    },
    ""GMAL_EATIN"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true
    },
    ""GMAL_PICKUP"": {
      ""outageValidation"": true,
      ""timeOfTheDayValidation"": true
    }
  },
  ""paymentTaxDiscountEnabled"": false
 }
}";
            await empheralPubSub.Publish("V1:RestaurantDetailsInvalidationEvent", message);
        }

        [TestCase]
        public async Task RestaurantStateInvalidationSubEventFalseCaseTest()
        {
            await TestDataInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": {
                                          ""restaurantID"": 2455,
                                          ""lastUpdateTime"": ""2024-07-26T10:08:54.3186957+05:30"",
                                          ""sequenceNumberActivationTime"": ""2024-07-18T15:16:24.4186955+05:30"",
                                          ""sequenceNumber"": ""05192034"",
                                           ""connectivity"": 2,
                                           ""isOpen"": true,
                                           ""isHealthy"": true,
                                           ""currentTimezoneOffsetInMinutesFromUTC"": -360,
                                           ""businessDate"": ""20240726"",
                                           ""databaseVersions"": {
                                               ""store"": ""20240613:141437000"",
                                               ""products"": ""20240725:085241000"",
                                               ""productNames"": ""20240613:141447000"",
                                               ""productOutages"": ""20240613:141424000"",
                                               ""promotions"": ""20240613:141438000"",
                                               ""restaurantPromotions"": ""20240613:141429000""
                                          },
                    ""maxPossibleNPOS61ResponseTimesInMilliseconds"": {
                        ""GetStoreStatus"": 120000,
                        ""GetStoredb"": 120000,
                        ""GetProduct"": 120000,
                        ""GetNames"": 120000,
                        ""GetProdOutage"": 120000,
                        ""GetPromotiondb"": 120000,
                        ""GetRestaurantPromotiondb"": 120000,
                        ""DoFoeStore"": 120000,
                        ""DoFoeStoreDT"": 120000,
                        ""DoFoeStoreStaging"": 120000,
                        ""TransferFromStaging"": 120000,
                        ""GetOrderStatus"": 120000,
                        ""UpdateOrderStatus"": 120000,
                        ""SendOrderPaymentStatus"": 120000
                    }
                }
            }";
            await empheralPubSub.Publish("V1:RestaurantStateInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is true
        public async Task RestaurantSettingsInvalidationSubEventWithPayloadTest()
        {
            await TestDataInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": {
                                    ""restaurantID"":57,
                                    ""marketID"":""US"",
                                    ""menuSchedule"":{}
                                }
                             }";
            await empheralPubSub.Publish("V1:RestaurantSettingsInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task RestaurantSettingsInvalidationSubEventyNoPayloadTest()
        {
            await TestSubEventInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": {
                                    ""restaurantID"":57,
                                    ""marketID"":""US"",
                                    ""menuSchedule"":{}
                                }
                             }";
            await empheralPubSub.Publish("V1:RestaurantSettingsInvalidationEvent", message);
        }


        [TestCase]
        // enable_sub_event_mcflow_publish is true
        public async Task RestaurantProductOtagesInvalidationSubEventWithPayloadTest()
        {
            await TestDataInitialize();
            string message = @"{
                              ""restaurantID"": 4545,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": ""93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"", 
                              ""subEvent"":[9990,9991,6462]
                                                      
                             }";
            await empheralPubSub.Publish("V1:RestaurantProductOutagesInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task RestaurantProductOutagesInvalidationSubEventNoPayloadTest()
        {
            await TestSubEventInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"":""93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"",
                              ""subEvent"": [9990,9991,6462]
                                    
                             }";
            await empheralPubSub.Publish("V1:RestaurantProductOutagesInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is true
        public async Task RestaurantPromotionsInvalidationSubEventyWithPayloadTest()
        {
            await TestDataInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": [1,2,3]
                             }";
            await empheralPubSub.Publish("V1:RestaurantPromotionInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task RestaurantPromotionsInvalidationSubEventyNoPayloadTest()
        {
            await TestSubEventInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": null
                             }";
            await empheralPubSub.Publish("V1:RestaurantPromotionInvalidationEvent", message);
        }
        
        [TestCase]
        // enable_sub_event_mcflow_publish is true
        public async Task OqmcInvalidationSubEventWithPayloadTest()
        {
          await TestDataInitialize();
          string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": {
                                ""restaurantID"": 57,
                                ""edtOverrideNormalOrderInMinutes"": 10,
                                ""edtOverrideLargeOrderInMinutes"": 10,
                                ""defaultEdtNormalOrderInMinutes"": 10,
                                ""defaultEdtLargeOrderInMinutes"": 10,
                                ""suspendDeliveryOrderingExpiryTimeUTC"": ""2024-09-06T11:57:27Z"",
                                ""edtOverrideExpiryTimeUTC"": ""2024-01-08T16:57:05Z"",
                                ""edtOverrideReasonCode"": ""Test"",
                                ""suspendDeliveryReasonCode"": ""Test"",
                                ""crewId"": ""string"",
                                ""startTime"": ""2024-09-06T13:21:37.746Z"",
                                ""overrideActivityType"": ""Test"",
                                ""marketID"": ""US""
                              }
                             }";
          await empheralPubSub.Publish("V1:OqmcInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task OqmcInvalidationSubEventNoPayloadTest()
        {
          await TestSubEventInitialize();
          string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": null
                             }";
          await empheralPubSub.Publish("V1:OqmcInvalidationEvent", message);
        }               

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task RestaurantProductInvalidationSubEventNoPayloadTest()
        {
            await TestSubEventInitialize();
            string message = @"{
                       ""restaurantID"": 57,
                       ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                       ""eTag"":""93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"",
                       ""subEvent"": [9990,9991,6462]     
                      }";
            await empheralPubSub.Publish("V1:RestaurantProductsInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is true
        public async Task RestaurantMenuCategoriesInvalidationSubEventyWithPayloadTest()
        {
            await TestDataInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": [
                                  {
                                    ""restaurantID"": 2455,
                                    ""menuID"": 1,
                                    ""ID"": 1,
                                    ""dayPart"": ""UNDEFINED"",
                                    ""display"": {
                                      ""parentID"": -1,
                                      ""name"": {
                                        ""en-US"": ""Amore"",
                                        ""es-US"": ""Amore""
                                      },
                                      ""order"": 4,
                                      ""color"": ""#F0FFFF"",
                                      ""imageName"": ""MenuBreakfastImage@2x.png""
                                    }
                                  }
                                ]
                             }";
            await empheralPubSub.Publish("V1:RestaurantMenuCategoriesInvalidationEvent", message);
        }

        [TestCase]
        // enable_sub_event_mcflow_publish is false
        public async Task RestaurantMenuCategoriesInvalidationSubEventyNoPayloadTest()
        {
            await TestSubEventInitialize();
            string message = @"{
                              ""restaurantID"": 57,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                              ""eTag"": null,
                              ""subEvent"": null
                             }";
            await empheralPubSub.Publish("V1:RestaurantMenuCategoriesInvalidationEvent", message);
        }

        [TestCase]
        public async Task RestaurantProductInvalidationSubEventPayloadTest()
        {
            await TestDataInitialize();
            string message = @"{
                       ""restaurantID"": 57,
                       ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                       ""eTag"":""93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64"",
                       ""subEvent"": [9990,9991,6462]
                             
                      }";
            await empheralPubSub.Publish("V1:RestaurantProductsInvalidationEvent", message);
        }
        #endregion

        [TestCase]
        public async Task RestaurantConfingV1InvalidationSubEventTest()
        {
            await TestInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                               ""eTag"": null,
                              ""subEvent"": {
  ""restaurantID"": 2455,
  ""isActiveForOrdering"": true,
  ""encryption"": {
    ""activeKeyID"": ""6"",
    ""keys"": {
      ""6"": ""@zeJcZbuPWsCwg`IGD]OS@xMKA^Qd[ktmFjYqnUvzr_hRHBXTfNEyp\\lVLoia""
    }
  },
  ""timeZone"": {
    ""standardTimeOffsetInMinutesFromUTC"": -360,
    ""daylightSavingTimeOffsetInMinutesFromUTC"": -300,
    ""daylightSavingTimeBegins"": ""2022-03-13T07:00:00Z"",
    ""daylightSavingTimeEnds"": ""2022-11-06T07:00:00Z""
  },
  ""possiblePaymentProvidersAtPossibleFulfillmentFacilities"": {
    ""Curbside"": [
      ""Adyen"",
      ""Alipay"",
      ""AlipayMobile"",
      ""AlipayWeb"",
      ""Barclaycard"",
      ""CyberSource"",
      ""CyberSourceWebView"",
      ""FirstData"",
      ""Moneris"",
      ""Onsite"",
      ""TeleCash"",
      ""WeChatMobile""
    ],
    ""Delivery"": [
      ""Adyen"",
      ""Alipay"",
      ""AlipayMobile"",
      ""AlipayWeb"",
      ""Barclaycard"",
      ""FirstData"",
      ""Moneris"",
      ""Onsite"",
      ""TeleCash"",
      ""WeChatMobile""
    ],
    ""DriveThru"": [
      ""Adyen"",
      ""Alipay"",
      ""AlipayMobile"",
      ""AlipayWeb"",
      ""Barclaycard"",
      ""CyberSource"",
      ""CyberSourceWebView"",
      ""FirstData"",
      ""Moneris"",
      ""Onsite"",
      ""TeleCash"",
      ""WeChatMobile""
    ],
    ""Lobby"": [
      ""Adyen"",
      ""Alipay"",
      ""AlipayMobile"",
      ""AlipayWeb"",
      ""Barclaycard"",
      ""CyberSource"",
      ""CyberSourceWebView"",
      ""FirstData"",
      ""Moneris"",
      ""Onsite"",
      ""TeleCash"",
      ""WeChatMobile""
    ],
    ""Pickup"": [
      ""Adyen"",
      ""Alipay"",
      ""AlipayMobile"",
      ""AlipayWeb"",
      ""Barclaycard"",
      ""CyberSource"",
      ""CyberSourceWebView"",
      ""FirstData"",
      ""Moneris"",
      ""Onsite"",
      ""TeleCash"",
      ""WeChatMobile""
    ]
  },
  ""companyName"": ""FOEEMULATOR"",
  ""foe"": {
    ""urls"": [
      ""http://foeemulator-dev01-us.dev.us-east-1.dev.digitalecp.mcd.com/US/24/2455""
    ]
  },
  ""marketConfigurationOverrides"": {
    ""PaymentProvider.Adyen.MerchantId"": ""MCD_US_455""
  }
}
            }";
            await empheralPubSub.Publish("V1:RestaurantConfigurationInvalidationEvent", message);
        }

        [TestCase]
        public async Task RestaurantConfingV2InvalidationSubEventTest()
        {
            await TestInitialize();
            string message = @"{
                              ""restaurantID"": 2455,
                              ""eventID"": ""0ec95b00-522d-45d5-aa33-b94ac356d18c"",
                               ""eTag"": null,
                              ""subEvent"": {
  ""restaurantID"": 2455,
  ""timeZone"": {
    ""standardTimeOffsetInMinutesFromUTC"": -360,
    ""daylightSavingTimeOffsetInMinutesFromUTC"": -300,
    ""daylightSavingTimeBegins"": ""2022-03-13T07:00:00Z"",
    ""daylightSavingTimeEnds"": ""2022-11-06T07:00:00Z""
  },
  ""activeChannels"": {
    ""COATES_IDMB"": {
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP""
      }
    },
    ""COATES_ODMB"": {
      ""priceCode"": ""TAKEOUT"",
      ""pointOfDistribution"": ""DRIVE_THRU"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""DRIVETHRU"": ""DRIVETHRU""
      }
    },
    ""GMA_DELIVERY"": {
      ""priceCode"": ""OTHER"",
      ""pointOfDistribution"": ""DELIVERY"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""DELIVERY"": ""DELIVERY""
      },
      ""podInfo"": {
        ""DELIVERY"": {
          ""podName"": ""FOE9901"",
          ""pod"": 3,
          ""remPod"": 3,
          ""type"": 2
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true,
        ""orderValueLimit"": 150,
        ""orderItemLimit"": 15
      }
    },
    ""GMA_EATIN"": {
      ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP"",
        ""TABLESERVICE"": ""TABLESERVICE""
      },
      ""podInfo"": {
        ""PICKUP"": {
          ""podName"": ""FOE0018"",
          ""pod"": 0,
          ""remPod"": 0,
          ""type"": 0
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true,
        ""orderValueLimit"": 100,
        ""orderItemLimit"": 10
      }
    },
    ""GMA_PICKUP"": {
      ""priceCode"": ""TAKEOUT"",
      ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""CURBSIDE"": ""CURBSIDE"",
        ""DRIVETHRU"": ""DRIVETHRU"",
        ""LOBBY"": ""PICKUP""
      },
      ""podInfo"": {
        ""DRIVETHRU"": {
          ""podName"": ""FOE0019"",
          ""pod"": 1,
          ""remPod"": 1,
          ""type"": 1
        },
        ""CURBSIDE"": {
          ""podName"": ""FOE0018"",
          ""pod"": 2,
          ""remPod"": 2,
          ""type"": 1
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true,
        ""orderValueLimit"": 100,
        ""orderItemLimit"": 10
      }
    },
    ""GMAL_DELIVERY"": {
      ""priceCode"": ""OTHER"",
      ""pointOfDistribution"": ""DELIVERY"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""DELIVERY"": ""DELIVERY"",
        ""ORDERAHEADLANE"": ""ORDERAHEADLANE""
      },
      ""podInfo"": {
        ""DELIVERY"": {
          ""podName"": ""FOE9901"",
          ""pod"": 3,
          ""remPod"": 3,
          ""type"": 2
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true,
        ""orderValueLimit"": 140,
        ""orderItemLimit"": 14
      }
    },
    ""GMAL_EATIN"": {
      ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""LOBBY"": ""PICKUP"",
        ""LOBBY_FAMILY"": ""PICKUP|KS1"",
        ""LOBBY_SINGLE"": ""PICKUP|KS2"",
        ""TABLESERVICE"": ""TABLESERVICE"",
        ""TABLESERVICE_FAMILY"": ""TABLESERVICE|KS1"",
        ""TABLESERVICE_SINGLE"": ""TABLESERVICE|KS2""
      },
      ""podInfo"": {
        ""PICKUP"": {
          ""podName"": ""FOE0018"",
          ""pod"": 0,
          ""remPod"": 0,
          ""type"": 0
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true
      }
    },
    ""GMAL_PICKUP"": {
      ""priceCode"": ""TAKEOUT"",
      ""pointOfDistribution"": ""PICKUP"",
      ""eligibleStoreAreasToRestaurantFulfillmentFlowMapping"": {
        ""CURBSIDE"": ""CURBSIDE"",
        ""DRIVETHRU"": ""DRIVETHRU"",
        ""LOBBY"": ""PICKUP"",
        ""LOBBY_FAMILY"": ""PICKUP|KS1"",
        ""LOBBY_SINGLE"": ""PICKUP|KS2"",
        ""ORDERAHEADLANE"": ""ORDERAHEADLANE""
      },
      ""podInfo"": {
        ""DRIVETHRU"": {
          ""podName"": ""FOE0019"",
          ""pod"": 1,
          ""remPod"": 1,
          ""type"": 1
        },
        ""CURBSIDE"": {
          ""podName"": ""FOE0018"",
          ""pod"": 2,
          ""remPod"": 2,
          ""type"": 1
        }
      },
      ""validationOverrides"": {
        ""outageValidation"": true,
        ""timeOfTheDayValidation"": true
      }
    }
  },
  ""foe"": {
    ""urls"": [
      ""http://foeemulator-dev01-us.dev.us-east-1.dev.digitalecp.mcd.com/US/24/2455""
    ]
  },
  ""marketConfigurationOverrides"": {
    ""PaymentProvider.Adyen.MerchantId"": ""MCD_US_2455""
  }
}
            }";
            await empheralPubSub.Publish("V1:RestaurantConfigurationInvalidationEvent", message);
        }
    }

}

