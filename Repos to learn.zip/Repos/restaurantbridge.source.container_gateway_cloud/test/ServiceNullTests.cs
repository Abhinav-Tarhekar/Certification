﻿using Common;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;


namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    public class ServiceNullTests
    {
        private RestaurantBridge.Gateway.Cloud.Services.Service _service;

        //public async Task<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined> RestaurantCombinedTestDataAsync()
        //{
        //    var restaurantCombinedJson = JsonConvert.DeserializeObject<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantCombined>(await File.ReadAllTextAsync($"data/error/RestaurantCombined.json"));
        //    return restaurantCombinedJson;
        //}
        public async Task<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings> RestaurantSettingsTestDataAsync()
        {
            var restaurantSettingsJson = JsonConvert.DeserializeObject<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings>(await File.ReadAllTextAsync($"data/error/RestaurantSettings.json"));
            return restaurantSettingsJson;
        }
        public async Task<RestaurantBridge.RestaurantConfiguration.V1.Models.RestaurantConfiguration> RestaurantConfigurationTestDataAsync()
        {
            var restaurantConfigurationJson = JsonConvert.DeserializeObject<RestaurantBridge.RestaurantConfiguration.V1.Models.RestaurantConfiguration>(await File.ReadAllTextAsync($"data/error/RestaurantConfiguration.json"));
            return restaurantConfigurationJson;
        }

        public async Task<V1.Models.RestaurantState> GetRestaurantStateTestDataAsync()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<V1.Models.RestaurantState>(await File.ReadAllTextAsync($"data/error/RestaurantState.json"));
            return restaurantStateJson;
        }

        public async Task<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails> RestaurantDetailsTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails>(await File.ReadAllTextAsync($"data/error/RestaurantDetails.json"));
            return restaurantDetailsJson;
        }

        public async Task<List<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantPromotion>> RestaurantPromotionsTestDataAsync()
        {
            var restaurantPromotionsJson = JsonConvert.DeserializeObject<List<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantPromotion>>(await File.ReadAllTextAsync($"data/error/RestaurantPromotions.json"));
            return restaurantPromotionsJson;
        }

        [SetUp]
        public async Task Initialize()
        {
            var etag = new RestaurantCombined.ETag();
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _logger = new Mock<ILog>();

            _service = new RestaurantBridge.Gateway.Cloud.Services.Service(
               _logger.Object, 
               _restaurantConfiguration.Object,
               _cacheParsedPromotions.Object,
               _cacheParsedSettings.Object,
               _cacheParsedDetails.Object,
               _restaurantMonitor.Object,
               _cacheParsedChannelMenus.Object);


            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "PROMOTIONS" };
            var result = await _service.GetRestaurantCombinedAsync(etag, It.IsAny<long>(), filterApis, new CancellationToken { });

            var restaurantSettings = await RestaurantSettingsTestDataAsync();

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                           .ReturnsAsync((restaurantSettings, eTag));



            var restaurantConfiguration = await RestaurantConfigurationTestDataAsync();
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { }))
                                      .ReturnsAsync((restaurantConfiguration, eTag));


            var restaurantDetails = await RestaurantDetailsTestDataAsync();
            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                          .ReturnsAsync((restaurantDetails, eTag));

            var restaurantState = await GetRestaurantStateTestDataAsync();
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync((restaurantState));

            var restaurantPromotions = await RestaurantPromotionsTestDataAsync();
            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { }))
                .ReturnsAsync((restaurantPromotions, eTag));
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedApiNullAsyncTest(long restaurantID)
        {
            var eTag = new RestaurantCombined.ETag();
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "PROMOTIONS", "STATE" };
            var result = await _service.GetRestaurantCombinedAsync(eTag, restaurantID, filterApis);
            Assert.IsNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedV2ApiNullAsyncTest(long restaurantID)
        {
            var eTag = new RestaurantCombinedV2.ETag();
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "STATE" };
            var result = await _service.GetRestaurantCombinedV2Async(eTag, restaurantID, filterApis);
            Assert.IsNull(result);
        }

    }
}
