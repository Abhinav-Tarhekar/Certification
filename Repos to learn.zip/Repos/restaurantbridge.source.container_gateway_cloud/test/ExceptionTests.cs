using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.Services.Exceptions;
using RestaurantBridge.Gateway.Cloud.V1;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    public class ExceptionTests
    {
        APIController apiController;
        ProductsSpecifiedCache productsSpecifiedCache;


        #region"Initialization Not Found Exception"
        public async Task InitializeNotFoundException()
        {
            var eTag = (string)null;

            var _logger = new Mock<ILog>();            
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();

            apiController = new APIController
               (
                _logger.Object,               
                _service.Object,
                _productsSpecifiedCache.Object,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            // var restaurantIDs = null;

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<string>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).ReturnsAsync((null, eTag));

            //var restaurantState = await GetRestaurantStateTestDataAsync();

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { }));

            #region Restaurant Details

            //var restIDs = await RestIDsTestDataAsync();

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { }));

            // var restaurantDetails = await RestaurantDetailsTestDataAsync();

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { }));

            #endregion

            #region Restaurant Settings

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Restaurant Configuration

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(),null, null, new CancellationToken { }));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { }));
            #endregion

            #region Restaurant Menus

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { }));

            //_cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>())).ReturnsAsync(eTag);
            #endregion

            #region Restaurant Menus Categories

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { }));

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { }));
            #endregion

            #region Restaurant Products

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));
            //  _cacheParsedProducts.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<int>>(It.IsAny<string>(), It.IsAny<long>())).ReturnsAsync(restaurantProductIDs, eTag);

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsGZIPAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { }));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { }));

            //  var restaurantProducts = await RestaurantProductsTestDataAsync();

            //byte[] dataGZIP;
         
            //  var restaurantProductsSpecified = await RestaurantProductsSpecifiedTestDataAsync();
            _productsSpecifiedCache.Setup(x => x.GetSingleAsync(It.IsAny<long>(), It.IsAny<int>()));

            #endregion

            #region Restaurant Promotion

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionIDsAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { }));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { }));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<HashSet<int>>(), It.IsAny<bool?>(), new CancellationToken { }));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsETagAsync(It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { }));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { }));


            #endregion
            #region Restaurant Combined
                _service.Setup(s => s.GetRestaurantCombinedAsync(It.IsAny<RestaurantCombined.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { }));
            #endregion

        }

        #endregion


        #region"Initialization Bad Gateway Exception"
        public async Task InitializeBadGatewayException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();            
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();

            apiController = new APIController
               (
                _logger.Object,                
                _service.Object,
                _productsSpecifiedCache.Object,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<string>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception("Error"));

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new Exception("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            #endregion

            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { })).Throws(new Exception("Error"));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(),new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Restaurant Menus
            //_cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenu>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>())).Throws(new Exception("Error"));

            #endregion

            #region Restaurant Menus Categories

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>(),new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(), It.IsAny<int?>(),new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

            #region Restaurant Products

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>() ,new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<int>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsGZIPAsync(It.IsAny<string>(),It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(),new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception("Error"));

            _productsSpecifiedCache.Setup(x => x.GetMultipleAsync(It.IsAny<long>(), It.IsAny<HashSet<int>>())).Throws(new Exception("Error"));

            _productsSpecifiedCache.Setup(x => x.GetSingleAsync(It.IsAny<long>(), It.IsAny<int>())).Throws(new Exception("Error"));
            #endregion

            #region Restaurant Promotion

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionIDsAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(),new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<HashSet<int>>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsETagAsync(It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new Exception("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { })).Throws(new Exception("Error"));

            #endregion
            #region Restaurant Combined
                _service.Setup(s => s.GetRestaurantCombinedAsync(It.IsAny<RestaurantCombined.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception("Error"));
            #endregion

        }
        #endregion


        #region"Initialization Request Timeout Exception"
        public async Task InitializeRequestTimeoutException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();
          
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();

            apiController = new APIController
               (
                _logger.Object,               
                _service.Object,
                _productsSpecifiedCache.Object,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<string>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new RequestTimeoutException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            #endregion

            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Menus
            //  _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenu>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>())).Throws(new RequestTimeoutException("Error"));

            #endregion

            #region Restaurant Menus Categories

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Products

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<int>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsGZIPAsync(It.IsAny<string>(),It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _productsSpecifiedCache.Setup(x => x.GetMultipleAsync(It.IsAny<long>(), It.IsAny<HashSet<int>>())).Throws(new RequestTimeoutException("Error"));

            _productsSpecifiedCache.Setup(x => x.GetSingleAsync(It.IsAny<long>(), It.IsAny<int>())).Throws(new RequestTimeoutException("Error"));
            #endregion

            #region Restaurant Promotion

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionIDsAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<HashSet<int>>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsETagAsync(It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));

            #endregion
            #region Restaurant Combined
                 _service.Setup(s => s.GetRestaurantCombinedAsync(It.IsAny<RestaurantCombined.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new RequestTimeoutException("Error"));
            #endregion

        }
        #endregion


        #region"Initialization Circuit Breaker Open Exception"
        public async Task InitializeCircuitBreakerOpenException()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();            
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();
            var _productsSpecifiedCache = new Mock<IProductsSpecifiedCache>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();

            apiController = new APIController
               (
                _logger.Object,                
                _service.Object,
                _productsSpecifiedCache.Object,
                _restaurantConfiguration.Object,
                _restaurantMonitor.Object,
                _cacheParsedPromotions.Object,
                _cacheParsedProductOutages.Object,
                _cacheParsedProducts.Object,
                _cacheParsedMenuCategories.Object,
                _cacheParsedSettings.Object,
                _cacheParsedDetails.Object
               );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<string>(), It.IsAny<HashSet<string>>(),new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            #region Restaurant Details
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
            .Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedDetails.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            #endregion

            #region Restaurant Settings
            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Restaurant Configuration
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(), null, null, new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _restaurantConfiguration.Setup(x => x.GetRestaurantConfigurationETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Restaurant Menus
            //_cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenu>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>())).Throws(new CircuitBreakerOpenException("Error"));

            #endregion

            #region Restaurant Menus Categories

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<V1.Models.RestaurantMenuCategory>>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedMenuCategories.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(), It.IsAny<int?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Restaurant Products

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<int>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsAsync(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedProductOutages.Setup(x => x.GetRestaurantProductOutagesETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductIDsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsGZIPAsync(It.IsAny<string>(),It.IsAny<long>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _productsSpecifiedCache.Setup(x => x.GetMultipleAsync(It.IsAny<long>(), It.IsAny<HashSet<int>>())).Throws(new CircuitBreakerOpenException("Error"));

            _productsSpecifiedCache.Setup(x => x.GetSingleAsync(It.IsAny<long>(), It.IsAny<int>())).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

            #region Restaurant Promotion

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionIDsAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsSpecified_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<HashSet<int>>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotionsETagAsync(It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotion_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<int>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));

            #endregion
            #region Restaurant Combined
            _service.Setup(s => s.GetRestaurantCombinedAsync(It.IsAny<RestaurantCombined.ETag>(), It.IsAny<long>(), It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new CircuitBreakerOpenException("Error"));
            #endregion

        }
        #endregion


        #region "Product Specified Cache"

        public async Task InitializeProductSpecifiedCache()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            var _logger = new Mock<ILog>();
            var _eventsManager = new Mock<EventsManager>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            int cacheWriteLockAutoReleaseTimeInMs = new int();
            int cacheWriteLockTakeRetryDelayInMs = new int();
            int cacheTimeToLiveInMs = new int();

            var productsSpecifiedCache = new ProductsSpecifiedCache
               (
                _logger.Object,
                _eventsManager.Object,
                _iStringKeyHashStore.Object,
                _iResourceLock.Object,
                _cacheParsedProducts.Object,
                cacheWriteLockAutoReleaseTimeInMs,
                cacheWriteLockTakeRetryDelayInMs,
                cacheTimeToLiveInMs
                );

            var context = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext()
            };

            apiController.ControllerContext = context;

            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(eTag);
        }

        #endregion


        #region "Test Cases"
        #region "RestaurantIDs"
        [Test]
        [TestCase(true, "ABC")]
        public async Task RestaurantIDsBadGatewayAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(true, "ABC")]
        public async Task RestaurantIDsRequestTimeoutAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(true, "ABC")]
        public async Task RestaurantIDsCircuitBreakerOpenAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(true, "ABC")]
        public async Task RestaurantIDsNotFoudnAsyncTest(bool? isActiveForOrdering, string IF_NONE_MATCH)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantIDsAsync(isActiveForOrdering, IF_NONE_MATCH);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        #endregion

        #region "Restaurant State"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantStateNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantStateAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }
        #endregion

        #region "Restaurant Details"

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }


        [Test]
        [TestCase(2455)]

        public async Task RestaurantDetailsHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantDetailsHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantDetailsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }



        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }


        [Test]
        [TestCase(2455)]

        public async Task RestaurantDetailsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantDetailsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantDetailsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantDetailsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase("IF_NONE_MATCH")]

        public async Task RestaurantDetailsAllBadGatewayAsyncTest(string IF_NONE_MATCH = null)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantDetailsAll();
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase()]

        public async Task RestaurantDetailsAllRequestTimeoutAsyncTest()
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantDetailsAll();
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase()]
        public async Task RestaurantDetailsAllCircuitBreakerOpenAsyncTest()
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantDetailsAll();
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        #endregion

        #region "Restaurant Setings"


        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantSettingsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantSettingsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantSettingsHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantSettingHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion

        #region "Restaurant Configuration"

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }


        [Test]
        [TestCase(2455)]

        public async Task RestaurantConfigurationBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantConfigurationRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantConfigurationAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantConfigurationHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantConfigurationHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantConfigurationHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion

        #region "Restaurant Menus"

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantMenusAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantConfigurationHeadNotFoudnAsyncTest(long restaurantID, int menuID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantMenuBadGatewayAsyncTest(long restaurantID, int menuID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantMenuRequestTimeoutAsyncTest(long restaurantID, int menuID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantMenuCircuitBreakerOpenAsyncTest(long restaurantID, int menuID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantMenuAsync(restaurantID, menuID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        #endregion

        #region "Restaurant Menus Categories"

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }


        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantMenusCategoriesAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesHeadNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantMenusCategoriesHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantMenusCategoriesHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantMenusCategoriesHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantMenusCategoriesHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantMenusCategoriesHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }
        #endregion

        #region "Restaurant Products"
        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantMenusCategoriesNotFoudnAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantMenusCategoriesBadGatewayAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantMenusCategoriesRequestTimeoutAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, null, true)]
        public async Task RestaurantMenusCategoriesCircuitBreakerOpenAsyncTest(long restaurantID, int? categoryID, bool OUTAGE)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductIDsAsync(restaurantID, categoryID, OUTAGE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductOutageIDsHeadNotFoudnAsyncTest(long restaurantID, int? categoryID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductOutageIDsHeadBadGatewayAsyncTest(long restaurantID, int? categoryID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductOutageIDsHeadRequestTimeoutAsyncTest(long restaurantID, int? categoryID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductOutageIDsHeadCircuitBreakerOpenAsyncTest(long restaurantID, int? categoryID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductOutageIDsHeadAsync(restaurantID, categoryID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantProductsHeadBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]

        public async Task RestaurantProductsHeadRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsHeadCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductsHeadAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantProductsNotFoudnAsyncTest(long restaurantID)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantProductsAsync(restaurantID);
            //var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            //Assert.AreEqual(404, statusCode);
            Assert.NotNull(result);
        }


        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductsSpecifiedBadGatewayAsyncTest(long restaurantID, HashSet<int> productIDs)
        {
            productIDs = new HashSet<int>(){ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductsSpecifiedAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductsSpecifiedRequestTimeoutAsyncTest(long restaurantID, HashSet<int> productIDs)
        {
            productIDs = new HashSet<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductsSpecifiedAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductsSpecifiedCircuitBreakerOpenAsyncTest(long restaurantID, HashSet<int> productIDs)
        {
            productIDs = new HashSet<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductsSpecifiedAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantProductsSpecifiedNotFoudnAsyncTest(long restaurantID, HashSet<int> productIDs)
        {
            productIDs = new HashSet<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantProductsSpecifiedAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }



        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductBadGatewayAsyncTest(long restaurantID, int productIDs)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductRequestTimeoutAsyncTest(long restaurantID, int productIDs)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductCircuitBreakerOpenAsyncTest(long restaurantID, int productIDs)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task RestaurantProductSpecifiedNotFoudnAsyncTest(long restaurantID, int productIDs)
        {
            InitializeNotFoundException();
            var result = await apiController.GetRestaurantProductAsync(restaurantID, productIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result).StatusCode;
            Assert.AreEqual(404, statusCode);
        }

        #endregion

        #region "Restaurant Promotions"
        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionIDsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantPromotionIDsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionIDsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantPromotionIDsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionIDsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantPromotionIDsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionsBadGatewayAsyncTest(long restaurantID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantPromotionsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionsRequestTimeoutAsyncTest(long restaurantID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantPromotionsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantPromotionsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantPromotionsAsync(restaurantID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionsSpecifiedBadGatewayAsyncTest(long restaurantID, HashSet<int> promotionIDs)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantPromotionsSpecifiedAsync(restaurantID, promotionIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionsSpecifiedRequestTimeoutAsyncTest(long restaurantID, HashSet<int> promotionIDs)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantPromotionsSpecifiedAsync(restaurantID, promotionIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionsSpecifiedCircuitBreakerOpenAsyncTest(long restaurantID, HashSet<int> promotionIDs)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantPromotionsSpecifiedAsync(restaurantID, promotionIDs);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }


        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionBadGatewayAsyncTest(long restaurantID, int promotionID)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantPromotionAsync(restaurantID, promotionID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionRequestTimeoutAsyncTest(long restaurantID, int promotionID)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantPromotionAsync(restaurantID, promotionID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, null)]
        public async Task RestaurantPromotionCircuitBreakerOpenAsyncTest(long restaurantID, int promotionID)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantPromotionAsync(restaurantID, promotionID);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task GetRestaurantPromotionsHeadBadGatewayAsyncTest(long restaurantID, [FromQuery] bool? ADVERTISABLE = null)
        {
            InitializeBadGatewayException();
            var result = await apiController.GetRestaurantPromotionsHeadAsync(restaurantID, ADVERTISABLE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(502, statusCode);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task GetRestaurantPromotionsHeadRequestTimeoutAsyncTest(long restaurantID, [FromQuery] bool? ADVERTISABLE = null)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantPromotionsHeadAsync(restaurantID, ADVERTISABLE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(504, statusCode);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task GetRestaurantPromotionsHeadCircuitBreakerOpenAsyncTest(long restaurantID, [FromQuery] bool? ADVERTISABLE = null)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantPromotionsHeadAsync(restaurantID, ADVERTISABLE);
            var statusCode = ((Microsoft.AspNetCore.Mvc.ObjectResult)result).StatusCode;
            Assert.AreEqual(503, statusCode);
        }



        #endregion
        #region Restaurant Combined
        #region V1
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantV1TimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantCombinedAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(504, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantV1CruitBreakAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetRestaurantCombinedAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(503, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantV1BadGatewayAsyncTest(long restaurantID)
        {
            await InitializeBadGatewayException();
            var result = await apiController.GetRestaurantCombinedAsync(restaurantID);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(502, statusCode.StatusCode);
        }
        [Test]
        [TestCase(2455)]
        public async Task CombinedRestaurantV1NotFoundAsyncTest(long restaurantID)
        {
            await InitializeNotFoundException();
            var result = await apiController.GetRestaurantCombinedAsync(restaurantID);
            var statusCode1 = ((StatusCodeResult)result.Result).StatusCode;
            Assert.AreEqual(404, statusCode1);
        }
        #endregion
        #endregion



        #endregion
    }
}
