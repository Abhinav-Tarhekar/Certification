﻿using Common;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Common.GeoLocationIndex;
using RestaurantBridge.Gateway.Cloud.Services;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{

    //[TestFixture]
    public class RestaurantSearchIndexTests
    {
        RestaurantSearchIndex restaurantSearch;

        #region Test Data
        //For Search Restaurants API
        public async Task<List<SearchedDetails>> SearchRestaurantsTestDataAsync()
        {
            var searchedDetailsJson = JsonConvert.DeserializeObject<List<SearchedDetails>>(await File.ReadAllTextAsync($"data/default/SearchRestaurants.json"));
            
            return searchedDetailsJson;
        }
        //Restaurant Details
        public async Task<IEnumerable<long>> RestIDsTestDataAsync()
        {
            var restaurantIDsJson = JsonConvert.DeserializeObject<IEnumerable<long>>(await File.ReadAllTextAsync($"data/default/RestaurantIDs.json"));
            return restaurantIDsJson;
        }
        public List<Details> SearchRestaurantTestDataAsync()
        {
            var searchedDetailsJson = JsonConvert.DeserializeObject<List<Details>>(File.ReadAllText($"data/default/SearchRestaurants.json"));
            return searchedDetailsJson;
        }

        #endregion

        #region Initialization
        [SetUp]
        public async Task Initialize()
        {
            string eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            Dictionary<long, Details> detailsLookup = new Dictionary<long, Details>();
            Dictionary<long, Details> _details = new Dictionary<long, Details>();
            GeoLocationIndex<Details> geoLocationIndex = new GeoLocationIndex<Details>();
            GeoLocationIndex<Details> _geoLocationIndex = new GeoLocationIndex<Details>();

            var _logger = new Mock<ILog>();
            var _eventsManager = new Mock<EventsManager>(null, null, null, null, null, null, null, null);
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
          

            restaurantSearch = new RestaurantSearchIndex(
                            _logger.Object,
                            _eventsManager.Object,
                            _restaurantConfiguration.Object,
                            _cacheParsedDetails.Object);
            
            var restIDs = RestIDsTestDataAsync();
            
            _restaurantConfiguration.Setup(p => p.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Returns(restIDs);

            var restDetails = SearchRestaurantTestDataAsync();

            foreach (var item in restDetails)
                _cacheParsedDetails.Setup(d => d.GetRestaurantDetails_DESERIALIZE_AS_Async<Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((item, eTag));

            foreach (var restItem in restDetails)
                _details.Add(restItem.restaurantID, restItem);

            detailsLookup = new Dictionary<long,Details>(_details);

            var singleRestDetails = restDetails.LastOrDefault();
            _geoLocationIndex.Add(singleRestDetails.latitude, singleRestDetails.longitude, singleRestDetails);

           await restaurantSearch.InitializeAsync();
            await restaurantSearch.ReInitializeAsync();
        }
        public async Task Initialize2()
        {
            string eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";

            Dictionary<long, Details> detailsLookup = new Dictionary<long, Details>();
            Dictionary<long, Details> _details = new Dictionary<long, Details>();
            GeoLocationIndex<Details> geoLocationIndex = new GeoLocationIndex<Details>();
            GeoLocationIndex<Details> _geoLocationIndex = new GeoLocationIndex<Details>();

            var _logger = new Mock<ILog>();
            var _eventsManager = new Mock<EventsManager>(null, null, null, null, null, null, null, null);
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();

            restaurantSearch = new RestaurantSearchIndex(
                            _logger.Object,
                            _eventsManager.Object,
                            _restaurantConfiguration.Object,
                            _cacheParsedDetails.Object);
            _restaurantConfiguration.Setup(x => x.GetRestaurantIDsAsync(It.IsAny<HashSet<string>>(), new CancellationToken { })).Throws(new Exception());
            var restDetails = SearchRestaurantTestDataAsync();

            foreach (var item in restDetails)
                _cacheParsedDetails.Setup(d => d.GetRestaurantDetails_DESERIALIZE_AS_Async<Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { })).ReturnsAsync((item, eTag));

            foreach (var restItem in restDetails)
                _details.Add(restItem.restaurantID, restItem);

            detailsLookup = new Dictionary<long, Details>(_details);

            var singleRestDetails = restDetails.LastOrDefault();
            _geoLocationIndex.Add(singleRestDetails.latitude, singleRestDetails.longitude, singleRestDetails);

            await restaurantSearch.InitializeAsync();
            await restaurantSearch.ReInitializeAsync();
        }
        #endregion

        #region Unit Test
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantsIDsAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs = new HashSet<long> { 2455 }, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID = 2455, marketID = "US", marketStoreID = 2455, latitude = 54.10, longitude = 84.19, maxDistanceInMeters = 5000, maxNumberOfRestaurantsToReturn = 10);
           
            Assert.AreEqual(2455, result[0].restaurantID);
        }
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantsIDsExceptionAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            await Initialize2();
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs = new HashSet<long> { 2455 }, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID = 2455, marketID = "US", marketStoreID = 2455, latitude = 54.10, longitude = 84.19, maxDistanceInMeters = 5000, maxNumberOfRestaurantsToReturn = 10);

            Assert.NotNull(result);
        }
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantsIDsObjectNullAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs = new HashSet<long> { 244,111 }, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID , marketID , marketStoreID , latitude , longitude , maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(0, result.Count);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID = 2455, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(2455, result[0].restaurantID);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantIDObjectNullAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID = 1111, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(0, result.Count);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByMarketIDandMarketStoreIDAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID, marketID = "US", marketStoreID = 2455, latitude , longitude , maxDistanceInMeters , maxNumberOfRestaurantsToReturn);

            Assert.AreEqual("US", result[0].marketID);
            Assert.AreEqual(2455, result[0].marketStoreID);
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByMarketIDandMarketStoreIDObjectNullAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs = new HashSet<string> { " " }, channels = new HashSet<string> { "" }, facilities = new HashSet<string> { "" }, restaurantID, marketID = "CA", marketStoreID = 2455, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(0, result.Count());
        }

        [Test]
        [TestCase(null, null, null, null, null, null, null, null, null, null, null)]
        public async Task SearchRestaurantsByMarketIDsAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs , channels, facilities, restaurantID, marketID, marketStoreID , latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(1, result.Count());
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByChannelsAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels = new HashSet<string> { "GMA_DELIVERY", "GMA_PICKUP" }, facilities = new HashSet<string> { "" }, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(1, result.Count());
        }

        [Test]
        [TestCase]
        public async Task SearchRestaurantsByFacilitiesAsyncTest(
            HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
            HashSet<string> channels = null, HashSet<string> facilities = null,
            long? restaurantID = null, string marketID = null,
            long? marketStoreID = null, double? latitude = null,
            double? longitude = null, double? maxDistanceInMeters = null,
            uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels , facilities = new HashSet<string> { "WI-FI", "24HR" }, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(1, result.Count());
        }
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByFacilitiesAsyncTestMax(
           HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
           HashSet<string> channels = null, HashSet<string> facilities = null,
           long? restaurantID = null, string marketID = null,
           long? marketStoreID = null, double? latitude = null,
           double? longitude = null, double? maxDistanceInMeters = null,
           uint? maxNumberOfRestaurantsToReturn = 10)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs, marketIDs, channels, facilities = new HashSet<string> { "WI-FI", "24HR" }, restaurantID, marketID, marketStoreID, latitude, longitude, maxDistanceInMeters, maxNumberOfRestaurantsToReturn);

            Assert.AreEqual(1, result.Count());
        }
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantsIDsAsyncTests(
           HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
           HashSet<string> channels = null, HashSet<string> facilities = null,
           long? restaurantID = null, string marketID = null,
           long? marketStoreID = null, double? latitude = null,
           double? longitude = null, double? maxDistanceInMeters = null,
           uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs = new HashSet<long> { 2455 }, marketIDs = new HashSet<string> { "US", "UK" }, channels = new HashSet<string> { "1", "2" }, facilities = new HashSet<string> { "" }, restaurantID = 2455, marketID = "US", marketStoreID = 2455, latitude = 54.10, longitude = 84.19, maxDistanceInMeters = 5000, maxNumberOfRestaurantsToReturn = 10);

            Assert.NotNull(result);
        }
        [Test]
        [TestCase]
        public async Task SearchRestaurantsByRestaurantsIDsAsyncTestsPartialConditions(
           HashSet<long> restaurantIDs = null, HashSet<string> marketIDs = null,
           HashSet<string> channels = null, HashSet<string> facilities = null,
           long? restaurantID = null, string marketID = null,
           long? marketStoreID = null, double? latitude = null,
           double? longitude = null, double? maxDistanceInMeters = null,
           uint? maxNumberOfRestaurantsToReturn = null)
        {
            var result = await restaurantSearch.SearchRestaurantsAsync(restaurantIDs = new HashSet<long> { 2455 }, marketIDs = new HashSet<string> { "UK" }, channels = new HashSet<string> { "1", "2" }, facilities = new HashSet<string> { "" }, restaurantID = 2455, marketID = "US", marketStoreID = 2455, latitude = 54.10, longitude = 84.19, maxDistanceInMeters = 5000, maxNumberOfRestaurantsToReturn = 10);

            Assert.NotNull(result);
        }

        #endregion

    }
}
