﻿using Common;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.API.V2.Models;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using RestaurantBridge.Gateway.Cloud.V2.Models;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;


namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    public class ServiceTests
    {
        private RestaurantBridge.Gateway.Cloud.Services.Service _service;

        public async Task<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings> RestaurantSettingsTestDataAsync()
        {
            var restaurantSettingsJson = JsonConvert.DeserializeObject<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings>(await File.ReadAllTextAsync($"data/default/RestaurantSettings.json"));
            return restaurantSettingsJson;
        }

        public async Task<RestaurantBridge.Gateway.Cloud.V2.Models.Settings> RestaurantSettingsV2TestDataAsync()
        {
            var restaurantSettingsJson = JsonConvert.DeserializeObject<V2.Models.Settings>(await File.ReadAllTextAsync($"data/default/RestaurantSettings.json"));
            return restaurantSettingsJson;
        }
        public async Task<RestaurantBridge.RestaurantConfiguration.V1.Models.RestaurantConfiguration> RestaurantConfigurationTestDataAsync()
        {
            var restaurantConfigurationJson = JsonConvert.DeserializeObject<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(await File.ReadAllTextAsync($"data/default/RestaurantConfiguration.json"));
            return restaurantConfigurationJson;
        }

        public async Task<RestaurantBridge.Gateway.Cloud.V2.Models.Configuration> RestaurantConfigurationV2TestDataAsync()
        {
            var restaurantConfigurationJson = JsonConvert.DeserializeObject<V2.Models.Configuration>(await File.ReadAllTextAsync($"data/default/RestaurantConfiguration.json"));
            return restaurantConfigurationJson;
        }

        public async Task<V1.Models.RestaurantState> GetRestaurantStateTestDataAsync()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<V1.Models.RestaurantState>(await File.ReadAllTextAsync($"data/default/RestaurantState.json"));
            return restaurantStateJson;
        }

        public async Task<V2.Models.ChannelMenus> GetRestaurantChannelMenusTestDataAsync()
        {
            var restaurantCMJson = JsonConvert.DeserializeObject<V2.Models.ChannelMenus>(await File.ReadAllTextAsync($"data/default/RestaurantChannelMenus.json"));
            return restaurantCMJson;
        }

        public async Task<V2.Models.State> GetRestaurantStateV2TestDataAsync()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<V2.Models.State>(await File.ReadAllTextAsync($"data/default/RestaurantState.json"));
            return restaurantStateJson;
        }

        public async Task<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails> RestaurantDetailsTestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails>(await File.ReadAllTextAsync($"data/default/RestaurantDetails.json"));
            return restaurantDetailsJson;
        }

        public async Task<V2.Models.Details> RestaurantDetailsV2TestDataAsync()
        {
            var restaurantDetailsJson = JsonConvert.DeserializeObject<V2.Models.Details>(await File.ReadAllTextAsync($"data/default/RestaurantDetails.json"));
            return restaurantDetailsJson;
        }

        public async Task<List<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantPromotion>> RestaurantPromotionsTestDataAsync()
        {
            var restaurantPromotionsJson = JsonConvert.DeserializeObject<List<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantPromotion>>(await File.ReadAllTextAsync($"data/default/RestaurantPromotions.json"));
            return restaurantPromotionsJson;
        }

        public async Task Initialize()
        {
            var etag = new RestaurantCombined.ETag();
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _logger = new Mock<ILog>();

            _service = new RestaurantBridge.Gateway.Cloud.Services.Service(
                _logger.Object,
              _restaurantConfiguration.Object,
              _cacheParsedPromotions.Object,
              _cacheParsedSettings.Object,
              _cacheParsedDetails.Object,
              _restaurantMonitor.Object,
               _cacheParsedChannelMenus.Object);


            var restaurantSettings = await RestaurantSettingsTestDataAsync();

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                           .ReturnsAsync((restaurantSettings, eTag));

            var restaurantConfiguration = await RestaurantConfigurationTestDataAsync();
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantConfiguration.V1.Models.RestaurantConfiguration>(It.IsAny<string>(), It.IsAny<long>(), null,null, new CancellationToken { }))
                                      .ReturnsAsync((restaurantConfiguration, eTag));


            var restaurantDetails = await RestaurantDetailsTestDataAsync();
            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantDetails>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                          .ReturnsAsync((restaurantDetails, eTag));

            var restaurantState = await GetRestaurantStateTestDataAsync();
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantState>(It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync((restaurantState));

            var restaurantPromotions = await RestaurantPromotionsTestDataAsync();
            _cacheParsedPromotions.Setup(x => x.GetRestaurantPromotions_DESERIALIZE_AS_Async<V1.Models.RestaurantPromotion>(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool?>(), new CancellationToken { }))
                .ReturnsAsync((restaurantPromotions, eTag));
        }

        public async Task InitializeV2()
        {
            var etag = new RestaurantCombined.ETag();
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _logger = new Mock<ILog>();

            _service = new RestaurantBridge.Gateway.Cloud.Services.Service(
                _logger.Object,
              _restaurantConfiguration.Object,
              _cacheParsedPromotions.Object,
              _cacheParsedSettings.Object,
              _cacheParsedDetails.Object,
              _restaurantMonitor.Object,
              _cacheParsedChannelMenus.Object);


            var restaurantSettings = await RestaurantSettingsV2TestDataAsync();

            _cacheParsedSettings.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V2.Models.Settings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                           .ReturnsAsync((restaurantSettings, eTag));

            var restaurantConfiguration = await RestaurantConfigurationV2TestDataAsync();
            _restaurantConfiguration.Setup(x => x.GetRestaurantConfiguration_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V2.Models.Configuration>(It.IsAny<string>(), It.IsAny<long>(), null,null, new CancellationToken { }))
                                      .ReturnsAsync((restaurantConfiguration, eTag));


            var restaurantDetails = await RestaurantDetailsV2TestDataAsync();
            _cacheParsedDetails.Setup(x => x.GetRestaurantDetails_DESERIALIZE_AS_Async<V2.Models.Details>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                          .ReturnsAsync((restaurantDetails, eTag));

            var restaurantState = await GetRestaurantStateV2TestDataAsync();
            _restaurantMonitor.Setup(x => x.GetRestaurantState_DESERIALIZE_AS_Async<V2.Models.State>(It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync((restaurantState));

            var restaurantChannelMenus = await GetRestaurantChannelMenusTestDataAsync();
            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync((restaurantChannelMenus, null));
        }

        public async Task InitializeProductLookupNullCase()
        {
            var etag = new RestaurantCombined.ETag();
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedChannelMenus = new Mock<Cache.ParsedChannelMenus.V1.IClientAdvanced>();
            var _logger = new Mock<ILog>();

            _service = new RestaurantBridge.Gateway.Cloud.Services.Service(
                _logger.Object,
              _restaurantConfiguration.Object,
              _cacheParsedPromotions.Object,
              _cacheParsedSettings.Object,
              _cacheParsedDetails.Object,
              _restaurantMonitor.Object,
              _cacheParsedChannelMenus.Object);

            _cacheParsedChannelMenus.Setup(x => x.GetRestaurantChannelMenus_DESERIALIZE_AS_Async<V2.Models.ChannelMenus>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync((null, null));
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedApiNotNullAsyncTest(long restaurantID)
        {
            await Initialize();
            var eTag = new RestaurantCombined.ETag();
            //var etag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "PROMOTIONS", "STATE" };
            var result = await _service.GetRestaurantCombinedAsync(eTag, restaurantID, filterApis);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Configuration);
            Assert.IsNotNull(result.Details);
            Assert.IsNotNull(result.Settings);
            Assert.IsNotNull(result.State);
            Assert.IsNotNull(result.Promotions);
            Assert.AreEqual(result.Configuration.foe.requestTimeoutInMillisecondsOverride, 90000);
            Assert.AreEqual(result.Configuration.foe.endpointVersionOverride, "1.2.3");

        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedNullAsyncTest(long restaurantID)
        {
            await Initialize();
            var eTag = new RestaurantCombined.ETag();
            //var etag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var filterApis = new HashSet<string>();
            var result = await _service.GetRestaurantCombinedAsync(eTag, restaurantID, filterApis);
            Assert.IsNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedApiV2NotNullAsyncTest(long restaurantID)
        {
            await InitializeV2();
            var eTag = new RestaurantCombinedV2.ETag();
            //var etag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "STATE" };
            var result = await _service.GetRestaurantCombinedV2Async(eTag, restaurantID, filterApis);
            Assert.IsNotNull(result.Configuration);
            Assert.IsNotNull(result.Details);
            Assert.IsNotNull(result.Settings);
            Assert.IsNotNull(result.State);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedV2NullAsyncTest(long restaurantID)
        {
            await InitializeV2();
            var eTag = new RestaurantCombinedV2.ETag();
            //var etag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var filterApis = new HashSet<string>();
            var result = await _service.GetRestaurantCombinedV2Async(eTag, restaurantID, filterApis);
            Assert.IsNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCombinedApiV2AsyncAttributesNotNullTest(long restaurantID)
        {
            await InitializeV2();
            var eTag = new RestaurantCombinedV2.ETag();
            //var etag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var filterApis = new HashSet<string> { "SETTINGS", "DETAILS", "CONFIGURATION", "STATE" };
            var result = await _service.GetRestaurantCombinedV2Async(eTag, restaurantID, filterApis);
            Assert.AreEqual(result.Configuration.foe.requestTimeoutInMillisecondsOverride, 90000);
            Assert.AreEqual(result.Configuration.foe.endpointVersionOverride, "1.2.3");
        }

        [Test]
        [TestCase(2455)]
        public async Task GetProductLookUpSuccessfulWithDisticntIdsTest(long restaurantID)
        {
            await InitializeV2();
            int[] productIDs = [1, 61, 107];
            var result = await _service.GetRestaurantProductLookupV2Async(restaurantID, productIDs);
            Assert.IsNotNull(result);
            Assert.AreEqual(6, result.channels.Count);
            Assert.AreEqual(3, result.channels["GMA_EATIN"].products.Count);
            Assert.AreEqual(3, result.channels["GMA_DELIVERY"].products.Count);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[1].ID);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].customizations);
            Assert.AreEqual(35, result.channels["GMA_DELIVERY"].products[1].customizations.Length);
            Assert.AreEqual(4200, result.channels["GMA_DELIVERY"].products[1].customizations[0].ID);
            Assert.AreEqual(ProductLookup.ProductDetails.Customizations.OptionType.QUANTITY, result.channels["GMA_DELIVERY"].products[1].customizations[0].type);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].customizations[0].Default);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].customizations[0].options);
            Assert.AreEqual(4, result.channels["GMA_DELIVERY"].products[1].customizations[0].options.Length);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0].Count);
            Assert.AreEqual(0, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0][0]);
            Assert.AreEqual(0, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0][1]);
            Assert.IsNull(result.channels["GMA_DELIVERY"].products[1].choices);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].localizations);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].localizations.Keys.Count);
            Assert.AreEqual("Hamburger", result.channels["GMA_DELIVERY"].products[1].localizations["en-US"].name);
            Assert.AreEqual("Hamburguesa", result.channels["GMA_DELIVERY"].products[1].localizations["es-US"].name);

            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[61].choices);
            Assert.AreEqual(10000005, result.channels["GMA_DELIVERY"].products[61].choices[0].ID);
            Assert.AreEqual(3, result.channels["GMA_DELIVERY"].products[61].choices[0].Defaults.Length);
            Assert.AreEqual(900, result.channels["GMA_DELIVERY"].products[61].choices[0].Defaults[0]);
            Assert.AreEqual(900, result.channels["GMA_DELIVERY"].products[61].choices[0].Defaults[1]);
            Assert.AreEqual(900, result.channels["GMA_DELIVERY"].products[61].choices[0].Defaults[2]);
            Assert.IsNull(result.channels["GMA_DELIVERY"].products[61].customizations);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[61].localizations);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[61].localizations.Keys.Count);
            Assert.AreEqual("20 McNuggets", result.channels["GMA_DELIVERY"].products[61].localizations["en-US"].name);
            Assert.AreEqual("McNuggets de 20 Piezas", result.channels["GMA_DELIVERY"].products[61].localizations["es-US"].name);

            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[107].choices);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[107].choices.Length);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[107].choices[0].Defaults.Length);
            Assert.AreEqual(1101, result.channels["GMA_DELIVERY"].products[107].choices[0].Defaults[0]);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[107].choices[1].Defaults.Length);
            Assert.AreEqual(35, result.channels["GMA_DELIVERY"].products[107].choices[1].Defaults[0]);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[107].localizations);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[107].localizations.Keys.Count);
            Assert.AreEqual("Big Breakfast", result.channels["GMA_DELIVERY"].products[107].localizations["en-US"].name);
            Assert.AreEqual("Big Breakfast", result.channels["GMA_DELIVERY"].products[107].localizations["es-US"].name);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetProductLookUpSuccessfulWithDupIdsTest(long restaurantID)
        {
            await InitializeV2();
            int[] productIDs = [1, 1, 107, 1234567];   // productCode of 1234567 doesn't exist, ignored
            var result = await _service.GetRestaurantProductLookupV2Async(restaurantID, productIDs);
            Assert.IsNotNull(result);
            Assert.AreEqual(6, result.channels.Count);

            Assert.AreEqual(2, result.channels["GMA_EATIN"].products.Count);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products.Count);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[1].ID);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].customizations);
            Assert.AreEqual(35, result.channels["GMA_DELIVERY"].products[1].customizations.Length);
            Assert.AreEqual(4200, result.channels["GMA_DELIVERY"].products[1].customizations[0].ID);
            Assert.AreEqual(ProductLookup.ProductDetails.Customizations.OptionType.QUANTITY, result.channels["GMA_DELIVERY"].products[1].customizations[0].type);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].customizations[0].Default);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].customizations[0].options);
            Assert.AreEqual(4, result.channels["GMA_DELIVERY"].products[1].customizations[0].options.Length);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0].Count);
            Assert.AreEqual(0, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0][0]);
            Assert.AreEqual(0, result.channels["GMA_DELIVERY"].products[1].customizations[0].options[0][1]);
            Assert.IsNull(result.channels["GMA_DELIVERY"].products[1].choices);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[1].localizations);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[1].localizations.Keys.Count);
            Assert.AreEqual("Hamburger", result.channels["GMA_DELIVERY"].products[1].localizations["en-US"].name);
            Assert.AreEqual("Hamburguesa", result.channels["GMA_DELIVERY"].products[1].localizations["es-US"].name);

            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[107].choices);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[107].choices.Length);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[107].choices[0].Defaults.Length);
            Assert.AreEqual(1101, result.channels["GMA_DELIVERY"].products[107].choices[0].Defaults[0]);
            Assert.AreEqual(1, result.channels["GMA_DELIVERY"].products[107].choices[1].Defaults.Length);
            Assert.AreEqual(35, result.channels["GMA_DELIVERY"].products[107].choices[1].Defaults[0]);
            Assert.IsNotNull(result.channels["GMA_DELIVERY"].products[107].localizations);
            Assert.AreEqual(2, result.channels["GMA_DELIVERY"].products[107].localizations.Keys.Count);
            Assert.AreEqual("Big Breakfast", result.channels["GMA_DELIVERY"].products[107].localizations["en-US"].name);
            Assert.AreEqual("Big Breakfast", result.channels["GMA_DELIVERY"].products[107].localizations["es-US"].name);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetProductLookUpNullTest(long restaurantID)
        {
            await InitializeProductLookupNullCase();
            int[] productIDs = [1, 107];
            var result = await _service.GetRestaurantProductLookupV2Async(restaurantID, productIDs);
            Assert.IsNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetProductLookUpNullProductIDsTest(long restaurantID)
        {
            await InitializeV2();
            int[] productIDs = [];
            var result = await _service.GetRestaurantProductLookupV2Async(restaurantID, productIDs);
            Assert.IsNull(result);
        }
    }
}
