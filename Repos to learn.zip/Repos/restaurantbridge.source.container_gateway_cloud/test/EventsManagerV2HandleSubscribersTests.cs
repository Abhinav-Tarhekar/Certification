﻿using Common;
using Common.RequestContext;
using McD.McFlow.Client.Library.Producer;
using Microsoft.AspNetCore.Http;
using Moq;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.API.Model;
using RestaurantBridge.Gateway.Cloud.Services;
using System;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;
using static RestaurantBridge.Gateway.Cloud.Services.EventsManager;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{

    [TestFixture]
    public class EventsManagerV2HandleSubscribersTests
    {
        private readonly IConfiguration configuration = new Mock<Configuration>().Object;
        private RestaurantBridge.Gateway.Cloud.Services.EventsManager _eventsManager;
        private TestingEmpheralPubSub empheralPubSub;
        private RestaurantMonitorEventHandler _restaurantMonitorEventHandler;
        private InvalidationEventArgs _invalidationEventArgs;

        Mock<WebSocket> _webSocket = new Mock<WebSocket>();
        Mock<IStringKeyValueStore> _stringKeyHashStore = new Mock<IStringKeyValueStore>();
        private IRequestContextItem _requestContextItem;
        private HttpContext _httpContext;
        private Mock<RestaurantMonitor.V1.IClientAdvanced> _restaurantMonitorClient;

        [SetUp]
        public async Task TestInitialize()
        {
            var logger = new Mock<ILog>();
            empheralPubSub = new TestingEmpheralPubSub();
        //    var stringKeyHashStore = new Mock<IStringKeyValueStore>();
            int beaconIntervalInMilliseconds = 30;

            _httpContext = Mock.Of<HttpContext>();
            _restaurantMonitorEventHandler = Mock.Of<RestaurantMonitorEventHandler>();
            //_invalidationEventArgs = Mock.Of<InvalidationEventArgs>();
            _invalidationEventArgs = new InvalidationEventArgs(It.IsAny<long>(), new CancellationToken());
            _requestContextItem = Mock.Of<IRequestContextItem>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            _stringKeyHashStore.Setup(x => x.ClearAsync(It.IsAny<string>())).Throws(new Exception());
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            var _resourceLock = new Mock<IResourceLock>().Object;
            _restaurantMonitorClient = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            _eventsManager = new EventsManager(
                logger.Object,
                empheralPubSub,
                configuration, 
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitorClient.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            await _eventsManager.InitializeAsync(Program.CancellationTokenSource.Token);
        }

        # region CurrentSubscribers
        [Test]
        public async Task CurrentsubscribeTest()
        {
            _eventsManager.CurrentSubscribers();
        }
        #endregion

        [Test]
        public async Task V1_HandleSubscribersAsyncOpenTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            _webSocket.SetupSequence(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(new WebSocketReceiveResult(1, WebSocketMessageType.Close, true)).Throws(new OperationCanceledException());

            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }

        [Test]
        public async Task V1_HandleSubscribersAsyncOpenExceptionTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            WebSocketReceiveResult result = null;
            _webSocket.SetupSequence(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(result).Throws(new Exception());

            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }

        [Test]
        public async Task V1_HandleSubscribersAsyncClosedTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Closed);
            _webSocket.Setup(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(new WebSocketReceiveResult(1, WebSocketMessageType.Close, true));
            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V1Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }

        [Test]
        public async Task V2_HandleSubscribersAsyncOpenTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            _webSocket.SetupSequence(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(new WebSocketReceiveResult(1, WebSocketMessageType.Close, true)).Throws(new OperationCanceledException());

            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V2Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }

        [Test]
        public async Task V2_HandleSubscribersAsyncOpenExceptionTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Open);
            WebSocketReceiveResult result = null;
            _webSocket.SetupSequence(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(result).Throws(new Exception());

            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V2Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }

        [Test]
        public async Task V2_HandleSubscribersAsyncClosedTest()
        {
            CancellationToken cancellationToken = new CancellationToken();

            _webSocket.Setup(x => x.State).Returns(WebSocketState.Closed);
            _webSocket.Setup(x => x.ReceiveAsync(It.IsAny<ArraySegment<byte>>(), It.IsAny<CancellationToken>())).ReturnsAsync(new WebSocketReceiveResult(1, WebSocketMessageType.Close, true));
            Mock<TaskCompletionSource<object>> socketFinishedTcs = new Mock<TaskCompletionSource<object>>();
            await _eventsManager.V2Manager.WebsocketManager.HandleSubscribersAsync(_httpContext, _webSocket.Object, socketFinishedTcs.Object, cancellationToken);
            Assert.IsTrue(true);
        }
    }
}

