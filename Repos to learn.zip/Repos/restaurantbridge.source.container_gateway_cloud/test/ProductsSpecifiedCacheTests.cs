﻿using Common;
using McD.McFlow.Client.Library.Producer;
using Moq;
using NUnit.Framework;
using RestaurantBridge.Common;
using RestaurantBridge.Gateway.Cloud.Services;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RestaurantBridge.Gateway.Cloud.UnitTest
{
    class ProductsSpecifiedCacheTests
    {
        IProductsSpecifiedCache _productsSpecifiedCache;
        EventsManager _eventsManager;

        [SetUp]
        public async Task Initialize()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _configuration = new Mock<IConfiguration>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _proxyPremiseNPOS61 = new Mock<Proxy.Premise.NPOS61.IClient>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            int cacheWriteLockTakeRetryDelayInMs = 10;
            int cacheTimeToLiveInMs = 10;
            var empheralPubSub = new Mock<IEmpheralPubSub>();
            var _stringKeyValueStore = new Mock<IStringKeyValueStore>();
            int beaconIntervalInMilliseconds = 30;
            var cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClient>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid());
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            var _resourceLock = new Mock<IResourceLock>().Object;
            _eventsManager = new EventsManager
               (
                _logger.Object,
                empheralPubSub.Object,
                configuration,
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitor.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs);

            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), default)).Returns(Task.FromResult(Guid.Empty));
            _productsSpecifiedCache = new ProductsSpecifiedCache(
                _logger.Object,
                _eventsManager,
                _iStringKeyHashStore.Object,
                _iResourceLock.Object,
                _cacheParsedProducts.Object,
                cacheWriteLockAutoReleaseTimeInMs,
                cacheWriteLockTakeRetryDelayInMs,
                cacheTimeToLiveInMs
                );
        }
        public async Task InitializeNew()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _configuration = new Mock<IConfiguration>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _proxyPremiseNPOS61 = new Mock<Proxy.Premise.NPOS61.IClient>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            int cacheWriteLockTakeRetryDelayInMs = 10;
            int cacheTimeToLiveInMs = 10;
            var empheralPubSub = new Mock<IEmpheralPubSub>();
            var _stringKeyValueStore = new Mock<IStringKeyValueStore>();
            int beaconIntervalInMilliseconds = 30;
            var cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClient>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid());
            var _resourceLock = new Mock<IResourceLock>().Object;
            _eventsManager = new EventsManager
               (
                _logger.Object,
                empheralPubSub.Object,
                configuration,
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitor.Object,
                _resourceLock,
                cacheWriteLockAutoReleaseTimeInMs
           );

            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), default)).Returns(Task.FromResult(Guid.Parse("12345678-1234-1234-1234-123456789012")));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("2455");
            _productsSpecifiedCache = new ProductsSpecifiedCache(
                _logger.Object,
                _eventsManager,
                _iStringKeyHashStore.Object,
                _iResourceLock.Object,
                _cacheParsedProducts.Object,
                cacheWriteLockAutoReleaseTimeInMs,
                cacheWriteLockTakeRetryDelayInMs,
                cacheTimeToLiveInMs
                );
        }
        public async Task InitializeNewDummy()
        {
            var eTag = "93cb5341aed10a59b71c66330b570de47a5f7362f02a8e88a2877028aa016d64";
            var _logger = new Mock<ILog>();
            var _configuration = new Mock<IConfiguration>();
            var _restaurantConfiguration = new Mock<RestaurantConfiguration.V1.IClientAdvanced>();
            var _restaurantMonitor = new Mock<RestaurantMonitor.V1.IClientAdvanced>();
            var _cacheParsedPromotions = new Mock<Cache.ParsedPromotions.V1.IClientAdvanced>();
            var _cacheParsedProductOutages = new Mock<Cache.ParsedProductOutages.V1.IClientAdvanced>();
            var _cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClientAdvanced>();
            var _cacheParsedMenuCategories = new Mock<Cache.ParsedMenuCategories.V1.IClientAdvanced>();
            var _cacheParsedSettings = new Mock<Cache.ParsedSettings.V1.IClientAdvanced>();
            var _cacheParsedDetails = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>();
            var _proxyPremiseNPOS61 = new Mock<Proxy.Premise.NPOS61.IClient>();
            var _iStringKeyHashStore = new Mock<IStringKeyHashStore>();
            var _iResourceLock = new Mock<IResourceLock>();
            int cacheWriteLockAutoReleaseTimeInMs = 10;
            int cacheWriteLockTakeRetryDelayInMs = 10;
            int cacheTimeToLiveInMs = 10;
            var empheralPubSub = new Mock<IEmpheralPubSub>();
            var _stringKeyValueStore = new Mock<IStringKeyValueStore>();
            int beaconIntervalInMilliseconds = 30;
            var cacheParsedProducts = new Mock<Cache.ParsedProducts.V1.IClient>();
            var _mcFlowProducer = new Mock<IMcFlowProducer<string, string>>().Object;
            var configuration = new Mock<IConfiguration>().Object;
            var _rbClientAdvanced = new Mock<Cache.ParsedDetails.V1.IClientAdvanced>().Object;
            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid());
            var _resourceLock = new Mock<IResourceLock>().Object;
            _eventsManager = new EventsManager
               (
                _logger.Object,
                empheralPubSub.Object,
                configuration,
                _mcFlowProducer,
                _rbClientAdvanced,
                _restaurantMonitor.Object,
                _resourceLock,
               cacheWriteLockAutoReleaseTimeInMs
           );

            _iResourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), default)).Returns(Task.FromResult(Guid.Parse("12345678-1234-1234-1234-123456789012")));
            _cacheParsedProducts.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).Throws(new Exception());
            _productsSpecifiedCache = new ProductsSpecifiedCache(
                _logger.Object,
                _eventsManager,
                _iStringKeyHashStore.Object,
                _iResourceLock.Object,
                _cacheParsedProducts.Object,
                cacheWriteLockAutoReleaseTimeInMs,
                cacheWriteLockTakeRetryDelayInMs,
                cacheTimeToLiveInMs
                );
        }

        #region "Test Cases"

        [Test]
        [TestCase("testing", 2455)]
        public async Task OnCachesClearElseAsyncTest(string eventName, long restaurantID)
        {
            await _productsSpecifiedCache.HelpAsync(eventName, restaurantID);
            Assert.IsTrue(true);
        }

        [Test]
        [TestCase(2455, 1)]
        public async Task GetSingleAsyncTest(long restaurantID, int productID)
        {
            await _productsSpecifiedCache.GetSingleAsync(restaurantID, productID);
            Assert.IsTrue(true);
        }
        [Test]
        [TestCase(2455, 1)]
        public async Task GetSingleAsyncNewTest(long restaurantID, int productID)
        {
            await InitializeNew();
            await _productsSpecifiedCache.GetSingleAsync(restaurantID, productID);
            Assert.IsTrue(true);
        }



        [Test]
        [TestCase(2455)]
        public async Task GetMultipleAsyncTest(long restaurantID)
        {
            HashSet<int> intTest = new HashSet<int>() { 1,2,3,4,5,6};
            await _productsSpecifiedCache.GetMultipleAsync(restaurantID, intTest);
            Assert.IsTrue(true);
        }
        [Test]
        [TestCase(2455)]
        public async Task GetMultipleExceptionAsyncTest(long restaurantID)
        {
            await InitializeNewDummy();
            HashSet<int> intTest = new HashSet<int>() { 1, 2, 3, 4, 5, 6 };
            await _productsSpecifiedCache.GetMultipleAsync(restaurantID, intTest);
            Assert.IsTrue(true);
        }
        [Test]
        [TestCase(2455,1)]
        public async Task GetSingleAsyncExceptionTest(long restaurantID, int productID)
        {
            await InitializeNewDummy();
            HashSet<int> intTest = new HashSet<int>() { 1, 2, 3, 4, 5, 6 };
            await _productsSpecifiedCache.GetSingleAsync(restaurantID, productID);
            Assert.IsTrue(true);
        }

        #endregion
    }
}
