#!/bin/bash

apk add mysql mysql-client

mysql --version