﻿using Common;
using RestaurantBridge.Gateway.Cloud.API.Monitoring.V1;
using RestaurantBridge.Gateway.Cloud.V1;

namespace GMACache.RestaurantCatalog
{
    public class CatalogMonitorEventsWorkerV1 : RestaurantMonitorEventsWorkerV1
    {
        public CatalogMonitorEventsWorkerV1(IClientAdvanced restaurantBridgeClient, ILog logger)
            : base(restaurantBridgeClient, logger)
        {
        }

        protected override string[] GetSubscribeList()
        {
            var eventsList = new string[]
           {
                Client.RestaurantEventMonitor.V1_CacheClear_Event,
                Client.RestaurantEventMonitor.V1_CacheReload_Event,
                Client.RestaurantEventMonitor.V1_Settings_Event,
                Client.RestaurantEventMonitor.V1_MenuCategories_Event,
                Client.RestaurantEventMonitor.V1_Products_Event
           };
            return eventsList;
        }
    }
}
