﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

using Common;
using StackExchange.Redis;

namespace GMACache.RestaurantCatalog
{
    public partial class Service
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetRestaurantCatalogKeyFor(long restaurantID) => $"{restaurantID}";

        private readonly ConcurrentDictionary<long, (byte[] gZippedContent, string eTag, bool isInvalidated)> _restaurantCatalogsResponseCache = new ConcurrentDictionary<long, (byte[], string, bool)>();

        private SemaphoreSlim _restaurantCatalogFillTaskLookupLock = new SemaphoreSlim(1, 1);
        // CONCURRENT DICTIONARY DOES NOT WORK AS GetOrAdd can call the add method in parallel :(
        private Dictionary<long, Task<(byte[] gZippedContent, string eTag, bool isInvalidated)>> _restaurantCatalogFillTaskLookup = new Dictionary<long, Task<(byte[], string, bool)>>();

        [ExcludeFromCodeCoverage]
        // since _cache_background_reload_while_serving_existing can't be set
        private async Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> GetRestaurantCatalogsThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            (byte[] gZippedContent, string eTag, bool isInvalidated) response;
            if (!_canUseCache && !_cache_background_reload_while_serving_existing)
            {
                Warn($"{restaurantID} : RESPONSE CACHE : can't use cache .. running in fallback mode ..");
                var data = await GetFromRedisOrBuildRestaurantCatalogsAsync(restaurantID, cancellationToken);
                return (data.gZippedContent, data.eTag, false);
            }

            if (_restaurantCatalogsResponseCache.TryGetValue(restaurantID, out response) && response.gZippedContent != null)
            {
                Debug($"{restaurantID} : RESPONSE CACHE : available => {response.eTag}{(response.isInvalidated ? ", INVALIDATED)" : "")}");
                if (response.isInvalidated)
                {
                    await ScheduleReloadCacheAsync("onInvalidatedCacheDetected", restaurantID, alreadyInvalidated: true);
                }
                return response;
            }

            response = await GetRestaurantCatalogsFromBuildAsync(restaurantID, cancellationToken);
            return response;
        }
        private async Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> GetRestaurantCatalogsFromBuildAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> fillTask = null;
            await _restaurantCatalogFillTaskLookupLock.WaitAsync(cancellationToken);
            try
            {
                if (!_restaurantCatalogFillTaskLookup.ContainsKey(restaurantID))
                {
                    _restaurantCatalogFillTaskLookup.Add(restaurantID, FillMemRestaturantCatalogResponseCacheAsync(restaurantID, cancellationToken));
                }
                fillTask = _restaurantCatalogFillTaskLookup[restaurantID];
            }
            finally
            {
                _restaurantCatalogFillTaskLookupLock.Release();
            }

            var response = await fillTask;
            return response;
        }
        private async Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> FillMemRestaturantCatalogResponseCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var RESTAURANT_CATALOG_KEY = GetRestaurantCatalogKeyFor(restaurantID);
            using (await NamedLock.LockAsync(RESTAURANT_CATALOG_KEY))
            {
                try
                {
                    Info($"{restaurantID} : RESPONSE CACHE : filling in mem cache ..");
                    var data = await GetFromRedisOrBuildRestaurantCatalogsAsync(restaurantID, cancellationToken);
                    (byte[] gZippedContent, string eTag, bool isInvalidated) response = (data.gZippedContent, data.eTag, !_canUseCache);
                    if (response.gZippedContent != null)
                    {
                        _restaurantCatalogsResponseCache.AddOrUpdate(restaurantID, response, (_, __) => response);
                        Debug($"{restaurantID} : RESPONSE CACHE : filled => {response.eTag}");
                    }
                    return response;
                }
                catch (Exception ex)
                {
                    Debug($"{restaurantID} : RESPONSE CACHE : fill FAILED : EXCEPTION : {ex.Message}", ex);
                    throw;
                }
                finally
                {
                    await _restaurantCatalogFillTaskLookupLock.WaitAsync();
                    try
                    {
                        _restaurantCatalogFillTaskLookup.Remove(restaurantID);
                    }
                    finally
                    {
                        _restaurantCatalogFillTaskLookupLock.Release();
                    }
                }
            }
        }
        private async Task<(byte[] gZippedContent, string eTag)> GetFromRedisOrBuildRestaurantCatalogsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var RESTAURANT_CATALOG_KEY = GetRestaurantCatalogKeyFor(restaurantID);

            try
            {
                Info($"{restaurantID} : RESPONSE CACHE : Redis fill ..");

                var expectedETag = await _restaurantCatalogBuilder.GetExpectedETag(restaurantID, cancellationToken);

                Info($"{restaurantID} : RESPONSE CACHE : Expected eTag : {expectedETag}");

                var redisData = await _stringKeyHashStore.GetAsync(RESTAURANT_CATALOG_KEY, new HashSet<string>(2) { _ETAG_, _CONTENT_ });

                if (redisData.ContainsKey(_ETAG_) && (redisData[_ETAG_] == expectedETag))
                {
                    Info($"{restaurantID} : RESPONSE CACHE : redis data is valid : eTag {redisData[_ETAG_]} == {expectedETag}");
                    return (Convert.FromBase64String(redisData[_CONTENT_]), redisData[_ETAG_]);
                }

                Info($"{restaurantID} : RESPONSE CACHE : May need to build .. getting resource lock ..");

                var lockID = GetLockIDFor(RESTAURANT_CATALOG_KEY);
                var lockTocken = await _resourceLock.TryTakeAsync(lockID, _catalogBuildLockAutoReleaseTime_ms, _catalogBuildLockTakeTimeout_ms, _catalogBuildLockTakeRetryDelay_ms, cancellationToken);
                if (lockTocken != Guid.Empty)
                {
                    try
                    {
                        Info($"{restaurantID} : RESPONSE CACHE : Got global resource lock. Checking if already done by other instance .. ");

                        expectedETag = await _restaurantCatalogBuilder.GetExpectedETag(restaurantID, cancellationToken);

                        Info($"{restaurantID} : RESPONSE CACHE : Expected eTag {expectedETag}");

                        redisData = await _stringKeyHashStore.GetAsync(RESTAURANT_CATALOG_KEY, new HashSet<string>(2) { _ETAG_, _CONTENT_ });

                        if (redisData.ContainsKey(_ETAG_) && (redisData[_ETAG_] == expectedETag))
                        {
                            Info($"{restaurantID} : RESPONSE CACHE : redis data is NOW valid : eTag {redisData[_ETAG_]} == {expectedETag}");
                            return (Convert.FromBase64String(redisData[_CONTENT_]), redisData[_ETAG_]);
                        }

                        Info($"{restaurantID} : RESPONSE CACHE : NEED to build ..");

                        var restaurantCatalogs = await _restaurantCatalogBuilder.Build(restaurantID, cancellationToken);

                        if (restaurantCatalogs.gZippedContent != null)
                        {
                            Info($"{restaurantID} : RESPONSE CACHE : Updating Redis ..");
                            await _stringKeyHashStore.SetAsync(RESTAURANT_CATALOG_KEY, new Dictionary<string, string>(2) { { _CONTENT_, Convert.ToBase64String(restaurantCatalogs.gZippedContent) }, { _ETAG_, restaurantCatalogs.eTag } }, _catalogTTL_ms);
                        }
                        else
                            Info($"RESPONSE CACHE : NOT Updating Redis, content was null / not found ..");

                        return restaurantCatalogs;
                    }
                    finally
                    {
                        Info($"{restaurantID} : RESPONSE CACHE : Releasing global resource lock ..");
                        await _resourceLock.ReleaseAsync(lockID, lockTocken);
                    }
                }
                else
                {
                    Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID} : RESPONSE CACHE : Failed to get global resource lock ..");
                    throw new Exception($"MARKET CATALOG RESPONSE CACHE : Failed to get global resource lock ..");
                }
            }
            catch (RedisTimeoutException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Redis timeout exception.");
                throw new RedisTimeoutException(ex.Message);
            }
            catch (RedisCommandException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Redis command exception.");
                throw new RedisCommandException(ex.Message);
            }
            catch (RedisConnectionException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Redis connection exception.");
                throw new RedisConnectionException(ex.Message);
            }

            catch (RedisServerException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Redis server exception.");
                throw new RedisServerException(ex.Message);
            }
            catch (RedisException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Redis exception.");
                throw new RedisException(ex.Message);
            }
            catch (RestaurantCatalogBuildException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Restaurant catalog build exception.");
                throw new RestaurantCatalogBuildException(ex.Message);
            }
            catch (RestaurantNotFoundException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildRestaurantCatalogsAsync)}: {restaurantID}: Restaurant not found exception.");
                throw new RestaurantNotFoundException(ex.Message);
            }
            catch (Exception ex)
            {
                Critical($"{restaurantID} : RESPONSE CACHE : FAILED TO FILL !!! : EXCEPTION : {ex.Message}", ex);
                throw ex;
                // do not mask this exception by returning a value here
                // this is a critical ERROR in all scenarios and should yield a 500 error
                // IF THIS HAPPENS WE ARE IN SEV-1 situation
            }
        }
        private async Task ClearRestaurantCatalogsRedisCacheAsync(string eventName, long restaurantID)
        {
            Info($"{eventName} : {restaurantID} : Clearing redis ..");
            var RESTAURANT_CATALOG_KEY = GetRestaurantCatalogKeyFor(restaurantID);
            var lockID = GetLockIDFor(RESTAURANT_CATALOG_KEY);
            var lockTocken = await _resourceLock.TryTakeAsync(lockID, _catalogBuildLockAutoReleaseTime_ms, _catalogBuildLockTakeTimeout_ms, _catalogBuildLockTakeRetryDelay_ms);
            if (lockTocken != Guid.Empty)
            {
                try
                {
                    await _stringKeyHashStore.ClearAsync(RESTAURANT_CATALOG_KEY);
                }
                finally
                {
                    await _resourceLock.ReleaseAsync(lockID, lockTocken);
                }
            }
            else
            {
                Error($"{eventName} : {restaurantID} : FAILED TO GET LOCK : clearing redis anyways ..");
                await _stringKeyHashStore.ClearAsync(RESTAURANT_CATALOG_KEY);
            }
        }
    }
}
