﻿using System;

namespace GMACache.RestaurantCatalog
{
    public class RestaurantNotFoundException : Exception { public RestaurantNotFoundException(string message) : base(message) { }  }
    public class CircuitBreakerOpenException : Exception { public CircuitBreakerOpenException(string message) : base(message) { } }
    public class RequestTimeoutException : Exception { public RequestTimeoutException(string message) : base(message) { } }
    public class RedisConnectionToBuildCatalogDataException : Exception { public RedisConnectionToBuildCatalogDataException(string message) : base(message) { } }
    public class RestaurantCatalogBuildException : Exception { public RestaurantCatalogBuildException(string message) : base(message) { } }

    public class MarketCatalogBuildException : Exception { public MarketCatalogBuildException(string message) : base(message) { } }

    public class RedisConnectionException : Exception { public RedisConnectionException(string message) : base(message) { } }

    public class RedisTimeoutException : Exception { public RedisTimeoutException(string message) : base(message) { } }
    public class RedisCommandException : Exception { public RedisCommandException(string message) : base(message) { } }
    public class RedisServerException : Exception { public RedisServerException(string message) : base(message) { } }

    public class RedisException : Exception { public RedisException(string message) : base(message) { } }

}
