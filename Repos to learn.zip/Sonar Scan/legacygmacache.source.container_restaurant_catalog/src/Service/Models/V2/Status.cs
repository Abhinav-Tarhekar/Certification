using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class Status
    {
        public int code { get; set; }
        public string type { get; set; }
        public string message { get; set; }
    }
}