using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class MarketSummaryResponseSchema
    {
        public Status status { get; set; }
        public MarketSummaryResponse response { get; set; }
    }
}
