using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class MarketFullResponseSchema
    {
        public Status status { get; set; }
        public MarketFullResponse response { get; set; }
    }
}
