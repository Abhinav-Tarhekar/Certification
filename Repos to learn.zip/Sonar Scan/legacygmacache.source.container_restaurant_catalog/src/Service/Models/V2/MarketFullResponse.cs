using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class MarketFullResponse
    {
        [Obsolete]
        public string categoryVersion { get; set; }
        public string categoriesVersion { get; set; }
        public List<CatalogCaches.Market.V2.DisplayCategory.Models.Category> categories { get; set; }

        public string facilityVersion { get; set; }
        public List<CatalogCaches.Market.V2.Facility.Models.Facility> facilities { get; set; }

        public string menuTypeVersion { get; set; }
        public List<CatalogCaches.Market.V2.MenuType.Models.MenuType> menuTypes { get; set; }
        
        public string namesVersion;
        public List<CatalogCaches.Market.V2.Names.Models.Names> names;
        
        public string tenderTypeVersion { get; set; }
        public List<CatalogCaches.Market.V2.TenderTypes.Models.TenderType> tenderTypes { get; set; }
        
        public string promotionVersion { get; set; }
        public List<CatalogCaches.Market.V2.MarketPromotion.Models.Promotion> promotions { get; set; }
        
        public string paymentMethodsVersion { get; set; }
        public List<CatalogCaches.Market.V2.PaymentMethod.Models.PaymentMethod> paymentMethods { get; set; }
        
        public string feedbackTypeVersion { get; set; }
        public List<CatalogCaches.Market.V2.FeedbackType.Models.FeedbackType> feedbackTypes { get; set; }
        
        public string languageVersion { get; set; }
        public List<CatalogCaches.Market.V2.Language.Models.Language> languages { get; set; }

        public string socialNetworkVersion { get; set; }
        public List<CatalogCaches.Market.V2.SocialNetworks.Models.SocialNetwork> socialNetwork { get; set; }
    }
}
