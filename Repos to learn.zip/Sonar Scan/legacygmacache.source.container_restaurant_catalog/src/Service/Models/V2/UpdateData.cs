using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class UpdateData
    {
        public UpdateData()
        {
            this.Market = new MarketFullResponse();
            this.Store = new List<UpdateStoreData>();
        }

        public MarketFullResponse Market { get; set; }
        public List<UpdateStoreData> Store { get; set; }
    }
}
