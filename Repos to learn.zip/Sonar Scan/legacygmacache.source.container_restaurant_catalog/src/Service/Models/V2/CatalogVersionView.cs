using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [ExcludeFromCodeCoverage]
    public class CatalogVersionView
    {
        public List<CatalogVersion> Market { get; set; }
        public List<StoreCatalogVersion> Store { get; set; }
    }
}
