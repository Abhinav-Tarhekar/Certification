using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class CategoriesSummaryResponse
    {
        public string categoriesVersion { get; set; }
        public List<Category> categories { get; set; }
        public class Category
        {
            public int id { get; set; }
            public string imageName { get; set; }
            public int? parentId { get; set; }
            public int displayOrder { get; set; }
            public int menuTypeId { get; set; }
            public List<Name> names { get; set; }
            public class Name
            {
                public string locale { get; set; }
                public string longname { get; set; }
                public string longName { get; set; }
            }
        }
    }
}
