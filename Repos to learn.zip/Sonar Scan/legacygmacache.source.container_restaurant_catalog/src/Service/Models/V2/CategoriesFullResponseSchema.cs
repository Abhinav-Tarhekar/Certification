using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class CategoriesFullResponseSchema
    {
        public Status status { get; set; }
        public CategoriesFullResponse response { get; set; }
    }
}
