using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [ExcludeFromCodeCoverage]
    public class StoreCatalogVersion
    {
        public List<CatalogVersion> Catalog { get; set; }
        public string StoreId { get; set; }
    }
}
