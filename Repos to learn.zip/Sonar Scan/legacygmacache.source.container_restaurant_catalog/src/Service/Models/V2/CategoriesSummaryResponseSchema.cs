using System;

namespace GMACache.RestaurantCatalog.Models.V2
{
    [Serializable]
    public class CategoriesSummaryResponseSchema
    {
        public Status status { get; set; }
        public CategoriesSummaryResponse response { get; set; }
    }
}
