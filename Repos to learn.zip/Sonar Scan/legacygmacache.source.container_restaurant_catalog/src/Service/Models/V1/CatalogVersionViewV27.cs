using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [ExcludeFromCodeCoverage]
    public class CatalogVersionViewV27
    {
        public List<CatalogVersionV27> Market { get; set; }
        public List<StoreCatalogVersionV27> Store { get; set; }
    }
}
