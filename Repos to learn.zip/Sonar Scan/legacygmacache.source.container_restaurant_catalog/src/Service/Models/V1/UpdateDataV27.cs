using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [Serializable]
    public class UpdateDataV27
    {
        public UpdateDataV27()
        {
            this.Market = new UpdateMarketDataV27();
            this.Store = new List<UpdateStoreDataV27>();
        }

        public UpdateMarketDataV27 Market { get; set; }
        public List<UpdateStoreDataV27> Store { get; set; }
    }
}
