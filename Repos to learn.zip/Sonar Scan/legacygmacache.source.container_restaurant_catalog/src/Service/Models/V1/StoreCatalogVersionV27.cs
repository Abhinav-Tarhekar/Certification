using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [ExcludeFromCodeCoverage]
    public class StoreCatalogVersionV27
    {
        public List<CatalogVersionV27> Catalog { get; set; }
        public string StoreId { get; set; }
    }
}
