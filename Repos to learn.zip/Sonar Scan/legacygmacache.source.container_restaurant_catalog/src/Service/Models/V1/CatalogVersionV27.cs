using System;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class CatalogVersionV27
    {
        public CatalogVersionType Type { get; set; }
        public string Version { get; set; }
    }

    public enum CatalogVersionType : int
    {
        StaticData = 1,
        Store = 2,
        DisplayCategory = 3,
        Facility = 4,
        Recipes = 5,
        Names = 6,
        Promotion = 7,
        Product = 8,
        Language = 9,
        StoreFacility = 10,
        ProductPrices = 11,
        Availability = 12,
        RecipePrices = 13,
        PaymentMethod = 14,
        FeedbackTypeName = 15,
        TenderTypes = 16,
        MenuType = 17,
        SocialNetwork = 18,
        OptIns = 19,
        CustomerEnums = 20,
    }
}
