using System.Collections.Generic;
using System;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion.Models;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [Serializable]
    public class UpdateStoreDataV27
    {
        public string Store { get; set; }

        //STEFAN: not cacheable : //public string NowInStoreLocalTime { get; set; }
        //STEFAN: THIS IS IN THE WRONG PLACE IT SHOULD BE PART OF DATA -- how would this be updated on a update ??? - it is versioned with RestaurantData
        //public List<CytIngredientGroupV27> CytIngredientGroups { get; set; }

        public string RestaurantDataVersion => null;
        public object RestaurantData => null;

        public string PromotionVersion { get; set; }
        public List<CatalogPromotionViewV27> Promotions { get; set; }

        public string ProductVersion { get; set; }
        public List<CatalogProductViewV27> Products { get; set; }

        public string ProductPriceVersion { get; set; }
        public List<CatalogProductPriceViewFullV27> ProductPrice { get; set; }

        public string RecipePriceVersion => null;
        public object RecipePrice => null;

        public string AvailabilityVersion { get; set; }
        public List<CatalogAvailabilityViewV27> Availability { get; set; }
    }
}
