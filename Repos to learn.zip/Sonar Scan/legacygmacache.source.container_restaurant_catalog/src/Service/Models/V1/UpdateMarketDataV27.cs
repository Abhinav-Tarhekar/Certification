using System;
using System.Collections.Generic;

using Newtonsoft.Json;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MarketPromotion.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes.Models;

namespace GMACache.RestaurantCatalog.Models.V1
{
    [Serializable]
    public class UpdateMarketDataV27
    {
        public string StaticDataVersion => null;
        public object StaticData => null;

        public string DisplayCategoryVersion { get; set; }
        public List<CatalogDisplayCategoryViewV27> DisplayCategory { get; set; }

        public string FacilityVersion { get; set; }
        public List<CatalogFacilityViewV27> Facilities { get; set; }

        public string NamesVersion { get; set; }
        public List<CatalogNamesViewV27> Names { get; set; }

        public string RestaurantsVersion => null;
        public object Restaurants => null;

        public string RecipeVersion => null;
        public object Recipes => null;

        public string LanguageVersion { get; set; }
        public List<CatalogLanguageViewV27> Languages { get; set; }

        public string PaymentMethodsVersion { get; set; }
        public List<CatalogPaymentMethodViewV27> PaymentMethods { get; set; }

        public string FeedbackTypeNamesVersion { get; set; }
        public List<FeedbackTypeNameViewV27> FeedbackTypeNames { get; set; }

        public string TenderTypeVersion { get; set; }
        public List<CatalogTenderTypeViewV27> TenderTypes { get; set; }

        public string PromotionVersion { get; set; }
        public List<CatalogPromotionViewV27> Promotions { get; set; }

        public string MenuTypeVersion { get; set; }
        public List<CatalogMenuTypeViewV27> MenuType { get; set; }

        public string SocialNetworkVersion { get; set; }
        public List<CatalogSocialNetworkViewV27> SocialNetwork { get; set; }

        [JsonProperty("Opt-InsVersion")]
        public string OptInsVersion { get; set; }
        [JsonProperty("Opt-Ins")]
        public List<CatalogDynamicOptInView> OptIns { get; set; }

        public string CustomerEnumsVersion { get; set; }
        //STEFAN: I CHANGED THIS ONE
        //public CatalogCustomerEnumsView CustomerEnums { get; set; }
        public CustomerCategoryCodesView CustomerEnums { get; set; }

    }
}
