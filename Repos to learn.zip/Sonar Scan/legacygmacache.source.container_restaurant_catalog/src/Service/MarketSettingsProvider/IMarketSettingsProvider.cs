﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog
{
    public interface IMarketSettingsProvider
    {
        Task<IMarketSettingsSnapshot> GetMarketSettingsSnapshotAsync(); // use this so that the version used during a catalog build is consistent with the market setting hash
    }
    public interface IMarketSettingsSnapshot
    {
        string SnapshotHash { get; } // used to detect changes, this must be cached for best possible speed, it is used on every catalog access
        ReadOnlyDictionary<string, MarketSettings> MarketSettingsLookup { get; }
    }
    public static class IMarketSettingsExtensions
    {
        public static string GetTranslationFor(this MarketSettings marketSettings, string groupID, string ID, string locale)
        {
            var groups = marketSettings.Translations;
            if (groups == null) { return null; }
            var group = groups.ContainsKey(groupID) ? groups[groupID] : null;
            if (group == null) { return null; }
            var translations = group.ContainsKey(ID) ? group[ID] : null;
            if (translations == null) { return null; }
            var translation = translations.ContainsKey(locale) ? translations[locale] : null;
            return translation;
        }

        public static IReadOnlyCollection<string> GetEnabledLanguageLocales(this MarketSettings marketSettings) {
            return (marketSettings.LanguageConfigurations == null) ? new HashSet<string>() : marketSettings.LanguageConfigurations.Where(l => l.Enabled).Select(l => l.Locale).ToHashSet();
        }

    }
}
