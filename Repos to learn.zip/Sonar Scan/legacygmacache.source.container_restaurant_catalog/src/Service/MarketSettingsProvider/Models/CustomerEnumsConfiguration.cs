﻿using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class CustomerEnumsConfiguration
    {
        public List<GenderConfiguration> Genders { get; set; }
        public List<EthnicityConfiguration> Enthnicities { get; set; }
    }
    [Serializable]
    public class GenderConfiguration
    { 
        public int Id { get; set; }
        public string Code { get; set; }
    }
    [Serializable]
    public class EthnicityConfiguration
    {
        public int Id { get; set; }
        public string Code { get; set; }
    }
}
