﻿using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    public enum PaymentMethod
    {
        UndefinedPaymentMethod = 0,
        Visa = 1,
        MasterCard = 2,
        Amex = 3,
        Discover = 4,
        PayPal = 5,
        TestHarness = 6,
        Cash = 7,
        ArchCard = 8,
        Alipay = 9,
        CyberSource = 10,
        Diners = 11,
        JCB = 12,
        WeChat = 13,
        Telecash = 14
    }
    public enum PaymentIntegrator
    {
        UndefinedIntegrator = 0,
        PayPal = 1,
        WestPac = 2,
        FirstData = 3,
        Onsite = 4,
        Barclaycard = 5,
        Alipay = 6,
        CyberSource = 7,
        AlipayMobile = 8,
        AlipayWeb = 9,
        WeChatMobile = 10,
        CyberSourceWebView = 12,
        Moneris = 13,
        TeleCash = 14
    }
    public enum PaymentMode
    {
        UndefinedPaymentMode = 0,
        GatewayAccount = 1,
        GatewayCard = 2,
        OnSiteRemote = 3,
        OnSiteCheckIn = 4
    }
    public enum PaymentRequestType
    {
        UndefinedPaymentRequestType = 0,
        API = 1,
        WebView = 2,
        None = 3,
        External = 4
    }
    public class PaymentMethodConfigurationKey
    {
        public PaymentMethod PaymentMethod { get; set; }
        public PaymentIntegrator PaymentIntegrator { get; set; }
    }
    public class PaymentMethodConfiguration
    {
        public PaymentMethodConfigurationKey Key { get; set; }
        public string Name { get; set; }
        public string DisplayImageName { get; set; }
        public bool Enabled { get; set; }
        public bool RequiresCVV { get; set; }
        public int? CVVLength { get; set; }
        public bool AllowCardUpdate { get; set; }
        public bool AllowBalanceInquiry { get; set; }
        public int TenderCode { get; set; }
        public DateTime LastModified { get; set; }
        public List<double> Amount { get; set; }
        public int NewPOSTenderId { get; set; }
        public bool EnableMerchantConfiguration { get; set; }
    }
    [Serializable]
    public class PaymentIntegratorConfiguration
    {
        public PaymentIntegrator Key { get; set; }
        public List<PaymentMethodConfiguration> SupportedPaymentMethods { get; set; }
        public string RegistrationUri { get; set; }
        public string RegistrationReturnUri { get; set; }
        public string ConfirmationUri { get; set; }
        public string UpdateCardUrl { get; set; }
        public string ExpirationDateUpdateURL { get; set; }
        public string ExpirationDateUpdateReturnURL { get; set; }
        public string IntegratorVersion { get; set; }
        // STEFAN: NOT USED // public PaymentCustomDataConfiguration CustomData { get; set; }
        public PaymentMode PaymentMode { get; set; }
        public TenderType TenderCode { get; set; }
        public string DisplayImageName { get; set; }
        public bool AcceptsOneTimePayment { get; set; }
        public int CVVThresholdAmount { get; set; }
        public int ThresholdAmount { get; set; }
        public int MinTransactionAmount { get; set; }
        public bool Enabled { get; set; }
        public bool RequiresPassword { get; set; }
        public DateTime LastModified { get; set; }
        public PaymentRequestType RegistrationType { get; set; }
        public PaymentRequestType PaymentType { get; set; }
        public string ConfirmationReturnUri { get; set; }
        public int NewPOSTenderId { get; set; }
        public string TenderDisplayImageName { get; set; }
        public int MinimumTenderAmount { get; set; }
        public bool IsTenderDefault { get; set; }
        public int DefaultTenderAmountDisplay { get; set; }
        public bool EnableMerchantConfiguration { get; set; }
        public int TimeoutOnSendTheRequest { get; set; }
        public string CustomerReferenceNumberPrefix { get; set; }
        public bool SynchronizeCards { get; set; }
    }
}
