﻿using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class MarketSettings
    {
        public MarketInformation MarketInformation { get; set; }
        public MarketParameters MarketParameters { get; set; }

        public IReadOnlyCollection<FacilityConfiguration> FacilityConfigurations { get; set; }
        public IReadOnlyCollection<FeedbackTypeConfiguration> FeedbackTypeConfigurations { get; set; }
        public IReadOnlyCollection<LanguageConfiguration> LanguageConfigurations { get; set; }
        public IReadOnlyCollection<TenderTypeConfiguration> TenderTypeConfigurations { get; set; }
        public IReadOnlyCollection<Promotion> MarketPromotions { get; set; }
        public IReadOnlyCollection<DynamicOptinConfiguration> OptIns { get; set; }
        public CustomerEnumsConfiguration CustomerEnumerationConfiguration { get; set; }
        public IReadOnlyCollection<SocialNetworkConfiguration> SocialNetworkConfigurations { get; set; }
        public IReadOnlyCollection<PaymentIntegratorConfiguration> PaymentConfigurations { get; set; }

        public IReadOnlyDictionary<string, IReadOnlyDictionary<string, IReadOnlyDictionary<string, string>>> Translations { get; set; }
    }
}
