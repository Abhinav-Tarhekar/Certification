﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    public class LanguageConfiguration
    {
        public string Locale { get; set; }
        public bool Enabled { get; set; }
        public string NewPOSLanguageCode { get; set; }
        public bool Default { get; set; }
        public DateTime LastModified { get; set; }
    }
}
