﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    public class FeedbackTypeConfiguration
    {
        public int Id { get; set; }
        public string Culture { get; set; }
        public string Name { get; set; }
        public bool IsValid { get; set; }
        public DateTime LastModified { get; set; }
    }
}
