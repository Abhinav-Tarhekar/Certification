﻿using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class MarketInformation
    {
        public string MarketName { get; set; }
        public int MarketID { get; set; }
    }
}
