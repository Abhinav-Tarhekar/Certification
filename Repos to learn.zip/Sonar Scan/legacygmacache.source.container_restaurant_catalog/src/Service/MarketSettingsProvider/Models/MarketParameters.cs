﻿using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class MarketParameters
    {
        public long DefaultPosStoreNumber { get; set; }
        public bool IgnoreNullPriceFromRfmAndPos { get; set; }
        public bool IgnoreNullValuesInCatalog { get; set; }
        public int MaxChoiceOptions { get; set; }
        public string ProductImportSaleTypeFilter { get; set; }
        public string ApplyProductImportSaleTypeFilterToProductCatalog { get; set; }
    }
}
