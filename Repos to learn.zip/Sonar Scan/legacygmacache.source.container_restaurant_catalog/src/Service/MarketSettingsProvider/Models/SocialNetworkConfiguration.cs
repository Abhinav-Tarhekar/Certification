﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    public enum SocialNetwork
    {
        Undefined = 0,
        GooglePlus = 1,
        Facebook = 2,
        WeChat = 3
    }
    [Serializable]
    public class SocialNetworkConfiguration
    {
        public SocialNetwork SocialNetworkID { get; set; }
        public string CustomData { get; set; }
        public string SocialNetworkProfileCallURI { get; set; }
        public string SocialNetworkProfileIDField { get; set; }
        public DateTime LastModified { get; set; }
        public bool IsValid { get; set; }
        public int SocialNetworkTimeoutRequest { get; set; }
        public bool useInternalIdInsteadOfUsername { get; set; }
    }
}
