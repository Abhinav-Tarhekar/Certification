﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    public enum TenderType
    {
        Undefined = 1,
        Cash = 2,
        CashLargeDenomination = 3,
        Check = 4,
        CreditCard = 5
    }

    [Serializable]
    public class TenderTypeConfiguration
    {
        public TenderType Code { get; set; }
        public string DisplayName { get; set; }
        public DateTime LastModified { get; set; }
        public bool IsCashless { get; set; }
    }
}
