﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class FacilityConfiguration
    {
        public int FacilityId { get; set; }
        public string FacilityCode { get; set; }
        public string Description { get; set; }
    }
}
