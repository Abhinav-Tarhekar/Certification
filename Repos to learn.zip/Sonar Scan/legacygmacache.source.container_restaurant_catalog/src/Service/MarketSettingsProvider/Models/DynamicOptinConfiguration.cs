﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class DynamicOptinConfiguration
    {
        public int DynamicOptinId { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public bool Mandatory { get; set; }
        public bool Enabled { get; set; }
        public DateTime LastModified { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public bool IsOneWay { get; set; }
        public string DCSSubscriptionId { get; set; }
    }
}
