﻿using System;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider.Models
{
    [Serializable]
    public class Promotion
    {
        public int PromoId { get; set; }
        public long StoreId { get; set; }
        public string ImageName { get; set; }
        public int ProductCode { get; set; }
        public string POSStoreNumber { get; set; }
        public bool IsValid { get; set; }
        public string AppName { get; set; }
        public DateTime LastModified { get; set; }
    }
}
