﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Common;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.MarketSettingsProvider
{
    public class MarketSettingsProvider_File : IMarketSettingsProvider
    {
        private readonly ILog Log;

        private readonly SemaphoreSlim SNAPSHOT_LOCK = new SemaphoreSlim(1);
        private readonly string _path;
        private IMarketSettingsSnapshot _currentMarketSettingSnapshot;

        public MarketSettingsProvider_File(ILog logger, string path)
        {
            Log = logger;
            _path = path;
        }
        public async Task<IMarketSettingsSnapshot> GetMarketSettingsSnapshotAsync()
        {
            if (_currentMarketSettingSnapshot == null)
            {
                try
                { 
                    await SNAPSHOT_LOCK.WaitAsync();
                    if (_currentMarketSettingSnapshot == null)
                    {
                        MarketSettingsSnapshot snapshot = null;
                        Log.Debug($"{nameof(MarketSettingsProvider_File)} : Loading all market settings from {_path} ...");
                        try
                        {
                            var marketSettingsLookup = new Dictionary<string, MarketSettings>();
                            foreach (var file in Directory.EnumerateFiles(_path, "*.json"))
                            {
                                Log.Debug($"{nameof(MarketSettingsProvider_File)} : Loading market settings from {file} ..");
                                string json = await File.ReadAllTextAsync(file);
                                marketSettingsLookup.Add(Path.GetFileNameWithoutExtension(file), JsonConvert.DeserializeObject<MarketSettings>(json));
                            }
                            snapshot = new MarketSettingsSnapshot(new ReadOnlyDictionary<string, MarketSettings>(marketSettingsLookup));
                        }
                        catch (Exception ex)
                        {
                            Log.Critical($"{nameof(MarketSettingsProvider_File)} : EXCEPTION : {ex.Message}", ex);
                        }
                        _currentMarketSettingSnapshot = snapshot ?? throw new Exception($"{nameof(MarketSettingsProvider_File)} : Failed to parse market settings from {_path} ...");
                    }
                }
                finally
                {
                    SNAPSHOT_LOCK.Release();
                }
            }
            return _currentMarketSettingSnapshot;
        }
    }
    public class MarketSettingsSnapshot : IMarketSettingsSnapshot
    {
        private string _SnapshotHash;
        private ReadOnlyDictionary<string, MarketSettings> _marketSettingsLookup;

        public MarketSettingsSnapshot(ReadOnlyDictionary<string, MarketSettings> marketSettingsLookup)
        {
            _marketSettingsLookup = marketSettingsLookup;

            string json = JsonConvert.SerializeObject(marketSettingsLookup);
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(json));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                _SnapshotHash = builder.ToString();
            }
        }

        [JsonIgnore]
        public string SnapshotHash => _SnapshotHash;
        public ReadOnlyDictionary<string, MarketSettings> MarketSettingsLookup => _marketSettingsLookup;
    }
}
