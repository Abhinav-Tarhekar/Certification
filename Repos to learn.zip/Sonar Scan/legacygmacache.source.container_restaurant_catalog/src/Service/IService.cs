﻿using System.Threading;
using System.Threading.Tasks;

using GMACache.RestaurantCatalog.Models.V1;

namespace GMACache.RestaurantCatalog
{
    public interface IService
    {
        Task InitializeAsync();
        Task HelpTaskAsync(long restaurantID, CancellationToken cancellationToken = default);
        Task<(string content, string eTag, bool isInvalidated)> GetLegacyEncodedMarketCatalogsAsync(bool decoded, string marketName, CancellationToken cancellationToken = default);
        Task<(string content, string eTag, bool isInvalidated)> GetLegacyEncodedRestaurantCatalogsAsync(long restaurantID, bool decoded, CancellationToken cancellationToken = default);
        Task<string> GetLegacyEncodedCatalogUpdatesAsync(CatalogVersionViewV27 catalogVersionsAlreadyAvailiableAtClient, string marketName, CancellationToken cancellationToken = default);

        Task<(byte[] gZippedSummaryContent, byte[] gZippedFullContent, string eTag, bool isInvalidated)> GetCategoriesAsync(string marketName, CancellationToken cancellationToken = default); 
        Task<(byte[] gZippedSummaryContent, byte[] gZippedFullContent, string eTag, bool isInvalidated)> GetMarketCatalogsAsync(string marketName, CancellationToken cancellationToken = default);
        Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> GetRestaurantCatalogsAsync(long restaurantID, CancellationToken cancellationToken = default);
    }
}
