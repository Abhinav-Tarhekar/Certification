﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Text;

using Common;

using GMACache.Common;

using RestaurantBridge.Gateway.Cloud.V1;
using GMACache.RestaurantCatalog.Models.V1;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog
{
    public partial class Service : IService
    {
        private readonly ILog Log;

        private void Debug(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Debug($"{nameof(Service)}:{member} : {message}", exception); }
        private void Info(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Info($"{nameof(Service)}:{member} : {message}", exception); }
        private void Warn(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Warn($"{nameof(Service)}:{member} : {message}", exception); }
        private void Error(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Error($"{nameof(Service)}:{member} : {message}", exception); }
        private void Critical(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Critical($"{nameof(Service)}:{member} : {message}", exception); }
        private void Fatal(string message, Exception exception = null, [CallerMemberName] string member = "") { Log.Fatal($"{nameof(Service)}:{member} : {message}", exception); }

        private readonly IMarketSettingsProvider _marketSettingsProvider;
        private readonly IResourceLock _resourceLock;
        private readonly IStringKeyHashStore _stringKeyHashStore;
        private readonly IClientAdvanced _restaurantBridgeService;

        private readonly int _cache_reload_delay_ms;
        private readonly bool _cache_background_reload_while_serving_existing;
        private readonly int _catalog_cache_reload_throttle_delay_ms;

        private readonly int _catalogTTL_ms;
        private readonly int _catalogBuildLockAutoReleaseTime_ms;
        private readonly int _catalogBuildLockTakeRetryDelay_ms;
        private readonly int _catalogBuildLockTakeTimeout_ms;

        private const string _ETAG_ = "_ETAG_";
        private const string _CONTENT_ = "_CONTENT_";
        private const string _SUMMARY_ = "_SUMMARY_";

        private volatile bool _canUseCache;

        private readonly CatalogCaches.Market.V1.CatalogBuilder _V1_marketCatalogBuilder;
        private readonly CatalogCaches.Market.V2.CatalogBuilder _V2_marketCatalogBuilder;

        private readonly CatalogCaches.Restaurant.CatalogBuilder _restaurantCatalogBuilder;

        public Service(
            ILog logger,
            IConfiguration configuration,
            IMarketSettingsProvider marketSettingsProvider,
            IResourceLock resourceLock,
            IStringKeyHashStore stringKeyHashStore,
            IClientAdvanced restaurantBridgeService,
            CatalogCaches.Market.V1.CatalogBuilder V1_marketCatalogBuilder,
            CatalogCaches.Market.V2.CatalogBuilder V2_marketCatalogBuilder,
            CatalogCaches.Restaurant.CatalogBuilder restaurantCatalogBuilder)
        {
            Log = logger;

            _cache_reload_delay_ms = configuration.catalog_cache_reload_event_consolidation_delay_ms;
            _cache_background_reload_while_serving_existing = configuration.catalog_cache_background_reload_while_serving_existing;
            _catalog_cache_reload_throttle_delay_ms = configuration.catalog_cache_reload_throttle_delay_ms;
            _catalogTTL_ms = (configuration.catalog_cache_ttl_hours == -1) ? -1 : configuration.catalog_cache_ttl_hours * 60 * 60 * 1000;
            _catalogBuildLockAutoReleaseTime_ms = configuration.catalog_cache_build_auto_release_time_ms;
            _catalogBuildLockTakeRetryDelay_ms = 250;
            _catalogBuildLockTakeTimeout_ms = _catalogBuildLockAutoReleaseTime_ms + _catalogBuildLockTakeRetryDelay_ms;

            _marketSettingsProvider = marketSettingsProvider;
            _resourceLock = resourceLock;
            _stringKeyHashStore = stringKeyHashStore;
            _restaurantBridgeService = restaurantBridgeService;

            _V1_marketCatalogBuilder = V1_marketCatalogBuilder;
            _V2_marketCatalogBuilder = V2_marketCatalogBuilder;
            _restaurantCatalogBuilder = restaurantCatalogBuilder;
        }

        public async Task InitializeAsync()
        {
            Info($"Intitializing ..");

            _restaurantBridgeService.EventMonitor.onDisconnect += async (_, e) => await DisableCacheAsync();
            _restaurantBridgeService.EventMonitor.onConnection += async (_, e) => await EnableCacheAsync();

            _restaurantBridgeService.EventMonitor.onCacheClear += async (_, e) => await ClearCacheAsync("onCacheClear", e.RestaurantID);
            _restaurantBridgeService.EventMonitor.onCacheReload += async (_, e) => await ScheduleReloadCacheAsync("onCacheReload", e.RestaurantID);

            _restaurantBridgeService.EventMonitor.onMenuCategoriesInvalidation += async (_, e) => await ScheduleReloadCacheAsync("onMenuCategoriesInvalidation", e.RestaurantID);
            _restaurantBridgeService.EventMonitor.onSettingsInvalidation += async (_, e) => await ScheduleReloadCacheAsync("onSettingsInvalidation", e.RestaurantID);
            _restaurantBridgeService.EventMonitor.onProductsInvalidation += async (_, e) => await ScheduleReloadCacheAsync("onProductsInvalidation", e.RestaurantID);

            _canUseCache = _restaurantBridgeService.EventMonitor.isConnected;
            await Task.CompletedTask;
        }

        private async Task DisableCacheAsync()
        {
            Info($"Disabling and Invalidating ENTIRE cache ..");
            _canUseCache = false;
            var restaurantIDs = new HashSet<long>();
            var defaultStores = (await _marketSettingsProvider.GetMarketSettingsSnapshotAsync()).MarketSettingsLookup.Values.Select(ms => ms.MarketParameters.DefaultPosStoreNumber);
            restaurantIDs.UnionWith(defaultStores);
            restaurantIDs.UnionWith(_restaurantCatalogsResponseCache.Keys);
            foreach(var restaurantID in restaurantIDs) { await InvalidateCacheAsync(nameof(DisableCacheAsync), restaurantID); }
        }
        private async Task EnableCacheAsync()
        {
            Info($"Invalidating ENTIRE cache and enabling ..");
            var restaurantIDs = new HashSet<long>();
            var defaultStores = (await _marketSettingsProvider.GetMarketSettingsSnapshotAsync()).MarketSettingsLookup.Values.Select(ms => ms.MarketParameters.DefaultPosStoreNumber);
            restaurantIDs.UnionWith(defaultStores);
            restaurantIDs.UnionWith(_restaurantCatalogsResponseCache.Keys);
            foreach (var restaurantID in restaurantIDs) { await InvalidateCacheAsync(nameof(EnableCacheAsync), restaurantID); }
            _canUseCache = true;
        }
        private async Task ClearCacheAsync(string eventName, long restaurantID)
        {
            Info($"({eventName},{restaurantID}) : Clearing cache entry ..");
            await ClearMemCache(eventName, restaurantID);
            await ClearRestaurantCatalogsRedisCacheAsync(eventName, restaurantID);
            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var defaultStores = marketSettingsSnapshot.MarketSettingsLookup.ToDictionary(kv => kv.Value.MarketParameters.DefaultPosStoreNumber, kv => kv.Key);
            if (defaultStores.ContainsKey(restaurantID))
            {
                var marketName = defaultStores[restaurantID];
                Info($"({eventName},{restaurantID}) : Clearing cache entry : restaurant is the current default store for market \"{marketName}\" clearing market catalog as well ..");
                await ClearMarketCatalogsRedisCacheAsync(eventName, marketName);
            }
        }

        private async Task InvalidateCacheAsync(string eventName, long restaurantID)
        {
            if (_cache_background_reload_while_serving_existing)
            {
                Log.Info($"{nameof(InvalidateCacheAsync)}({eventName},{restaurantID}) : Invalidating cache entry ..");
                using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
                {
                    if (_restaurantCatalogsResponseCache.TryGetValue(restaurantID, out var current_cached_data))
                    {
                        var new_value = (current_cached_data.gZippedContent, current_cached_data.eTag, true);
                        _restaurantCatalogsResponseCache.AddOrUpdate(restaurantID, new_value, (_, __) => new_value);
                    }
                }

                var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
                var defaultStores = marketSettingsSnapshot.MarketSettingsLookup.ToDictionary(kv => kv.Value.MarketParameters.DefaultPosStoreNumber, kv => kv.Key);
                if (defaultStores.ContainsKey(restaurantID))
                {
                    var marketName = defaultStores[restaurantID];

                    Log.Info($"{nameof(InvalidateCacheAsync)}({eventName},{restaurantID}) : restaurant is the current default store for market \"{marketName}\" invalidating market catalog as well ..");

                    using (await NamedLock.LockAsync(GetMarketCatalogKeyFor(marketName)))
                    {
                        if (_marketCatalogsResponseCache.TryGetValue(marketName, out var current_cached_data))
                        {
                            var new_value = (current_cached_data.content, current_cached_data.eTag, true);
                            _marketCatalogsResponseCache.AddOrUpdate(marketName, new_value, (_, __) => new_value);
                        }
                    }
                }
            }
            else
            {
                await ClearCacheAsync(eventName, restaurantID);
            }
        }

        private SemaphoreSlim _reloadTaskLookupLock = new SemaphoreSlim(1, 1);
        // CONCURRENT DICTIONARY DOES NOT WORK AS GetOrAdd can call the add method in parallel :(
        private Dictionary<long, Task> _reloadTaskLookup = new Dictionary<long, Task>();
        private async Task ScheduleReloadCacheAsync(string eventName, string marketName, bool alreadyInvalidated = false)
        {
            //TODO: implements something here
        }
        private async Task ScheduleReloadCacheAsync(string eventName, long restaurantID, bool alreadyInvalidated = false)
        {
            if (!alreadyInvalidated)
            {
                await InvalidateCacheAsync(eventName, restaurantID);
            }
            await _reloadTaskLookupLock.WaitAsync();
            try
            {
                var alreadyScheduled = _reloadTaskLookup.ContainsKey(restaurantID);
                Log.Info($"{nameof(ScheduleReloadCacheAsync)}({eventName},{restaurantID}) : Reloading cache ..{(alreadyScheduled ? " ALREADY SCHEDULED .." : "")}");
                if (!alreadyScheduled)
                {
                    _reloadTaskLookup.Add(restaurantID, ReloadCacheAsync(restaurantID)); // yes fire and forget
                }
            }
            finally
            {
                _reloadTaskLookupLock.Release();
            }
        }
        private async Task ReloadCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                Log.Info($"{nameof(ReloadCacheAsync)}({restaurantID}) : Delaying {_cache_reload_delay_ms} ms cache reload to deduplicate ..");
                await Task.Delay(_cache_reload_delay_ms);
                Log.Info($"{nameof(ReloadCacheAsync)}({restaurantID}) : Reloading cache ..");
                await GetRestaurantCatalogsFromBuildAsync(restaurantID,cancellationToken);

                var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
                var defaultStores = marketSettingsSnapshot.MarketSettingsLookup.ToDictionary(kv => kv.Value.MarketParameters.DefaultPosStoreNumber, kv => kv.Key);
                if (defaultStores.ContainsKey(restaurantID))
                {
                    var marketName = defaultStores[restaurantID];

                    Log.Info($"{nameof(ReloadCacheAsync)}({restaurantID}) : Reloading cache : restaurant is the current default store for market \"{marketName}\" reloading market catalog as well ..");
                    await GetMarketCatalogsFromBuildAsync(marketName, cancellationToken);
                }
            }
            catch (Exception ex)
            {
                Log.Warn($"{nameof(ReloadCacheAsync)}({restaurantID}) : Failed to prewarm cache ..", ex);
            }
            await _reloadTaskLookupLock.WaitAsync();
            try
            {
                _reloadTaskLookup.Remove(restaurantID, out _);
            }
            finally
            {
                _reloadTaskLookupLock.Release();
            }
            if (!_canUseCache)
            {
                // prevent from scheduling another reload immediately when opperating in conditions where RB connectivity is bad
                await Task.Delay(_catalog_cache_reload_throttle_delay_ms);
            }
        }
        private async Task ClearMemCache(string eventName, long restaurantID)
        {
            Debug($"{eventName} : {restaurantID}");

            using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
            {
                _restaurantCatalogsResponseCache.TryRemove(restaurantID, out _);
            }
            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var defaultStores = marketSettingsSnapshot.MarketSettingsLookup.ToDictionary(kv => kv.Value.MarketParameters.DefaultPosStoreNumber, kv => kv.Key);
            if (defaultStores.ContainsKey(restaurantID))
            {
                var marketName = defaultStores[restaurantID];

                Debug($"{eventName} : {restaurantID} : restaurant is the current default store for market \"{marketName}\" clearing market catalog as well ..");
                using (await NamedLock.LockAsync(GetRestaurantCatalogKeyFor(restaurantID)))
                {
                    _marketCatalogsResponseCache.TryRemove(marketName, out _);
                }
            }
        }

        // This dummy methods is just for unit test purpose only
        public async Task HelpTaskAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            await DisableCacheAsync();
            await EnableCacheAsync();
            await ClearCacheAsync("eventName", restaurantID);
            await InvalidateCacheAsync("eventName", restaurantID);
            await ScheduleReloadCacheAsync("eventName", "us");
            await ScheduleReloadCacheAsync("eventNam", restaurantID);            
            await ClearMemCache("eventName", restaurantID);
            await GetRestaurantCatalogsAsync(restaurantID, cancellationToken);
            Warn("Test");
            Error("Test");
            Fatal("Test");
            await ReloadCacheAsync(restaurantID, cancellationToken);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetLockIDFor(string resourceKey) => $"{resourceKey}_LOCK";

        public async Task<byte[]> Compress(string stringToCompress)
        {
            byte[] dataToCompress = Encoding.UTF8.GetBytes(stringToCompress);
            using (MemoryStream memStream = new MemoryStream())
            {
                using (GZipStream zipStream = new GZipStream(memStream, CompressionMode.Compress))
                {
                    await zipStream.WriteAsync(dataToCompress, 0, dataToCompress.Length);
                    await zipStream.FlushAsync();
                }
                return memStream.ToArray();
            }
        }

        #region V1 API 
        //Excluded V1 API due to decommission
        [ExcludeFromCodeCoverage]
        public async Task<(string content, string eTag, bool isInvalidated)> GetLegacyEncodedMarketCatalogsAsync(bool decoded, string marketName, CancellationToken cancellationToken = default)
        {
            var marketSettings = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();

            if (string.IsNullOrWhiteSpace(marketName))
            {
                marketName = marketSettings.MarketSettingsLookup.Keys.First();
            }

            if (!marketSettings.MarketSettingsLookup.ContainsKey(marketName))
            {
                return (null, null, false);
            }

            var response = await GetMarketCatalogsThroughCacheAsync(marketName, cancellationToken);
            var V1LegacyEncodedMarketCatalog = (response.content?.V1_MarketCatalogs, response.eTag, response.isInvalidated);
            return await Decode(decoded, V1LegacyEncodedMarketCatalog);
        }

        [ExcludeFromCodeCoverage]
        public async Task<(string content, string eTag, bool isInvalidated)> GetLegacyEncodedRestaurantCatalogsAsync(long restaurantID, bool decoded, CancellationToken cancellationToken = default)
        {
            var response = await GetLegacyEncodedRestaurantCatalogsThroughCacheAsync(restaurantID, cancellationToken);
            return await Decode(decoded, response);
        }
        [ExcludeFromCodeCoverage]
        public async Task<string> GetLegacyEncodedCatalogUpdatesAsync(CatalogVersionViewV27 catalogVersionsAlreadyAvailiableAtClient, string marketName = null, CancellationToken cancellationToken = default)
        {
            Debug($"..");

            if (catalogVersionsAlreadyAvailiableAtClient.Market != null && catalogVersionsAlreadyAvailiableAtClient.Market.Count > 0 && catalogVersionsAlreadyAvailiableAtClient.Market[0].Version.StartsWith("2014"))
            {
                Debug("GMA/MW static market catalog request .. redirecting to {nameof(GetLegacyEncodedMarketCatalogsAsync)} ...");
                return (await GetLegacyEncodedMarketCatalogsAsync(false, marketName,cancellationToken)).content;
            }
            if (catalogVersionsAlreadyAvailiableAtClient.Store != null && catalogVersionsAlreadyAvailiableAtClient.Store.Count > 0 && catalogVersionsAlreadyAvailiableAtClient.Store[0].Catalog.Count > 0 && catalogVersionsAlreadyAvailiableAtClient.Store[0].Catalog[0].Version.StartsWith("2015"))
            {
                long restaurantID = long.Parse(catalogVersionsAlreadyAvailiableAtClient.Store[0].StoreId);
                Debug($"GMA/MW static restaurant catalog request .. redirecting to {nameof(GetLegacyEncodedRestaurantCatalogsAsync)}({catalogVersionsAlreadyAvailiableAtClient.Store[0].StoreId}) ...");
                return (await GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, false,cancellationToken)).content;
            }

            throw new Exception("THIS COMBINATION OF CATALOGS IS NO LONGER SUPPORTED !!!");
        }
        [ExcludeFromCodeCoverage]
        private async Task<(string content, string eTag, bool isInvalidated)> GetLegacyEncodedRestaurantCatalogsThroughCacheAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            var (gZippedContent, etag, isInvalidated) = await GetRestaurantCatalogsAsync(restaurantID, cancellationToken);
            return (Convert.ToBase64String(gZippedContent), etag, isInvalidated);
        }
        [ExcludeFromCodeCoverage]
        private async Task<(string catalog, string eTag, bool isInvalidated)> Decode(bool decoded, (string content, string eTag, bool isInvalidated) data)
        {
            var result = data.content;
            if (decoded)
            {
                byte[] gzipped = Convert.FromBase64String(result);
                using (var compressedStream = new MemoryStream(gzipped))
                using (var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
                using (var resultStream = new MemoryStream())
                {
                    await zipStream.CopyToAsync(resultStream);
                    result = Encoding.UTF8.GetString(resultStream.ToArray());
                }
            }
            return (result, data.eTag, data.isInvalidated);
        }

        #endregion

        #region V2 API

        public async Task<(byte[] gZippedSummaryContent, byte[] gZippedFullContent, string eTag, bool isInvalidated)> GetCategoriesAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var marketSettings = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();

            if (string.IsNullOrWhiteSpace(marketName))
            {
                marketName = marketSettings.MarketSettingsLookup.Keys.First(); // fallback for if it is a single market
            }
            else
            {
                marketName = marketName.ToUpper();
            }

            if (!marketSettings.MarketSettingsLookup.ContainsKey(marketName))
            {
                return (null, null, null, false);
            }

            var response = await GetMarketCatalogsThroughCacheAsync(marketName,cancellationToken);
            return (response.content?.V2_Catagories_Summary, response.content?.V2_Catagories, response.eTag, response.isInvalidated);
        }
        public async Task<(byte[] gZippedSummaryContent, byte[] gZippedFullContent, string eTag, bool isInvalidated)> GetMarketCatalogsAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var marketSettings = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();

            if (string.IsNullOrWhiteSpace(marketName))
            {
                marketName = marketSettings.MarketSettingsLookup.Keys.First(); // fallback for if it is a single market
            }
            else
            {
                marketName = marketName.ToUpper();
            }

            if (!marketSettings.MarketSettingsLookup.ContainsKey(marketName))
            {
                return (null, null, null, false);
            }

            var response = await GetMarketCatalogsThroughCacheAsync(marketName, cancellationToken);
            return (response.content?.V2_MarketCatalogs_Summary, response.content?.V2_MarketCatalogs, response.eTag, response.isInvalidated);
        }
        public Task<(byte[] gZippedContent, string eTag, bool isInvalidated)> GetRestaurantCatalogsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            return GetRestaurantCatalogsThroughCacheAsync(restaurantID, cancellationToken);
        }

       #endregion
    }
}
