﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Common;
using System.Diagnostics.CodeAnalysis;
using RestaurantBridge.Gateway.Cloud.V1.Models;

namespace GMACache.RestaurantCatalog
{
    public partial class Service
    {
        public class MarketCatalogsResponses
        {
            public string V1_MarketCatalogs;
            public byte[] V2_MarketCatalogs_Summary;
            public byte[] V2_MarketCatalogs;
            public byte[] V2_Catagories_Summary;
            public byte[] V2_Catagories;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetMarketCatalogKeyFor(string marketName) => $"_{marketName}_";

        private readonly ConcurrentDictionary<string, (MarketCatalogsResponses content, string eTag, bool isInvalidated)> _marketCatalogsResponseCache = new ConcurrentDictionary<string, (MarketCatalogsResponses content, string eTag, bool isInvalidated)>();

        private SemaphoreSlim _marketCatalogFillTaskLookupLock = new SemaphoreSlim(1, 1);
        // CONCURRENT DICTIONARY DOES NOT WORK AS GetOrAdd can call the add method in parallel :(
        private Dictionary<string, Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)>> _marketCatalogFillTaskLookup = new Dictionary<string, Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)>>();

        [ExcludeFromCodeCoverage]
        // since _cache_background_reload_while_serving_existing can't be set
        private async Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)> GetMarketCatalogsThroughCacheAsync(string marketName, CancellationToken cancellationToken = default)
        {
            (MarketCatalogsResponses content, string eTag, bool isInvalidated) response;
            if (!_canUseCache && !_cache_background_reload_while_serving_existing)
            {
                Warn($"{marketName} : RESPONSE CACHE : can't use cache .. running in fallback mode ..");
                var data = await GetFromRedisOrBuildMarketCatalogsAsync(marketName, cancellationToken);
                return (data.content, data.eTag, false);
            }

            if (_marketCatalogsResponseCache.TryGetValue(marketName, out response) && response.content != null)
            {
                Debug($"{marketName} : RESPONSE CACHE : available => {response.eTag}{(response.isInvalidated ? ", INVALIDATED)" : "")}");
                if (response.isInvalidated)
                {
                    await ScheduleReloadCacheAsync("onInvalidatedCacheDetected", marketName, alreadyInvalidated: true);
                }
                return response;
            }

            response = await GetMarketCatalogsFromBuildAsync(marketName, cancellationToken);
            return response;
        }
        private async Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)> GetMarketCatalogsFromBuildAsync(string marketName, CancellationToken cancellationToken = default)
        {
            Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)> fillTask = null;
            await _marketCatalogFillTaskLookupLock.WaitAsync();
            try
            {
                if (!_marketCatalogFillTaskLookup.ContainsKey(marketName))
                {
                    _marketCatalogFillTaskLookup.Add(marketName, FillMemMarketCatalogResponseCacheAsync(marketName, cancellationToken));
                }
                fillTask = _marketCatalogFillTaskLookup[marketName];
            }
            finally
            {
                _marketCatalogFillTaskLookupLock.Release();
            }

            var response = await fillTask;
            return response;
        }
        private async Task<(MarketCatalogsResponses content, string eTag, bool isInvalidated)> FillMemMarketCatalogResponseCacheAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var MARKET_CATALOG_KEY = GetMarketCatalogKeyFor(marketName);
            using (await NamedLock.LockAsync(MARKET_CATALOG_KEY))
            {
                try
                {
                    Info($"{marketName} : RESPONSE CACHE : filling in mem cache ..");
                    var data = await GetFromRedisOrBuildMarketCatalogsAsync(marketName, cancellationToken);
                    var response = (data.content, data.eTag, !_canUseCache);
                    if (response.content != null)
                    {
                        _marketCatalogsResponseCache.AddOrUpdate(marketName, response, (_, __) => response);
                        Debug($"{marketName} : RESPONSE CACHE : filled => {response.eTag}");
                    }
                    return response;
                }
                catch (Exception ex)
                {
                    Debug($"{marketName} : RESPONSE CACHE : fill FAILED : EXCEPTION : {ex.Message}", ex);
                    throw;
                }
                finally
                {
                    await _marketCatalogFillTaskLookupLock.WaitAsync();
                    try
                    {
                        _marketCatalogFillTaskLookup.Remove(marketName);
                    }
                    finally
                    {
                        _marketCatalogFillTaskLookupLock.Release();
                    }
                }
            }
        }
        private async Task<(MarketCatalogsResponses content, string eTag)> GetFromRedisOrBuildMarketCatalogsAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var MARKET_CATALOG_KEY = GetMarketCatalogKeyFor(marketName);

            try
            {
                Info($"{marketName} : RESPONSE CACHE : Redis fill ..");

                var expectedETag = await GetExpectedETagAsync(marketName, cancellationToken);

                Info($"{marketName} : RESPONSE CACHE : Expected eTag : {expectedETag}");

                var redisData = await _stringKeyHashStore.GetAsync(MARKET_CATALOG_KEY, new HashSet<string>(2) { _ETAG_, _CONTENT_ });

                if (redisData.ContainsKey(_ETAG_) && (redisData[_ETAG_] == expectedETag))
                {
                    Info($"{marketName} : RESPONSE CACHE : redis data is valid : eTag {redisData[_ETAG_]} == {expectedETag}");
                    return (JsonConvert.DeserializeObject<MarketCatalogsResponses>(redisData[_CONTENT_]), redisData[_ETAG_]);
                }

                Info($"{marketName} : RESPONSE CACHE : May need to build .. getting resource lock ..");

                var lockID = GetLockIDFor(MARKET_CATALOG_KEY);
                var lockTocken = await _resourceLock.TryTakeAsync(lockID, _catalogBuildLockAutoReleaseTime_ms, _catalogBuildLockTakeTimeout_ms, _catalogBuildLockTakeRetryDelay_ms, cancellationToken);
                if (lockTocken != Guid.Empty)
                {
                    try
                    {
                        Info($"{marketName} : RESPONSE CACHE : Got global resource lock. Checking if already done by other instance .. ");

                        expectedETag = await GetExpectedETagAsync(marketName, cancellationToken);

                        Info($"{marketName} : RESPONSE CACHE : Expected eTag {expectedETag}");

                        redisData = await _stringKeyHashStore.GetAsync(MARKET_CATALOG_KEY, new HashSet<string>(2) { _ETAG_, _CONTENT_ });

                        if (redisData.ContainsKey(_ETAG_) && (redisData[_ETAG_] == expectedETag))
                        {
                            Info($"{marketName} : RESPONSE CACHE : redis data is NOW valid : eTag {redisData[_ETAG_]} == {expectedETag}");
                            return (JsonConvert.DeserializeObject<MarketCatalogsResponses>(redisData[_CONTENT_]), redisData[_ETAG_]);
                        }

                        Info($"{marketName} : RESPONSE CACHE : NEED to build ..");

                        var restaurantCatalogs = await BuildAsync(marketName, cancellationToken);

                        if (restaurantCatalogs.content != null)
                        {
                            Info($"{marketName} : RESPONSE CACHE : Updating Redis ..");
                            await _stringKeyHashStore.SetAsync(MARKET_CATALOG_KEY, new Dictionary<string, string>(2) { { _CONTENT_, JsonConvert.SerializeObject(restaurantCatalogs.content) }, { _ETAG_, restaurantCatalogs.eTag } }, _catalogTTL_ms);

                        }
                        else
                        {
                            Info($"RESPONSE CACHE : NOT Updating Redis, content was null / not found ..");
                        }
                        return restaurantCatalogs;
                    }
                    finally
                    {
                        Info($"{marketName} : RESPONSE CACHE : Releasing global resource lock ..");
                        await _resourceLock.ReleaseAsync(lockID, lockTocken);
                    }
                }
                else
                {
                    Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: MARKET CATALOG RESPONSE CACHE : Failed to get global resource lock ..");
                    throw new Exception($"MARKET CATALOG RESPONSE CACHE : Failed to get global resource lock ..");
                }
            }
            catch (RedisTimeoutException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName}: Redis timeout exception.");
                throw new RedisTimeoutException(ex.Message);
            }
            catch (RedisCommandException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName}: Redis command exception.");
                throw new RedisCommandException(ex.Message);
            }
            catch (RedisConnectionException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName}: Redis connection exception.");
                throw new RedisConnectionException(ex.Message);
            }

            catch (RedisServerException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName}: Redis server exception.");
                throw new RedisServerException(ex.Message);
            }
            catch (RedisException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName}: Redis exception.");
                throw new RedisException(ex.Message);
            }

            catch (MarketCatalogBuildException ex)
            {
                Log.Critical($"{nameof(GetFromRedisOrBuildMarketCatalogsAsync)}: {marketName} : {ex.Message}");
                throw new MarketCatalogBuildException(ex.Message);
            }

            catch (Exception ex)
            {
                Critical($"{marketName} : RESPONSE CACHE : FAILED TO FILL !!! : EXCEPTION : {ex.Message}", ex);
                throw ex;
                // do not mask this exception by returning a value here
                // this is a critical ERROR in all scenarios and should yield a 500 error
                // IF THIS HAPPENS WE ARE IN SEV-1 situation
            }
        }


        private async Task<string> GetExpectedETagAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var V1 = await _V1_marketCatalogBuilder.GetExpectedETagAsync(marketName, cancellationToken);
            var V2 = await _V2_marketCatalogBuilder.GetExpectedETagAsync(marketName, cancellationToken);
            return $"{V1}:{V2}";
        }

        [ExcludeFromCodeCoverage]
        // can't mock CatalogBuilder
        // error:  Unsupported expression: Non-overridable members (here: ) may not be used in setup / verification expressions
        private async Task<(MarketCatalogsResponses content, string eTag)> BuildAsync(string marketName, CancellationToken cancellationToken = default)
        {
            try
            {
                var V1 = await _V1_marketCatalogBuilder.BuildAsync(marketName, cancellationToken);
                var V2 = await _V2_marketCatalogBuilder.BuildAsync(marketName, cancellationToken);

                if (
                    (V1.content != null) &&
                    (V2.gZippedSummaryContent != null) &&
                    (V2.gZippedFullContent != null) &&
                    (V2.gZippedCategoriesSummaryContent != null) &&
                    (V2.gZippedCategoriesFullContent != null)
                    )
                {
                    var responses = new MarketCatalogsResponses();
                    responses.V1_MarketCatalogs = V1.content;
                    responses.V2_MarketCatalogs_Summary = V2.gZippedSummaryContent;
                    responses.V2_MarketCatalogs = V2.gZippedFullContent;
                    responses.V2_Catagories_Summary = V2.gZippedCategoriesSummaryContent;
                    responses.V2_Catagories = V2.gZippedCategoriesFullContent;

                    return (responses, $"{V1.eTag}:{V2.eTag}");
                }
                Error($"Failed to build market catalog for \"{marketName}\" due for catalog builder returning a null value");
            }
            catch (Exception ex)
            {
                Log.Critical($"{nameof(BuildAsync)}:Failed to build market catalog for \"{marketName}\" due to exception.");
                throw new MarketCatalogBuildException($"Exception: {ex.Message} | StackTrace : {ex.StackTrace}");
            }
            return (null, null);
        }

        private async Task ClearMarketCatalogsRedisCacheAsync(string eventName, string marketName)
        {
            Info($"{eventName} : {marketName} : Clearing redis ..");
            var MARKET_CATALOG_KEY = GetMarketCatalogKeyFor(marketName);
            var lockID = GetLockIDFor(MARKET_CATALOG_KEY);
            var lockTocken = await _resourceLock.TryTakeAsync(lockID, _catalogBuildLockAutoReleaseTime_ms, _catalogBuildLockTakeTimeout_ms, _catalogBuildLockTakeRetryDelay_ms);
            if (lockTocken != Guid.Empty)
            {
                try
                {
                    await _stringKeyHashStore.ClearAsync(MARKET_CATALOG_KEY);
                }
                finally
                {
                    await _resourceLock.ReleaseAsync(lockID, lockTocken);
                }
            }
            else
            {
                Error($"{eventName} : {marketName} : FAILED TO GET LOCK : clearing redis anyways ..");
                await _stringKeyHashStore.ClearAsync(MARKET_CATALOG_KEY);
            }
        }
    }
}
