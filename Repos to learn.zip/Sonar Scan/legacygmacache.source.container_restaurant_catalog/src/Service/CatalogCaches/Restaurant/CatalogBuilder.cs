﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Common;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion;

using GMACache.RestaurantCatalog.Models.V1;
using System.Threading;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant
{
    public static class HELPERS
    {
        public static string ToDateTimeIso8601String(this DateTime dt) { return dt.ToString(@"yyyy-MM-dd\THH:mm:ss"); }
        public static string CalculateSHA256HashString(string input)
        {
            using (var hasher = SHA256.Create())
            {
                byte[] data = hasher.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder sb = new StringBuilder();
                foreach (var t in data) { sb.Append(t.ToString("x2")); }
                return sb.ToString();
            }
        }
    }

    public class CatalogBuilder
    {
        const int CATALOG_CONVERTER_VERSION = 6; // increase if any of the used parses are altered to ensure cache invalidation

        private readonly ILog Log;
        private readonly IMarketSettingsProvider _marketSettingsProvider;
        private readonly RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced _restaurantBridgeService;

        public CatalogBuilder(ILog logger, IMarketSettingsProvider marketSettingsProvider, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced restaurantBridgeService)
        {
            Log = logger;
            _marketSettingsProvider = marketSettingsProvider;
            _restaurantBridgeService = restaurantBridgeService;
        }

        public async Task<string> GetExpectedETag(long restaurantID, CancellationToken cancellationToken = default)
        {
            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var detailsETagTask = _restaurantBridgeService.GetRestaurantDetailsETagAsync(restaurantID, cancellationToken);
            var settingETagTask = _restaurantBridgeService.GetRestaurantSettingsETagAsync(restaurantID, cancellationToken);
            var productsETagTask = _restaurantBridgeService.GetRestaurantProductsETagAsync(restaurantID, cancellationToken);

            await Task.WhenAll(detailsETagTask, settingETagTask, productsETagTask);

            var detailsETag = await detailsETagTask;
            var settingETag = await settingETagTask;
            var productsETag = await productsETagTask;

            if (detailsETag == null || settingETag == null || productsETag == null)
            {
                throw new RestaurantNotFoundException($"Store Not Found : {restaurantID} : {detailsETag ?? "null"} : {settingETag ?? "null"} : {productsETag ?? "null"}");
            }

            var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{detailsETag}{settingETag}:{productsETag}";
            return HELPERS.CalculateSHA256HashString(eTagData);
        }

        public async Task<(byte[] gZippedContent, string eTag)> Build(long restaurantID, CancellationToken cancellationToken = default)
        {
                Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Started  ..");

            // GATHER
            Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Getting settings  ..");

            try
            {
                var currentRestaurantDetails = await _restaurantBridgeService.GetRestaurantDetailsAsync(restaurantID, cancellationToken);
                if (currentRestaurantDetails == null)
                {
                    Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Restaurant not found.");
                    return (null, null);
                }

                var marketName = currentRestaurantDetails.marketID;

                var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
                if (!marketSettingsSnapshot.MarketSettingsLookup.ContainsKey(marketName))
                {
                    Log.Critical($"Restaurant.Catalog.Build.{restaurantID} : Restaurant has market \"{marketName}\" which is not configured !!");
                    return (null, null);
                }

                var marketSettings = marketSettingsSnapshot.MarketSettingsLookup[marketName];

                Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Getting settings  ..");
                var (currentRestaurantSettings, settingETag) = await _restaurantBridgeService.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantSettings>(null, restaurantID, cancellationToken);
                if (currentRestaurantSettings == null)
                {
                    Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Restaurant not found.");
                    return (null, null);
                }


                Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Getting products  ..");
                var (currentProducts, productsETag) = await _restaurantBridgeService.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(null, restaurantID, cancellationToken);
                if (currentProducts == null)
                {
                    Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Restaurant not found.");
                    return (null, null);
                }

                Log.Debug($"Restaurant.Catalog.Build.{restaurantID} : Getting {currentProducts.Count} products for complete.");

                var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{settingETag}:{productsETag}";

                if (marketSettings.MarketParameters.IgnoreNullPriceFromRfmAndPos)
                {
                    Log.Debug($"Market.Catalog.Build : Filtering no price products  ..");

                    // THIS IS WHAT BRIDGE USED TO DO - to get the noPriceProductCodes
                    // BUT IT REQUIRES A 500ms to pull and deserialize and build the data at the product container
                    // the result was only ever used HERE in catalog AND catalog had to get all products anyways 
                    // This was a crazy amount of compute time and bandwidth wasted

                    var noPriceProductCodes = new SortedSet<int>();
                    foreach (var product in currentProducts)
                    {
                        if ((product.productInformation.CategoryType == RestaurantBridge.Gateway.Cloud.V1.Models.CategoryType.Product
                            || product.productInformation.CategoryType == RestaurantBridge.Gateway.Cloud.V1.Models.CategoryType.ValueMeal
                            || product.productInformation.CategoryType == RestaurantBridge.Gateway.Cloud.V1.Models.CategoryType.Meal)
                            && product.productInformation.Prices.Any()
                            && product.productInformation.Prices.All(p => p.Price == System.Decimal.Zero
                            && p.IsNullPrice))
                        {
                            noPriceProductCodes.Add(product.ID);
                        }
                    }

                    /////////////////////////////////////////////////////////////////

                    var noPriceProductIDs = new HashSet<int>(noPriceProductCodes);
                    var filteredProducts = currentProducts.Where(p => !noPriceProductIDs.Contains(p.ID)).ToList();
                    var choices = filteredProducts.Where(p => p.productInformation.Choices != null).Select(p => p.productInformation.Choices).ToList();

                    List<int> choiceCodes = new List<int>();
                    choices.ForEach(p => p.ToList().ForEach(cho => choiceCodes.Add(cho.Key)));
                    choiceCodes = choiceCodes.Distinct().ToList();

                    filteredProducts.ForEach(p =>
                    {
                        if (choiceCodes.Contains(p.ID) && p.productInformation.Compositions != null && p.productInformation.Compositions.Count > 0)
                        {
                            var keyToRemove = p.productInformation.Compositions.Where(c => noPriceProductIDs.Contains(c.Key)).Select(c => c.Key).ToList();
                            keyToRemove.ForEach(key => p.productInformation.Compositions.Remove(key));
                        }
                    });

                    currentProducts = filteredProducts;
                }

                // PREP

                var lastModifiedTime = DateTime.UtcNow.ToDateTimeIso8601String();
                var eTag = HELPERS.CalculateSHA256HashString(eTagData);

                // CONVERT

                var restaurantCatalogs = new UpdateDataV27
                {
                    Market = new UpdateMarketDataV27(),
                    Store = new List<UpdateStoreDataV27>() { new UpdateStoreDataV27 { Store = restaurantID.ToString() } }
                };

                {
                    Log.Info($"Restaurant.Catalog.Build.{restaurantID} : Building PromotionViewV27 ...");
                    var orderedCatalog = new List<CatalogPromotionViewV27>();

                    var configurations = marketSettings.MarketPromotions;
                    if (configurations != null)
                    {
                        var restaurantSpecificPromotions = configurations.Where(x => x.StoreId == restaurantID);

                        foreach (var configuration in configurations.OrderBy(i => i.PromoId))
                        {
                            orderedCatalog.Add(configuration.ToCatalogPromotionViewV27());
                        }
                    }
                    restaurantCatalogs.Store[0].PromotionVersion = lastModifiedTime;
                    restaurantCatalogs.Store[0].Promotions = orderedCatalog;
                }

                {
                    Log.Info($"Restaurant.Catalog.Build.{restaurantID} : Building List<CatalogAvailabilityViewV27> ...");

                    var currentProductCodes = currentProducts.Select(p => p.ID);

                    // IDEA-4028  remove all DELIVERY POD from PRODUCTS that have POD_FILTER.DELIVERY but do not have GMA in the list
                    foreach (var product in currentProducts)
                    {
                        if (product.customParameters != null && product.customParameters.ContainsKey("POD_FILTER.DELIVERY"))
                        {
                            if (!product.customParameters["POD_FILTER.DELIVERY"].Split('|', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Contains("GMA"))
                            {
                                Distribution itemReferenceInSet = product.productInformation?.Distributions?.FirstOrDefault(d => "DELIVERY".Equals(d.TypeName, StringComparison.OrdinalIgnoreCase));
                                if (itemReferenceInSet != null)
                                {
                                    product.productInformation?.Distributions?.Remove(itemReferenceInSet);
                                    Log.Info($"Restaurant.Catalog.Build.{restaurantID} : REMOVED DELIVERY POD on product {product.ID} because of POD_FILTER.DELIVERY : {product.customParameters["POD_FILTER.DELIVERY"]}");
                                }
                            }
                        }
                    }

                    //#region SaleType filtering
                    var saleTypes = new HashSet<string> { "PICKUP", "DELIVERY" };
                    if (!string.IsNullOrEmpty(marketSettings.MarketParameters.ProductImportSaleTypeFilter))
                    {
                        saleTypes = marketSettings.MarketParameters.ProductImportSaleTypeFilter.ToUpperInvariant().Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToHashSet();
                    }

                    HashSet<int> currentAvailableProductCodes = new HashSet<int>(currentProductCodes);
                    if (saleTypes.Count > 0)
                    {
                        currentAvailableProductCodes = currentProducts
                          .Where(p => p.productInformation?.Distributions != null && (p.productInformation.Distributions.Any(d => saleTypes.Contains(d.TypeName.ToUpperInvariant()))))
                          .Select(p => p.ID)
                          .ToHashSet();

                        var unavailableProductCodes = currentProductCodes.Except(currentAvailableProductCodes);

                        List<CatalogAvailabilityViewV27> orderedAvailabilityCatalog = unavailableProductCodes.OrderBy(i => i).Select(p => p.ToCatalogAvailabilityViewV27()).ToList();
                        restaurantCatalogs.Store[0].AvailabilityVersion = lastModifiedTime;
                        restaurantCatalogs.Store[0].Availability = orderedAvailabilityCatalog;
                    }

                    Log.Info($"Restaurant.Catalog.Build.{restaurantID} : Building List<CatalogProductViewV27> ...");

                    var filterCatalog = "true".Equals(marketSettings.MarketParameters.ApplyProductImportSaleTypeFilterToProductCatalog);
                    var orderedCatalog = new List<CatalogProductViewV27>();
                    foreach (var product in currentProducts.OrderBy(i => i.ID))
                    {
                        try
                        {
                            if (!filterCatalog || currentAvailableProductCodes.Contains(product.ID))
                            {
                                var legacyProduct = product.ToCatalogProductViewV27(marketSettings);
                                orderedCatalog.Add(legacyProduct);
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Error("BAD MOJO", ex);
                        }
                    }
                    restaurantCatalogs.Store[0].ProductVersion = lastModifiedTime;
                    restaurantCatalogs.Store[0].Products = orderedCatalog;
                }

                {
                    Log.Info($"Restaurant.Catalog.Build.{restaurantID} : Building List<CatalogProductPriceViewFullV27> ...");

                    int currencyDecimalDigits = currentRestaurantSettings.currency.decimalDigits;

                    List<CatalogProductPriceViewFullV27> orderedCatalog = currentProducts.OrderBy(i => i.ID).Select(p => p.ToCatalogProductPriceViewFullV27(currencyDecimalDigits)).ToList();

                    restaurantCatalogs.Store[0].ProductPriceVersion = lastModifiedTime;
                    restaurantCatalogs.Store[0].ProductPrice = orderedCatalog;
                }

                bool ignoreNullValues = marketSettings.MarketParameters.IgnoreNullValuesInCatalog;
                var fullCatalogJSON = JsonConvert.SerializeObject(restaurantCatalogs, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
                var fullCatalogJSONBytes = Encoding.UTF8.GetBytes(fullCatalogJSON);
                byte[] fullCatalogJSONBytesZippedBytes;
                using (var ms = new MemoryStream())
                using (var sw = new GZipStream(ms, CompressionMode.Compress))
                {
                    sw.Write(fullCatalogJSONBytes, 0, fullCatalogJSONBytes.Length);
                    sw.Close();
                    fullCatalogJSONBytesZippedBytes = ms.ToArray();
                    ms.Close();
                }
                return (fullCatalogJSONBytesZippedBytes, eTag);
            }
            catch (Exception ex)
            {
                Log.Error($"{restaurantID} Exception thrown during building restaurant catalog: {ex.StackTrace}");
                throw new RestaurantCatalogBuildException($"Failed to build restaurant catalog data {ex.Message}");
            }
        }
    }
}
