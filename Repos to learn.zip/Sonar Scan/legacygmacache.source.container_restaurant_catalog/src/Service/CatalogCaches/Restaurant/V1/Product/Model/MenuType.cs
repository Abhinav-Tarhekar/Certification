namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    public enum MenuType : int
    {
        Breakfast = 0,
        Regular = 1,
        Both = 2,
        Unknown = -1
    }
}
