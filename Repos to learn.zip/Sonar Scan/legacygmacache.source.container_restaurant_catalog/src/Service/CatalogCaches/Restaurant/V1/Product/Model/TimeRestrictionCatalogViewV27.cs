using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class TimeRestrictionCatalogViewV27
    {
        public string FromTime { get; set; }
        public string ToTime { get; set; }
    }
}
