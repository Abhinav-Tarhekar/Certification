using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class CatalogNamesViewV27
    {
        public int? ProductCode { get; set; }
        public bool IsValid { get; set; }
        public List<CatalogNamesCultureViewV27> Names { get; set; }
    }
}
