using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class CytGroupV27
    {
        public string Group { get; set; }
        
    }
}
