using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class PODCatalogViewV27
    {
        public int SaleTypeID { get; set; }
        public string TypeName { get; set; }
    }
}
