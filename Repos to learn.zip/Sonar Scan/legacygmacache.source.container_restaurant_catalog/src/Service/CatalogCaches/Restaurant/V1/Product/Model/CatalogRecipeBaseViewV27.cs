using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class CatalogRecipeBaseViewV27
    {
        public bool IsCustomerFriendly { get; set; }
        public int MinQuantity { get; set; }
        public int DefaultQuantity { get; set; }
        public int MaxQuantity { get; set; }
        public int RefundTreshold { get; set; }
        public int ChargeTreshold { get; set; }
        public bool CostInclusive { get; set; }
        public int ProductCode { get; set; }
        public int? DefaultSolution { get; set; }
        public int? ReferencePriceProductCode { get; set; }
        public string CytIngredientGroup { get; set; }
        public string CytIngredientType { get; set; }
    }
}
