using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class NutritionV27
    {
        public decimal? Energy { get; set; }
        public string Name { get; set; }
        public string Serving { get; set; }
        public decimal? Caloriesfromfat { get; set; }
        public decimal? Totalfat { get; set; }
        public decimal? TotalfatDV { get; set; }
        public decimal? Saturatedfat { get; set; }
        public decimal? SaturatedfatDV { get; set; }
        public decimal? Transfat { get; set; }
        public decimal? Cholesterol { get; set; }
        public decimal? CholesterolDV { get; set; }
        public decimal? Sodium { get; set; }
        public decimal? SodiumDV { get; set; }
        public decimal? Carbohydrates { get; set; }
        public decimal? CarbohydratesDV { get; set; }
        public decimal? Dietaryfiber { get; set; }
        public decimal? DietaryfiberDV { get; set; }
        public decimal? Sugars { get; set; }
        public decimal? Protein { get; set; }
        public decimal? ProteinDV { get; set; }
        public decimal? Vitaminc { get; set; }
        public decimal? Vitamina { get; set; }
        public decimal? Calcium { get; set; }
        public decimal? Iron { get; set; }
        public string Ingredients { get; set; }
        public string Allergenes { get; set; }
        public string SpecialInfo { get; set; }
        public decimal? KCal { get; set; }
        public bool? ExcludedInAccount { get; set; }
        public bool? SelfPour { get; set; }
        public decimal? MinBeverageSelfPour { get; set; }
        public decimal? MaxBeverageSelfPour { get; set; }
        public decimal? MinBeverageSelfPourKCal { get; set; }
        public decimal? MaxBeverageSelfPourKCal { get; set; }
        public List<int> SelfPourProducts { get; set; }
        public decimal? PortionExtraEnergy { get; set; }
        public decimal? PortionExtraEnergyKCal { get; set; }
        public decimal? PortionLightEnergy { get; set; }
        public decimal? PortionLightEnergyKCal { get; set; }
        public decimal? MinEnergy { get; set; }
        public decimal? MaxEnergy { get; set; }
        public string Suffix { get; set; }
        public List<int> DisclaimerIDs { get; set; }
    }
}