using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class CatalogProductViewV27
    {
        public NutritionV27 Nutrition { get; set; }
        public List<ItemCategoryCatalogViewV27> Categories { get; set; }
        public List<DimensionCatalogViewV27> Dimensions { get; set; }
        public List<int> StaticData { get; set; }
        public List<TimeRestrictionCatalogViewV27> TimeRestriction { get; set; }
        public bool IsPromotional { get; set; }
        public string DisplayImageName { get; set; }
        public bool IsPromotionalChoice { get; set; }
        public string PromotionalLabel { get; set; }
        public string PromotionStartDate { get; set; }
        public string PromotionEndDate { get; set; }
        public List<PromotionRestrictionCatalogViewV27> PromotionRestriction { get; set; }
        public List<int> PromotionsAssociated { get; set; }
        public int ProductCode { get; set; }
        public int FamilyGroupID { get; set; }
        public Nullable<int> RecipeID { get; set; }
        public int MenuTypeID { get; set; }
        public bool IsMcCafe { get; set; }
        public bool IsSalable { get; set; }
        public Nullable<int> MaxChoiceOptionsMOT { get; set; }
        public Nullable<bool> AcceptsLight { get; set; }
        public Nullable<bool> AcceptsOnly { get; set; }
        public int ProductType { get; set; }
        public string ProductUnit { get; set; }
        public int? MaxQttyAllowedPerOrder { get; set; }
        public List<PODCatalogViewV27> POD { get; set; }
        public List<int> ExtendedMenuTypeID { get; set; }
        public CatalogRecipeViewV27 Recipe { get; set; }
        public CatalogNamesViewV27 Names { get; set; }
        public string NutritionPrimaryProductCode { get; set; }
        public SmartRoutingV27 SmartRouting { get; set; }
        public int MaxExtraIngredientsQuantity { get; set; }
        public ProductVolumePrices VolumePrices { get; set; }
        public List<string> Tags { get; set; }
        public string DepositCode { get; set; }
        public decimal? SugarLevyAmount { get; set; }
    }
}
