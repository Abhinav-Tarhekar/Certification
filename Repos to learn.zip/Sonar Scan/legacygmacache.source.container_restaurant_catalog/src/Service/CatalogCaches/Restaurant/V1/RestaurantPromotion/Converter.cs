﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion
{
    public static class Converter
    {
        public static CatalogPromotionViewV27 ToCatalogPromotionViewV27(this Promotion value)
        {
            return new CatalogPromotionViewV27()
            {
                DisplayImageName = value.ImageName ?? string.Empty,
                IsValid = value.IsValid,
                ProductCode = value.ProductCode,
                PromotionID = value.PromoId,
                //TODO StaticData??? PosStoreNumber??
                StaticData = null
            };
        }
    }
}
