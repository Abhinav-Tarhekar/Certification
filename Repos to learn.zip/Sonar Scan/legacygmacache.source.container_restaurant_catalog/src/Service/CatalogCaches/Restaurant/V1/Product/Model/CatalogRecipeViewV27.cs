using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class CatalogRecipeViewV27
    {
        public int RecipeID { get; set; }
        public bool IsValid { get; set; }
        public bool IsCustomerFriendly { get; set; }
        public int? DefaultSolution { get; set; }
        public List<CatalogRecipeBaseViewV27> Ingredients { get; set; }
        public List<CatalogRecipeBaseViewV27> Extras { get; set; }
        public List<CatalogRecipeBaseViewV27> Choices { get; set; }
        public List<CatalogRecipeBaseViewV27> Comments { get; set; }
    }
}
