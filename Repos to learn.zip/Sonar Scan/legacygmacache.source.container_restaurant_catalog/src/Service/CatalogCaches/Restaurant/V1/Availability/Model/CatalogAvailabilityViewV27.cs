using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability.Models
{
    [Serializable]
    public class CatalogAvailabilityViewV27
    {
        public int ProductCode { get; set; }
    }
}
