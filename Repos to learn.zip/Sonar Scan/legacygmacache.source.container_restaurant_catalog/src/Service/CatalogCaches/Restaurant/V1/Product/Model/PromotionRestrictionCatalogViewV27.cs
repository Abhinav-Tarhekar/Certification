using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class PromotionRestrictionCatalogViewV27
    {
        public string DayOfWeekID { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
    }
}
