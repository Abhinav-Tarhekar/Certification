﻿using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class ProductVolumePrices
    {
        public string LabelUnit { get; set; }
        public decimal? MenuItemVolumeUnit { get; set; }
        public decimal? BaselineUnitofMeasure { get; set; }
        public decimal? PriceperUnitEatin { get; set; }
        public decimal? PriceperUnitTakeout { get; set; }
        public decimal? PriceperUnitOther { get; set; }
    }
}
