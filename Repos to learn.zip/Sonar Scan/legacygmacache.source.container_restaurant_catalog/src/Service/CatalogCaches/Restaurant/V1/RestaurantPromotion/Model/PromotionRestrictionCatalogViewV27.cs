using System;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion.Models
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class PromotionRestrictionCatalogViewV27
    {
        public string DayOfWeekID { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
    }
}
