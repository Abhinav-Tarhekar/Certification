﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Murmur;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product
{
    public static class Converter
    {
        private static bool ToNotNullableBool(this bool? value) { return (value.HasValue) ? value.Value : false; }
        private static CatalogNamesViewV27 ToCatalogNamesViewV27(this IDictionary<string, ProductName> names, int productCode, MarketSettings marketSettings)
        {
            var requiredLocales = new HashSet<string>(marketSettings.GetEnabledLanguageLocales());

            var catalogNames = new List<CatalogNamesCultureViewV27>();

            foreach (var name in names)
            {
                if (!requiredLocales.Contains(name.Key)) { continue; }  // the language is not active
                if (names.Values == null) { continue; }                 // the dictionary has no data for this language
                catalogNames.Add(new CatalogNamesCultureViewV27
                {
                    LanguageID = name.Key,
                    Name = name.Value.CustomerDisplayName ?? productCode.ToString(),
                    ShortName = name.Value.CustomerDisplayShortName ?? productCode.ToString(),
                    LongName = name.Value.CustomerDisplayLongName ?? productCode.ToString()
                });
                requiredLocales.Remove(name.Key); // Keep track of what we added alreay be removing from required set
            }

            foreach (var remainingRequredLocale in requiredLocales)
            {
                catalogNames.Add(new CatalogNamesCultureViewV27
                {
                    LanguageID = remainingRequredLocale,
                    LongName = productCode.ToString(),
                    Name = productCode.ToString(),
                    ShortName = productCode.ToString()
                });
            }

            return new CatalogNamesViewV27()
            {
                ProductCode = productCode,
                IsValid = true,
                Names = catalogNames.OrderBy(i => i.LanguageID).ToList()
            };
        }
        private static int ToMenuType(this TimeOfDay timeOfDay)
        {
            switch (timeOfDay)
            {
                case TimeOfDay.Breakfast: return (int)MenuType.Breakfast;
                case TimeOfDay.BlTransition: return (int)MenuType.Both;
                case TimeOfDay.Lunch: return (int)MenuType.Regular;
                default: return (int)MenuType.Unknown;
            }
        }
        private static NutritionV27 ToNutritionV27(this IDictionary<int, ProductNutrition> value)
        {
            if (value == null || value.Count == 0) return null;

            var n = value.First().Value;

            return new NutritionV27()
            {
                Allergenes = n.Allergenes,
                Calcium = (decimal?)n.Calcium,
                Caloriesfromfat = (decimal?)n.Caloriesfromfat,
                Carbohydrates = (decimal?)n.Carbohydrates,
                CarbohydratesDV = (decimal?)n.CarbohydratesDV,
                Cholesterol = (decimal?)n.Cholesterol,
                CholesterolDV = (decimal?)n.CholesterolDV,
                Dietaryfiber = (decimal?)n.Dietaryfiber,
                DietaryfiberDV = (decimal?)n.DietaryfiberDV,
                Energy = (decimal?)n.Energy,
                Ingredients = n.Ingredients,
                Iron = (decimal?)n.Iron,
                Name = n.Name,
                Protein = (decimal?)n.Protein,
                ProteinDV = (decimal?)n.ProteinDV,
                Saturatedfat = (decimal?)n.Saturatedfat,
                SaturatedfatDV = (decimal?)n.Saturatedfatdv,
                Serving = n.Serving,
                Sodium = (decimal?)n.Sodium,
                SodiumDV = (decimal?)n.SodiumDV,
                SpecialInfo = n.SpecialInfo,
                Sugars = (decimal?)n.Sugars,
                Totalfat = (decimal?)n.Totalfat,
                TotalfatDV = (decimal?)n.Totalfatdv,
                Transfat = (decimal?)n.Transfat,
                Vitamina = (decimal?)n.Vitamina,
                Vitaminc = (decimal?)n.Vitaminc,
                ExcludedInAccount = n.ExcludedInAccount,
                SelfPour = n.SelfPour,
                PortionExtraEnergy = (decimal?)n.PortionExtraEnergy,
                PortionExtraEnergyKCal = (decimal?)n.PortionExtraEnergyKCal,
                PortionLightEnergy = (decimal?)n.PortionLightEnergy,
                PortionLightEnergyKCal = (decimal?)n.PortionLightEnergyKCal,
                SelfPourProducts = n.SelfPourProducts,
                KCal = (decimal?)n.KCal,
                MaxBeverageSelfPour = (decimal?)n.MaxBeverageSelfPour,
                MaxBeverageSelfPourKCal = (decimal?)n.MaxBeverageSelfPourKCal,
                MinBeverageSelfPour = (decimal?)n.MinBeverageSelfPour,
                MinBeverageSelfPourKCal = (decimal?)n.MinBeverageSelfPourKCal,
                MinEnergy = (decimal?)n.MinEnergy,
                MaxEnergy = (decimal?)n.MaxEnergy,
                Suffix = n.Suffix,
                DisclaimerIDs = n.DisclaimerIDs
            };
        }

        private static Dictionary<string, PODCatalogViewV27> podToLegacyPODCatalogViewMapping = new Dictionary<string, PODCatalogViewV27>()
        {
            {"DELIVERY", new PODCatalogViewV27() { SaleTypeID = 1, TypeName = "Delivery" }},
            {"DRIVE_THRU", new PODCatalogViewV27() { SaleTypeID = 2, TypeName = "Drivethru" }},
            {"FRONT_COUNTER", new PODCatalogViewV27() { SaleTypeID = 3, TypeName = "FrontCounter" }},
            {"WALK_THRU", new PODCatalogViewV27() { SaleTypeID = 4, TypeName = "WalkThru" }},
            {"COLDKIOSK", new PODCatalogViewV27() { SaleTypeID = 5, TypeName = "ColdKiosk" }},
            {"COLDKIOSK_DRINK", new PODCatalogViewV27() { SaleTypeID = 6, TypeName = "ColdKioskDrink" }},
            {"CSO", new PODCatalogViewV27() { SaleTypeID = 7, TypeName = "Kiosk" }},
            {"HOT", new PODCatalogViewV27() { SaleTypeID = 8, TypeName = "Handheld" }},
            {"MCCAFE", new PODCatalogViewV27() { SaleTypeID = 9, TypeName = "McCafe" }},
            {"MCEXPRESS", new PODCatalogViewV27() { SaleTypeID = 10, TypeName = "McExpress" }},
            {"PICKUP", new PODCatalogViewV27() { SaleTypeID = 11, TypeName = "Pickup" }}
        };
        private static PODCatalogViewV27 ToPODCatalogView(this string saleTypeName)
        {
            PODCatalogViewV27 result = new PODCatalogViewV27()
            {
                SaleTypeID = 0,
                TypeName = saleTypeName
            };

            podToLegacyPODCatalogViewMapping.TryGetValue(saleTypeName, out result);

            return result;
        }
        private static List<PODCatalogViewV27> ToPODCatalogViewList(this List<string> saleTypeNameList)
        {
            List<PODCatalogViewV27> result = new List<PODCatalogViewV27>();

            if (saleTypeNameList != null && saleTypeNameList.Count > 0)
            {
                saleTypeNameList.ForEach(s => result.Add(s.ToPODCatalogView()));
            }

            return result;
        }
        private static int ToLegacyProductType(this CategoryType cat)
        {
            switch (cat)
            {
                case CategoryType.Undefined:
                    return -1;
                case CategoryType.Product:
                    return 0;
                case CategoryType.Ingredient:
                    return 1;
                case CategoryType.Meal:
                    return 2;
                case CategoryType.Group:
                    return 3;
                case CategoryType.Comment:
                    return 4;
                case CategoryType.GiftCert:
                    return 5;
                case CategoryType.Modifier:
                    return 6;
                case CategoryType.DeliveryFee:
                    return 7;
                case CategoryType.Flag:
                    return 8;
                case CategoryType.Choice:
                    return 9;
                case CategoryType.NonFoodProduct:
                    return 10;
                default:
                    return int.MinValue;
            }
        }

        public static CatalogRecipeBaseViewV27 ToCatalogRecipeBaseViewV27(ProductChoice choiceInfo)
        {
            return new CatalogRecipeBaseViewV27
            {
                ChargeTreshold = choiceInfo.ChargeTreshold,
                CostInclusive = choiceInfo.CostInclusive,
                DefaultQuantity = choiceInfo.DefaultQuantity,
                DefaultSolution = choiceInfo.DefaultChoiceSolution == 0 ? (int?)null : choiceInfo.DefaultChoiceSolution,
                IsCustomerFriendly = choiceInfo.IsCustomerFriendly,
                MaxQuantity = choiceInfo.MaxQuantity,
                MinQuantity = choiceInfo.MinQuantity,
                ProductCode = choiceInfo.OriginalID,
                ReferencePriceProductCode = choiceInfo.ReferenceChoice == 0 ? (int?)null : choiceInfo.ReferenceChoice,
                RefundTreshold = choiceInfo.RefundTreshold,
                CytIngredientGroup = choiceInfo.CytIngredientGroup,
                CytIngredientType = choiceInfo.CytIngredientType.ToString().ToUpper()
            };
        }
        public static List<CatalogRecipeBaseViewV27> ToCatalogRecipeBaseViewV27(IDictionary<int, ProductChoice> choiceInfo)
        {
            return (choiceInfo == null) ? new List<CatalogRecipeBaseViewV27>() : choiceInfo.OrderBy(pi => pi.Value.Rank).Select(i => ToCatalogRecipeBaseViewV27(i.Value)).ToList();
        }

        public static CatalogRecipeBaseViewV27 ToCatalogRecipeBaseViewV27(ProductItemConfig productItem)
        {
            CatalogRecipeBaseViewV27 result = new CatalogRecipeBaseViewV27()
            {
                MinQuantity = productItem.MinQuantity,
                IsCustomerFriendly = productItem.IsCustomerFriendly,
                DefaultQuantity = productItem.DefaultQuantity,
                MaxQuantity = productItem.MaxQuantity,
                RefundTreshold = productItem.RefundTreshold,
                ChargeTreshold = productItem.ChargeTreshold,
                CostInclusive = productItem.CostInclusive,
                ProductCode = productItem.OriginalID,
                CytIngredientGroup = productItem.CytIngredientGroup,
                CytIngredientType = productItem.CytIngredientType.ToString().ToUpper()
            };

            return result;
        }
        public static List<CatalogRecipeBaseViewV27> ToCatalogRecipeBaseViewV27(IDictionary<int, ProductItemConfig> productItem, bool filter, int maxChoiceOptions)
        {
            if (productItem == null)
            {
                return new List<CatalogRecipeBaseViewV27>();
            }
            else if (filter)
            {
                return productItem.OrderBy(pi => pi.Value.Rank)
                                  .Take(maxChoiceOptions)
                                  .Select(i => ToCatalogRecipeBaseViewV27(i.Value)).ToList();
            }
            else
            {
                return productItem.OrderBy(pi => pi.Value.Rank).Select(i => ToCatalogRecipeBaseViewV27(i.Value)).ToList();
            }
        }

        #region RecipeHash Calculations
        public static byte[] ToHashByteArray32(this string input)
        {
            return MurmurHash.Create32().ComputeHash(Encoding.UTF8.GetBytes(input));
        }
        public static int ToHashInt32(this string input)
        {
            return Math.Abs(BitConverter.ToInt32(input.ToHashByteArray32(), 0));
        }
        public static string GetRecipeAsStringForHashing(this ProductItemConfig recipe)
        {
            return new StringBuilder()
                .Append(recipe.OriginalID)
                .Append("|")
                .Append(recipe.MinQuantity)
                .Append("|")
                .Append(recipe.DefaultQuantity)
                .Append("|")
                .Append(recipe.MaxQuantity)
                .Append("|")
                .Append(recipe.RefundTreshold)
                .Append("|")
                .Append(recipe.ChargeTreshold)
                .Append("|")
                .Append(recipe.CostInclusive)
                .Append("|")
                .Append(recipe.IsCustomerFriendly)
                .Append("|")
                .Append(recipe.Rank)
                .Append("|")
                .Append(recipe.TypeID)
                .Append("|")
                .Append(recipe.DisplayApart)
                .ToString();
        }
        public static string GetRecipeAsStringForHashing(this ProductInformation product)
        {
            return new StringBuilder()
                .Append(product.Compositions == null ? "" : product.Compositions
                    .OrderBy(kvp => kvp.Key)
                    .Select(kvp => kvp.Value.GetRecipeAsStringForHashing())
                    .Aggregate(new StringBuilder(), (sb, s) => sb.Append(s).Append("|")).ToString()
                )
                .Append("|")
                .Append(product.Choices == null ? "" : product.Choices
                    .OrderBy(kvp => kvp.Key)
                    .Select(kvp => kvp.Value.GetRecipeAsStringForHashing())
                    .Aggregate(new StringBuilder(), (sb, s) => sb.Append(s).Append("|")).ToString()
                )
                .Append("|")
                .Append(product.CanAdds == null ? "" : product.CanAdds
                    .OrderBy(kvp => kvp.Key)
                    .Select(kvp => kvp.Value.GetRecipeAsStringForHashing())
                    .Aggregate(new StringBuilder(), (sb, s) => sb.Append(s).Append("|")).ToString()
                )
                .Append("|")
                .Append(product.Comments == null ? "" : product.Comments
                    .OrderBy(kvp => kvp.Key)
                    .Select(kvp => kvp.Value.GetRecipeAsStringForHashing())
                    .Aggregate(new StringBuilder(), (sb, s) => sb.Append(s).Append("|")).ToString()
                )
                .ToString();
        }
        public static int GetRecipeHash32(this ProductInformation product)
        {
            return product.GetRecipeAsStringForHashing().ToHashInt32();
        }
        #endregion
        private static CatalogRecipeViewV27 ToCatalogRecipeViewV27(this RestaurantProduct product, int maxChoiceOptions)
        {
            var pinfo = product.productInformation;

            return new CatalogRecipeViewV27()
            {
                RecipeID = pinfo.GetRecipeHash32(),
                IsValid = true,
                IsCustomerFriendly = false,
                DefaultSolution = null,
                Ingredients = ToCatalogRecipeBaseViewV27(pinfo.Compositions, pinfo.CategoryType == CategoryType.Choice, maxChoiceOptions),
                Extras = ToCatalogRecipeBaseViewV27(pinfo.CanAdds, false, maxChoiceOptions),
                Choices = ToCatalogRecipeBaseViewV27(pinfo.Choices),
                Comments = ToCatalogRecipeBaseViewV27(pinfo.Comments, false, maxChoiceOptions)
            };
        }

        private static Models.ProductVolumePrices ToLegacyVolumePrices(this RestaurantBridge.Gateway.Cloud.V1.Models.ProductVolumePrices productVolumePrices)
        {
            return new Models.ProductVolumePrices
            {
                BaselineUnitofMeasure = productVolumePrices.BaselineUnitofMeasure,
                LabelUnit = productVolumePrices.LabelUnit,
                MenuItemVolumeUnit = productVolumePrices.MenuItemVolumeUnit,
                PriceperUnitEatin = productVolumePrices.PriceperUnitEatin,
                PriceperUnitOther = productVolumePrices.PriceperUnitOther,
                PriceperUnitTakeout = productVolumePrices.PriceperUnitTakeout
            };
        }

        public static CatalogProductViewV27 ToCatalogProductViewV27(this RestaurantProduct product, MarketSettings marketSettings)
        {
            var productInformation = product.productInformation;

            CatalogProductViewV27 catalogProductViewV27 = new CatalogProductViewV27();

            catalogProductViewV27.ExtendedMenuTypeID = productInformation.MenuTypes?.ToList();

            if (productInformation.DisplayCategories != null && productInformation.DisplayCategories.Count > 0)
            {
                catalogProductViewV27.Categories = productInformation.DisplayCategories.Select(d => new ItemCategoryCatalogViewV27()
                {
                    DisplayCategoryID = d.Value.DisplayCategoryID,// in v270 it is from ROI.DisplayCategory.ExternalID made available through [RRW].[ProductCatalogView]
                    DisplayOrder = d.Value.DisplayOrderDC, // in v270 it is from ROI.StoreItemDisplayCategory.DisplayOrder made available through [RRW].[ProductCatalogView]
                    DisplaySizeSelection = d.Value.DisplayOrderIDC//in v270 it is from ROI.StoreItemDisplayCategory.DisplaySizeSelection made available through [RRW].[ProductCatalogView]
                }).OrderBy(i => i.DisplayCategoryID).ToList();
            }
            #region CYT information
            if (productInformation.IsCytProduct || productInformation.IsCytIngredient || productInformation.DeliverEarlyEnabled.HasValue)
            {
                catalogProductViewV27.SmartRouting = new SmartRoutingV27
                {
                    CytProduct = productInformation.IsCytProduct ? productInformation.CytProductCategory.ToString() : null,
                    CytGroupDisplayOrder = productInformation.CytProductDisplayOrder != null
                        ? productInformation.CytProductDisplayOrder.Select(x => new CytGroupV27
                        {
                            Group = x
                        }).OrderBy(i => i.Group).ToList() : null,
                    CytIngredientGroup = productInformation.IsCytIngredient ? productInformation.CytIngredientGroup : null,
                    CytIngredientType = productInformation.IsCytIngredient ? productInformation.CytIngredientType.ToString().ToUpper() : null,
                    DeliverEarlyEnabled = productInformation.DeliverEarlyEnabled
                };
            }
            #endregion
            catalogProductViewV27.MaxExtraIngredientsQuantity = productInformation.MaxExtraIngredientsQuantity;
            catalogProductViewV27.AcceptsLight = productInformation.AcceptsLight;
            catalogProductViewV27.AcceptsOnly = productInformation.AcceptsOnly;
            catalogProductViewV27.Dimensions = productInformation.Dimensions == null ? null : productInformation.Dimensions.Select(d => new DimensionCatalogViewV27()
            {
                ProductCode = d.Value.OriginalId,
                ShowSizeToCustomer = !d.Value.RemoveFromMOT.ToNotNullableBool(),
                SizeCodeID = d.Value.SizeCodeId
            }).Where(d => d.ShowSizeToCustomer).OrderBy(i => i.ProductCode).ToList();
            catalogProductViewV27.DisplayImageName = productInformation.DisplayImageName ?? string.Empty;
            catalogProductViewV27.FamilyGroupID = (int)productInformation.FamilyId;//looks like a good map, though in v270 it is filled from [RRW].[FamilyGroup]; which has a wider range of values
            catalogProductViewV27.IsMcCafe = productInformation.IsMcCafe.ToNotNullableBool();
            catalogProductViewV27.IsPromotional = productInformation.PromotionInformation == null ? false : productInformation.PromotionInformation.IsPromotional.ToNotNullableBool();
            catalogProductViewV27.IsPromotionalChoice = productInformation.PromotionInformation == null ? false : productInformation.PromotionInformation.IsPromotionalChoice.ToNotNullableBool();
            catalogProductViewV27.IsSalable = productInformation.IsSalable.ToNotNullableBool();
            catalogProductViewV27.MaxChoiceOptionsMOT = marketSettings.MarketParameters.MaxChoiceOptions; //Todo check int->int? conversion.
            catalogProductViewV27.MaxQttyAllowedPerOrder = productInformation.MaxAllowedPerOrder == 0 ? (int?)null : productInformation.MaxAllowedPerOrder;
            catalogProductViewV27.Names = productInformation.Names.ToCatalogNamesViewV27(product.ID, marketSettings);
            catalogProductViewV27.MenuTypeID = productInformation.TimeOfDay.ToMenuType();
            catalogProductViewV27.Nutrition = productInformation.Nutritions.ToNutritionV27();
            catalogProductViewV27.POD = productInformation.Distributions == null ? null : productInformation.Distributions.Select(d => d.TypeName).ToList().ToPODCatalogViewList().OrderBy(c => c.SaleTypeID).ToList();
            catalogProductViewV27.ProductCode = product.ID;
            catalogProductViewV27.ProductUnit = productInformation.ProductUnit;//?? in v270 it is from RRW.StoreItem.ProductUnit (such as "CSO_UNIT_PORTION" or "CSO_UNIT_FILLET") made available through [RRW].[ProductCatalogView]
            catalogProductViewV27.ProductType = (int)productInformation.CategoryType.ToLegacyProductType();//in v270 maps to [RRW].[ItemCategory].ItemCategoryID
            if (productInformation.PromotionInformation == null)
            {
                catalogProductViewV27.PromotionalLabel = string.Empty;
                catalogProductViewV27.PromotionEndDate = string.Empty;
                catalogProductViewV27.PromotionRestriction = null;
                catalogProductViewV27.PromotionsAssociated = null;
                catalogProductViewV27.PromotionStartDate = string.Empty;
            }
            else
            {
                catalogProductViewV27.PromotionalLabel = productInformation.PromotionInformation.PromotionalLabel == null ? string.Empty : productInformation.PromotionInformation.PromotionalLabel;
                catalogProductViewV27.PromotionEndDate = productInformation.PromotionInformation.PromotionEndDate.HasValue == false ? string.Empty : productInformation.PromotionInformation.PromotionEndDate.Value.Date.ToString("yyyy-mm-dd");
                catalogProductViewV27.PromotionRestriction = productInformation.PromotionInformation.PromotionsRestriction == null ?
                                        null : productInformation.PromotionInformation.PromotionsRestriction.Select(p => new PromotionRestrictionCatalogViewV27()
                                        {
                                            DayOfWeekID = p.Value.DayOfWeekID.ToString(),
                                            FromTime = p.Value.FromTime ?? string.Empty,
                                            ToTime = p.Value.ToTime ?? string.Empty
                                        }).OrderBy(i=> i.DayOfWeekID).ThenBy(i=> i.FromTime).ThenBy(i => i.ToTime).ToList();
                catalogProductViewV27.PromotionsAssociated = productInformation.PromotionInformation.PromotionsAssociated == null ?
                                        null : productInformation.PromotionInformation.PromotionsAssociated
                                            .Where(p => p.Value.IsValid.ToNotNullableBool() && p.Value.AssociationType == 1/*as per legacy code*/)
                                            .Select(p => p.Value.PromotionOriginalID).OrderBy(i => i).ToList();
                catalogProductViewV27.PromotionStartDate = productInformation.PromotionInformation.PromotionStartDate.HasValue == false ? string.Empty : productInformation.PromotionInformation.PromotionStartDate.Value.Date.ToString("yyyy-mm-dd");
            }
            catalogProductViewV27.Recipe = product.ToCatalogRecipeViewV27(marketSettings.MarketParameters.MaxChoiceOptions);
            if (catalogProductViewV27.Recipe != null)
            {
                if (catalogProductViewV27.Recipe.Choices == null) { catalogProductViewV27.Recipe.Choices = new List<CatalogRecipeBaseViewV27>(); }
                if (catalogProductViewV27.Recipe.Comments == null) { catalogProductViewV27.Recipe.Comments = new List<CatalogRecipeBaseViewV27>(); }
                if (catalogProductViewV27.Recipe.Extras == null) { catalogProductViewV27.Recipe.Extras = new List<CatalogRecipeBaseViewV27>(); }
                if (catalogProductViewV27.Recipe.Ingredients == null) { catalogProductViewV27.Recipe.Ingredients = new List<CatalogRecipeBaseViewV27>(); }
            }
            catalogProductViewV27.RecipeID = catalogProductViewV27.Recipe.RecipeID;
            catalogProductViewV27.StaticData = new List<int>(); //?? in v270 it is from ROI.StoreItemStaticData.StaticDataID made available through [RRW].[ProductCatalogView]
            catalogProductViewV27.TimeRestriction = productInformation.TimeRestrictions == null ? null : productInformation.TimeRestrictions.Select(t => new TimeRestrictionCatalogViewV27()
            {
                FromTime = t.FromTime ?? string.Empty,
                ToTime = t.ToTime ?? string.Empty
            }).OrderBy(i => i.FromTime).ThenBy(i => i.ToTime).ToList();
            catalogProductViewV27.NutritionPrimaryProductCode = productInformation.NutritionPrimaryProductCode;
            catalogProductViewV27.VolumePrices = productInformation.VolumePrices?.ToLegacyVolumePrices();
            catalogProductViewV27.Tags = productInformation.Tags?.ToList();
            catalogProductViewV27.DepositCode = productInformation.DepositCode;
            catalogProductViewV27.SugarLevyAmount = productInformation.SugarLevyAmount;

            return catalogProductViewV27;
        }
    }
}
