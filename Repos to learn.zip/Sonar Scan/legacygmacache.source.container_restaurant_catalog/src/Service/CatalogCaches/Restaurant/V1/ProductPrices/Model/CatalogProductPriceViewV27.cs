using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices.Models
{
    [Serializable]
    public class CatalogProductPriceViewV27
    {
        public int PriceTypeID { get; set; }
        public decimal Price { get; set; }
        public bool IsValid { get; set; }
    }
}
