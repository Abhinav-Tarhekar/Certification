using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class DimensionCatalogViewV27
    {
        public int SizeCodeID { get; set; }
        public int ProductCode { get; set; }
        public bool ShowSizeToCustomer { get; set; }
    }
}
