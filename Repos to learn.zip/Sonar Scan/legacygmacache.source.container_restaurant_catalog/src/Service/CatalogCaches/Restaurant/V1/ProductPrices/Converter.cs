﻿using System;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices
{
    public static class Converter
    {
        public static CatalogProductPriceViewFullV27 ToCatalogProductPriceViewFullV27(this RestaurantProduct product, int currencyDecimalDigits)
        {
            CatalogProductPriceViewFullV27 catalogProductPriceViewFullV27 = new CatalogProductPriceViewFullV27();
            catalogProductPriceViewFullV27.ProductCode = product.ID;
            catalogProductPriceViewFullV27.Prices = product.productInformation.Prices == null ? null : product.productInformation.Prices.Select(p => new CatalogProductPriceViewV27()
            {
                PriceTypeID = (int)p.PriceType,
                Price = p.Price / Convert.ToDecimal(Math.Pow(10, currencyDecimalDigits)),
                IsValid = true 
            }).OrderBy(i => i.PriceTypeID).ToList();

            return catalogProductPriceViewFullV27;
        }
    }
}
