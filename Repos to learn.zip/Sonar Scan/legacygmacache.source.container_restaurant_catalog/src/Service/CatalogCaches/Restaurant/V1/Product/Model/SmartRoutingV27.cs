using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class SmartRoutingV27
    {
        public string CytProduct { get; set; }
        public List<CytGroupV27> CytGroupDisplayOrder { get; set; }
        public string CytIngredientGroup { get; set; }
        public string CytIngredientType { get; set; }
        public bool? DeliverEarlyEnabled { get; set; }
    }
}
