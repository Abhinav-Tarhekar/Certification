using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
    [Serializable]
    public class ItemCategoryCatalogViewV27
    {
        public int DisplayCategoryID { get; set; }
        public int DisplayOrder { get; set; }
        public int DisplaySizeSelection { get; set; }
    }
}
