using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.ProductPrices.Models
{
    [Serializable]
    public class CatalogProductPriceViewFullV27
    {
        public int ProductCode { get; set; }
        public List<CatalogProductPriceViewV27> Prices { get; set; }
    }
}
