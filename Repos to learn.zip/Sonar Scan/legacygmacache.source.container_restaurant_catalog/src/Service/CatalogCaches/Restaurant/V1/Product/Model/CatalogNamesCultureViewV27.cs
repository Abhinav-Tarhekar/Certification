using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Product.Models
{
   [Serializable]
    public class CatalogNamesCultureViewV27
    {
        public string LanguageID { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }
        public string Name { get; set; }
    }
}
