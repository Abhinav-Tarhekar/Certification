using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.RestaurantPromotion.Models
{
    [Serializable]
    public class CatalogPromotionViewV27
    {
        public int PromotionID { get; set; }
        public int ProductCode { get; set; }
        public bool IsValid { get; set; }
        public string DisplayImageName { get; set; }
        public List<int> StaticData { get; set; }//TODO: DELETAR APOS TERMINAR PERIODO DE ROLLOUT DA REMOÇÂO DO STATICDATA
    }
}
