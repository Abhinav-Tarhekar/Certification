﻿using GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Restaurant.V1.Availability
{
    public static class Converter
    {
        public static CatalogAvailabilityViewV27 ToCatalogAvailabilityViewV27(this int value)
        {
            return new CatalogAvailabilityViewV27 { ProductCode = value };
        }
    }
}
