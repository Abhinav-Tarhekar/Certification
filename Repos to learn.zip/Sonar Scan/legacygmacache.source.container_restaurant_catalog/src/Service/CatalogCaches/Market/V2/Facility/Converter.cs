﻿using System.Collections.Generic;
using System.Linq;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Facility
{
    public static class Converter
    {
        public static Models.Facility ToCatalogFacilityViewV27(this FacilityConfiguration value, MarketSettings marketSettings)
        {
            var names = new List<Models.Name>();
            foreach (var remainingRequredLocale in marketSettings.GetEnabledLanguageLocales())
            {
                names.Add(new Models.Name
                {
                    languageId = remainingRequredLocale,
                    name = value.Description
                });
            }
            return new Models.Facility()
            {
                //FacilityID = value.FacilityId,
                facilityname = value.FacilityCode,
                isValid = true,
                names = names.OrderBy(i => i.languageId).ToList()
            };
        }
    }
}
