﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.TenderTypes
{
    public static class Converter
    {
        public static Models.TenderType ToCatalogTenderTypeViewV27(this TenderTypeConfiguration value, int marketID)
        {
            return new Models.TenderType()
            {
                isValid = true,
                lastModification = value.LastModified.ToString(@"yyyy-MM-dd\THH:mm:ss"), //TODO: Use FormatHelper
                code = (int)value.Code,
                name = value.DisplayName,
                id = (int)value.Code
            };
        }
    }
}
