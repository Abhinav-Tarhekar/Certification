﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Common;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.DisplayCategory;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Facility;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.FeedbackType;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Language;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.MarketPromotion;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.MenuType;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Names;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.PaymentMethod;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.SocialNetworks;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V2.TenderTypes;

using GMACache.RestaurantCatalog.Models.V2;
using System.Threading;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2
{
    public static class HELPERS
    {
        public static string ToDateTimeIso8601String(this DateTime dt) { return dt.ToString(@"yyyy-MM-dd\THH:mm:ss"); }
        public static string CalculateSHA256HashString(string input)
        {
            using (var hasher = SHA256.Create())
            {
                byte[] data = hasher.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder sb = new StringBuilder();
                foreach (var t in data) { sb.Append(t.ToString("x2")); }
                return sb.ToString();
            }
        }
    }

    public class CatalogBuilder
    {
        const int CATALOG_CONVERTER_VERSION = 7; // increase if any of the used parses are altered to ensure cache invalidation

        private readonly ILog Log;
        private readonly IMarketSettingsProvider _marketSettingsProvider;
        private readonly RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced _restaurantBridgeService;

        public CatalogBuilder(ILog logger, IMarketSettingsProvider marketSettingsProvider, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced restaurantBridgeService)
        {
            Log = logger;
            _marketSettingsProvider = marketSettingsProvider;
            _restaurantBridgeService = restaurantBridgeService;
        }

        public async Task<string> GetExpectedETagAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var marketSettings = marketSettingsSnapshot.MarketSettingsLookup[marketName];

            var defaultRestaurantID = marketSettings.MarketParameters.DefaultPosStoreNumber;

            var categoriesETagTask = _restaurantBridgeService.GetRestaurantMenuCategoriesETagAsync(defaultRestaurantID, null,cancellationToken);
            var productsETagTask = _restaurantBridgeService.GetRestaurantProductsETagAsync(defaultRestaurantID,cancellationToken);

            await Task.WhenAll(categoriesETagTask, productsETagTask);

            var categoriesETag = await categoriesETagTask;
            var productsETag = await productsETagTask;

            if (categoriesETag == null || productsETag == null)
            {
                throw new RestaurantNotFoundException($"Default Store Not Found : {defaultRestaurantID} : {categoriesETag ?? "null"} : {productsETag ?? "null"}");
            }
            var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{categoriesETag}:{productsETag}";
            return HELPERS.CalculateSHA256HashString(eTagData);
        }

        public async Task<(byte[] gZippedSummaryContent, byte[] gZippedFullContent, byte[] gZippedCategoriesSummaryContent, byte[] gZippedCategoriesFullContent, string eTag)> BuildAsync(string marketName, CancellationToken cancellationToken = default)
        {

            Log.Debug($"Market.V2.Catalog.Build : Started  ..");

            // GATHER

            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var marketSettings = marketSettingsSnapshot.MarketSettingsLookup[marketName];

            var defaultRestaurantID = marketSettings.MarketParameters.DefaultPosStoreNumber;

            Log.Debug($"Market.V2.Catalog.Build : Getting menu categories : defaultRestaurantID = {defaultRestaurantID} ..");
            var (currentCategories, categoriesETag) = await _restaurantBridgeService.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantBridge.Gateway.Cloud.V1.Models.RestaurantMenuCategory>>(null, defaultRestaurantID, null, cancellationToken);
            if (currentCategories == null)
            {
                throw new RestaurantNotFoundException($"Failed to get MenuCategories for {defaultRestaurantID}");
            }

            Log.Debug($"Market.V2.Catalog.Build : Getting products : defaultRestaurantID = {defaultRestaurantID} ..");
            var (currentProducts, productsETag) = await _restaurantBridgeService.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(null, defaultRestaurantID, cancellationToken);
            if (currentProducts == null)
            {
                throw new RestaurantNotFoundException($"Failed to get Products for {defaultRestaurantID}");
            }

            Log.Debug($"Market.V2.Catalog.Build : Getting {currentProducts.Count} products for complete.");

            var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{categoriesETag}:{productsETag}";

            if (marketSettings.MarketParameters.IgnoreNullPriceFromRfmAndPos)
            {
                Log.Debug($"Market.V2.Catalog.Build : Filtering no price products  ..");

                // THIS IS WHAT BRIDGE USED TO DO - to get the noPriceProductCodes
                // BUT IT REQUIRES A 500ms to pull and deserialize and build the data at the product container
                // the result was only ever used HERE in catalog AND catalog had to get all products anyways 
                // This was a crazy amount of compute time and bandwidth wasted

                var noPriceProductCodes = new SortedSet<int>();
                foreach (var product in currentProducts)
                {
                    if ((product.productInformation.CategoryType == CategoryType.Product
                        || product.productInformation.CategoryType == CategoryType.ValueMeal
                        || product.productInformation.CategoryType == CategoryType.Meal)
                        && product.productInformation.Prices.Any()
                        && product.productInformation.Prices.All(p => p.Price == Decimal.Zero
                        && p.IsNullPrice))
                    {
                        noPriceProductCodes.Add(product.ID);
                    }
                }

                /////////////////////////////////////////////////////////////////

                var noPriceProductIDs = new HashSet<int>(noPriceProductCodes);
                var filteredProducts = currentProducts.Where(p => !noPriceProductIDs.Contains(p.ID)).ToList();
                var choices = filteredProducts.Where(p => p.productInformation.Choices != null).Select(p => p.productInformation.Choices).ToList();

                List<int> choiceCodes = new List<int>();
                choices.ForEach(p => p.ToList().ForEach(cho => choiceCodes.Add(cho.Key)));
                choiceCodes = choiceCodes.Distinct().ToList();

                filteredProducts.ForEach(p =>
                {
                    if (choiceCodes.Contains(p.ID) && p.productInformation.Compositions != null && p.productInformation.Compositions.Count > 0)
                    {
                        var keyToRemove = p.productInformation.Compositions.Where(c => noPriceProductIDs.Contains(c.Key)).Select(c => c.Key).ToList();
                        keyToRemove.ForEach(key => p.productInformation.Compositions.Remove(key));
                    }
                });

                currentProducts = filteredProducts;
            }

            // PREP

            var lastModifiedTime = DateTime.UtcNow.ToDateTimeIso8601String();
            var eTag = HELPERS.CalculateSHA256HashString(eTagData);

            // CONVERT
            var response = new MarketFullResponse();

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogDisplayCategoryViewV27> ...");

                // NPM-8593: remove MenuTypes from DisplayCategory catalog
                var rootItems = currentCategories.Where(c => c.display.parentID == -1).Select(c => c.ID).ToHashSet(); // used to set the parentID back to 0 as the GMA expects
                List<DisplayCategory.Models.Category> orderedCatalog = currentCategories.Where(c => c.display.parentID != -1).Select(c => c.ToCatalogDisplayCategoryViewV27(rootItems)).OrderBy(i => i.id).ToList();
                response.categoryVersion = lastModifiedTime;
                response.categoriesVersion = lastModifiedTime;
                response.categories = orderedCatalog;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogFacilityViewV27> ...");

                var orderedCatalog = new List<Facility.Models.Facility>();
                var configurations = marketSettings.FacilityConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.FacilityCode))
                    {
                        orderedCatalog.Add(configuration.ToCatalogFacilityViewV27(marketSettings));
                    }
                }
                response.facilityVersion = lastModifiedTime;
                response.facilities = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<FeedbackTypeNameViewV27> ...");

                var orderedCatalog = new List<FeedbackType.Models.FeedbackType>();
                var configurations = marketSettings.FeedbackTypeConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Id))
                    {
                        orderedCatalog.Add(configuration.ToFeedbackTypeNameViewV27());
                    }
                }
            
                response.feedbackTypeVersion = lastModifiedTime;
                response.feedbackTypes = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogLanguageViewV27> ...");

                var orderedCatalog = new List<Language.Models.Language>();
                var configurations = marketSettings.LanguageConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Locale))
                    {
                        orderedCatalog.Add(configuration.ToCatalogLanguageViewV27());
                    }
                }
                response.languageVersion = lastModifiedTime;
                response.languages = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build :  List<CatalogPromotionViewV27> ...");

                var orderedCatalog = new List<MarketPromotion.Models.Promotion>();

                var configurations = marketSettings.MarketPromotions;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.PromoId))
                    {
                        orderedCatalog.Add(configuration.ToCatalogPromotionViewV27());
                    }
                }
                response.promotionVersion = lastModifiedTime;
                response.promotions = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogMenuTypeViewV27> ...");

                List<MenuType.Models.MenuType> orderedCatalog = currentCategories.Where(c => c.display.parentID == -1).Select(c => c.ToCatalogMenuTypeViewV27()).OrderBy(i => i.id).ToList();

                response.menuTypeVersion = lastModifiedTime;
                response.menuTypes = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogNamesViewV27> ...");

                var orderedCatalog = new List<Names.Models.Names>();
                foreach (var product in currentProducts.OrderBy(i => i.ID))
                {
                    orderedCatalog.Add(product.productInformation.Names.ToCatalogNamesViewV27(product.ID, marketSettings));
                }
                response.namesVersion = lastModifiedTime;
                response.names = orderedCatalog;
            }
            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogPaymentMethodViewV27> ...");

                var orderedCatalog = new List<PaymentMethod.Models.PaymentMethod>();
                var configurations = marketSettings.PaymentConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Key))
                    {
                        var catalogPaymentMethodViewV27 = configuration.ToCatalogPaymentMethodViewV27(marketSettings);
                        if (catalogPaymentMethodViewV27 != null) // some can have no supported payment methods
                        {
                            orderedCatalog.Add(catalogPaymentMethodViewV27);
                        }
                    }
                }
                response.paymentMethodsVersion = lastModifiedTime;
                response.paymentMethods = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogSocialNetworkViewV27> ...");

                var orderedCatalog = new List<SocialNetworks.Models.SocialNetwork>();
                var configurations = marketSettings.SocialNetworkConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.SocialNetworkID))
                    {
                        orderedCatalog.Add(configuration.ToCatalogSocialNetworkViewV27());
                    }
                }
                response.socialNetworkVersion = lastModifiedTime;
                response.socialNetwork = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V2.Catalog.Build : List<CatalogTenderTypeViewV27> ...");

                var orderedCatalog = new List<TenderTypes.Models.TenderType>();
                var marketID = marketSettings.MarketInformation.MarketID;
                var configurations = marketSettings.TenderTypeConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Code))
                    {
                        orderedCatalog.Add(configuration.ToCatalogTenderTypeViewV27(marketID));
                    }
                }
                response.tenderTypeVersion = lastModifiedTime;
                response.tenderTypes = orderedCatalog; ;
            }

            bool ignoreNullValues = marketSettings.MarketParameters.IgnoreNullValuesInCatalog;

            var status = new Status();
            status.code = 20000;
            status.message = "The call was successful.";
            status.type = "Success";

            var fullResponseSchema = new MarketFullResponseSchema();
            fullResponseSchema.status = status;
            fullResponseSchema.response = response;

            var fullResponseSchemaJSON = JsonConvert.SerializeObject(fullResponseSchema, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
            var fullResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(fullResponseSchemaJSON);
            byte[] fullResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(fullResponseSchemaJSONBytes, 0, fullResponseSchemaJSONBytes.Length);
                sw.Close();
                fullResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var summaryResponse = new MarketSummaryResponse();
            summaryResponse.menuTypeVersion = response.menuTypeVersion;
            summaryResponse.menuTypes = response.menuTypes;
            summaryResponse.tenderTypeVersion = response.tenderTypeVersion;
            summaryResponse.tenderTypes = response.tenderTypes;
            summaryResponse.paymentMethodsVersion = response.paymentMethodsVersion;
            summaryResponse.paymentMethods = response.paymentMethods;
            summaryResponse.feedbackTypeVersion = response.feedbackTypeVersion;
            summaryResponse.feedbackTypes = response.feedbackTypes;

            var summaryResponseSchema = new MarketSummaryResponseSchema();
            summaryResponseSchema.status = status;
            summaryResponseSchema.response = summaryResponse;
            
            var summaryResponseSchemaJSON = JsonConvert.SerializeObject(summaryResponseSchema, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
            var summaryResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(summaryResponseSchemaJSON);
            byte[] summaryResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(summaryResponseSchemaJSONBytes, 0, summaryResponseSchemaJSONBytes.Length);
                sw.Close();
                summaryResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var categoriesFullResponse = new CategoriesFullResponse();
            categoriesFullResponse.categoriesVersion = response.categoriesVersion;
            categoriesFullResponse.categories = response.categories.Select(category => new CategoriesFullResponse.Category {
                id = category.id,
                imageName = string.IsNullOrWhiteSpace(category.imagename) ? null : category.imagename,
                parentId= category.parentId,
                colorCode = string.IsNullOrWhiteSpace(category.colorCode) ? null : category.colorCode,
                isValid = category.isValid,
                displayOrder = category.displayOrder,
                fromTime = string.IsNullOrWhiteSpace(category.fromTime)? null: category.fromTime,
                toTime = string.IsNullOrWhiteSpace(category.toTime) ? null : category.toTime,
                menuTypeId = category.menuTypeId,
                names = category.names.Select(name => new CategoriesFullResponse.Category.Name { locale = name.locale, longname=name.longname, shortname=name.shortname, longName = name.longName, shortName = name.shortName }).ToList()
            }).ToList();
            var categoriesFullResponseSchema = new CategoriesFullResponseSchema();
            categoriesFullResponseSchema.status = status;
            categoriesFullResponseSchema.response = categoriesFullResponse;
            var categoriesFullResponseJSON = JsonConvert.SerializeObject(categoriesFullResponseSchema, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
            var categoriesFullResponseJSONBytes = Encoding.UTF8.GetBytes(categoriesFullResponseJSON);
            byte[] categoriesFullResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(categoriesFullResponseJSONBytes, 0, categoriesFullResponseJSONBytes.Length);
                sw.Close();
                categoriesFullResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var categoriesSummaryResponse = new CategoriesSummaryResponse();
            categoriesSummaryResponse.categoriesVersion = categoriesFullResponse.categoriesVersion;
            categoriesSummaryResponse.categories = categoriesFullResponse.categories.Select(category => new CategoriesSummaryResponse.Category
            {
                id = category.id,
                imageName = category.imageName,
                parentId = category.parentId,
                displayOrder = category.displayOrder,
                menuTypeId = category.menuTypeId,
                names = category.names.Select(name => new CategoriesSummaryResponse.Category.Name { locale = name.locale, longname = name.longname, longName = name.longName }).ToList()
            }).ToList();
            var categoriesSummaryResponseSchema = new CategoriesSummaryResponseSchema();
            categoriesSummaryResponseSchema.status = status;
            categoriesSummaryResponseSchema.response = categoriesSummaryResponse;
            var categoriesSummaryResponseJSON = JsonConvert.SerializeObject(categoriesSummaryResponseSchema, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
            var categoriesSummaryResponseJSONBytes = Encoding.UTF8.GetBytes(categoriesSummaryResponseJSON);
            byte[] categoriesSummaryResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(categoriesSummaryResponseJSONBytes, 0, categoriesSummaryResponseJSONBytes.Length);
                sw.Close();
                categoriesSummaryResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            return (summaryResponseSchemaJSONBytesGZipped, fullResponseSchemaJSONBytesGZipped, categoriesSummaryResponseSchemaJSONBytesGZipped, categoriesFullResponseSchemaJSONBytesGZipped, eTag);
        }
    }
}
