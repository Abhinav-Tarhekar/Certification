using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Names.Models
{
    [Serializable]
    public class CultureName
    {
        public string languageId { get; set; }
        public string shortName { get; set; }
        public string longName { get; set; }
        public string name { get; set; }
    }
}
