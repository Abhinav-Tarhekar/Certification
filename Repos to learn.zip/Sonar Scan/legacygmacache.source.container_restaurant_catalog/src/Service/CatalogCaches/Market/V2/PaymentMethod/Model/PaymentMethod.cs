using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.PaymentMethod.Models
{
    public enum TenderType
    {
        Undefined = 1,
        Cash = 2,
        CashLargeDenomination = 3,
        Check = 4,
        CreditCard = 5
    }
    [Serializable]
    public class PaymentMethod
    {
        public int id { get; set; }
        public bool isEnabled { get; set; }
        public string imageName { get; set; }
        public bool isValid { get; set; }
        public int paymentMode { get; set; }
        public int registrationType { get; set; }
        public int paymentType { get; set; }
        public string registrationReturnURL { get; set; }
        public string paymentReturnURL { get; set; }
        public bool acceptsOneTimePayment { get; set; }
        public bool requiresPassword { get; set; }
        public int rank { get; set; }
        public double minTransactionAmount { get; set; }
        public double thresholdAmount { get; set; }
        public List<TenderType> tenderTypeCodes { get; set; }
        public double CVVThresholdAmount { get; set; }
        public List<PaymentLabel> paymentLabels { get; set; }
        public List<PaymentSchema> paymentSchemas { get; set; }

    }


}
