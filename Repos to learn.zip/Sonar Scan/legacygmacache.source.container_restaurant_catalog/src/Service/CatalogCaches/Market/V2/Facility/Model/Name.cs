using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Facility.Models
{
    [Serializable]
    public class Name
    {
        public string languageId { get; set; }
        public string name { get; set; }
    }
}
