﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.FeedbackType
{
    public static class Converter
    {
        public static Models.FeedbackType ToFeedbackTypeNameViewV27(this FeedbackTypeConfiguration value)
        {
            return new Models.FeedbackType()
            {
                locale = value.Culture,
                id = value.Id,
                isValid = value.IsValid,
                lastModification = value.LastModified.ToString(@"yyyy-MM-dd\THH:mm:ss"), //TODO: Use FormatHelper
                name = value.Name
            };
        }
    }
}
