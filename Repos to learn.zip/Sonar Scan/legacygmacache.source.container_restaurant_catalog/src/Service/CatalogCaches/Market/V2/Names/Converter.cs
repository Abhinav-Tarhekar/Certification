﻿using System.Collections.Generic;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Names
{
    public static class Converter
    {
        public static Models.Names ToCatalogNamesViewV27(this IDictionary<string, ProductName> names, int productCode, MarketSettings marketSettings)
        {
            var requiredLocales = new HashSet<string>(marketSettings.GetEnabledLanguageLocales());

            var catalogNames = new List<Models.CultureName>();

            foreach (var name in names)
            {
                if (!requiredLocales.Contains(name.Key)) { continue; }  // the language is not active
                if (names.Values == null) { continue; }                 // the dictionary has no data for this language
                catalogNames.Add(new Models.CultureName
                {
                    languageId = name.Key,
                    name = name.Value.CustomerDisplayName ?? productCode.ToString(),
                    shortName = name.Value.CustomerDisplayShortName ?? productCode.ToString(),
                    longName = name.Value.CustomerDisplayLongName ?? productCode.ToString()
                });
                requiredLocales.Remove(name.Key); // Keep track of what we added alreay be removing from required set
            }

            foreach (var remainingRequredLocale in requiredLocales)
            {
                catalogNames.Add(new Models.CultureName
                {
                    languageId = remainingRequredLocale,
                    longName = productCode.ToString(),
                    name = productCode.ToString(),
                    shortName = productCode.ToString()
                });
            }

            return new Models.Names()
            {
                ProductCode = productCode,
                isValid = true,
                names = catalogNames.OrderBy(i => i.languageId).ToList()
            };
        }
    }
}
