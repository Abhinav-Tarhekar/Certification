using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.PaymentMethod.Models
{
    [Serializable]
    public class PaymentLabel
    {
        public string locale { get; set; }
        public string name { get; set; }
        public string optionName { get; set; }
    }
}
