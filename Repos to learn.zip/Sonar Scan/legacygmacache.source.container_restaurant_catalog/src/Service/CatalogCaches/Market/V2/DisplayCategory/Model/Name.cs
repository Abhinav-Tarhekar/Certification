using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.DisplayCategory.Models
{
    [Serializable]
    public class Name
    {
        public string locale { get; set; }
        public string longname { get; set; }
        public string shortname { get; set; }
        public string longName { get; set; }
        public string shortName { get; set; }
    }
}
