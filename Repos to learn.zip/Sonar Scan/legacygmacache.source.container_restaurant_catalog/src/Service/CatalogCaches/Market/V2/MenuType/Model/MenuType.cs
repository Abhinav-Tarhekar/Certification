using System.Collections.Generic;
using System;
using Newtonsoft.Json;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.MenuType.Models
{
    [Serializable]
    public class MenuType
    {
        public int id { get; set; }
        public string description { get; set; }
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public bool isValid { get; set; }
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public int sequence { get; set; }
        public List<Name> names { get; set; }
        //public object color { get; set; }
        //public object lastModification { get; set; }
    }
}
