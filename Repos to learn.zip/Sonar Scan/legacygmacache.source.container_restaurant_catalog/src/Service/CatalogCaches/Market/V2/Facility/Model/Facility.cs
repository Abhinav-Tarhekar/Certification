using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Facility.Models
{
    [Serializable]
    public class Facility
    {
        public string facilityname { get; set; }
        public bool isValid { get; set; }
        public List<Name> names { get; set; }
    }
}
