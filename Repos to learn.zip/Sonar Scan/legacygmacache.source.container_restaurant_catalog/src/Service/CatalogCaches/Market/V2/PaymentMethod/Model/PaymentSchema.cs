using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.PaymentMethod.Models
{
    [Serializable]
    public class PaymentSchema
    {
        public int id { get; set; }
        public string name { get; set; }
        public string imageName { get; set; }
        public int? CVVLength { get; set; }
        public bool requiresCVV { get; set; }
        public bool allowCardUpdate { get; set; }
        public bool allowBalanceEnquiry { get; set; }
        public List<double> amount { get; set; }
        public int newPOSTenderId { get; set; }
    }
}
