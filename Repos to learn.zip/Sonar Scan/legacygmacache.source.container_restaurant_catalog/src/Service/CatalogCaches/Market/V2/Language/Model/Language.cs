using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Language.Models
{ 
    [Serializable]
    public class Language
    {
        public string cultureAbbreviation { get; set; }
        public bool isValid { get; set; }
        public string name { get; set; }
        public int languageId { get; set; }
    }
}
