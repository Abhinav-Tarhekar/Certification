namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.SocialNetworks.Models
{
    public class SocialNetwork
    {
        public string customData { get; set; }
        public bool isValid { get; set; }
        public int socialNetworkId { get; set; }
        public string socialNetworkName { get; set; }
    }
}
