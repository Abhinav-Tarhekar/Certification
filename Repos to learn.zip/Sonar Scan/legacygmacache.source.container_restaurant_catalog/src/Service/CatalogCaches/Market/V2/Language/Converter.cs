﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Language
{
    public static class Converter
    {
        public static Models.Language ToCatalogLanguageViewV27(this LanguageConfiguration value)
        {
            return new Models.Language()
            {
                cultureAbbreviation = value.Locale,
                isValid = true,
                //TODO Confirm LanguageId Parameter
                languageId = 0,
                name = value.Locale
            };
        }
    }
}
