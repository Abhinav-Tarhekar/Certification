﻿using System.Collections.Generic;
using System.Linq;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.PaymentMethod
{
    public static class Converter
    {
        public static Models.PaymentMethod ToCatalogPaymentMethodViewV27(this PaymentIntegratorConfiguration value, MarketSettings marketSettings)
        {
            if (value.SupportedPaymentMethods == null) { return null; }

            var orderedLabels = new List<Models.PaymentLabel>();

            foreach (var requiredLocale in marketSettings.GetEnabledLanguageLocales().OrderBy(i => i))
            {
                orderedLabels.Add(
                    new Models.PaymentLabel()
                    {
                        locale = requiredLocale,
                        name = marketSettings.GetTranslationFor("PaymentLabelNames", value.Key.ToString(), requiredLocale) ?? value.Key.ToString(),
                        optionName = marketSettings.GetTranslationFor("PaymentLabelOptionNames", value.Key.ToString(), requiredLocale) ?? value.Key.ToString()
                    });
            }

            var orderedSchemas = new List<Models.PaymentSchema>();
            if (value.SupportedPaymentMethods != null)
            {
                foreach (var pmconf in value.SupportedPaymentMethods.OrderBy(i => i.Key.PaymentIntegrator))
                {
                    orderedSchemas.Add(
                        new Models.PaymentSchema()
                        {
                            allowBalanceEnquiry = pmconf.AllowBalanceInquiry,
                            allowCardUpdate = pmconf.AllowCardUpdate,
                            CVVLength = pmconf.CVVLength,
                            imageName = pmconf.DisplayImageName ?? string.Empty,
                            name = pmconf.Name,
                            id = (int)pmconf.Key.PaymentMethod,
                            requiresCVV = pmconf.RequiresCVV,//not required 
                            amount = pmconf.Amount,
                            newPOSTenderId = pmconf.NewPOSTenderId
                        });
                }
            }

            return new Models.PaymentMethod()
            {
                paymentLabels = orderedLabels,
                paymentSchemas = orderedSchemas,
                acceptsOneTimePayment = value.AcceptsOneTimePayment,
                CVVThresholdAmount = value.CVVThresholdAmount,//not required 
                imageName = value.DisplayImageName ?? string.Empty,
                isEnabled = value.Enabled,
                isValid = true,
                minTransactionAmount = value.MinTransactionAmount,
                id = (int)value.Key,
                paymentMode = (int)value.PaymentMode,
                paymentReturnURL = "", //?
                paymentType = (int)value.PaymentType, //value.Key == PaymentIntegrator.Onsite ? PaymentRequestType.None : PaymentRequestType.API,
                rank = 0, //?
                registrationReturnURL = (value.RegistrationReturnUri == null) ? "" : value.RegistrationReturnUri.ToString(),
                registrationType = (int)value.RegistrationType, //value.Key == PaymentIntegrator.Onsite ? PaymentRequestType.None : PaymentRequestType.WebView,
                //RequiresPwd = value.RequiresPassword, // Not Required
                //ENA-4287: should be a list instead of an int and the name should be "tenderTypeCodes" in plural
                tenderTypeCodes = new List<Models.TenderType>() { (Models.TenderType)value.TenderCode },
                thresholdAmount = value.ThresholdAmount
            };
        }
    }
}
