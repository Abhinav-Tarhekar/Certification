﻿using System.Collections.Generic;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.MenuType
{
    public static class Converter
    {
        public static Models.MenuType ToCatalogMenuTypeViewV27(this RestaurantMenuCategory value)
        {
            return new Models.MenuType()
            {
                id = value.menuID,
                description = value.display.name.Values.FirstOrDefault(),
                isValid = true,
                names = value.display.name.Select(p => new Models.Name { locale = p.Key, longName= p.Value, longname = p.Value, shortName = p.Value, shortname = p.Value }).OrderBy(i => i.locale).ToList(),
                sequence = value.display.order,
            };
        }
    }
}
