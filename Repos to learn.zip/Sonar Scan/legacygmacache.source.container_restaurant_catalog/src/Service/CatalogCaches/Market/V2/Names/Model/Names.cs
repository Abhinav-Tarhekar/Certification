using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.Names.Models
{
    [Serializable]
    public class Names
    {
        public int ProductCode { get; set; }
        public bool isValid { get; set; }
        public List<CultureName> names { get; set; }
    }
}
