using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.DisplayCategory.Models
{
    [Serializable]
    public class Category
    {
        public string colorCode { get; set; }
        public int displayOrder { get; set; }
        public int extendedMenuTypeId { get; set; }
        public string fromTime { get; set; }
        public int id { get; set; }
        public string imagename { get; set; }
        public bool isValid { get; set; }
        public int menuTypeId { get; set; }
        public List<Name> names { get; set; }
        public string toTime { get; set; }
        public int? parentId { get; set; }
    }
}
