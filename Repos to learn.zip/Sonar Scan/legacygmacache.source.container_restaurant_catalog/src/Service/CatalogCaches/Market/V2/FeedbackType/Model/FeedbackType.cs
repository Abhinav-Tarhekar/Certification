using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.FeedbackType.Models
{
    [Serializable]
    public class FeedbackType
    {
        public int id { get; set; }
        public string locale { get; set; }
        public string name { get; set; }
        public bool isValid { get; set; }
        public string lastModification { get; set; }
    }
}
