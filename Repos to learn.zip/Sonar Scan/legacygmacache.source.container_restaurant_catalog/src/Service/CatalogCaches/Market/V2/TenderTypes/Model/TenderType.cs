using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.TenderTypes.Models
{
    [Serializable]
    public class TenderType
    {
        public int id { get; set; }
        public int code { get; set; }
        public string name { get; set; }
        public int minimumTenderAmount { get; set; }
        public int defaultTenderAmountDisplay { get; set; }
        public bool isDefault { get; set; }
        public string lastModification { get; set; }
        public bool isValid { get; set; }
    }
}
