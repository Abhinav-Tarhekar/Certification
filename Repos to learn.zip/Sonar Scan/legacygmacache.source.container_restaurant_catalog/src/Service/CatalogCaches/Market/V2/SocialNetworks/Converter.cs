﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.SocialNetworks
{
    public static class Converter
    {
        public static Models.SocialNetwork ToCatalogSocialNetworkViewV27(this SocialNetworkConfiguration value)
        {
            return new Models.SocialNetwork()
            {
                socialNetworkId = (int)value.SocialNetworkID,
                socialNetworkName = value.SocialNetworkID.ToString(),
                customData = value.CustomData,
                isValid = value.IsValid
            };
        }
    }
}
