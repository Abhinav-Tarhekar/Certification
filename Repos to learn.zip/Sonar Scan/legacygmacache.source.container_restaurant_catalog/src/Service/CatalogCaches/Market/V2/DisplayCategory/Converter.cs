﻿using System.Collections.Generic;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.DisplayCategory
{
    public static class Converter
    {
        public static Models.Category ToCatalogDisplayCategoryViewV27(this RestaurantMenuCategory value, HashSet<int> rootItemIDs)
        {
            return new Models.Category
            {
                displayOrder = value.display.order,
                colorCode = value.display.color,
                id = value.ID,
                imagename = value.display.imageName ?? string.Empty,
                extendedMenuTypeId = value.dayPart.ToMenuType(),
                isValid = true, //value.Information.ToTime is set to be deprecated
                names = value.display.name.Select(p => new Models.Name { locale = p.Key, longName = p.Value, shortName = p.Value, longname = p.Value, shortname = p.Value }).OrderBy(i => i.locale).ToList(),
                parentId = rootItemIDs.Contains(value.display.parentID) ? (int?)null : (int?)value.display.parentID,
                menuTypeId = value.menuID,
                fromTime = string.Empty, // STEFAN: CONFIRM - I found nothing in ecp ever writes this value
                toTime = string.Empty // STEFAN: CONFIRM - I found nothing in ecp ever writes this value
            };
        }
        private static int ToMenuType(this RestaurantMenuDayPart dayPart)
        {
            switch (dayPart)
            {
                case RestaurantMenuDayPart.BREAKFAST: return 0;
                case RestaurantMenuDayPart.BLTRANSITION: return 2;
                case RestaurantMenuDayPart.LUNCH: return 1;
                default: return -1;
            }
        }
    }
}
