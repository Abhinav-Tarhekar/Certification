﻿namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V2.MarketPromotion
{
    public static class Converter
    {
        public static Models.Promotion ToCatalogPromotionViewV27(this MarketSettingsProvider.Models.Promotion value)
        {
            return new Models.Promotion()
            {
                RestaurantID = value.StoreId,
                DisplayImageName = value.ImageName ?? string.Empty,
                IsValid = value.IsValid,
                ProductCode = value.ProductCode,
                PromotionID = value.PromoId
            };
        }
    }
}
