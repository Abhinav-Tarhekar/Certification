using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models
{
    [Serializable]
    public class PaymentMethodSchemaCatalogViewV27
    {
        public int PaymentSchemaID { get; set; }
        public string Name { get; set; }
        public string DisplayImageName { get; set; }
        public List<int> StaticData { get; set; } //TODO: DELETAR APOS TERMINAR PERIODO DE ROLLOUT DA REMOÇÂO DO STATICDATA
        public int? CVVLength { get; set; }
        public bool RequiresCVV { get; set; }
        public bool AllowCardUpdate { get; set; }
        public bool AllowBalanceInquiry { get; set; }
        public List<double> Amount { get; set; }
        public int NewPOSTenderId { get; set; }
    }
}
