﻿using System.Collections.Generic;
using System.Linq;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility
{
    public static class Converter
    {
        public static CatalogFacilityViewV27 ToCatalogFacilityViewV27(this FacilityConfiguration value, MarketSettings marketSettings)
        {
            var names = new List<CatalogFacilityLanguageViewV27>();
            foreach (var remainingRequredLocale in marketSettings.GetEnabledLanguageLocales())
            {
                names.Add(new CatalogFacilityLanguageViewV27
                {
                    LanguageID = remainingRequredLocale,
                    Name = value.Description
                });
            }
            return new CatalogFacilityViewV27()
            {
                //FacilityID = value.FacilityId,
                FacilityName = value.FacilityCode,
                IsValid = true,
                Names = names.OrderBy(i => i.LanguageID).ToList()
            };
        }
    }
}
