namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks.Models
{
    public enum SocialNetwork
    {
        Undefined = 0,
        GooglePlus = 1,
        Facebook = 2,
        WeChat = 3
    }
    public class CatalogSocialNetworkViewV27
    {
        public SocialNetwork SocialNetworkID { get; set; }
        public string SocialNetworkName { get; set; }
        public string CustomData { get; set; }
        public bool IsValid { get; set; }
    }
}
