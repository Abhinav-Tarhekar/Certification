﻿using System.Collections.Generic;
using System.Linq;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod
{
    public static class Converter
    {
        public static CatalogPaymentMethodViewV27 ToCatalogPaymentMethodViewV27(this PaymentIntegratorConfiguration value, MarketSettings marketSettings)
        {
            if (value.SupportedPaymentMethods == null) { return null; }

            var orderedLabels = new List<PaymentLabelViewV27>();

            foreach (var requiredLocale in marketSettings.GetEnabledLanguageLocales().OrderBy(i => i))
            {
                orderedLabels.Add(
                    new PaymentLabelViewV27()
                    {
                        LanguageID = requiredLocale,
                        Name = marketSettings.GetTranslationFor("PaymentLabelNames", value.Key.ToString(), requiredLocale) ?? value.Key.ToString(),
                        OptionName = marketSettings.GetTranslationFor("PaymentLabelOptionNames", value.Key.ToString(), requiredLocale) ?? value.Key.ToString()
                    });
            }

            var orderedSchemas = new List<PaymentMethodSchemaCatalogViewV27>();
            if (value.SupportedPaymentMethods != null)
            {
                foreach (var pmconf in value.SupportedPaymentMethods.OrderBy(i => i.Key.PaymentIntegrator))
                {
                    orderedSchemas.Add(
                        new PaymentMethodSchemaCatalogViewV27()
                        {
                            AllowBalanceInquiry = pmconf.AllowBalanceInquiry,
                            AllowCardUpdate = pmconf.AllowCardUpdate,
                            CVVLength = pmconf.CVVLength,
                            DisplayImageName = pmconf.DisplayImageName ?? string.Empty,
                            Name = pmconf.Name,
                            PaymentSchemaID = (int)pmconf.Key.PaymentMethod,
                            RequiresCVV = pmconf.RequiresCVV,//not required 
                            StaticData = null,
                            Amount = pmconf.Amount,
                            NewPOSTenderId = pmconf.NewPOSTenderId
                        });
                }
            }

            return new CatalogPaymentMethodViewV27()
            {
                PaymentLabels = orderedLabels,
                PaymentSchemas = orderedSchemas,
                AcceptsOneTimePayment = value.AcceptsOneTimePayment,
                CVVThresholdAmount = value.CVVThresholdAmount,//not required 
                DisplayImageName = value.DisplayImageName ?? string.Empty,
                IsEnabled = value.Enabled,
                IsValid = true,
                minTransactionAmount = value.MinTransactionAmount,
                PaymentMethodID = (int)value.Key,
                PaymentMode = (Models.PaymentMode)value.PaymentMode,
                PaymentReturnURL = "", //?
                PaymentType = (Models.PaymentRequestType)value.PaymentType, //value.Key == PaymentIntegrator.Onsite ? PaymentRequestType.None : PaymentRequestType.API,
                Rank = 0, //?
                RegistrationReturnURL = (value.RegistrationReturnUri == null) ? "" : value.RegistrationReturnUri.ToString(),
                RegistrationType = (Models.PaymentRequestType)value.RegistrationType, //value.Key == PaymentIntegrator.Onsite ? PaymentRequestType.None : PaymentRequestType.WebView,
                //RequiresPwd = value.RequiresPassword, // Not Required
                StaticsData = null,
                //ENA-4287: should be a list instead of an int and the name should be "tenderTypeCodes" in plural
                TenderTypeCodes = new List<Models.TenderType>() { (Models.TenderType)value.TenderCode },
                thresholdAmount = value.ThresholdAmount
            };
        }
    }
}
