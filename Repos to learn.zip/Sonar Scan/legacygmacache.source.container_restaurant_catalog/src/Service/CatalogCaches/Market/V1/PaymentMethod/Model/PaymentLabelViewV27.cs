using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models
{
    [Serializable]
    public class PaymentLabelViewV27
    {
        public string LanguageID { get; set; }
        public string Name { get; set; }
        public string OptionName { get; set; }
    }
}
