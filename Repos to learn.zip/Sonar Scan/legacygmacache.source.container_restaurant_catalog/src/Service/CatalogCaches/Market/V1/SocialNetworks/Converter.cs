﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks
{
    public static class Converter
    {
        public static CatalogSocialNetworkViewV27 ToCatalogSocialNetworkViewV27(this SocialNetworkConfiguration value)
        {
            return new CatalogSocialNetworkViewV27()
            {
                SocialNetworkID = (Models.SocialNetwork)value.SocialNetworkID,
                SocialNetworkName = value.SocialNetworkID.ToString(),
                CustomData = value.CustomData,
                IsValid = value.IsValid
            };
        }
    }
}
