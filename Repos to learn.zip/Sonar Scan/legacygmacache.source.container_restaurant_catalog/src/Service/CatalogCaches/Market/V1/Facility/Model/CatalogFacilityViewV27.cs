using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility.Models
{
    [Serializable]
    public class CatalogFacilityViewV27
    {
        //public int FacilityID { get; set; } // STEFAN: removed as it is dangerous to use - use name / code instead.
        public string FacilityName { get; set; }
        public bool IsValid { get; set; }
        public List<CatalogFacilityLanguageViewV27> Names { get; set; }
    }
}
