using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models
{
    public enum PaymentMode
    {
        GatewayAccount = 1,
        GatewayCard = 2,
        OnSiteRemote = 3,
        OnSiteCheckIn = 4
    }
    public enum PaymentRequestType
    {
        API = 1,
        WebView = 2,
        None = 3
    }
    public enum TenderType
    {
        Undefined = 1,
        Cash = 2,
        CashLargeDenomination = 3,
        Check = 4,
        CreditCard = 5
    }
    [Serializable]
    public class CatalogPaymentMethodViewV27
    {
        public List<int> StaticsData { get; set; }//TODO: DELETAR APOS TERMINAR PERIODO DE ROLLOUT DA REMOÇÂO DO STATICDATA
        public List<PaymentLabelViewV27> PaymentLabels { get; set; }
        public int PaymentMethodID { get; set; }
        public bool IsEnabled { get; set; }
        public string DisplayImageName { get; set; }
        public bool IsValid { get; set; }
        public PaymentMode PaymentMode { get; set; }
        public PaymentRequestType RegistrationType { get; set; }
        public PaymentRequestType PaymentType { get; set; }
        public string RegistrationReturnURL { get; set; }
        public string PaymentReturnURL { get; set; }
        public List<PaymentMethodSchemaCatalogViewV27> PaymentSchemas { get; set; }
        public bool AcceptsOneTimePayment { get; set; }
        public bool RequiresPwd { get; set; }
        public int Rank { get; set; }
        public Decimal minTransactionAmount { get; set; }
        public Decimal thresholdAmount { get; set; }
        public Decimal CVVThresholdAmount { get; set; }
        public List<TenderType> TenderTypeCodes { get; set; }
    }


}
