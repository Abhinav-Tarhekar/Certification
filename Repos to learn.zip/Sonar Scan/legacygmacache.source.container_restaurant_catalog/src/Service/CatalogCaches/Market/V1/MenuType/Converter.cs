﻿using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType
{
    public static class Converter
    {
        public static CatalogMenuTypeViewV27 ToCatalogMenuTypeViewV27(this RestaurantMenuCategory value)
        {
            return new CatalogMenuTypeViewV27()
            {
                MenuTypeID = value.menuID,
                Description = value.display.name.Values.FirstOrDefault(),
                IsValid = true,
                Names = value.display.name.Select(p => new MenuTypeNamesV27 { LanguageID = p.Key, LongName = p.Value, ShortName = p.Value }).OrderBy(i => i.LanguageID).ToList(),
                Sequence = value.display.order,
                StaticData = null
            };
        }
    }
}
