﻿using System.Collections.Generic;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory
{
    public static class Converter
    {
        public static CatalogDisplayCategoryViewV27 ToCatalogDisplayCategoryViewV27(this RestaurantMenuCategory value, HashSet<int> rootItemIDs)
        {
            return new CatalogDisplayCategoryViewV27
            {
                CategoryDisplayOrder = value.display.order,
                Colors = value.display.color,
                DisplayCategoryID = value.ID,
                DisplayImageName = value.display.imageName ?? string.Empty,
                ExtendedMenuTypeID = value.menuID,
                IsValid = true, //value.Information.ToTime is set to be deprecated
                Names = value.display.name.Select(p => new CatalogDisplayCategoryCultureViewV27 { LanguageID = p.Key, LongName = p.Value, ShortName = p.Value }).OrderBy(i => i.LanguageID).ToList(),
                ParentDisplayCategoryID = rootItemIDs.Contains(value.display.parentID) ? (int?)null : value.display.parentID,
                StaticData = null, //TODO: analyze gap
                MenuTypeID = value.dayPart.ToMenuType(),
                FromTime = string.Empty, // STEFAN: CONFIRM - I found nothing in ecp ever writes this value
                ToTime = string.Empty // STEFAN: CONFIRM - I found nothing in ecp ever writes this value
            };
        }
        private static int ToMenuType(this RestaurantMenuDayPart dayPart)
        {
            switch (dayPart)
            {
                case RestaurantMenuDayPart.BREAKFAST: return (int)Models.MenuType.Breakfast;
                case RestaurantMenuDayPart.BLTRANSITION: return (int)Models.MenuType.Both;
                case RestaurantMenuDayPart.LUNCH: return (int)Models.MenuType.Regular;
                default: return (int)Models.MenuType.Unknown;
            }
        }
    }
}
