namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns.Models
{
    public class CatalogDynamicOptInView
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public bool Mandatory { get; set; }
        public bool Enabled { get; set; }
        public bool? IsOneWay { get; set; }
    }
}
