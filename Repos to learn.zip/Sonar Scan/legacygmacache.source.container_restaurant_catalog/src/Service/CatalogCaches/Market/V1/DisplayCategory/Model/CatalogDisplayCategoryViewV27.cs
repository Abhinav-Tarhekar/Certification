using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory.Models
{
    [Serializable]
    public class CatalogDisplayCategoryViewV27
    {
        public int DisplayCategoryID { get; set; }
        public string DisplayImageName { get; set; }
        public List<int> StaticData { get; set; } //TODO: DELETAR APOS TERMINAR PERIODO DE ROLLOUT DA REMOÇÂO DO STATICDATA
        public int? ParentDisplayCategoryID { get; set; }
        public string Colors { get; set; }
        public int MenuTypeID { get; set; }
        public bool IsValid { get; set; }
        public int CategoryDisplayOrder { get; set; }
        public List<CatalogDisplayCategoryCultureViewV27> Names { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public int? ExtendedMenuTypeID { get; set; }
    }
}
