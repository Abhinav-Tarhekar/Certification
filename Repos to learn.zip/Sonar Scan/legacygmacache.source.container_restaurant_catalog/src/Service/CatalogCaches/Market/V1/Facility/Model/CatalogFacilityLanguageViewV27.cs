using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility.Models
{
    [Serializable]
    public class CatalogFacilityLanguageViewV27
    {
        public string LanguageID { get; set; }
        public string Name { get; set; }
    }
}
