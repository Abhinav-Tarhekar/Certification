using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType.Models
{
    [Serializable]
    public class FeedbackTypeNameViewV27
    {
        public int FeedbackTypeID { get; set; }
        public string CultureAbbreviation { get; set; }
        public string Name { get; set; }
        public bool IsValid { get; set; }
        public string LastModification { get; set; }
    }
}
