﻿using System.Collections.Generic;
using System.Linq;

using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums
{
    public static class Converter
    {
        public static CustomerCategoryCodesView ToCatalogCustomerEnums(this CustomerEnumsConfiguration value, MarketSettings marketSettings)
        {
            var genders = new List<CustomerCategoryCodes>();
            foreach (var genderCategory in value.Genders)
            {
                if (genderCategory.Code != null)
                {
                    var translations = new Dictionary<string, string>();
                    foreach (var requiredLocale in marketSettings.GetEnabledLanguageLocales().OrderBy(i => i))
                    {
                        var translation = marketSettings.GetTranslationFor("CustomerEnums.Gender", genderCategory.Code, requiredLocale) ?? genderCategory.Code;
                        translations.Add(requiredLocale, translation);
                    }
                    genders.Add(new CustomerCategoryCodes
                    {
                        Id = genderCategory.Id,
                        Code = genderCategory.Code,
                        Translations = translations
                    });
                }
            };
            var enthnicities = new List<CustomerCategoryCodes>();
            foreach (var ethnicityCategory  in value.Enthnicities)
            {
                if (ethnicityCategory.Code != null)
                {
                    var translations = new Dictionary<string, string>();
                    foreach(var requiredLocale in marketSettings.GetEnabledLanguageLocales().OrderBy(i => i))
                    {
                        var translation = marketSettings.GetTranslationFor("CustomerEnums.Ethnicity", ethnicityCategory.Code, requiredLocale) ?? ethnicityCategory.Code;
                        translations.Add(requiredLocale, translation);
                    }
                    genders.Add(new CustomerCategoryCodes
                    {
                        Id = ethnicityCategory.Id,
                        Code = ethnicityCategory.Code,
                        Translations = translations
                    });
                }
            };

            return new CustomerCategoryCodesView()
            {
                Genders = genders.OrderBy(i => i.Id).ToList(),
                Enthnicities = enthnicities.OrderBy(i => i.Id).ToList()
            };
        }
    }
}
