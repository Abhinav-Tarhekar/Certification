using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names.Models
{
    [Serializable]
    public class CatalogNamesCultureViewV27
    {
        public string LanguageID { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }
        public string Name { get; set; }
    }
}
