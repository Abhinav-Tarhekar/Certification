using System.Collections.Generic;
using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType.Models
{
    [Serializable]
    public class CatalogMenuTypeViewV27
    {
        public int MenuTypeID { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }
        public bool IsValid { get; set; }
        public int Sequence { get; set; }
        public List<MenuTypeNamesV27> Names { get; set; }
        public List<int> StaticData { get; set; }
        public string LastModification { get; set; }
    }
}
