using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MarketPromotion.Models
{
    [Serializable]
    public class CatalogPromotionViewV27
    {
        public long RestaurantID { get; set; } // STEFAN ADDED THIS DATA SO THAT ONE CATALOG CACHE CAN SERVE BOTH MARKET AND RESTAURANT AS THERE IS ONLY ONE ID
        public int PromotionID { get; set; }
        public int ProductCode { get; set; }
        public bool IsValid { get; set; }
        public string DisplayImageName { get; set; }
        public List<int> StaticData { get; set; }
    }
}
