using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums.Models
{
    [ExcludeFromCodeCoverage]
    //STEFAN: THIS VIEW IS NOT CACHABLE .. WE SHOULD DEPRECATE IT
    [Serializable]
    public class CatalogCustomerEnumsView
    {
        public string MarketId { get; set; }
        public string Language { get; set; }
        public List<EnumInstance> Genders { get; set; }
        public List<EnumInstance> Enthnicities { get; set; }
    }

    [ExcludeFromCodeCoverage]
    [Serializable]
    public class EnumInstance
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Translation { get; set; }
    }

    // STEFAN: INSTEAD USE THE BELOW FOR CACHING THEN SOMEWHERE IN A CONTROLLER FILTER TO THE ABOVE
    //         IF THIS IS REQUESTED AS A PART OF A OVERALL VIEW .. WELL THEN WE CAN MANY CACHED VIEWS :(

    // BTW ... HOW CAN THE PHONE APP POSSIBLY USED THIS 
    // ARE WE ASKING TO SELF IDENTIFY ? WHY ? IS THIS NOT AN ETHICAL LANDMINE TO STORE THIS ANYWHERE 

    [Serializable]
    public class CustomerCategoryCodesView
    {
        public List<CustomerCategoryCodes> Genders { get; set; }
        public List<CustomerCategoryCodes> Enthnicities { get; set; }
    }
    public class CustomerCategoryCodes
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public Dictionary<string,string> Translations { get; set; }
    }
}
