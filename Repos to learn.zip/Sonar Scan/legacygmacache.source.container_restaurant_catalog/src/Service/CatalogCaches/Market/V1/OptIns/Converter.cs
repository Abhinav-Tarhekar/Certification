﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns
{
    public static class Converter
    {
        public static CatalogDynamicOptInView ToCatalogDynamicOptinView(this DynamicOptinConfiguration value)
        {
            return new CatalogDynamicOptInView
            {
                Type = value.Type,
                Description = value.Description,
                Mandatory = value.Mandatory,
                Enabled = value.Enabled,
                IsOneWay = value.IsOneWay
            };
        }
    }
}
