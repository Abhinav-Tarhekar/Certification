using System;
using System.Collections.Generic;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes.Models
{
    [Serializable]
    public class CatalogTenderTypeViewV27
    {
        public int TenderTypeId { get; set; }
        public int TenderTypeCode { get; set; }
        public string TenderTypeDisplayName { get; set; }
        public int MarketID { get; set; }
        public int MinimumTenderAmount { get; set; }
        public int DefaultTenderAmountDisplay { get; set; }
        public bool IsDefault { get; set; }
        public string LastModification { get; set; }
        public bool IsValid { get; set; }
        public List<int> StaticsData { get; set; }
    }
}
