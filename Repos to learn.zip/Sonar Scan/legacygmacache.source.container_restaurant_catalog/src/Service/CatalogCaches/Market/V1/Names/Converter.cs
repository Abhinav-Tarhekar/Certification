﻿using System.Collections.Generic;
using System.Linq;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names.Models;
using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names
{
    public static class Converter
    {
        public static CatalogNamesViewV27 ToCatalogNamesViewV27(this IDictionary<string, ProductName> names, int productCode, MarketSettings marketSettings)
        {
            var requiredLocales = new HashSet<string>(marketSettings.GetEnabledLanguageLocales());

            var catalogNames = new List<CatalogNamesCultureViewV27>();

            foreach (var name in names)
            {
                if (!requiredLocales.Contains(name.Key)) { continue; }  // the language is not active
                if (names.Values == null) { continue; }                 // the dictionary has no data for this language
                catalogNames.Add(new CatalogNamesCultureViewV27
                {
                    LanguageID = name.Key,
                    Name = name.Value.CustomerDisplayName ?? productCode.ToString(),
                    ShortName = name.Value.CustomerDisplayShortName ?? productCode.ToString(),
                    LongName = name.Value.CustomerDisplayLongName ?? productCode.ToString()
                });
                requiredLocales.Remove(name.Key); // Keep track of what we added alreay be removing from required set
            }

            foreach (var remainingRequredLocale in requiredLocales)
            {
                catalogNames.Add(new CatalogNamesCultureViewV27
                {
                    LanguageID = remainingRequredLocale,
                    LongName = productCode.ToString(),
                    Name = productCode.ToString(),
                    ShortName = productCode.ToString()
                });
            }

            return new CatalogNamesViewV27()
            {
                ProductCode = productCode,
                IsValid = true,
                Names = catalogNames.OrderBy(i => i.LanguageID).ToList()
            };
        }
    }
}
