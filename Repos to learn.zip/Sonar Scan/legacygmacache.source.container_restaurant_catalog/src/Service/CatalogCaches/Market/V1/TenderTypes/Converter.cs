﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes
{
    public static class Converter
    {
        public static CatalogTenderTypeViewV27 ToCatalogTenderTypeViewV27(this TenderTypeConfiguration value, int marketID)
        {
            return new CatalogTenderTypeViewV27()
            {
                IsValid = true,
                LastModification = value.LastModified.ToString(@"yyyy-MM-dd\THH:mm:ss"), //TODO: Use FormatHelper
                MarketID = marketID,
                TenderTypeCode = (int)value.Code,
                TenderTypeDisplayName = value.DisplayName,
                TenderTypeId = (int)value.Code
            };
        }
    }
}
