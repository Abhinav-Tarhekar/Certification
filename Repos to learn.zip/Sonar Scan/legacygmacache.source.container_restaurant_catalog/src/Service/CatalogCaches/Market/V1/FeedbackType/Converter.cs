﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType
{
    public static class Converter
    {
        public static FeedbackTypeNameViewV27 ToFeedbackTypeNameViewV27(this FeedbackTypeConfiguration value)
        {
            return new FeedbackTypeNameViewV27()
            {
                CultureAbbreviation = value.Culture,
                FeedbackTypeID = value.Id,
                IsValid = value.IsValid,
                LastModification = value.LastModified.ToString(@"yyyy-MM-dd\THH:mm:ss"), //TODO: Use FormatHelper
                Name = value.Name
            };
        }
    }
}
