﻿using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language.Models;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language
{
    public static class Converter
    {
        public static CatalogLanguageViewV27 ToCatalogLanguageViewV27(this LanguageConfiguration value)
        {
            return new CatalogLanguageViewV27()
            {
                CultureAbbreviation = value.Locale,
                IsValid = true,
                //TODO Confirm LanguageId Parameter
                LanguageID = 0,
                Name = value.Locale
            };
        }
    }
}
