﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Common;

using RestaurantBridge.Gateway.Cloud.V1.Models;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CustomerEnums;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Facility;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.FeedbackType;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MarketPromotion.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MarketPromotion;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Names;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.OptIns;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.PaymentMethod;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.SocialNetworks;

using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes.Models;
using GMACache.RestaurantCatalog.CatalogCaches.Market.V1.TenderTypes;

using GMACache.RestaurantCatalog.Models.V1;
using System.Threading;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1
{
    public static class HELPERS
    {
        public static string ToDateTimeIso8601String(this DateTime dt) { return dt.ToString(@"yyyy-MM-dd\THH:mm:ss"); }
        public static string CalculateSHA256HashString(string input)
        {
            using (var hasher = SHA256.Create())
            {
                byte[] data = hasher.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder sb = new StringBuilder();
                foreach (var t in data) { sb.Append(t.ToString("x2")); }
                return sb.ToString();
            }
        }
    }

    public class CatalogBuilder
    {
        const int CATALOG_CONVERTER_VERSION = 4; // increase if any of the used parses are altered to ensure cache invalidation

        private readonly ILog Log;
        private readonly IMarketSettingsProvider _marketSettingsProvider;
        private readonly RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced _restaurantBridgeService;

        public CatalogBuilder(ILog logger, IMarketSettingsProvider marketSettingsProvider, RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced restaurantBridgeService)
        {
            Log = logger;
            _marketSettingsProvider = marketSettingsProvider;
            _restaurantBridgeService = restaurantBridgeService;
        }

        public async Task<string> GetExpectedETagAsync(string marketName, CancellationToken cancellationToken = default)
        {
            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var marketSettings = marketSettingsSnapshot.MarketSettingsLookup[marketName];
            var defaultRestaurantID = marketSettings.MarketParameters.DefaultPosStoreNumber;

            var categoriesETagTask = _restaurantBridgeService.GetRestaurantMenuCategoriesETagAsync(defaultRestaurantID, null,cancellationToken);
            var productsETagTask = _restaurantBridgeService.GetRestaurantProductsETagAsync(defaultRestaurantID,cancellationToken);

            await Task.WhenAll(categoriesETagTask, productsETagTask);

            var categoriesETag = await categoriesETagTask;
            var productsETag = await productsETagTask;

            if (categoriesETag == null || productsETag == null)
            {
                throw new RestaurantNotFoundException($"Default Store Not Found : {defaultRestaurantID} : {categoriesETag ?? "null"} : {productsETag ?? "null"}");
            }
            var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{categoriesETag}:{productsETag}";
            return HELPERS.CalculateSHA256HashString(eTagData);
        }

        public async Task<(string content, string eTag)> BuildAsync(string marketName, CancellationToken cancellationToken = default)
        {

            Log.Debug($"Market.V1.Catalog.Build : Started  ..");

            // GATHER

            var marketSettingsSnapshot = await _marketSettingsProvider.GetMarketSettingsSnapshotAsync();
            var marketSettings = marketSettingsSnapshot.MarketSettingsLookup[marketName];
            var defaultRestaurantID = marketSettings.MarketParameters.DefaultPosStoreNumber;

            Log.Debug($"Market.V1.Catalog.Build : Getting menu categories : defaultRestaurantID = {defaultRestaurantID} ..");
            var (currentCategories, categoriesETag) = await _restaurantBridgeService.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantMenuCategory>>(null, defaultRestaurantID, null,cancellationToken);
            if (currentCategories == null)
            {
                throw new RestaurantNotFoundException($"Failed to get MenuCategories for {defaultRestaurantID}");
            }

            Log.Debug($"Market.V1.Catalog.Build : Getting products : defaultRestaurantID = {defaultRestaurantID} ..");
            var (currentProducts, productsETag) = await _restaurantBridgeService.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(null, defaultRestaurantID,cancellationToken);
            if (currentProducts == null)
            {
                throw new RestaurantNotFoundException($"Failed to get Products for {defaultRestaurantID}");
            }

            Log.Debug($"Market.V1.Catalog.Build : Getting {currentProducts.Count} products for complete.");

            var eTagData = $"{CATALOG_CONVERTER_VERSION}:{marketSettingsSnapshot.SnapshotHash}:{categoriesETag}:{productsETag}";

            if (marketSettings.MarketParameters.IgnoreNullPriceFromRfmAndPos)
            {
                Log.Debug($"Market.V1.Catalog.Build : Filtering no price products  ..");

                // THIS IS WHAT BRIDGE USED TO DO - to get the noPriceProductCodes
                // BUT IT REQUIRES A 500ms to pull and deserialize and build the data at the product container
                // the result was only ever used HERE in catalog AND catalog had to get all products anyways 
                // This was a crazy amount of compute time and bandwidth wasted

                var noPriceProductCodes = new SortedSet<int>();
                foreach (var product in currentProducts)
                {
                    if ((product.productInformation.CategoryType == CategoryType.Product
                        || product.productInformation.CategoryType == CategoryType.ValueMeal
                        || product.productInformation.CategoryType == CategoryType.Meal)
                        && product.productInformation.Prices.Any()
                        && product.productInformation.Prices.All(p => p.Price == Decimal.Zero
                        && p.IsNullPrice))
                    {
                        noPriceProductCodes.Add(product.ID);
                    }
                }

                /////////////////////////////////////////////////////////////////

                var noPriceProductIDs = new HashSet<int>(noPriceProductCodes);
                var filteredProducts = currentProducts.Where(p => !noPriceProductIDs.Contains(p.ID)).ToList();
                var choices = filteredProducts.Where(p => p.productInformation.Choices != null).Select(p => p.productInformation.Choices).ToList();

                List<int> choiceCodes = new List<int>();
                choices.ForEach(p => p.ToList().ForEach(cho => choiceCodes.Add(cho.Key)));
                choiceCodes = choiceCodes.Distinct().ToList();

                filteredProducts.ForEach(p =>
                {
                    if (choiceCodes.Contains(p.ID) && p.productInformation.Compositions != null && p.productInformation.Compositions.Count > 0)
                    {
                        var keyToRemove = p.productInformation.Compositions.Where(c => noPriceProductIDs.Contains(c.Key)).Select(c => c.Key).ToList();
                        keyToRemove.ForEach(key => p.productInformation.Compositions.Remove(key));
                    }
                });

                currentProducts = filteredProducts;
            }

            // PREP

            var lastModifiedTime = DateTime.UtcNow.ToDateTimeIso8601String();
            var eTag = HELPERS.CalculateSHA256HashString(eTagData);

            // CONVERT

            var marketCatalogs = new UpdateDataV27
            {
                Market = new UpdateMarketDataV27(),
                Store = new List<UpdateStoreDataV27>()
            };


            {
                Log.Info($"Market.V1.Catalog.Build : CustomerCategoryCodesView ...");

                CustomerCategoryCodesView orderedCatalog = null;
                var configuration = marketSettings.CustomerEnumerationConfiguration;
                if (configuration != null)
                {
                    orderedCatalog = configuration.ToCatalogCustomerEnums(marketSettings);
                }
                marketCatalogs.Market.CustomerEnumsVersion = lastModifiedTime;
                marketCatalogs.Market.CustomerEnums = orderedCatalog;

            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogDisplayCategoryViewV27> ...");

                // NPM-8593: remove MenuTypes from DisplayCategory catalog
                var rootItems = currentCategories.Where(c => c.display.parentID == -1).Select(c => c.ID).ToHashSet(); // used to set the parentID back to 0 as the GMA expects
                List<CatalogDisplayCategoryViewV27> orderedCatalog = currentCategories.Where(c => c.display.parentID != -1).Select(c => c.ToCatalogDisplayCategoryViewV27(rootItems)).OrderBy(i => i.DisplayCategoryID).ToList();
                marketCatalogs.Market.DisplayCategoryVersion = lastModifiedTime;
                marketCatalogs.Market.DisplayCategory = orderedCatalog;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogFacilityViewV27> ...");

                var orderedCatalog = new List<CatalogFacilityViewV27>();
                var configurations = marketSettings.FacilityConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.FacilityCode))
                    {
                        orderedCatalog.Add(configuration.ToCatalogFacilityViewV27(marketSettings));
                    }
                }
                marketCatalogs.Market.FacilityVersion = lastModifiedTime;
                marketCatalogs.Market.Facilities = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<FeedbackTypeNameViewV27> ...");

                var orderedCatalog = new List<FeedbackTypeNameViewV27>();
                var configurations = marketSettings.FeedbackTypeConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Id))
                    {
                        orderedCatalog.Add(configuration.ToFeedbackTypeNameViewV27());
                    }
                }
            
                marketCatalogs.Market.FeedbackTypeNamesVersion = lastModifiedTime;
                marketCatalogs.Market.FeedbackTypeNames = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogLanguageViewV27> ...");

                var orderedCatalog = new List<CatalogLanguageViewV27>();
                var configurations = marketSettings.LanguageConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Locale))
                    {
                        orderedCatalog.Add(configuration.ToCatalogLanguageViewV27());
                    }
                }
                marketCatalogs.Market.LanguageVersion = lastModifiedTime;
                marketCatalogs.Market.Languages = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build :  List<CatalogPromotionViewV27> ...");

                var orderedCatalog = new List<CatalogPromotionViewV27>();

                var configurations = marketSettings.MarketPromotions;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.PromoId))
                    {
                        orderedCatalog.Add(configuration.ToCatalogPromotionViewV27());
                    }
                }
                marketCatalogs.Market.PromotionVersion = lastModifiedTime;
                marketCatalogs.Market.Promotions = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogMenuTypeViewV27> ...");

                List<CatalogMenuTypeViewV27> orderedCatalog = currentCategories.Where(c => c.display.parentID == -1).Select(c => c.ToCatalogMenuTypeViewV27()).OrderBy(i => i.MenuTypeID).ToList();

                marketCatalogs.Market.MenuTypeVersion = lastModifiedTime;
                marketCatalogs.Market.MenuType = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogNamesViewV27> ...");

                var orderedCatalog = new List<CatalogNamesViewV27>();
                foreach (var product in currentProducts.OrderBy(i => i.ID))
                {
                    orderedCatalog.Add(product.productInformation.Names.ToCatalogNamesViewV27(product.ID, marketSettings));
                }
                marketCatalogs.Market.NamesVersion = lastModifiedTime;
                marketCatalogs.Market.Names = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogDynamicOptInView> ...");

                var orderedCatalog = new List<CatalogDynamicOptInView>();
                var configurations = marketSettings.OptIns;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.DynamicOptinId))
                    {
                        orderedCatalog.Add(configuration.ToCatalogDynamicOptinView());
                    }
                }
                marketCatalogs.Market.OptInsVersion = lastModifiedTime;
                marketCatalogs.Market.OptIns = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogPaymentMethodViewV27> ...");

                var orderedCatalog = new List<CatalogPaymentMethodViewV27>();
                var configurations = marketSettings.PaymentConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Key))
                    {
                        var catalogPaymentMethodViewV27 = configuration.ToCatalogPaymentMethodViewV27(marketSettings);
                        if (catalogPaymentMethodViewV27 != null) // some can have no supported payment methods
                        {
                            orderedCatalog.Add(catalogPaymentMethodViewV27);
                        }
                    }
                }
                marketCatalogs.Market.PaymentMethodsVersion = lastModifiedTime;
                marketCatalogs.Market.PaymentMethods = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogSocialNetworkViewV27> ...");

                var orderedCatalog = new List<CatalogSocialNetworkViewV27>();
                var configurations = marketSettings.SocialNetworkConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.SocialNetworkID))
                    {
                        orderedCatalog.Add(configuration.ToCatalogSocialNetworkViewV27());
                    }
                }
                marketCatalogs.Market.SocialNetworkVersion = lastModifiedTime;
                marketCatalogs.Market.SocialNetwork = orderedCatalog; ;
            }

            {
                Log.Info($"Market.V1.Catalog.Build : List<CatalogTenderTypeViewV27> ...");

                var orderedCatalog = new List<CatalogTenderTypeViewV27>();
                var marketID = marketSettings.MarketInformation.MarketID;
                var configurations = marketSettings.TenderTypeConfigurations;
                if (configurations != null)
                {
                    foreach (var configuration in configurations.OrderBy(i => i.Code))
                    {
                        orderedCatalog.Add(configuration.ToCatalogTenderTypeViewV27(marketID));
                    }
                }
                marketCatalogs.Market.TenderTypeVersion = lastModifiedTime;
                marketCatalogs.Market.TenderTypes = orderedCatalog; ;
            }

            bool ignoreNullValues = marketSettings.MarketParameters.IgnoreNullValuesInCatalog;
            var fullCatalogJSON = JsonConvert.SerializeObject(marketCatalogs, new JsonSerializerSettings() { NullValueHandling = ignoreNullValues ? NullValueHandling.Ignore : NullValueHandling.Include });
            var fullCatalogJSONBytes = Encoding.UTF8.GetBytes(fullCatalogJSON);
            byte[] fullCatalogJSONBytesZippedBytes;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(fullCatalogJSONBytes, 0, fullCatalogJSONBytes.Length);
                sw.Close();
                fullCatalogJSONBytesZippedBytes = ms.ToArray();
                ms.Close();
            }

            string fullCatalogJSONBytesZippedBytesBase64EncodedString = Convert.ToBase64String(fullCatalogJSONBytesZippedBytes);

            return (fullCatalogJSONBytesZippedBytesBase64EncodedString, eTag);
        }
    }
}
