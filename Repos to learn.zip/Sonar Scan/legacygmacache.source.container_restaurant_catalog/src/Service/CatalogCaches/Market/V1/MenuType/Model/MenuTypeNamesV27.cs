using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.MenuType.Models
{
    [Serializable]
    public class MenuTypeNamesV27
    {
        public string LanguageID { get; set; }
        public string LongName { get; set; }
        public string ShortName { get; set; }
    }
}
