using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.DisplayCategory.Models
{
    [Serializable]
    public class CatalogDisplayCategoryCultureViewV27
    {
        public string LanguageID { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }
    }
}
