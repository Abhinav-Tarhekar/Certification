using System;

namespace GMACache.RestaurantCatalog.CatalogCaches.Market.V1.Language.Models
{
    [Serializable]
    public class CatalogLanguageViewV27
    {
        public int LanguageID { get; set; }
        public string Name { get; set; }
        public string CultureAbbreviation { get; set; }
        public bool IsValid { get; set; }
    }
}
