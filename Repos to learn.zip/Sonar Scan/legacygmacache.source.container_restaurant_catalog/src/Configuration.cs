﻿using System;
using System.Text;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using Common.Logger;

namespace GMACache.RestaurantCatalog
{
    public interface IConfiguration
    {
        string http_prefix { get; }
        int http_client_timeout_ms { get; }
        string restaurant_bridge_api_url { get; }

        string redis_connection_string { get; }
        int redis_database_number { get; }
        string redis_key_prefix { get; }

        string market_settings_path { get; }

        int catalog_cache_ttl_hours { get; }
        int catalog_cache_build_auto_release_time_ms { get; }
        int catalog_cache_reload_event_consolidation_delay_ms { get; }
        bool catalog_cache_background_reload_while_serving_existing { get; }
        int catalog_cache_reload_throttle_delay_ms { get; }

        string v2_api_cache_control_headers { get; }

        int min_worker_threads { get; }
        int min_io_threads { get; }

        Logger.Level min_log_level { get; }
    }

    public class Configuration : IConfiguration
    {
        private const string HTTP_PREFIX = "http://*:9001";
        private const string HTTP_CLIENT_TIMEOUT_MS = "60000";
        private const string RESTAURANT_BRIDGE_API_URL = "http://localhost:8080/api";

        private const string REDIS_CONNECTION_STRING = "redis:6379";
        private const string REDIS_DATABASE_NUMBER = "0";
        private const string REDIS_KEY_PREFIX = "DEV";

        private const string MARKET_SETTINGS_PATH = "./marketsettings";

        private const string CATALOG_CACHE_TTL_HOURS = "-1";
        private const string CATALOG_CACHE_BUILD_AUTO_RELEASE_TIME_MS = null; // takes default value from HTTP_CLIENT_TIMEOUT_MS unless specifically set;

        private const string CATALOG_CACHE_RELOAD_EVENT_CONSOLIDATION_DELAY_MS = "5000";
        private const string CATALOG_CACHE_BACKGROUND_RELOAD_WHILE_SERVING_EXISTING = "true";
        private const string CATALOG_CACHE_RELOAD_THROTTLE_DELAY_MS = "300000";  // 5 minute delay in situation were RB cloud is down so we don't hammer it 


        private const string V2_API_CACHE_CONTROL_HEADERS = "public, no-cache, must-revalidate, no-transform"; // NOTE: THIS IS A HACK BECAUSE WE NEED TO TUNE TO GMA IMPLEMENTATION .. THE "CORRECT" VALUES ARE THE DEFAULTS HERE

        private const string MIN_WORKER_THREADS = "100";
        private const string MIN_IO_THREADS = "100";

        private const string MIN_LOG_LEVEL = "DEBUG";

        public string http_prefix { get; private set; }
        public int http_client_timeout_ms { get; private set; }
        public string restaurant_bridge_api_url { get; private set; }

        public string redis_connection_string { get; private set; }
        public int redis_database_number { get; private set; }
        public string redis_key_prefix { get; private set; }

        public int catalog_cache_ttl_hours { get; private set; }
        public int catalog_cache_build_auto_release_time_ms { get; private set; }
        public int catalog_cache_reload_event_consolidation_delay_ms { get; private set; }
        public bool catalog_cache_background_reload_while_serving_existing { get; private set; }
        public int catalog_cache_reload_throttle_delay_ms { get; private set; }

        public string market_settings_path { get; private set; }

        public string v2_api_cache_control_headers { get; private set; }

        public int min_worker_threads { get; private set; }
        public int min_io_threads { get; private set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public Logger.Level min_log_level { get; private set; }

        public Configuration()
        {
            http_prefix = Environment.GetEnvironmentVariable("HTTP_PREFIX") ?? HTTP_PREFIX;
            http_client_timeout_ms = int.Parse(Environment.GetEnvironmentVariable("HTTP_CLIENT_TIMEOUT_MS") ?? HTTP_CLIENT_TIMEOUT_MS);
            restaurant_bridge_api_url = Environment.GetEnvironmentVariable("RESTAURANT_BRIDGE_API_URL") ?? RESTAURANT_BRIDGE_API_URL;

            redis_connection_string = Environment.GetEnvironmentVariable("REDIS_CONNECTION_STRING") ?? REDIS_CONNECTION_STRING;
            redis_database_number = int.Parse(Environment.GetEnvironmentVariable("REDIS_DATABASE_NUMBER") ?? REDIS_DATABASE_NUMBER);
            redis_key_prefix = Environment.GetEnvironmentVariable("REDIS_KEY_PREFIX") ?? REDIS_KEY_PREFIX;

            catalog_cache_ttl_hours = int.Parse(Environment.GetEnvironmentVariable("CATALOG_CACHE_TTL_HOURS") ?? CATALOG_CACHE_TTL_HOURS);
            catalog_cache_build_auto_release_time_ms = int.Parse(Environment.GetEnvironmentVariable("CATALOG_CACHE_BUILD_AUTO_RELEASE_TIME_MS") ?? CATALOG_CACHE_BUILD_AUTO_RELEASE_TIME_MS ?? http_client_timeout_ms.ToString());
            catalog_cache_reload_event_consolidation_delay_ms = int.Parse(Environment.GetEnvironmentVariable("CATALOG_CACHE_RELOAD_EVENT_CONSOLIDATION_DELAY_MS") ?? CATALOG_CACHE_RELOAD_EVENT_CONSOLIDATION_DELAY_MS);
            catalog_cache_background_reload_while_serving_existing = "true".Equals(Environment.GetEnvironmentVariable("CATALOG_CACHE_BACKGROUND_RELOAD_WHILE_SERVING_EXISITNG") ?? CATALOG_CACHE_BACKGROUND_RELOAD_WHILE_SERVING_EXISTING, StringComparison.OrdinalIgnoreCase);
            catalog_cache_reload_throttle_delay_ms = int.Parse(Environment.GetEnvironmentVariable("CATALOG_CACHE_RELOAD_THROTTLE_DELAY_MS") ?? CATALOG_CACHE_RELOAD_THROTTLE_DELAY_MS);

            market_settings_path = Environment.GetEnvironmentVariable("MARKET_SETTINGS_PATH") ?? MARKET_SETTINGS_PATH;

            v2_api_cache_control_headers = Environment.GetEnvironmentVariable("V2_API_CACHE_CONTROL_HEADERS") ?? V2_API_CACHE_CONTROL_HEADERS;

            min_worker_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_WORKER_THREADS") ?? MIN_WORKER_THREADS);
            min_io_threads = int.Parse(Environment.GetEnvironmentVariable("MIN_IO_THREADS") ?? MIN_IO_THREADS);

            min_log_level = (Logger.Level)Enum.Parse(typeof(Logger.Level), Environment.GetEnvironmentVariable("MIN_LOG_LEVEL") ?? MIN_LOG_LEVEL);
        }

        private string _configurationSummary;
        public override string ToString()
        {
            if (_configurationSummary == null)
            {
                StringBuilder configurationSummary = new StringBuilder();
                configurationSummary.AppendLine("CONFIGURATION :");
                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                configurationSummary.AppendLine($"http_prefix: {http_prefix}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"http_client_timeout_ms: {http_client_timeout_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"restaurant_bridge_api_url: {restaurant_bridge_api_url}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"redis_connection_string: {redis_connection_string}");
                configurationSummary.AppendLine($"redis_database_number:   {redis_database_number}");
                configurationSummary.AppendLine($"redis_key_prefix:        {redis_key_prefix}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"catalog_cache_ttl_hours:                                {catalog_cache_ttl_hours}");
                configurationSummary.AppendLine($"catalog_cache_build_auto_release_time_ms:               {catalog_cache_build_auto_release_time_ms}");
                configurationSummary.AppendLine($"catalog_cache_reload_event_consolidation_delay_ms:      {catalog_cache_reload_event_consolidation_delay_ms}");
                configurationSummary.AppendLine($"catalog_cache_background_reload_while_serving_exisitng: {catalog_cache_background_reload_while_serving_existing}");
                configurationSummary.AppendLine($"catalog_cache_reload_throttle_delay_ms:                 {catalog_cache_reload_throttle_delay_ms}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"market_settings_path: {market_settings_path}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_worker_threads:  {min_worker_threads}");
                configurationSummary.AppendLine($"min_io_threads:      {min_io_threads}");
                configurationSummary.AppendLine();
                configurationSummary.AppendLine($"min_log_level: {min_log_level}");
                configurationSummary.AppendLine(string.Empty.PadRight(80, '*'));
                _configurationSummary = configurationSummary.ToString();
            }
            return _configurationSummary;
        }
    }
}