﻿using Common;
using Common.RequestContext;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RestaurantBridge.Gateway.Cloud.V1;
using Swashbuckle.AspNetCore.Filters;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace GMACache.RestaurantCatalog
{
    public class Startup
    {
        private static readonly string SERVICE_NAME = System.Reflection.Assembly.GetEntryAssembly().EntryPoint.DeclaringType.Namespace;

        private readonly ILog Log;
        private readonly IConfiguration Configuration;
        private readonly Regex typeCleanerRegex = new Regex($"{SERVICE_NAME}\\.([^\\.]+)\\.Legacy\\.Models\\.(.*)", RegexOptions.Compiled);

        public Startup(ILog log, IConfiguration configuration)
        {
            Log = log;
            Configuration = configuration;
        }

        private class ApiExplorerGroupPerVersionConvention : IControllerModelConvention
        {
            public void Apply(ControllerModel controller)
            {
                var controllerNamespace = controller.ControllerType.Namespace;
                var apiVersion = controllerNamespace?.Split('.').Last().ToLower();
                controller.ApiExplorer.GroupName = apiVersion;
            }
        }

        public void ConfigureServices(IServiceCollection services)
        {
            var marketSettingsProvider = new MarketSettingsProvider.MarketSettingsProvider_File(Log, Configuration.market_settings_path);
            services.AddSingleton<IMarketSettingsProvider>(marketSettingsProvider);
            services.AddSingleton<Common.IResourceLock>((_) =>
            {
                var instance = new Common.ResourceLock.ResourceLock_Redis(
                    Log,
                    Configuration.redis_connection_string,
                    Configuration.redis_database_number,
                    $"{Configuration.redis_key_prefix}:GMACache:{nameof(RestaurantCatalog)}");
                instance.StartAsync().Wait();
                return instance;
            });
            services.AddSingleton<Common.IStringKeyHashStore>((_) =>
            {
                var instance = new Common.StringKeyHashStore.StringKeyHashStore_Redis(
                    Log,
                    Configuration.redis_connection_string,
                    Configuration.redis_database_number,
                    $"{Configuration.redis_key_prefix}:GMACache:{nameof(RestaurantCatalog)}");
                instance.StartAsync().Wait();
                return instance;
            });
            services.AddSingleton<IClientAdvanced>((_) =>
            {
                var client = new Client(Log, Configuration.restaurant_bridge_api_url, SERVICE_NAME, () => RequestContext.CorrelationID.Value, Configuration.http_client_timeout_ms);
                return client;
            });
            services.AddSingleton<CatalogCaches.Market.V1.CatalogBuilder, CatalogCaches.Market.V1.CatalogBuilder>();
            services.AddSingleton<CatalogCaches.Market.V2.CatalogBuilder, CatalogCaches.Market.V2.CatalogBuilder>();
            services.AddSingleton<CatalogCaches.Restaurant.CatalogBuilder, CatalogCaches.Restaurant.CatalogBuilder>();
            services.AddSingleton<IService, RestaurantCatalog.Service>();

            services.AddControllers();
            services.AddMvc(c => c.Conventions.Add(new ApiExplorerGroupPerVersionConvention())).AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;

                var nullHandling = NullValueHandling.Include;
                var marketSnapshot = marketSettingsProvider.GetMarketSettingsSnapshotAsync().Result;
                var marketSettings = marketSnapshot.MarketSettingsLookup[marketSnapshot.MarketSettingsLookup.Keys.First()];
                if (marketSettings.MarketParameters.IgnoreNullValuesInCatalog)
                {
                    nullHandling = NullValueHandling.Ignore;
                }

                options.SerializerSettings.NullValueHandling = nullHandling;
            });

            services.Configure<GzipCompressionProviderOptions>(options => options.Level = System.IO.Compression.CompressionLevel.Optimal);
            services.AddResponseCompression();

            services.AddSwaggerGen(c =>
            {
                c.EnableAnnotations();
                c.OperationFilter<AddHeaderOperationFilter>(RequestContext.HTTP_HEADER_KEY_CLIENT_NAME, "The name of the service that is making the request", false);
                c.OperationFilter<AddHeaderOperationFilter>(RequestContext.HTTP_HEADER_KEY_CORRELATION_ID, "The correlation ID for this request.", false);
                c.CustomSchemaIds((type) => (typeCleanerRegex.IsMatch(type.FullName)) ? typeCleanerRegex.Replace(type.FullName, "$1.$2") : (type.FullName.Replace("GMACache.RestaurantCatalog.", "")).Replace("+",",")) ;
                c.SwaggerDoc("diagnostic", new OpenApiInfo { Title = $"{SERVICE_NAME} DIAGNOSTICS", Version = "diagnostic" });
                c.SwaggerDoc("v1", new OpenApiInfo { Title = $"{SERVICE_NAME} API", Version = "v1" });
                c.SwaggerDoc("v2", new OpenApiInfo { Title = $"{SERVICE_NAME} API", Version = "v2-preview" });
            });
            services.AddSwaggerGenNewtonsoftSupport();

            // Get the current settings.
            ThreadPool.GetMinThreads(out int minWorkerThreads, out int minIOCThreads);
            Log.Info($"Minimum thread was -> Workers={minWorkerThreads}, IOC={minIOCThreads}");
            ThreadPool.SetMinThreads(Configuration.min_worker_threads, Configuration.min_io_threads);
            Log.Info($"Minimum thread set to -> Workers={Configuration.min_worker_threads}, IOC={Configuration.min_io_threads}");

            services.AddHostedService<CatalogMonitorEventsWorkerV1>();
        }

        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            // THIS KICK STARTS THE DEPENDENCY INJECTION SO INSTANCE ARE READY FOR FIRST REQUEST
            // also otherwise context of first request will be forever logged by internal tasks
            app.ApplicationServices.GetService<IService>().InitializeAsync().Wait();

            app.UseResponseCompression();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swaggerDoc, httpRequest) =>
                {
                    if (httpRequest.Headers.ContainsKey("X-Forwarded-Path"))
                    {
                        var serverUrl = $"{httpRequest.Headers["X-Forwarded-Proto"]}://" +
                                        $"{httpRequest.Headers["X-Forwarded-Host"]}/" +
                                        $"{httpRequest.Headers["X-Forwarded-Path"]}";
                        swaggerDoc.Servers = new List<OpenApiServer>()
                        {
                            new OpenApiServer { Url = serverUrl }
                        };
                    }
                });
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/diagnostic/swagger.json", $"{SERVICE_NAME} DIAGNOSTIC");
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{SERVICE_NAME} API - V1");
                c.SwaggerEndpoint("/swagger/v2/swagger.json", $"{SERVICE_NAME} API - V2");
            });
            app.Use((context, next) =>
            {
                if (context.Request.Headers.ContainsKey(RequestContext.HTTP_HEADER_KEY_CLIENT_NAME)) { RequestContext.ClientName.Init(context.Request.Headers[RequestContext.HTTP_HEADER_KEY_CLIENT_NAME]); }
                if (context.Request.Headers.ContainsKey(RequestContext.HTTP_HEADER_KEY_CORRELATION_ID)) { RequestContext.CorrelationID.Init(context.Request.Headers[RequestContext.HTTP_HEADER_KEY_CORRELATION_ID]); }
                return next.Invoke();
            });
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
