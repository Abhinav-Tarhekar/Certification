﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.Common
{
    public interface IResourceLock
    {
        Task<Guid> TryTakeAsync(string ID, int timeUntilAutoRelease_ms, int tryTakeTimeout_ms, int takeRetryDelay_ms, CancellationToken cancellationToken = default(CancellationToken));
        Task<bool> RenewAsync(string ID, Guid lockToken, int timeUntilAutoRelease_ms);
        Task<bool> ReleaseAsync(string ID, Guid lockToken);
    }
}
