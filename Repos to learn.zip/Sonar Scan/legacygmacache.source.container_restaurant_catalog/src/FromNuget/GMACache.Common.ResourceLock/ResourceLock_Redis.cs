﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

using StackExchange.Redis;

using Common;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.Common.ResourceLock
{
    /* -- Exluded due to can't be mockable redis server ConnectionMultiplexer -- */
    [ExcludeFromCodeCoverage]
    public class ResourceLock_Redis : IResourceLock, IDisposable
    {
        private const int LOCKS_HARD_MINIMUM_AUTORELEASE_TIME_MS = 10;    // minimum sensible time for this implementation
        private const int LOCKS_HARD_MINIMUM_TAKE_RETRY_DELAY_MS = 10;    // minimum sensible time for this implementation
        private const int LOCKS_HARD_MINIMUM_TAKE_TIMEOUT_MS = 10;        // minimum sensible time for this implementation

        private readonly SemaphoreSlim _start_stop_dispose_lock;
        private volatile bool _running;

        private readonly ILog Log;

        private readonly string _redisConnectionString;
        private readonly int _databaseNumber;
        private readonly string _keyPrefix;

        private ConnectionMultiplexer _redisConnectionMultiplexer;

        private int _MinimumAutoReleaseTime_ms;
        private int _MinimumTakeTimeout_ms;
        private int _MinimumTakeRetryDelay_ms;

        public ResourceLock_Redis(ILog logger, string redisConnectionString, int redisDatabaseNumber, string keyPrefix)
        {
            _start_stop_dispose_lock = new SemaphoreSlim(1);
            _running = false;

            Log = logger;

            _redisConnectionString = redisConnectionString;
            _databaseNumber = redisDatabaseNumber;

            _keyPrefix = keyPrefix.Trim(':');

            _redisConnectionMultiplexer = null;

            _MinimumAutoReleaseTime_ms = LOCKS_HARD_MINIMUM_AUTORELEASE_TIME_MS;
            _MinimumTakeTimeout_ms = LOCKS_HARD_MINIMUM_TAKE_TIMEOUT_MS;
            _MinimumTakeRetryDelay_ms = LOCKS_HARD_MINIMUM_TAKE_RETRY_DELAY_MS;
        }
        
        public async Task StartAsync()
        {
            await _start_stop_dispose_lock.WaitAsync();
            try
            {
                if (_disposed) { throw new ObjectDisposedException($"{nameof(ResourceLock_Redis)} disposed."); }
                if (!_running)
                {
                    _redisConnectionMultiplexer = await ConnectionMultiplexer.ConnectAsync(_redisConnectionString, new VerboseLogTextWriter(Log));
                    _running = true;
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }
        public async Task StopAsync()
        {
            await _start_stop_dispose_lock.WaitAsync();
            try
            {
                if (_disposed) { throw new ObjectDisposedException($"{nameof(ResourceLock_Redis)} disposed."); }
                if (_running)
                {
                    _running = false;
                    if (_redisConnectionMultiplexer != null)
                    {
                        await _redisConnectionMultiplexer.CloseAsync();
                        _redisConnectionMultiplexer = null;
                    }
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetFullKeyFor(string ID) { return string.Join(":", _keyPrefix, ID); }
        async Task<Guid> IResourceLock.TryTakeAsync(string ID, int timeUntilAutoRelease_ms, int tryTakeTimeout_ms, int takeRetryDelay_ms, CancellationToken cancellationToken)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(ResourceLock_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(ResourceLock_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(ID)) { throw new ArgumentOutOfRangeException("String cannot be null or whitespace", nameof(ID)); }
            if (timeUntilAutoRelease_ms < _MinimumAutoReleaseTime_ms) { throw new ArgumentOutOfRangeException($"Minimum accepted value is {_MinimumAutoReleaseTime_ms}", nameof(timeUntilAutoRelease_ms)); }
            if (tryTakeTimeout_ms < _MinimumTakeTimeout_ms) { throw new ArgumentOutOfRangeException($"Minimum accepted value is {_MinimumTakeTimeout_ms}", nameof(tryTakeTimeout_ms)); }
            if (takeRetryDelay_ms < _MinimumTakeRetryDelay_ms) { throw new ArgumentOutOfRangeException($"Minimum accepted value is {_MinimumTakeRetryDelay_ms}", nameof(takeRetryDelay_ms)); }

            Guid lockToken = Guid.NewGuid();
            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            bool lockTaken = false;
            DateTime firstAttempt = DateTime.UtcNow;
            do
            {
                lockTaken = await db.LockTakeAsync(GetFullKeyFor(ID), lockToken.ToString("D"), TimeSpan.FromMilliseconds(timeUntilAutoRelease_ms));
                if (!lockTaken)
                {
                    var now = DateTime.UtcNow;
                    var nextAttempt = (now.AddMilliseconds(takeRetryDelay_ms));
                    if ((nextAttempt - firstAttempt).TotalMilliseconds > tryTakeTimeout_ms) { break; }
                    if (cancellationToken.IsCancellationRequested) { break; }
                    await Task.Delay(takeRetryDelay_ms, cancellationToken);
                }
            } while (!lockTaken);

            return lockTaken ? lockToken : Guid.Empty;
        }
        Task<bool> IResourceLock.RenewAsync(string ID, Guid lockToken, int timeUntilAutoRelease_ms)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(ResourceLock_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(ResourceLock_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(ID)) { throw new ArgumentOutOfRangeException("String cannot be null or whitespace", nameof(ID)); }
            if (timeUntilAutoRelease_ms < _MinimumAutoReleaseTime_ms) { throw new ArgumentOutOfRangeException($"Minimum accepted value is {_MinimumAutoReleaseTime_ms}", nameof(timeUntilAutoRelease_ms)); }

            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            return db.LockExtendAsync(GetFullKeyFor(ID), lockToken.ToString("D"), TimeSpan.FromMilliseconds(timeUntilAutoRelease_ms));
        }
        Task<bool> IResourceLock.ReleaseAsync(string ID, Guid lockToken)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(ResourceLock_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(ResourceLock_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(ID)) { throw new ArgumentOutOfRangeException("String cannot be null or whitespace", nameof(ID)); }

            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            return db.LockReleaseAsync(GetFullKeyFor(ID), lockToken.ToString("D"));
        }
        private class VerboseLogTextWriter : System.IO.TextWriter
        {
            ILog Log;
            public VerboseLogTextWriter(ILog logger) { Log = logger; }
            private void WriteToLog(string message) { Log.Verbose($"{nameof(ResourceLock_Redis)} : StackExchange.Redis : {message}"); }
            public override void Write(string message) { WriteToLog(message); }
            public override void WriteLine() { WriteToLog(string.Empty); }
            public override void WriteLine(string message) { WriteToLog(message); }
            public override System.Text.Encoding Encoding { get { return System.Text.Encoding.UTF8; } }
        }
        #region IDisposable Support
        private volatile bool _disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            _start_stop_dispose_lock.Wait();
            try
            {
                if (!_disposed)
                {
                    if (disposing)
                    {
                        _running = false;
                        if (_redisConnectionMultiplexer != null)
                        {
                            _redisConnectionMultiplexer.Close();
                            _redisConnectionMultiplexer = null;
                        }
                    }

                    _disposed = true;
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }
        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}