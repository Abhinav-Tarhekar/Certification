﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using StackExchange.Redis;
using Common;
using System.Diagnostics.CodeAnalysis;

namespace GMACache.Common.StringKeyHashStore
{
    /* -- Exluded due to can't be mockable redis server ConnectionMultiplexer -- */
    [ExcludeFromCodeCoverage]
    public class StringKeyHashStore_Redis : IStringKeyHashStore, IDisposable
    {
        private readonly SemaphoreSlim _start_stop_dispose_lock;
        private volatile bool _running;

        private readonly ILog Log;

        private readonly string _redisConnectionString;
        private readonly int _databaseNumber;
        private readonly string _keyPrefix;

        private ConnectionMultiplexer _redisConnectionMultiplexer;

        public StringKeyHashStore_Redis(ILog logger, string redisConnectionString, int redisDatabaseNumber, string keyPrefix)
        {
            _start_stop_dispose_lock = new SemaphoreSlim(1);
            _running = false;

            Log = logger;
            _redisConnectionString = redisConnectionString;
            _databaseNumber = redisDatabaseNumber;

            _keyPrefix = keyPrefix.Trim(':');

            _redisConnectionMultiplexer = null;
        }

        public async Task StartAsync()
        {
            await _start_stop_dispose_lock.WaitAsync();
            try
            {
                if (_disposed) { throw new ObjectDisposedException($"{nameof(StringKeyHashStore_Redis)} disposed."); }
                if (!_running)
                {
                    _redisConnectionMultiplexer = await ConnectionMultiplexer.ConnectAsync(_redisConnectionString, new VerboseLogTextWriter(Log));
                    _running = true;
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }
        public async Task StopAsync()
        {
            await _start_stop_dispose_lock.WaitAsync();
            try
            {
                if (_disposed) { throw new ObjectDisposedException($"{nameof(StringKeyHashStore_Redis)} disposed."); }
                if (_running)
                {
                    _running = false;
                    if (_redisConnectionMultiplexer != null)
                    {
                        await _redisConnectionMultiplexer.CloseAsync();
                        _redisConnectionMultiplexer = null;
                    }
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private string GetFullKeyFor(string key) { return string.Join(":", _keyPrefix, key); }

        async Task IStringKeyHashStore.SetAsync(string key, IDictionary<string, string> data, int timeToLiveInMilliseconds)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(StringKeyHashStore_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(StringKeyHashStore_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(key)) { throw new ArgumentOutOfRangeException(nameof(key), "String cannot be null or whitespace"); }
            if (data == null) { throw new ArgumentOutOfRangeException(nameof(data), "data cannot be null"); }
            if (data.Count <= 0) { throw new ArgumentOutOfRangeException(nameof(data), "data must have items"); }

            var fullKey = GetFullKeyFor(key);

            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            await db.KeyDeleteAsync(fullKey);
            await db.HashSetAsync(fullKey, data.Select(kv => new HashEntry(kv.Key, kv.Value)).ToArray());

            if (timeToLiveInMilliseconds != -1)
            {
                await db.KeyExpireAsync(fullKey, TimeSpan.FromMilliseconds(timeToLiveInMilliseconds));
            }
        }
        async Task<Dictionary<string, string>> IStringKeyHashStore.GetAsync(string key, ISet<string> itemKeys)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(StringKeyHashStore_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(StringKeyHashStore_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(key)) { throw new ArgumentOutOfRangeException(nameof(key), "String cannot be null or whitespace"); }

            var fullKey = GetFullKeyFor(key);

            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            if (itemKeys == null)
            {
                var result = (await db.HashGetAllAsync(fullKey)).ToDictionary(kv => (string)kv.Name, kv => (string)kv.Value);
                return result;
            }
            else
            {
                var keys = itemKeys.Select(i => (RedisValue)i).ToArray();
                var values = await db.HashGetAsync(fullKey, keys);
                if (values == null) { return null; }
                Dictionary<string, string> result = new Dictionary<string, string>();
                for (int i=0; i<keys.Length; i++)
                {
                    result.Add(keys[i], values[i]);
                }
                return result;
            }
        }
        Task IStringKeyHashStore.ClearAsync(string key)
        {
            if (_disposed) { throw new ObjectDisposedException($"{nameof(StringKeyHashStore_Redis)} disposed."); }
            if (!_running) { throw new Exception($"{nameof(StringKeyHashStore_Redis)} not started."); }
            if (string.IsNullOrWhiteSpace(key)) { throw new ArgumentOutOfRangeException(nameof(key), "String cannot be null or whitespace"); }
            IDatabase db = _redisConnectionMultiplexer.GetDatabase(_databaseNumber);
            return db.KeyDeleteAsync(GetFullKeyFor(key));
        }

        private class VerboseLogTextWriter : System.IO.TextWriter
        {
            ILog Log;
            public VerboseLogTextWriter(ILog logger) { Log = logger; }
            private void WriteToLog(string message) { Log.Verbose($"{nameof(StringKeyHashStore_Redis)} : StackExchange.Redis : {message}"); }
            public override void Write(string message) { WriteToLog(message); }
            public override void WriteLine() { WriteToLog(string.Empty); }
            public override void WriteLine(string message) { WriteToLog(message); }
            public override System.Text.Encoding Encoding { get { return System.Text.Encoding.UTF8; } }
        }

        #region IDisposable Support
        private volatile bool _disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            _start_stop_dispose_lock.Wait();
            try
            {
                if (!_disposed)
                {
                    if (disposing)
                    {
                        if (_redisConnectionMultiplexer != null)
                        {
                            _redisConnectionMultiplexer.Close();
                            _redisConnectionMultiplexer = null;
                        }
                        _running = false;
                    }
                    _disposed = true;
                }
            }
            finally
            {
                _start_stop_dispose_lock.Release();
            }
        }
        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}

