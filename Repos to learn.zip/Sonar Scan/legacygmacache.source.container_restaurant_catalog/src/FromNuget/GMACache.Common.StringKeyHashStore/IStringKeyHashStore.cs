﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace GMACache.Common
{
    public interface IStringKeyHashStore
    {
        Task SetAsync(string key, IDictionary<string, string> data, int timeToLiveInMilliseconds);
        Task<Dictionary<string,string>> GetAsync(string key, ISet<string> itemKeys = null);
        Task ClearAsync(string key);
    }
}
