﻿using System;
using System.Reflection;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Common;

namespace GMACache.RestaurantCatalog.Diagnostic
{
    [ApiController]
    [Produces("application/json")]
    [Route("diagnostic")]
    public class DiagnosticController : ControllerBase
    {
        private ILog Log;
        private ObjectResult LoggedFailureCode(int statusCode, Exception exception) { return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}"); }

        private IConfiguration _configuration;
        private IMarketSettingsProvider _marketSettingProvider;
        public DiagnosticController(ILog logger, IConfiguration configuration, IMarketSettingsProvider marketSettingProvider)
        {
            Log = logger;
            _configuration = configuration;
            _marketSettingProvider = marketSettingProvider;
        }

        // GET diagnostics/healthz
        [HttpGet("healthz")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public ActionResult<IConfiguration> GetHealth()
        {
            //TODO: STEFAN
            return StatusCode(StatusCodes.Status200OK, "OK");
            //return StatusCode(StatusCodes.Status503ServiceUnavailable, "A GOOD REASON WHY");
        }

        // GET diagnostics/version
        [HttpGet("version")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<string> GetVersions()
        {
            var version = $"{Assembly.GetEntryAssembly().GetName().Version} [{Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "UNKNOWN"}]";
            return StatusCode(StatusCodes.Status200OK, version);
        }

        // GET diagnostics/configuration
        [HttpGet("configuration")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IConfiguration> GetConfiguration()
        {
            try
            {
                return StatusCode(StatusCodes.Status200OK, _configuration);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // GET diagnostics/marketsettings
        [HttpGet("marketsettings")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IMarketSettingsSnapshot>> GetMarketSettingsAsync()
        {
            try
            {
                var marketSettings = (await _marketSettingProvider.GetMarketSettingsSnapshotAsync());
                return StatusCode(StatusCodes.Status200OK, marketSettings);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // GET diagnostics/insights
        [HttpGet("insights")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<string> GetInsights()
        {
            return StatusCode(StatusCodes.Status200OK, "SOME INSIGHT");
        }

        // GET diagnostics/stats
        [HttpGet("stats")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<string> GetStats()
        {
            return StatusCode(StatusCodes.Status200OK, "SOME DATA");
        }
    }
}