﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Common;

using GMACache.RestaurantCatalog.Models.V1;
using System.Diagnostics.CodeAnalysis;
using System.Threading;

namespace GMACache.RestaurantCatalog.V1
{
    //Excluded this controller because it was dicommision 
    [ExcludeFromCodeCoverage]
    [ApiController]
    [Route("api/v1/catalogs")]
    public class APIController : ControllerBase
    {
        private ILog Log;
        private ObjectResult LoggedFailureCode(int statusCode, Exception exception) { return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}"); }

        private IService _service;
        public APIController(ILog log, IService service)
        {
            Log = log;
            _service = service;
        }

        public class CatalogVersionRequest { public CatalogVersionViewV27 catalogVersion; }
        public class EcpResultWrapper { public object Data; public int ResultCode; }


        // GET api/v1/catalogs/legacy/marketcatalogs
        [Obsolete]
        [HttpGet("legacy/marketcatalogs")]
        [Produces("text/plain")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<string>> GetLegacyEncodedMarketCatalogsAsync(bool? decoded, [FromHeader(Name = "mcd-marketid")] string marketName = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (marketCatalogs, eTag, isInvalidated) = await _service.GetLegacyEncodedMarketCatalogsAsync(decoded ?? false, marketName);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag: $"\"{eTag}\"";
                    Response.Headers["Cache-Control"] = "public, no-cache, must-revalidate, no-transform";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (marketCatalogs != null)
                {
                    return StatusCode(StatusCodes.Status200OK, marketCatalogs);
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs .. check default store configuration");
            }
            catch (RestaurantNotFoundException)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs .. check default store configuration");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // HEAD api/v1/catalogs/legacy/marketcatalogs
        [Obsolete]
        [HttpHead("legacy/marketcatalogs")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult> HeadLegacyEncodedMarketCatalogsAsync(bool? decoded, [FromHeader(Name = "mcd-marketid")] string marketName = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (marketCatalogs, eTag, isInvalidated) = await _service.GetLegacyEncodedMarketCatalogsAsync(decoded ?? false, marketName);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag: $"\"{eTag}\"";
                        Response.Headers["Cache-Control"] = "public, no-cache, must-revalidate, no-transform";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs .. check default store configuration");
            }
            catch (RestaurantNotFoundException)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs .. check default store configuration");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // GET api/v1/catalogs/legacy/restaurantcatalogs/{restaurantID}
        [Obsolete]
        [HttpGet("legacy/restaurantcatalogs/{restaurantID}")]
        [Produces("text/plain")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<string>> GetLegacyEncodedRestaurantCatalogsAsync(long restaurantID, bool? decoded, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (restaurantCatalogs, eTag, isInvalidated) = await _service.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded ?? false);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag: $"\"{eTag}\"";
                    Response.Headers["Cache-Control"] = "public, no-cache, must-revalidate, no-transform";
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (restaurantCatalogs != null)
                {
                    return StatusCode(StatusCodes.Status200OK, restaurantCatalogs);
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs for {restaurantID}");
            }
            catch (RestaurantNotFoundException)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // HEAD api/v1/catalogs/legacy/restaurantcatalogs/{restaurantID}
        [Obsolete]
        [HttpHead("legacy/restaurantcatalogs/{restaurantID}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult> HeadLegacyEncodedRestaurantCatalogsAsync(long restaurantID, bool? decoded, CancellationToken cancellationToken = default)
        {
            try
            {
                var (restaurantCatalogs, eTag, isInvalidated) = await _service.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded ?? false,cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag: $"\"{eTag}\"";
                        Response.Headers["Cache-Control"] = "public, no-cache, must-revalidate, no-transform";
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs for {restaurantID}");
            }
            catch (RestaurantNotFoundException)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"No catalogs for {restaurantID}");
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }

        // POST api/v1/catalogs/legacy/updates
        [Obsolete]
        [HttpPost("legacy/updates")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<EcpResultWrapper>> GetLegacyEncodedCatalogUpdatesAsync([FromBody] CatalogVersionRequest catalogVersionRequest, [FromHeader(Name = "mcd-marketid")] string marketName = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var catalogUpdates = await _service.GetLegacyEncodedCatalogUpdatesAsync(catalogVersionRequest.catalogVersion, marketName,cancellationToken);
                if (catalogUpdates != null)
                {
                    return StatusCode(StatusCodes.Status200OK, new EcpResultWrapper { Data = catalogUpdates, ResultCode = 1 });
                }
                return StatusCode(StatusCodes.Status200OK, new EcpResultWrapper { Data = (string)null, ResultCode = -1303 /*RestaurantNotFound*/ });
            }
            catch (RestaurantNotFoundException)
            {
                return StatusCode(StatusCodes.Status200OK, new EcpResultWrapper { Data = (string)null, ResultCode = -1303 /*RestaurantNotFound*/ });
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
    }
}
