﻿using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using Common;

using GMACache.RestaurantCatalog.Models.V2;
using System.Threading;

namespace GMACache.RestaurantCatalog.V2
{
    [ApiController]
    [Route("api/v2")]
    public class APIController : ControllerBase
    {
        #region helper methods
        private ObjectResult LoggedFailureCode(int statusCode, Exception exception) { return StatusCode(statusCode, $"{exception.Message}\n{exception.StackTrace.ToString()}"); }
        private async Task<string> Decompress(byte[] dataToDecompress)
        {
            using (var compressedStream = new MemoryStream(dataToDecompress))
            using (var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress))
            using (var resultStream = new MemoryStream())
            {
                await zipStream.CopyToAsync(resultStream);
                return Encoding.UTF8.GetString(resultStream.ToArray());
            }
        }
        #endregion

        private readonly ILog Log;
        private readonly IService _service;
        private readonly string _CACHE_CONTROL_HEADERS_;
        private readonly string _CANNED_NOT_FOUND_RESPONSE_;

        public APIController(ILog log, IService service, IConfiguration configuration)
        {
            Log = log;
            _service = service;
            _CACHE_CONTROL_HEADERS_ = configuration.v2_api_cache_control_headers;
            var errorResponse = new
            {
                status = new
                {
                    code = 30000,
                    type = "BusinessException",
                    errors = new object[] { new {
                                code= 30002,
                                type= "DataNotFoundException",
                                message = "No Catalog Data Found for given request",
                                property = "restaurantId",
                                service = "GMACache.RestaurantCatalog.V2"
                            }
                        }
                }
            };
            _CANNED_NOT_FOUND_RESPONSE_ = JsonConvert.SerializeObject(errorResponse);
        }


        [JsonConverter(typeof(StringEnumConverter))]
        public enum FILTER { full, summary };

        // GET api/v2/categories
        [HttpGet("categories")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CategoriesFullResponseSchema))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<UpdateData>> GetCategoriesAsync(FILTER filter = FILTER.full, [FromHeader(Name = "mcd-marketid")] string marketName = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (gZippedSummaryContent, gZippedFullContent, eTag, isInvalidated) = await _service.GetCategoriesAsync(marketName,cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                    Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                var gZippedRespponseContent = gZippedFullContent;
                if (filter == FILTER.summary)
                {
                    gZippedRespponseContent = gZippedSummaryContent;
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
        // HEAD api/v2/categories
        [HttpHead("categories")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult> HeadCategoriesAsync([FromHeader(Name = "mcd-marketid")] string marketName = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (_, _, eTag, isInvalidated) = await _service.GetCategoriesAsync(marketName, cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                        Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }


        // GET api/v2/marketcatalogs
        [HttpGet("marketcatalogs")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketFullResponseSchema))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<UpdateData>> GetMarketCatalogsAsync(FILTER filter = FILTER.full, string fields = null, [FromHeader(Name = "mcd-marketid")] string marketName = null, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (gZippedSummaryContent, gZippedFullContent, eTag, isInvalidated) = await _service.GetMarketCatalogsAsync(marketName, cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                    Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                var gZippedRespponseContent = gZippedFullContent;
                if ((filter == FILTER.summary) || (!string.IsNullOrWhiteSpace(fields)))
                {
                    gZippedRespponseContent = gZippedSummaryContent;
                }
                if (gZippedRespponseContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedRespponseContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await Decompress(gZippedRespponseContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
        // HEAD api/v2/marketcatalogs
        [HttpHead("marketcatalogs")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult> HeadMarketCatalogsAsync([FromHeader(Name = "mcd-marketid")] string marketName = null, CancellationToken cancellationToken = default)
        {
            try
            {
                var (_, _, eTag, isInvalidated) = await _service.GetMarketCatalogsAsync(marketName, cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                        Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }


        // GET api/v2/restaurantcatalogs/{restaurantID}
        [HttpGet("restaurantcatalogs/{restaurantID}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateData))]
        [ProducesResponseType(StatusCodes.Status304NotModified)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult<UpdateData>> GetRestaurantCatalogsAsync(long restaurantID, [FromHeader(Name = "If-None-Match")] string IF_NONE_MATCH = null, CancellationToken cancellationToken = default)
        {
            try
            {
                if (IF_NONE_MATCH != null) { IF_NONE_MATCH = IF_NONE_MATCH.Trim('"'); }
                var (gZippedContent, eTag, isInvalidated) = await _service.GetRestaurantCatalogsAsync(restaurantID, cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                    Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                }
                if (eTag != null && IF_NONE_MATCH == eTag)
                {
                    return StatusCode(StatusCodes.Status304NotModified);
                }
                if (gZippedContent != null)
                {
                    var compression = Request.Headers["Accept-Encoding"].ToString();
                    if (compression.Contains("gzip", StringComparison.OrdinalIgnoreCase))
                    {
                        Response.Headers.Add("Content-Encoding", "gzip");
                        return File(gZippedContent, "application/json");
                    }
                    else
                    {
                        var jsonContent = await Decompress(gZippedContent);
                        return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = jsonContent, ContentType = "application/json" };
                    }
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
        // HEAD api/v2/restaurantcatalogs/{restaurantID}
        [HttpHead("restaurantcatalogs/{restaurantID}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(string))]
        public async Task<ActionResult> HeadRestaurantCatalogsAsync(long restaurantID, CancellationToken cancellationToken = default)
        {
            try
            {
                var (restaurantCatalogs, eTag, isInvalidated) = await _service.GetRestaurantCatalogsAsync(restaurantID, cancellationToken);
                if (isInvalidated) { Response.Headers["mcd-response-derived-from-invalidated-cache-data"] = "true"; }
                if (eTag != null)
                {
                    if (!string.IsNullOrWhiteSpace(eTag))
                    {
                        Response.Headers["ETag"] = eTag.StartsWith("\"") ? eTag : $"\"{eTag}\"";
                        Response.Headers["Cache-Control"] = _CACHE_CONTROL_HEADERS_;
                    }
                    return StatusCode(StatusCodes.Status200OK);
                }
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RestaurantNotFoundException)
            {
                return new ContentResult { StatusCode = StatusCodes.Status200OK, Content = _CANNED_NOT_FOUND_RESPONSE_, ContentType = "application/json" };
            }
            catch (RequestTimeoutException rtex)
            {
                return LoggedFailureCode(StatusCodes.Status504GatewayTimeout, rtex);
            }
            catch (CircuitBreakerOpenException cboex)
            {
                return LoggedFailureCode(StatusCodes.Status503ServiceUnavailable, cboex);
            }
            catch (Exception ex)
            {
                return LoggedFailureCode(StatusCodes.Status502BadGateway, ex);
            }
        }
    }
}