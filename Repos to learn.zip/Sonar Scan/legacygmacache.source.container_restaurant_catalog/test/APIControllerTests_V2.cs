﻿using Common;
using GMACache.RestaurantCatalog.Models.V2;
using GMACache.RestaurantCatalog.V2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static GMACache.RestaurantCatalog.UnitTest.APIControllerTests_V2;
using static GMACache.RestaurantCatalog.V2.APIController;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class APIControllerTests_V2
    {
        APIController apiController_V2;
      
        #region "Test Data"
        public async Task<Models.V2.MarketFullResponse> MarketCatalogJsonTestDataFull()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<Models.V2.MarketFullResponse>(await File.ReadAllTextAsync($"data/default/RestaurantState.json"));
            return restaurantStateJson;
        }
        #endregion "Test Data"
        [SetUp]
        public async Task Initialize()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            var full = marketCatalogJsonTestDataFull();
            var Summary = marketCatalogJsonTestDataSummary();
            var fullCategories= categoriesJsonTestDataFull();
            var summaryCategories=categoriesJsonTestDataSummary();
            var restaurantCatalog = restaurantCatalogJsonTestDataFull();           

            var fullResponseSchema = new MarketFullResponseSchema();
            fullResponseSchema.status = full.Result.status;
            fullResponseSchema.response = full.Result.response;

            var fullResponseSchemaJSON = JsonConvert.SerializeObject(fullResponseSchema);
            var fullResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(fullResponseSchemaJSON);
            byte[] fullResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(fullResponseSchemaJSONBytes, 0, fullResponseSchemaJSONBytes.Length);
                sw.Close();
                fullResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var summaryResponseSchema = new MarketSummaryResponseSchema();
            summaryResponseSchema.status = Summary.Result.status;
            summaryResponseSchema.response = Summary.Result.response;

            var summaryResponseSchemaJSON = JsonConvert.SerializeObject(summaryResponseSchema);
            var summaryResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(summaryResponseSchemaJSON);
            byte[] summaryResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(summaryResponseSchemaJSONBytes, 0, summaryResponseSchemaJSONBytes.Length);
                sw.Close();
                summaryResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var fullCategoryResponseSchema = new CategoriesFullResponseSchema();
            fullCategoryResponseSchema.status = fullCategories.Result.status;
            fullCategoryResponseSchema.response = fullCategories.Result.response;

            var fullCategorisResponseSchemaJSON = JsonConvert.SerializeObject(fullCategoryResponseSchema);
            var fullCategoryResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(fullCategorisResponseSchemaJSON);
            byte[] fullCategoryResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(fullCategoryResponseSchemaJSONBytes, 0, fullCategoryResponseSchemaJSONBytes.Length);
                sw.Close();
                fullCategoryResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var summaryCategoryResponseSchema = new CategoriesSummaryResponseSchema();
            summaryCategoryResponseSchema.status = summaryCategories.Result.status;
            summaryCategoryResponseSchema.response = summaryCategories.Result.response;

            var summaryCategorisResponseSchemaJSON = JsonConvert.SerializeObject(summaryCategoryResponseSchema);
            var summaryCategoryResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(summaryCategorisResponseSchemaJSON);
            byte[] summaryCategoryResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(summaryCategoryResponseSchemaJSONBytes, 0, summaryCategoryResponseSchemaJSONBytes.Length);
                sw.Close();
                summaryCategoryResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            var restaturantcatelogResponseSchema = new UpdateData();
            restaturantcatelogResponseSchema.Market = restaurantCatalog.Result.Market;
            restaturantcatelogResponseSchema.Store = restaurantCatalog.Result.Store;

            var restaturantcatelogResponseSchemaJSON = JsonConvert.SerializeObject(restaturantcatelogResponseSchema);
            var restaturantcatelogResponseSchemaJSONBytes = Encoding.UTF8.GetBytes(restaturantcatelogResponseSchemaJSON);
            byte[] restaturantcatelogResponseSchemaJSONBytesGZipped;
            using (var ms = new MemoryStream())
            using (var sw = new GZipStream(ms, CompressionMode.Compress))
            {
                sw.Write(restaturantcatelogResponseSchemaJSONBytes, 0, restaturantcatelogResponseSchemaJSONBytes.Length);
                sw.Close();
                restaturantcatelogResponseSchemaJSONBytesGZipped = ms.ToArray();
                ms.Close();
            }

            _service.Setup(x => x.GetRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()))
           .ReturnsAsync((restaturantcatelogResponseSchemaJSONBytesGZipped, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b", true));

            _service.Setup(x => x.GetMarketCatalogsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((summaryResponseSchemaJSONBytesGZipped, fullResponseSchemaJSONBytes, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b", true));

            _service.Setup(x => x.GetCategoriesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((summaryCategoryResponseSchemaJSONBytesGZipped, fullCategoryResponseSchemaJSONBytes, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b", true));
            apiController_V2 = new APIController
              (
               _logger.Object,
               _service.Object,
               _configuration.Object
              );

            var context = new ControllerContext() { HttpContext = new DefaultHttpContext() };
            apiController_V2.ControllerContext = context;

        }
        #region "Test Data"
        private async Task<MarketFullResponseSchema> marketCatalogJsonTestDataFull()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<MarketFullResponseSchema>(await File.ReadAllTextAsync($"./data/default/MarketCatelogResponseFull.json"));
            return restaurantStateJson;
        }

        private async Task<MarketSummaryResponseSchema> marketCatalogJsonTestDataSummary()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<MarketSummaryResponseSchema>(await File.ReadAllTextAsync($"./data/default/MarketCatelogResponseSummary.json"));
            return restaurantStateJson;
        }

        private async Task<CategoriesFullResponseSchema> categoriesJsonTestDataFull()
        {
            var CategoriesFullJson = JsonConvert.DeserializeObject<CategoriesFullResponseSchema>(await File.ReadAllTextAsync($"./data/default/CategoriesFullResponse.json"));
            return CategoriesFullJson;
        }

        private async Task<CategoriesSummaryResponseSchema> categoriesJsonTestDataSummary()
        {
            var CategoriesSummaryJson = JsonConvert.DeserializeObject<CategoriesSummaryResponseSchema>(await File.ReadAllTextAsync($"./data/default/CategoriesSummaryResponse.json"));
            return CategoriesSummaryJson;
        }
        private async Task<UpdateData> restaurantCatalogJsonTestDataFull()
        {
            var restaurantStateJson = JsonConvert.DeserializeObject<UpdateData>(await File.ReadAllTextAsync($"./data/default/RestaurantCatalogsTestData.json"));
            return restaurantStateJson;
        }
        #endregion "Test Data"

        #region Unit tests for GetCategoriesAsync
        [Test]
        [TestCase("")]
        public async Task GetCategoriesAsyncTest(string marketName)
        {
            var result = await apiController_V2.GetCategoriesAsync((APIController.FILTER)FILTER.summary, null,null, new CancellationToken());
            Assert.IsNotNull(result);
        }
        [Test]
        [TestCase("661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetCategoriesAsync(string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetCategoriesAsync((APIController.FILTER)FILTER.summary, null, IF_NONE_MATCH, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase("661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetCategoriesAsync__IfNoneMatchStatuscode(string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetCategoriesAsync((APIController.FILTER)FILTER.summary, null, IF_NONE_MATCH, new CancellationToken());
            var objResult = result.Result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 304);
        }
        #endregion
        #region Unit Tests for GetMarketCatalogsAsync       
        [Test]
        [TestCase("")]
        public async Task GetMarketCatalogsAsyncTest(string marketName)
        {
            var result = await apiController_V2.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary, null, null, null, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase("661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetMarketCatalogsAsync(string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary, null, null, IF_NONE_MATCH, new CancellationToken());
            Assert.IsNotNull(result);
        }


        [Test]
        [TestCase("661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetMarketCatalogsAsync__IfNoneMatchStatuscode(string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary, null, null, IF_NONE_MATCH, new CancellationToken());
            var objResult = result.Result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 304);
        }
        //[Test]       
        //public async Task GetMarketCatalogsAsync__ExpectedResult()
        //{
        //    var result = await apiController_V2.GetMarketCatalogsAsync((APIController.FILTER)FILTER.full, null, null, null);
        //    var objResult = result.Result as StatusCodeResult;
        //    Assert.AreEqual(objResult.StatusCode, 200);
        //}        

        #endregion
        #region Unit Tests for Head GetMarketCatalogsAsync
        [Test]
        [TestCase("")]
        public async Task HeadGetMarketCatalogsAsyncTest(string marketName)
        {
            var result = await apiController_V2.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase("")]
        public async Task HeadGetMarketCatalogsAsyncTestStatusCode(string marketName)
        {
            var result = await apiController_V2.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            var objResult = result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase("")]
        public async Task HeadMarketCatalogsNotFoundAsyncTest(string marketName)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            apiController_V2 = new APIController
              (
               _logger.Object,
               _service.Object,
               _configuration.Object
              );

            var result = await apiController_V2.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            Assert.IsNotNull(result);
        }

        //[Test]
        //[TestCase("")]
        //public async Task HeadMarketNotFoundStatusCodeCatalogsAsyncTest(string marketName)
        //{
        //    var _logger = new Mock<ILog>();
        //    var _service = new Mock<IService>();
        //    var _configuration = new Mock<IConfiguration>();

        //    apiController_V2 = new APIController
        //      (
        //       _logger.Object,
        //       _service.Object,
        //        _configuration.Object
        //      );

        //    var result = await apiController_V2.HeadMarketCatalogsAsync(marketName);
        //    var objResult = result as ObjectResult;
        //    Assert.AreEqual(objResult.StatusCode, 404);
        //}

        #endregion
        #region Unit tests for Head GetCategoriesAsync
        [Test]
        [TestCase("")]
        public async Task HeadCategoriesAsyncTest(string marketName)
        {
            var result = await apiController_V2.HeadCategoriesAsync(marketName, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase("")]
        public async Task HeadCategoriesAsyncTestStatusCode(string marketName)
        {
            var result = await apiController_V2.HeadCategoriesAsync(marketName, new CancellationToken());
            var objResult = result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase("")]
        public async Task HeadCategoriesNotFoundAsyncTest(string marketName)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            apiController_V2 = new APIController
              (
               _logger.Object,
               _service.Object,
               _configuration.Object
              );

            var result = await apiController_V2.HeadCategoriesAsync(marketName, new CancellationToken());
            Assert.IsNotNull(result);
        }
        #endregion

        #region Unit Tests for GetRCatalogsAsync       
        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_Test(long restaturantId)
        {
            var result = await apiController_V2.GetRestaurantCatalogsAsync(restaturantId, null, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455,"661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetRestaurantCatalogsAsync(long restaurantID, string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetRestaurantCatalogsAsync(restaurantID, IF_NONE_MATCH, new CancellationToken());
            Assert.IsNotNull(result);
        }


        [Test]
        [TestCase(2455,"661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetRestaurantCatalogsAsync_ifNoneMatchStatuscode(long restaurantID,string IF_NONE_MATCH)
        {
            var result = await apiController_V2.GetRestaurantCatalogsAsync(restaurantID, IF_NONE_MATCH, new CancellationToken());
            var objResult = result.Result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 304);
        }
        #endregion
        #region Unit Tests for Head GetRCatalogsAsync
        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogAsyncTest(long restaturantId)
        {
            var result = await apiController_V2.HeadRestaurantCatalogsAsync(restaturantId, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogAsyncTestStatusCode(long restaturantId)
        {
            var result = await apiController_V2.HeadRestaurantCatalogsAsync(restaturantId, new CancellationToken());
            var objResult = result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogNotFoundAsyncTest(long restaturantId)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            apiController_V2 = new APIController
              (
               _logger.Object,
               _service.Object,
               _configuration.Object
              );           
            var result = await apiController_V2.HeadRestaurantCatalogsAsync(restaturantId, new CancellationToken());
            Assert.IsNotNull(result);
        }
        #endregion

    }
}
