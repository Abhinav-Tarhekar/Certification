﻿using Common;
using GMACache.RestaurantCatalog.V1;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class APIControllerExceptionTests
    {
        APIController apiController;

        #region Initialize

        public async Task InitializeException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            _service.Setup(x => x.GetLegacyEncodedRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<CancellationToken>())).Throws(new Exception());
            _service.Setup(x => x.GetLegacyEncodedMarketCatalogsAsync(It.IsAny<bool>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new Exception());

            apiController = new APIController(_logger.Object, _service.Object);
        }

        public async Task InitializeRestaurantNotFoundException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            _service.Setup(x => x.GetLegacyEncodedRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<CancellationToken>())).Throws(new RestaurantNotFoundException("Error"));
            _service.Setup(x => x.GetLegacyEncodedMarketCatalogsAsync(It.IsAny<bool>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RestaurantNotFoundException("Error"));

            apiController = new APIController(_logger.Object, _service.Object);
        }

        public async Task InitializeRequestTimeoutException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            _service.Setup(x => x.GetLegacyEncodedRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<CancellationToken>())).Throws(new RequestTimeoutException("Error"));
            _service.Setup(x => x.GetLegacyEncodedMarketCatalogsAsync(It.IsAny<bool>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RequestTimeoutException("Error"));

            apiController = new APIController(_logger.Object, _service.Object);
        }

        public async Task InitializeCircuitBreakerOpenException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            _service.Setup(x => x.GetLegacyEncodedRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<CancellationToken>())).Throws(new CircuitBreakerOpenException("Error"));
            _service.Setup(x => x.GetLegacyEncodedMarketCatalogsAsync(It.IsAny<bool>(), It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new CircuitBreakerOpenException("Error"));

            apiController = new APIController(_logger.Object, _service.Object);
        }

        #endregion        

        #region Test cases for GetLegacyEncodedMarketCatalogsAsync

        [Test]
        [TestCase(true)]
        public async Task MarketCatalogsBadGatewayAsyncTest(bool decoded)
        {
            InitializeException();
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(true)]
        public async Task MarketCatalogsNotFoundAsyncTest(bool decoded)
        {
            InitializeRestaurantNotFoundException();
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 404);
        }

        [Test]
        [TestCase(true)]
        public async Task MarketCatalogsRequestTimeoutAsyncTest(bool decoded)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(true)]
        public async Task MarketCatalogsCircuitBreakerOpenAsyncTest(bool decoded)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        #endregion

        #region Unit Test Cases for GetLegacyEncodedRestaurantCatalogsAsync API

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantCatalogObjectBadGatewayAsyncTest(long restaurantID, bool decoded)
        {
            InitializeException();
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantCatalogNotFoundAsyncTest(long restaurantID, bool decoded)
        {
            InitializeRestaurantNotFoundException();
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 404);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantCatalogObjectRequestTimeoutAsyncTest(long restaurantID, bool decoded)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantCatalogObjecCircuitBreakerOpenAsyncTest(long restaurantID, bool decoded)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        #endregion

        #region Unit Test cases for HeadLegacyEncodedMarketCatalogsAsync

        [Test]
        [TestCase(true)]
        public async Task HeadLegacyEncodedMarketCatalogsAsyncTest(bool decoded)
        {
            InitializeException();
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadLegacyEncodedMarketCatalogsNotFoundAsyncTest(bool decoded)
        {
            InitializeRestaurantNotFoundException();
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 404);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadLegacyMarketCatalogsRequestTimeoutAsyncTest(bool decoded)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadMarketCatalogsCircuitBreakerOpenAsyncTest(bool decoded)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        #endregion

        #region Unit Test Cases for HeadLegacyEncodedRestaurantCatalogsAsync API

        [Test]
        [TestCase(2455, true)]
        public async Task HeadLegacyEncodedRestaurantCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            InitializeException();
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadLegacyEncodedRestaurantCatalogsNotFoundAsyncTest(long restaurantID, bool decoded)
        {
            InitializeRestaurantNotFoundException();
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 404);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadRestaurantCatalogObjectRequestTimeoutAsyncTest(long restaurantID, bool decoded)
        {
            InitializeRequestTimeoutException();
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadRestaurantCatalogObjecCircuitBreakerOpenAsyncTest(long restaurantID, bool decoded)
        {
            InitializeCircuitBreakerOpenException();
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }

        #endregion
    }
}
