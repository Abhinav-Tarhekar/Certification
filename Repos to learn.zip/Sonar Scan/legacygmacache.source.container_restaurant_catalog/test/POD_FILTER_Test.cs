﻿using Common;
using GMACache.RestaurantCatalog.MarketSettingsProvider;
using GMACache.RestaurantCatalog.Models.V2;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class POD_FILTER_Test
    {
        public async Task<GMACache.RestaurantCatalog.CatalogCaches.Restaurant.CatalogBuilder> IntitializeRestaurantBuilder(string dataSet)
        {
            GMACache.RestaurantCatalog.CatalogCaches.Restaurant.CatalogBuilder catalogBuilder;
            MarketSettingsProvider_File marketSettingsProvider_File;

            var _logger = new Mock<ILog>();
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
            var _restaurantBridgeService = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();

            catalogBuilder = new GMACache.RestaurantCatalog.CatalogCaches.Restaurant.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            #region Market Settings Provider Mocked Data

            marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object,
                $"./data/{dataSet}/marketsettings"
                );
                IMarketSettingsSnapshot settingsSnapshot = await marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();
                _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(settingsSnapshot);
            #endregion

            var restaurantDetailsData = JsonConvert.DeserializeObject<RestaurantDetails>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantDetails.json"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsAsync(It.IsAny<long>(), new CancellationToken {}))
                .ReturnsAsync((restaurantDetailsData));

            var restaurantMenuCategoryData = JsonConvert.DeserializeObject<List<RestaurantMenuCategory>>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantMenuCategory.json"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantMenuCategory>>(null, It.IsAny<long>(), null, new CancellationToken { }))
                .ReturnsAsync((restaurantMenuCategoryData, "49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb"));

            var restaurantSettingsData = JsonConvert.DeserializeObject<RestaurantSettings>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantSettings.json"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantSettingsData, "f6da83d6a183aaf8bf0e56193c98949859c64b9fbf391d80653f3aa7fe60546b"));

            var restaurantproductData = JsonConvert.DeserializeObject<List<RestaurantProduct>>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantProduct.json"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantproductData, "a4f8bc742511b0ba83a056fdebf2afa66db816b862ef50784cf1600ac3c47f74"));

            return catalogBuilder;
    }

        public static string UnZip(byte[] byteArray)
        {
            using (System.IO.MemoryStream output = new System.IO.MemoryStream())
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(byteArray))
                using (System.IO.Compression.GZipStream sr = new System.IO.Compression.GZipStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    sr.CopyTo(output);
                }
                string str = Encoding.UTF8.GetString(output.GetBuffer(), 0, (int)output.Length);
                return str;
            }
        }

        [Test]
        public async Task Test_POD_FILTER_is_not_activated_POD()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST-NO-TPO-FILTER-4588")).Build(959911);
            string catalogContent = UnZip(catalogContentResult.gZippedContent);
            var updateData = JsonConvert.DeserializeObject<UpdateData>(catalogContent);

            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 4588).POD.Where(pod => "PICKUP".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == false, "4588 : PICKUP");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 4588).POD.Where(pod => "DELIVERY".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == true, "4588 : DELIVERY");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 1401).POD.Where(pod => "PICKUP".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == true, "1401 : PICKUP");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 1401).POD.Where(pod => "DELIVERY".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == true, "1401 : DELIVERY");
        }

        [Test]
        public async Task Test_POD_FILTER_is_remiving_POD()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST")).Build(959911);
            string catalogContent = UnZip(catalogContentResult.gZippedContent);
            var updateData = JsonConvert.DeserializeObject<UpdateData>(catalogContent);

            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 4588).POD.Where(pod => "PICKUP".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == false, "4588 : PICKUP");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 4588).POD.Where(pod => "DELIVERY".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == false, "4588 : DELIVERY");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 1401).POD.Where(pod => "PICKUP".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == true, "1401 : PICKUP");
            Assert.That(updateData.Store[0].Products.First(p => p.ProductCode == 1401).POD.Where(pod => "DELIVERY".Equals(pod.TypeName, StringComparison.OrdinalIgnoreCase)).Any() == true, "1401 : DELIVERY");
        }
    }
}
