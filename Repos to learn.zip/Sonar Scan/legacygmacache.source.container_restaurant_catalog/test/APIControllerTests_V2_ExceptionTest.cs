﻿using Common;
using GMACache.RestaurantCatalog.V2;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static GMACache.RestaurantCatalog.UnitTest.APIControllerTests_V2;
using static GMACache.RestaurantCatalog.V2.APIController;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class APIControllerTests_V2_ExceptionTest
    {
        APIController apiController;

        #region Initialize
        public async Task InitializeException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            _service.Setup(x => x.GetMarketCatalogsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new Exception());
            _service.Setup(x => x.GetRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).Throws(new Exception());
            _service.Setup(x => x.GetCategoriesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new Exception());

            apiController = new APIController(_logger.Object, _service.Object,_configuration.Object);
        }
        public async Task InitializeRequestTimeoutException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            _service.Setup(x => x.GetMarketCatalogsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RequestTimeoutException("error"));
            _service.Setup(x => x.GetRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).Throws(new RequestTimeoutException("error"));
            _service.Setup(x => x.GetCategoriesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RequestTimeoutException("error"));

            apiController = new APIController(_logger.Object, _service.Object, _configuration.Object);
        }
        public async Task InitializeCircuitBreakerOpenException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            _service.Setup(x => x.GetMarketCatalogsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new CircuitBreakerOpenException("error"));
            _service.Setup(x => x.GetRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).Throws(new CircuitBreakerOpenException("error"));
            _service.Setup(x => x.GetCategoriesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new CircuitBreakerOpenException("error"));

            apiController = new APIController(_logger.Object, _service.Object, _configuration.Object);
        }
        public async Task InitializeRestaurantNotFoundException()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();
            var _configuration = new Mock<IConfiguration>();

            _service.Setup(x => x.GetMarketCatalogsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RestaurantNotFoundException("error"));
            _service.Setup(x => x.GetRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).Throws(new RestaurantNotFoundException("error"));
            _service.Setup(x => x.GetCategoriesAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).Throws(new RestaurantNotFoundException("error"));

            apiController = new APIController(_logger.Object, _service.Object, _configuration.Object);
        }
        
        #endregion
        #region Test cases for GetMarketCatalogsAsync

       [Test]
        [TestCase("")]
        public async Task MarketCatalogsBadGatewayAsyncTest(string marketName)
        {
            await InitializeException();
            var result = await apiController.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary,null, marketName,null, new CancellationToken());
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase("")]
        public async Task MarketCatalogsNotFoundAsyncTest(string marketName)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary,null, marketName,null, new CancellationToken());
            var statusCode = result.Result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);

        }
        [Test]
        [TestCase("")]
        public async Task MarketCatalogsRequestTimeoutAsyncTest(string marketName)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase("")]
        public async Task MarketCatalogsCircuitBreakerOpenAsyncTest(string marketName)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetMarketCatalogsAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion

        #region Test cases for Head MarketCatalog
        [Test]
        [TestCase("")]
        public async Task HeadMarketCatalogsBadGatewayAsyncTest(string marketName)
        {
            await InitializeException();
            var result = await apiController.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase("")]
        public async Task HeadMarketCatalogsNotFoundAsyncTest(string marketName)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            var statusCode = result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);

        }
        [Test]
        [TestCase("")]
        public async Task HeadMarketCatalogsRequestTimeoutAsyncTest(string marketName)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase("")]
        public async Task HeadMarketCatalogsCircuitBreakerOpenAsyncTest(string marketName)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.HeadMarketCatalogsAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
        #region Test cases for Categories
        [Test]
        [TestCase("")]
        public async Task CategoriesBadGatewayAsyncTest(string marketName)
        {
            await InitializeException();
            var result = await apiController.GetCategoriesAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase("")]
        public async Task CategoriesgsNotFoundAsyncTest(string marketName)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.GetCategoriesAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);

        }
        [Test]
        [TestCase("")]
        public async Task CategoriesRequestTimeoutAsyncTest(string marketName)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetCategoriesAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase("")]
        public async Task CategoriesCircuitBreakerOpenAsyncTest(string marketName)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.GetCategoriesAsync((APIController.FILTER)FILTER.summary, marketName);
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
        #region Test cases for Head Categories

        [Test]
        [TestCase("")]
        public async Task HeadCategoriesBadGatewayAsyncTest(string marketName)
        {
            await InitializeException();
            var result = await apiController.HeadCategoriesAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase("")]
        public async Task HeadCategoriesNotFoundAsyncTest(string marketName)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.HeadCategoriesAsync(marketName, new CancellationToken());
            var statusCode = result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);

        }
        [Test]
        [TestCase("")]
        public async Task HeadCategoriesRequestTimeoutAsyncTest(string marketName)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.HeadCategoriesAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase("")]
        public async Task HeadCategoriesCircuitBreakerOpenAsyncTest(string marketName)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.HeadCategoriesAsync(marketName, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
        #region Test cases for GetRestaurantCatalogsAsync

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsyncTest(long restaurantID)
        {
            await InitializeException();
            var result = await apiController.GetRestaurantCatalogsAsync(restaurantID,null, new CancellationToken());
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantCatalogsNotFound_FechedFromCacheTest(long restaurantID)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.GetRestaurantCatalogsAsync(restaurantID, null, new CancellationToken());
            var statusCode = result.Result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);
        }
        [Test]
        [TestCase(2455)]
        public async Task RestaurantCatalogsTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.GetRestaurantCatalogsAsync(restaurantID, null, new CancellationToken());
            var statusCode = result.Result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455)]
        public async Task RestaurantCatalogsCircuitBreakerOpenAsyncTest(long restaurantID)
        { 
           await InitializeCircuitBreakerOpenException();
           var result = await apiController.GetRestaurantCatalogsAsync(restaurantID, null, new CancellationToken());
           var statusCode = result.Result as ObjectResult;
           Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
        #region Test cases for Head GetRestaurantCatalogsAsync
        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogsBadGatewayAsyncTest(long restaurantID)
        {
            await InitializeException();
            var result = await apiController.HeadRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 502);
        }
        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogsNotFoundAsyncTest(long restaurantID)
        {
            await InitializeRestaurantNotFoundException();
            var result = await apiController.HeadRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            var statusCode = result as ContentResult;
            Assert.AreEqual(statusCode.StatusCode, 200);

        }
        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogsRequestTimeoutAsyncTest(long restaurantID)
        {
            await InitializeRequestTimeoutException();
            var result = await apiController.HeadRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 504);
        }

        [Test]
        [TestCase(2455)]
        public async Task HeadRestaurantCatalogsCircuitBreakerOpenAsyncTest(long restaurantID)
        {
            await InitializeCircuitBreakerOpenException();
            var result = await apiController.HeadRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            var statusCode = result as ObjectResult;
            Assert.AreEqual(statusCode.StatusCode, 503);
        }
        #endregion
    }
}
