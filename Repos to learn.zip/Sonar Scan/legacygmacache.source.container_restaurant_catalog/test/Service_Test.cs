﻿using Common;
using GMACache.Common;
using GMACache.RestaurantCatalog.Models.V2;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using GMACache.RestaurantCatalog.MarketSettingsProvider.Models;
using System.Collections.ObjectModel;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System.Linq.Expressions;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class Service_Test
    {
        private Service _service;
        private ReadOnlyDictionary<string, MarketSettings> _marketSettingsLookup;
        private Mock<ILog> logger = new Mock<ILog>();
        private IConfiguration _configuration = new Mock<Configuration>().Object;

        private Mock<IMarketSettingsProvider> _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
        private Mock<IResourceLock> resourceLock = new Mock<IResourceLock>();
        private Mock<IStringKeyHashStore> stringKeyHashStore = new Mock<IStringKeyHashStore>();
        private Mock<IMarketSettingsSnapshot> marketSettingsSnapshot = new Mock<IMarketSettingsSnapshot>();
        private Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced> _restaurantBridgeService = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();
        public CatalogBuilderTests_V2 catalogBuilderTests_V2 = new CatalogBuilderTests_V2();

        [SetUp]
        public async Task TestInitialize()
        {
            var clientAdvanced = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();
            var eventMonitor = new Mock<RestaurantBridge.Gateway.Cloud.V1.IEventMonitor>();

            var fullCategories = categoriesJsonTestDataFull();
            var summaryCategories = categoriesJsonTestDataSummary();
            var clientAdvanced2 = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();
            var marketSettingsProvider2 = new Mock<IMarketSettingsProvider>();

            #region Release resource lock

            resourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
                    .ReturnsAsync(Guid.NewGuid());

            #endregion

            var marketSettingsLookup = new Dictionary<string, MarketSettings>();
            foreach (var file in Directory.EnumerateFiles("./data/default/marketsettings", "*.json"))
            {
                string json = await File.ReadAllTextAsync(file);
                marketSettingsLookup.Add(Path.GetFileNameWithoutExtension(file), JsonConvert.DeserializeObject<MarketSettings>(json));
            }
            var snapshotw = new ReadOnlyDictionary<string, MarketSettings>(marketSettingsLookup);
            _marketSettingsLookup = snapshotw;
            var MarketSettings = new MarketSettings();

            _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(marketSettingsSnapshot.Object);
            marketSettingsSnapshot.Setup(x => x.MarketSettingsLookup).Returns(_marketSettingsLookup);

            CatalogCaches.Restaurant.CatalogBuilder cloud_marketCatalogBuilder = new CatalogCaches.Restaurant.CatalogBuilder(
                logger.Object,
                _marketSettingsProvider.Object,
                _restaurantBridgeService.Object
                );

            CatalogCaches.Market.V1.CatalogBuilder V1_marketCatalogBuilder = new CatalogCaches.Market.V1.CatalogBuilder(
                logger.Object,
                _marketSettingsProvider.Object,
                _restaurantBridgeService.Object
                );
            CatalogCaches.Market.V2.CatalogBuilder V2_marketCatalogBuilder = new CatalogCaches.Market.V2.CatalogBuilder(
                logger.Object,
                _marketSettingsProvider.Object,
                _restaurantBridgeService.Object
                );

            Dictionary<string, string> dict = new Dictionary<string, string>();
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ReturnsAsync(dict);

            clientAdvanced.Setup(x => x.EventMonitor).Returns((RestaurantBridge.Gateway.Cloud.V1.IEventMonitor)(eventMonitor.Object));
            _service = new Service(logger.Object,
                _configuration,
                _marketSettingsProvider.Object,
                resourceLock.Object,
                stringKeyHashStore.Object,
                clientAdvanced.Object,
                V1_marketCatalogBuilder,
                V2_marketCatalogBuilder,
                cloud_marketCatalogBuilder);

            await _service.InitializeAsync();
        }
        public async Task TestInitializeForService_RestaurantCatalogandCatalogBuilder(string methodName)
        {
            #region Setup for Service_RestaurantCatalog and Catalog Builder
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantDetails");
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantSettings");
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantProducts");

            var restaurantDetailsData = JsonConvert.DeserializeObject<RestaurantDetails>
            (await File.ReadAllTextAsync($"./data/AU-MILK-POD_FILTER-TEST/RestaurantDetails.json"));

            var restaurantSettingsData = JsonConvert.DeserializeObject<RestaurantSettings>
            (await File.ReadAllTextAsync($"./data/AU-MILK-POD_FILTER-TEST/RestaurantSettings.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantSettingsData, "f6da83d6a183aaf8bf0e56193c98949859c64b9fbf391d80653f3aa7fe60546b"));

            if (methodName.Equals("BuildObjectNotNull"))
                restaurantDetailsData.marketID = "US";
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsAsync(It.IsAny<long>(), new CancellationToken { }))
                .ReturnsAsync(restaurantDetailsData);

            var restaurantproductData = JsonConvert.DeserializeObject<List<RestaurantProduct>>
            (await File.ReadAllTextAsync($"./data/AU-MILK-POD_FILTER-TEST/RestaurantProduct.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantproductData, "a4f8bc742511b0ba83a056fdebf2afa66db816b862ef50784cf1600ac3c47f74"));

            await (await catalogBuilderTests_V2.IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "IgnoreNullPriceFromRfmAndPos")).Build(959911);
            #endregion
        }

        #region "Test Data"
        private async Task<CategoriesFullResponseSchema> categoriesJsonTestDataFull()
        {
            var CategoriesFullJson = JsonConvert.DeserializeObject<CategoriesFullResponseSchema>(await File.ReadAllTextAsync($"./data/default/CategoriesFullResponse.json"));
            return CategoriesFullJson;
        }
        private async Task<CategoriesSummaryResponseSchema> categoriesJsonTestDataSummary()
        {
            var CategoriesSummaryJson = JsonConvert.DeserializeObject<CategoriesSummaryResponseSchema>(await File.ReadAllTextAsync($"./data/default/CategoriesSummaryResponse.json"));
            return CategoriesSummaryJson;
        }
        #endregion

        #region V2 API Testing
        [Test]
        [TestCase("US")]
        public async Task GetCategoriesAsyncTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            //var result = await _service.GetCategoriesAsync(marketName, new CancellationToken());
            //Assert.IsNotNull(result);
            try
            {
                var result = await _service.GetCategoriesAsync(marketName, new CancellationToken());
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }
        [Test]
        [TestCase("")]
        public async Task GetCategoriesAsync_MarketNameNullTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            //var result = await _service.GetCategoriesAsync(marketName, new CancellationToken());
            //Assert.IsNotNull(result);
            try
            {
                var result = await _service.GetCategoriesAsync(marketName, new CancellationToken());
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }
        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsyncTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            //var result = await _service.GetMarketCatalogsAsync(marketName);
            //Assert.IsNotNull(result);
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }
        [Test]
        [TestCase("")]
        public async Task GetMarketCatalogsAsync_MarketNameNullTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            //var result = await _service.GetMarketCatalogsAsync(marketName, new CancellationToken());
            //Assert.IsNotNull(result);
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName, new CancellationToken());
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task DummyPrivateMethodsTest(long restaurantID)
        {
            await TestInitializeForService_RestaurantCatalogandCatalogBuilder("BuildObjectNotNull");
            await _service.HelpTaskAsync(restaurantID, new CancellationToken());
            Assert.IsTrue(true);
        }

        [Test]
        public async Task CompressTest()
        {
            var result = await _service.Compress("test");
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task DummyPrivateMethodForBuildMethodNegativeTest(long restaurantID)
        {
            await TestInitializeForService_RestaurantCatalogandCatalogBuilder("BuildObjectNull");
            await _service.HelpTaskAsync(restaurantID, new CancellationToken());
            Assert.IsTrue(true);
        }

        [Test]
        [TestCase(2455)]
        public async Task DummyPrivateMethodForBuildMethodNegativeExceptionTest(long restaurantID)
        {
            resourceLock.Setup(x => x.TryTakeAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), default)).Returns(Task.FromResult(Guid.Empty));
            await TestInitializeForService_RestaurantCatalogandCatalogBuilder("BuildObjectNull");
            try
            {
                await _service.HelpTaskAsync(restaurantID, new CancellationToken());
            }
            catch
            {
                Assert.IsTrue(true);
            }
        }
        #endregion

        #region Exception
        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RestaurantNotFoundExceptionTest(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult<string>(null));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RestaurantNotFoundException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_NoExceptionTest(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RedisTimeOutException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisTimeoutException("Redis Timeout Exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RedisTimeoutException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RedisCommandException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisCommandException("Redis Command Exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RedisCommandException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RedisConnectionException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisConnectionException("Redis Connection Exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RedisConnectionException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RedisServerException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisServerException("Redis server Exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RedisServerException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RedisException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisException("Redis Exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RedisException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_RestaurantCatalogBuildException(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RestaurantCatalogBuildException("Redis catalog build exception"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (RestaurantCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase(2455)]
        public async Task GetRestaurantCatalogsAsync_GeneralExceptionTest(long restaurantID)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(restaurantID, new CancellationToken { })).Returns(Task.FromResult("string"));

            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new Exception("reading exception testing"));
            try
            {
                var result = await _service.GetRestaurantCatalogsAsync(restaurantID, new CancellationToken());
            }
            catch (Exception)
            {
                Assert.IsTrue(true);
            }
        }

        /// <summary>
        /// Market Catalog Exceptions
        /// </summary>
        /// <param name="marketName"></param>
        /// <returns></returns>


        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RestaurantNotFoundExceptionTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult<string>(null));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RestaurantNotFoundException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_MarketCatalogBuildExceptionTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RedisTimeoutException(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisTimeoutException("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RedisTimeoutException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RedisCommandException(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisCommandException("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RedisCommandException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RedisConnectionException(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisConnectionException("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RedisConnectionException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RedisServerException(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisServerException("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RedisServerException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_RedisException(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new RedisException("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (RedisException)
            {
                Assert.IsTrue(true);
            }
        }

        [Test]
        [TestCase("US")]
        public async Task GetMarketCatalogsAsync_GeneralExceptionTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            stringKeyHashStore.Setup(x => x.GetAsync(It.IsAny<string>(), It.IsAny<ISet<string>>())).ThrowsAsync(new Exception("reading exception testing"));
            try
            {
                var result = await _service.GetMarketCatalogsAsync(marketName);
            }
            catch (Exception)
            {
                Assert.IsTrue(true);
            }
        }

        #endregion

        #region V1 API Testing

        [Test]
        [TestCase("US")]
        public async Task GetLegacyEncodedMarketCatalogsDecodFalseAsyncTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            //var result = await _service.GetLegacyEncodedMarketCatalogsAsync(false, marketName, new CancellationToken());
            //Assert.IsNotNull(result);
            try
            {
                var result = await _service.GetLegacyEncodedMarketCatalogsAsync(false, marketName, new CancellationToken());
            }
            catch (MarketCatalogBuildException)
            {
                Assert.IsTrue(true);
            }
        }

        #endregion
    }
}
