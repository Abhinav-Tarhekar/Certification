﻿using Common;
using GMACache.RestaurantCatalog.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class APIControllerTests
    {
        APIController apiController;

        [SetUp]
        public async Task Setup()
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            var restCatalogJsonTestData = await File.ReadAllTextAsync($"./data/default/RestaurantCatalogsTestData.json");
            _service.Setup(x => x.GetLegacyEncodedRestaurantCatalogsAsync(It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((restCatalogJsonTestData, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b", true));

            var marketCatalogJsonTestData = await File.ReadAllTextAsync($"./data/default/MarketCatalogsTestData.json");
            _service.Setup(x => x.GetLegacyEncodedMarketCatalogsAsync(It.IsAny<bool>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((marketCatalogJsonTestData, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b", true));

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              ); 

            var context = new ControllerContext() { HttpContext = new DefaultHttpContext() };
            apiController.ControllerContext = context;
        }

        #region Unit Tests for GetLegacyEncodedMarketCatalogsAsync

        [Test]
        [TestCase(true)]
        public async Task GetLegacyEncodedMarketCatalogsAsyncTest(bool decoded)
        {
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(true)]
        public async Task GetLegacyEncodedMarketCatalogsAsyncTestStatusCode( bool decoded)
        {
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetLegacyEncodedMarketCatalogsAsyncTestIfNoneMatch( bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded, IF_NONE_MATCH);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task MarketCatalogsAsyncTest_IfNoneMatchStatuscode(bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded, null, IF_NONE_MATCH);
            var objResult = result.Result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 304);
        }

        [Test]
        [TestCase(true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa286")]
        public async Task MarketCatalogsAsyncTest_IfNoneMatchMisMatch(bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded, IF_NONE_MATCH);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(true)]
        public async Task MarketCatalogsNotFoundAsyncTest(bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(true)]
        public async Task MarketNotFoundStatusCodeCatalogsAsyncTest(bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.GetLegacyEncodedMarketCatalogsAsync(decoded);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 404);
        }

        #endregion

        #region Unit Tests for GetLegacyEncodedRestaurantCatalogsAsync

        [Test]
        [TestCase(2455, true)]
        public async Task GetLegacyEncodedRestaurantCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task GetLegacyEncodedRestaurantCatalogsAsyncTestStatusCode(long restaurantID, bool decoded)
        {
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task GetLegacyEncodedRestaurantCatalogsAsyncTestIfNoneMatch(long restaurantID, bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded, IF_NONE_MATCH);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa28652b")]
        public async Task RestaurantCatalogsAsyncTest_IfNoneMatchStatuscode(long restaurantID, bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded, IF_NONE_MATCH);
            var objResult = result.Result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 304);
        }

        [Test]
        [TestCase(2455, true, "661b92ecfb03efee4228f587811e1ed6faa98521bf321a98cf0b30b3aa286")]
        public async Task RestaurantCatalogsAsyncTest_IfNoneMatchMisMatch(long restaurantID, bool decoded, string IF_NONE_MATCH)
        {
            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded, IF_NONE_MATCH);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantNotFoundCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task RestaurantNotFoundStatusCodeCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.GetLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var objResult = result.Result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 404);
        }

        #endregion

        #region Unit Tests for HeadLegacyEncodedMarketCatalogsAsync

        [Test]
        [TestCase(true)]
        public async Task HeadLegacyEncodedMarketCatalogsAsyncTest(bool decoded)
        {
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadLegacyEncodedMarketCatalogsAsyncTestStatusCode(bool decoded)
        {
            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var objResult = result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadMarketCatalogsNotFoundAsyncTest(bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(true)]
        public async Task HeadMarketNotFoundStatusCodeCatalogsAsyncTest(bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.HeadLegacyEncodedMarketCatalogsAsync(decoded);
            var objResult = result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 404);
        }

        #endregion

        #region Unit Tests for HeadLegacyEncodedRestaurantCatalogsAsync

        [Test]
        [TestCase(2455, true)]
        public async Task HeadLegacyEncodedRestaurantCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadLegacyEncodedRestaurantCatalogsAsyncTestStatusCode(long restaurantID, bool decoded)
        {
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var objResult = result as StatusCodeResult;
            Assert.AreEqual(objResult.StatusCode, 200);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadLegacyEncodedRestaurantCatalogsAsyncTestIfNoneMatch(long restaurantID, bool decoded)
        {
            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadRestaurantNotFoundCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            Assert.IsNotNull(result);
        }

        [Test]
        [TestCase(2455, true)]
        public async Task HeadRestaurantNotFoundStatusCodeCatalogsAsyncTest(long restaurantID, bool decoded)
        {
            var _logger = new Mock<ILog>();
            var _service = new Mock<IService>();

            apiController = new APIController
              (
               _logger.Object,
               _service.Object
              );

            var result = await apiController.HeadLegacyEncodedRestaurantCatalogsAsync(restaurantID, decoded);
            var objResult = result as ObjectResult;
            Assert.AreEqual(objResult.StatusCode, 404);
        }

        #endregion
    }
}
