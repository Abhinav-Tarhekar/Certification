﻿using Common;
using GMACache.RestaurantCatalog.MarketSettingsProvider;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class CatalogBuilderTests_V1
    {
        private GMACache.RestaurantCatalog.CatalogCaches.Market.V1.CatalogBuilder _catalogBuilder;
        private MarketSettingsProvider_File _marketSettingsProvider_File;
        private Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced> _restaurantBridgeService = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();

        [SetUp]
        public async Task TestInitialize()
        {
            var _logger = new Mock<ILog>();
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();

            _catalogBuilder = new CatalogCaches.Market.V1.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            #region Market Settings Provider Mocked Data

            _marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object,
                "./data/default/marketsettings"
                );
            IMarketSettingsSnapshot settingsSnapshot = await _marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();
            _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(settingsSnapshot);
            #endregion


            #region Restaurant Menu Category Mock Data

            var restaurantMenuCategoryData = JsonConvert.DeserializeObject<List<RestaurantMenuCategory>>
            (await File.ReadAllTextAsync($"./data/default/RestaurantMenuCategory.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantMenuCategory>>(null, It.IsAny<long>(), null, new CancellationToken { })).ReturnsAsync((restaurantMenuCategoryData, "49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb"));

            #endregion

            #region Restaurant Products Mock Data

            var restaurantproductData = JsonConvert.DeserializeObject<List<RestaurantProduct>>
            (await File.ReadAllTextAsync($"./data/default/RestaurantProduct.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantproductData, "8cd3a17e4cdcf8edb2f620ba4b58c71e15b695f1a9fd96f3ab79d65ea7e5853c"));

            #endregion
        }
        public static string UnZip(string content)
        {
            byte[] byteArray = Convert.FromBase64String(content);
            using (System.IO.MemoryStream output = new System.IO.MemoryStream())
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(byteArray))
                using (System.IO.Compression.GZipStream sr = new System.IO.Compression.GZipStream(ms, System.IO.Compression.CompressionMode.Decompress))
                {
                    sr.CopyTo(output);
                }

                string str = Encoding.UTF8.GetString(output.GetBuffer(), 0, (int)output.Length);
                return str;
            }
        }
        //Catalog V1 Tests
        [Test]
        public async Task CatalogBuilderV1NotNullTest()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            var jsonContentResult = UnZip(catalogContentResult.content);
            NUnit.Framework.Assert.IsNotNull(catalogContentResult);
        }        

        [Test]
        public async Task CatalogBuilderV1GetLongName()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            var jsonContentResult = UnZip(catalogContentResult.content);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(jsonContentResult);
            var LongName = SummaryContentDetails.Market.Names[0].Names[0].LongName.ToString();
            NUnit.Framework.Assert.AreEqual("Hamburger", LongName);
        }

        [Test]
        public async Task CatalogBuilderV1GetShortName()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            var jsonContentResult = UnZip(catalogContentResult.content);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(jsonContentResult);
            var ShortName = SummaryContentDetails.Market.Names[0].Names[0].ShortName.ToString();
            NUnit.Framework.Assert.AreEqual("Hamb", ShortName);
        }

        [Test]
        [TestCase("US")]
        public async Task CatalogBuilderEtagNotNullTest(string marketName)
        {
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(2455, null, new CancellationToken { })).Returns(Task.FromResult("string"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(2455, new CancellationToken { })).Returns(Task.FromResult("string"));
            var expectedETagAsync = await _catalogBuilder.GetExpectedETagAsync(marketName);
            NUnit.Framework.Assert.IsNotNull(expectedETagAsync);
        }

        [Test]
        [TestCase("US")]
        [ExpectedException(typeof(RestaurantNotFoundException), "Default Store Not Found: 2455 : null : null")]
        public async Task CatalogBuilderEtagThrowsExceptionTest(string marketName)
        {
            var expectedETagAsync = await _catalogBuilder.GetExpectedETagAsync(marketName);
            NUnit.Framework.Assert.IsTrue(true);
        }

        [Test]
        public async Task CatalogBuilderMarketSettingsTranslationsNullAsyncTest()
        {
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
            var _logger = new Mock<ILog>();

            _catalogBuilder = new CatalogCaches.Market.V1.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            #region Market Settings Provider Mock Data
            _marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object, "./marketsettings");

            IMarketSettingsSnapshot settingsSnapshot = await _marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();
            settingsSnapshot.MarketSettingsLookup["US"].Translations = null;
            _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(settingsSnapshot);
            #endregion

            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            var jsonContentResult = UnZip(catalogContentResult.content);
            NUnit.Framework.Assert.IsNotNull(catalogContentResult);
        }

        [Test]
        public async Task CatalogBuilderMarketSettingsNullAsyncTest()
        {
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
            var _logger = new Mock<ILog>();

            _catalogBuilder = new CatalogCaches.Market.V1.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            _marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object, "./marketsettingsTest");

            _marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();
            
            NUnit.Framework.Assert.IsTrue(true);
        }
    }
}
