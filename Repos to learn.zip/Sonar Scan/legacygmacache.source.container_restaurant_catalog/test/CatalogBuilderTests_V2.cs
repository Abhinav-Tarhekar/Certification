﻿using Common;
using GMACache.RestaurantCatalog.MarketSettingsProvider;
using GMACache.RestaurantCatalog.Models.V2;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestaurantBridge.Gateway.Cloud.V1.Models;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GMACache.RestaurantCatalog.UnitTest
{
    [TestFixture]
    public class CatalogBuilderTests_V2
    {
        private GMACache.RestaurantCatalog.CatalogCaches.Market.V2.CatalogBuilder _catalogBuilder;
        private MarketSettingsProvider_File _marketSettingsProvider_File;

        [SetUp]
        public async Task TestInitialize()
        {
            var _logger = new Mock<ILog>();
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
            var _restaurantBridgeService = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();

            _catalogBuilder = new GMACache.RestaurantCatalog.CatalogCaches.Market.V2.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            #region Market Settings Provider Mocked Data

            _marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object,
                "./data/default/marketsettings"
                );
            IMarketSettingsSnapshot settingsSnapshot = await _marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();
            _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(settingsSnapshot);
            #endregion

            #region Restaurant Menu Category Mock Data

            var restaurantMenuCategoryData = JsonConvert.DeserializeObject<List<RestaurantMenuCategory>>
            (await File.ReadAllTextAsync($"./data/default/RestaurantMenuCategory.json"));

            var rest= await File.ReadAllTextAsync($"./data/default/RestaurantMenuCategory.json");
            var restProduct = await File.ReadAllTextAsync($"./data/default/RestaurantProduct.json");

            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantMenuCategory>>(null, It.IsAny<long>(), null, new CancellationToken { })).ReturnsAsync((restaurantMenuCategoryData, "49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategoriesETagAsync(It.IsAny<long>(),null, new CancellationToken { })).ReturnsAsync(rest);
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync(restProduct);
            #endregion

            #region Restaurant Products Mock Data

            var restaurantproductData = JsonConvert.DeserializeObject<List<RestaurantProduct>>
            (await File.ReadAllTextAsync($"./data/default/RestaurantProduct.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantproductData, "a0f20b9c0ad617cfe7e27db6c8940475ec5d17c9472f0b6c1c520ad32970f04e"));

            #endregion
        }
        public async Task<CatalogCaches.Restaurant.CatalogBuilder> IntitializeRestaurantBuilder(string dataSet, string functionName)
        {
            CatalogCaches.Restaurant.CatalogBuilder catalogBuilder;
            MarketSettingsProvider_File marketSettingsProvider_File;
            string negativeMarketSettPath = string.Empty;            

            var _logger = new Mock<ILog>();
            var _marketSettingsProvider = new Mock<IMarketSettingsProvider>();
            var _restaurantBridgeService = new Mock<RestaurantBridge.Gateway.Cloud.V1.IClientAdvanced>();

            catalogBuilder = new CatalogCaches.Restaurant.CatalogBuilder(
                            _logger.Object,
                            _marketSettingsProvider.Object,
                            _restaurantBridgeService.Object);

            #region Market Settings Provider Mocked Data

            switch (functionName)
            {
                case "IgnoreNullPriceFromRfmAndPos":
                    { negativeMarketSettPath = "NegativeMarketSettings"; }
                    break;
                case "GetMarketSettingsSnapshotAsync":
                    { negativeMarketSettPath = "default"; }
                    break;
            }

            marketSettingsProvider_File = new MarketSettingsProvider_File(
                _logger.Object,
                $"./data/{(!string.IsNullOrEmpty(negativeMarketSettPath) ? negativeMarketSettPath : dataSet)}/marketsettings"
                );           

            IMarketSettingsSnapshot settingsSnapshot = await marketSettingsProvider_File.GetMarketSettingsSnapshotAsync();            
            _marketSettingsProvider.Setup(x => x.GetMarketSettingsSnapshotAsync()).ReturnsAsync(settingsSnapshot);
            #endregion

            var restaurantDetailsData = JsonConvert.DeserializeObject<RestaurantDetails>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantDetails.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsAsync(It.IsAny<long>(), new CancellationToken { }))
                .Returns(functionName.Equals("RestaurantDetailsAsync") ? Task.FromResult<RestaurantDetails>(null) : Task.FromResult<RestaurantDetails>(restaurantDetailsData));

            var restaurantMenuCategoryData = JsonConvert.DeserializeObject<List<RestaurantMenuCategory>>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantMenuCategory.json"));
            _restaurantBridgeService.Setup(x => x.GetRestaurantMenuCategories_DESERIALIZE_AS_Async<List<RestaurantMenuCategory>>(null, It.IsAny<long>(), null, new CancellationToken { }))
                .ReturnsAsync((restaurantMenuCategoryData, "49f744762fa2338f9ff694291adf04eb99b051b91421ef82089fcf5bd9433fcb"));

            var restaurantSettingsData = JsonConvert.DeserializeObject<RestaurantSettings>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantSettings.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantSettingsData, "f6da83d6a183aaf8bf0e56193c98949859c64b9fbf391d80653f3aa7fe60546b"));

            if (functionName.Equals("GetRestaurantSettings_DESERIALIZE_AS_Async"))
            {
                restaurantSettingsData = null;
                _restaurantBridgeService.Setup(x => x.GetRestaurantSettings_DESERIALIZE_AS_Async<RestaurantSettings>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                 .ReturnsAsync((restaurantSettingsData, null));
            }

            var restaurantproductData = JsonConvert.DeserializeObject<List<RestaurantProduct>>
            (await File.ReadAllTextAsync($"./data/{dataSet}/RestaurantProduct.json"));

            _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
             .ReturnsAsync((restaurantproductData, "a4f8bc742511b0ba83a056fdebf2afa66db816b862ef50784cf1600ac3c47f74"));

            if (functionName.Equals("GetRestaurantProducts_DESERIALIZE_AS_Async"))
            {
                restaurantproductData = null;
                _restaurantBridgeService.Setup(x => x.GetRestaurantProducts_DESERIALIZE_AS_Async<List<RestaurantProduct>>(It.IsAny<string>(), It.IsAny<long>(), new CancellationToken { }))
                 .ReturnsAsync((restaurantproductData, null));
            }

            _restaurantBridgeService.Setup(x => x.GetRestaurantDetailsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantDetails");
            _restaurantBridgeService.Setup(x => x.GetRestaurantSettingsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantSettings");
            _restaurantBridgeService.Setup(x => x.GetRestaurantProductsETagAsync(It.IsAny<long>(), new CancellationToken { })).ReturnsAsync("RestaurantProducts");

            return catalogBuilder;
        }
        public static string UnZip(byte[] byteArray)
        {
            using (MemoryStream output = new MemoryStream())
            {
                using (MemoryStream ms = new MemoryStream(byteArray))
                using (GZipStream sr = new GZipStream(ms, CompressionMode.Decompress))
                {
                    sr.CopyTo(output);
                }
                string str = Encoding.UTF8.GetString(output.GetBuffer(), 0, (int)output.Length);
                return str;
            }
        }

        [Test]
        public async Task CatalogBuilderNotNullTest()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            var text = UnZip(catalogContentResult.gZippedSummaryContent);
            Assert.IsNotNull(text);
        }

        [Test]
        public async Task CatalogBuilderExistsLCASElongname()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            string SummaryContent = UnZip(catalogContentResult.gZippedSummaryContent);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(SummaryContent);
            var lowercase = SummaryContentDetails.response.menuTypes[0].names[0].longname.ToString();
            Assert.AreEqual("Amore", lowercase);
        }

        [Test]
        public async Task CatalogBuilderExistsCamelCaseLongName()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            string SummaryContent = UnZip(catalogContentResult.gZippedSummaryContent);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(SummaryContent);
            var camelCase = SummaryContentDetails.response.menuTypes[0].names[0].longName.ToString();
            Assert.AreEqual("Amore", camelCase);
        }

        [Test]
        public async Task CatalogBuilderExistsLCASEshortname()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            string SummaryContent = UnZip(catalogContentResult.gZippedSummaryContent);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(SummaryContent);
            var lowercase = SummaryContentDetails.response.menuTypes[0].names[0].shortname.ToString();
            Assert.AreEqual("Amore", lowercase);
        }

        [Test]
        public async Task CatalogBuilderExistsCamelCaseShortName()
        {
            var catalogContentResult = await _catalogBuilder.BuildAsync("US");
            string SummaryContent = UnZip(catalogContentResult.gZippedSummaryContent);
            var SummaryContentDetails = JsonConvert.DeserializeObject<dynamic>(SummaryContent);
            var camelCase = SummaryContentDetails.response.menuTypes[0].names[0].shortName.ToString();
            Assert.AreEqual("Amore", camelCase);
        }
        [Test]
        [TestCase("US")]
        public async Task CatalogBuilderEtagNotNullTest(string marketName)
        {
            var expectedETagAsync = await _catalogBuilder.GetExpectedETagAsync(marketName);            
            Assert.IsNotNull(expectedETagAsync);
        }

        [Test]
        public async Task RestaurantDetailsObjectNullAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "RestaurantDetailsAsync")).Build(959911);

            Assert.AreEqual(null, catalogContentResult.gZippedContent);
            Assert.AreEqual(null, catalogContentResult.eTag);
        }

        [Test]
        public async Task RestaurantSettingsObjectNullAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "GetRestaurantSettings_DESERIALIZE_AS_Async")).Build(959911);

            Assert.AreEqual(null, catalogContentResult.gZippedContent);
            Assert.AreEqual(null, catalogContentResult.eTag);
        }

        [Test]
        public async Task MarketSettingsSnapshotDifferentMarketObjectNullAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "GetMarketSettingsSnapshotAsync")).Build(959911);

            Assert.AreEqual(null, catalogContentResult.gZippedContent);
            Assert.AreEqual(null, catalogContentResult.eTag);
        }

        [Test]
        public async Task GetRestaurantProducts_DESERIALIZE_AS_AsyncObjectNullAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "GetRestaurantProducts_DESERIALIZE_AS_Async")).Build(959911);

            Assert.AreEqual(null, catalogContentResult.gZippedContent);
            Assert.AreEqual(null, catalogContentResult.eTag);
        }

        [Test]
        public async Task IgnoreNullPriceProductFromRFMAndPosAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "IgnoreNullPriceFromRfmAndPos")).Build(959911);
            string catalogContent = UnZip(catalogContentResult.gZippedContent);
            var updateData = JsonConvert.DeserializeObject<UpdateData>(catalogContent);

            Assert.NotNull(updateData.Store[0].ProductPrice);
        }

        [Test]
        public async Task GetExpectedETagAsyncTest()
        {
            var eTag = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "")).GetExpectedETag(959911);

            Assert.AreEqual(eTag, "fb630213195c5da16caeaf4deeb0e1bd31555ba9c46923e5f2e927ccf66bf2fd");
        }

        [Test]
        public async Task ProductLanguageandMarketSettingsChangeAsyncTest()
        {
            var catalogContentResult = await (await IntitializeRestaurantBuilder("AU-MILK-POD_FILTER-TEST", "")).Build(959911);
            string catalogContent = UnZip(catalogContentResult.gZippedContent);
            var updateData = JsonConvert.DeserializeObject<UpdateData>(catalogContent);

            Assert.AreEqual(updateData.Store[0].Products[0].Names.Names[0].LanguageID, "en-AU");
        }
    }
}
