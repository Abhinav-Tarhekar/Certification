# GMACache.RestaurantCatalog

This service generates and CACHES the GMA specific views of restaurant and market data using the bridge to source RFM data.

You can visit "http://URL/swagger" to explore or exercise this API...
