#!/bin/sh -l
# BUILD_DIR="/"
DOCKERFILE="Dockerfile.SonarScan"

GIT_REPO=$(git remote show origin | grep Fetch | perl -pi -e 's/.*\/[^\/]+\/((?:[^\/](?!git))+)(?:\.git)?$/\1/g')
GIT_BRANCH=$(git log -1 --pretty=%D HEAD | sed 's/.*origin\///g;s/, .*//g')
GIT_COMMIT_HASH=$(git rev-parse HEAD)

NUGET_SOURCE_PUBLIC=${NUGET_SOURCE_PUBLIC:-https://api.nuget.org/v3/index.json}
NUGET_SOURCE_INTERNAL=${NUGET_SOURCE_INTERNAL:-http://artifactory.sharedtools.vet-tools.digitalecp.mcd.com/artifactory/api/nuget/nuget-release-local}
NUGET_SOURCE_PRIVATE=${NUGET_SOURCE_PRIVATE:-http://artifactory.sharedtools.vet-tools.digitalecp.mcd.com/artifactory/api/nuget/nuget-restaurantbridge-private}


echo "SONAR SCAN EDEVOPS"
echo "-----------------------------------------------------------"
echo "EDVOPS_SONAR_HOST_URL : $EDVOPS_SONAR_HOST_URL"
echo "EDVOPS_SONAR_LOGIN    : $EDVOPS_SONAR_LOGIN"


echo "-----------------------------------------------------------"
echo "GIT_REPO : $GIT_REPO"
echo "GIT_BRANCH : $GIT_BRANCH"
echo "GIT_COMMIT_HASH : $GIT_COMMIT_HASH"
echo "-----------------------------------------------------------"
echo "NUGET_SOURCE_PUBLIC : $NUGET_SOURCE_PUBLIC"
echo "NUGET_SOURCE_INTERNAL : $NUGET_SOURCE_INTERNAL"
echo "NUGET_SOURCE_PRIVATE : $NUGET_SOURCE_PRIVATE"
echo "NUGET_SOURCE_MCFLOW : $NUGET_SOURCE_MCFLOW"
echo "NUGET_SOURCE_MCFLOW_COMMONLIB : $NUGET_SOURCE_MCFLOW_COMMONLIB"
echo "NUGET_SOURCE_PRIVATE_ORDERCORE : $NUGET_SOURCE_PRIVATE_ORDERCORE"
echo "-----------------------------------------------------------"

echo "EDevOps SonarQube Scan"
csprojFilename=$(find src -type f -name "*.csprojasq" | awk -F'/' '{print $NF}')

docker build -t "sonarscan-g$GIT_COMMIT_HASH" \
  -f "/$DOCKERFILE" --build-arg EDVOPS_SONAR_HOST_URL=$EDVOPS_SONAR_HOST_URL --build-arg EDVOPS_SONAR_LOGIN=$EDVOPS_SONAR_LOGIN --build-arg GIT_REPO=$GIT_REPO --build-arg GIT_BRANCH=$GIT_BRANCH --build-arg GIT_COMMIT_HASH=$GIT_COMMIT_HASH --build-arg NUGET_SOURCE_PUBLIC=$NUGET_SOURCE_PUBLIC --build-arg NUGET_SOURCE_INTERNAL=$NUGET_SOURCE_INTERNAL --build-arg NUGET_SOURCE_PRIVATE=$NUGET_SOURCE_PRIVATE --build-arg NUGET_SOURCE_MCFLOW=$NUGET_SOURCE_MCFLOW --build-arg NUGET_SOURCE_MCFLOW_COMMONLIB=$NUGET_SOURCE_MCFLOW_COMMONLIB --build-arg NUGET_SOURCE_PRIVATE_ORDERCORE=$NUGET_SOURCE_PRIVATE_ORDERCORE --build-arg NUGET_SOURCE_USERNAME=$NUGET_SOURCE_USERNAME --build-arg NUGET_SOURCE_PASSWORD=$NUGET_SOURCE_PASSWORD --build-arg CSPROJFILE_NAME=$csprojFilename . 2>&1

echo "REMOVING CONTAINER IMAGES .."
docker rmi --force $(docker images | grep "sonarscan-g$GIT_COMMIT_HASH" | head -n 1 | tr -s ' ' | cut -d ' ' -f 3)
