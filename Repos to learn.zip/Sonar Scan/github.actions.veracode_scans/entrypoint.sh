#!/bin/sh -l

# sudo apt update
# apt -y install sudo git
# apt -y install perl
ls
pwd
# cd /scan
BUILD_DIR="/"
DOCKERFILE="Dockerfile.Veracode"
GIT_REPO=$(git remote show origin | grep Fetch | perl -pi -e 's/.*\/[^\/]+\/((?:[^\/](?!git))+)(?:\.git)?$/\1/g')
GIT_BRANCH=$(git log -1 --pretty=%D HEAD | sed 's/.*origin\///g;s/, .*//g')
GIT_COMMIT_HASH=$(git rev-parse HEAD)
NUGET_SOURCE_PUBLIC=${NUGET_SOURCE_PUBLIC:-https://api.nuget.org/v3/index.json}
NUGET_SOURCE_INTERNAL=${NUGET_SOURCE_INTERNAL:-http://artifactory.sharedtools.vet-tools.digitalecp.mcd.com/artifactory/api/nuget/nuget-release-local}
NUGET_SOURCE_PRIVATE=${NUGET_SOURCE_PRIVATE:-http://artifactory.sharedtools.vet-tools.digitalecp.mcd.com/artifactory/api/nuget/nuget-restaurantbridge-private}
echo "-----------------------------------------------------------"
echo "VERA CODE SCANS"
echo "-----------------------------------------------------------"
echo "VERACODE_API_KEY_ID      : $VERACODE_API_KEY_ID"
echo "VERACODE_API_KEY_SECRET  : $VERACODE_API_KEY_SECRET"
echo "SRCCLR_API_TOKEN         : $SRCCLR_API_TOKEN"
echo "-----------------------------------------------------------"
echo "GIT_REPO : $GIT_REPO"
echo "GIT_BRANCH : $GIT_BRANCH"
echo "GIT_COMMIT_HASH : $GIT_COMMIT_HASH"
echo "-----------------------------------------------------------"
echo "NUGET_SOURCE_PUBLIC : $NUGET_SOURCE_PUBLIC"
echo "NUGET_SOURCE_INTERNAL : $NUGET_SOURCE_INTERNAL"
echo "NUGET_SOURCE_PRIVATE : $NUGET_SOURCE_PRIVATE"
echo "NUGET_SOURCE_PRIVATE_ORDERCORE : $NUGET_SOURCE_PRIVATE_ORDERCORE"
csprojFilename=$(find src -type f -name "*.csprojasq" | awk -F'/' '{print $NF}')
echo "-----------------------------------------------------------"
docker build --pull -t "veracode-$GIT_COMMIT_HASH" -f "/$DOCKERFILE" --build-arg VERACODE_API_KEY_ID=$VERACODE_API_KEY_ID --build-arg VERACODE_API_KEY_SECRET=$VERACODE_API_KEY_SECRET --build-arg SRCCLR_API_TOKEN=$SRCCLR_API_TOKEN --build-arg NUGET_SOURCE_PUBLIC=$NUGET_SOURCE_PUBLIC --build-arg NUGET_SOURCE_INTERNAL=$NUGET_SOURCE_INTERNAL --build-arg NUGET_SOURCE_PRIVATE=$NUGET_SOURCE_PRIVATE --build-arg NUGET_SOURCE_PRIVATE_ORDERCORE=$NUGET_SOURCE_PRIVATE_ORDERCORE --build-arg GIT_REPO=$GIT_REPO --build-arg NUGET_SOURCE_USERNAME=$NUGET_SOURCE_USERNAME --build-arg NUGET_SOURCE_PASSWORD=$NUGET_SOURCE_PASSWORD --build-arg NUGET_SOURCE_MCFLOW=$NUGET_SOURCE_MCFLOW --build-arg NUGET_SOURCE_MCFLOW_COMMONLIB=$NUGET_SOURCE_MCFLOW_COMMONLIB --build-arg CSPROJFILE_NAME=$csprojFilename . 2>&1
echo "REMOVING CONTAINER IMAGES .."
docker rmi --force $(docker images | grep "veracode-$GIT_COMMIT_HASH" | head -n 1 | tr -s ' ' | cut -d ' ' -f 3) 
