# Action: instrument_dotnet_container

This action takes a 12 factor .Net container and adds the MCD newrelic instrumentation

## Inputs

## `CONTAINER_DOCKER_IMAGE`
**Required** : The container image reference for the container to instruments
## `CONTAINER_MAIN_DLL`
**Required** : The container image's entrypoint DLL

## Example usage

```yaml
uses: mcverse-sandbox-org/github.actions.instrument_dotnet_container@v1
with:
  CONTAINER_DOCKER_IMAGE: ${{ steps.build.outputs.CONTAINER_DOCKER_IMAGE }}
  CONTAINER_MAIN_DLL: ${{ steps.build.outputs.CONTAINER_MAIN_DLL }}
```
